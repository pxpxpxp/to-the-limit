# Reset-fixed interim validation (2026-10-30)

This is experimental and not a full machine, firmware, or hardware validation.
The reset-fixed top RTL is identified in `source_sha256.txt`; previous interim
controller/DDR, PCE replay and CPU logs are in `../interim_validation/` and
apply to the byte-identical controller/PCE/DDR modules, not to a full mixed-
language production machine. The reset wrapper tests extract production
expressions/blocks and model PCE reset-sampling semantics.

Fresh checks on the reset-fixed tree:
* `python3 tests/run_reset_replay.py`: PASS reset during capture/validation,
  apply fault reset, reset at commit edge, and full modeled 32,768-address RAM/
  VRAM plus 256-address SAT clear sweeps. It also verifies interrupted overwrite
  CRC rejection. This is a behavioral model, not an actual MiSTer RAM test.
* `python3 tests/run_input_reset.py`: PASS extracted input reset/toggle priority.
* `python3 tests/run_commit_matrix.py` and `tests/test_commit_guard.py`: PASS all
  128 reset/config/availability gate combinations.
* `python3 tests/run_backup_snapshot.py`: PASS production backup logic with a
  behavioral asymmetric RAM; reset-pending held low in this focused test.
* `python3 tests/test_video_freeze.py`: PASS extracted video timing cadence.
* `tests/test_snapshot_map.py`, `tests/test_snapshot_file.py`, and
  `tests/test_eligibility.py`: PASS static/host-level checks.

Full Quartus synthesis, routing, timing, assembly and actual MiSTer SD/power-cycle
behavior remain required. The no-disc CD-side state and final output pipelines
are not fully serialized. Do not treat a partial test as a release signoff.
