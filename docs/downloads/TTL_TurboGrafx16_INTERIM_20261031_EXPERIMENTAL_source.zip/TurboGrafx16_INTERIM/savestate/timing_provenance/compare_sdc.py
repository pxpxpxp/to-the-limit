#!/usr/bin/env python3
"""Compare effective report_sdc tables, excluding only the five intended cuts.

Strips source Location to account for the temporary SDC filename. Any other
missing or extra row is flagged. Does not decide whether a path is safe.
"""
from collections import Counter
from pathlib import Path
import sys
if len(sys.argv) not in (3,4): raise SystemExit('usage: compare_sdc.py ORIGINAL_SDC_REPORT TIGHTENED_SDC_REPORT [EXPECTED_REMOVED=5]')
expected=int(sys.argv[3]) if len(sys.argv)==4 else 5
if expected not in (0,4,5): raise SystemExit('expected removals must be 0, 4 or 5')
def rows(p,drop_target=False):
 result=Counter(); header=None; removed=Counter()
 for line in Path(p).read_text(errors='replace').splitlines():
  if not line.lstrip().startswith(';'): continue
  cells=[c.strip() for c in line.split(';')[1:-1]]
  if not cells: continue
  if cells[0]=='SDC Command':header=cells;continue
  if not cells[0].startswith(('set_','create_','derive_')) or not header or len(header)!=len(cells):continue
  vals=tuple((h,v) for h,v in zip(header,cells) if h not in ('Location','Comments'))
  flat=' '.join(v for _,v in vals);cmd=cells[0]
  if drop_target and ((cmd=='set_false_path' and 'emu|use_sdr' in flat) or (cmd=='set_multicycle_path' and ('emu|ddram|*' in flat or 'emu|sdram|*' in flat))):
   removed[cmd]+=1;continue
  result[vals]+=1
 return result,removed
original,removed=rows(sys.argv[1],True);strict,_=rows(sys.argv[2])
missing=original-strict;extra=strict-original
print('original removed exception rows:',dict(removed),'matched rows:',sum((original&strict).values()))
for label,delta in [('missing in tightened',missing),('extra in tightened',extra)]:
 for row,count in delta.items():print(label,count,row)
wanted=Counter({'set_multicycle_path':4,'set_false_path':1}) if expected==5 else (Counter({'set_multicycle_path':4}) if expected==4 else Counter())
if removed != wanted or missing or extra:
 raise SystemExit('INCONCLUSIVE: inspect effective/ignored SDC reports manually')
print(f'PASS: effective SDC rows match except {expected} intended tightened exceptions')
