The JSON describes the *older* interim revision, not this reset-fixed source.
It found a snapshot-related −0.569 ns use_sdr/restore path hidden by a legacy
false path; that exception was removed in this candidate. The old RBF must not
be treated as timing-safe. HPS clock-model cut arcs and unconstrained board
SDRAM I/O also require explicit triage. Audit scripts are snapshots of the
analysis tools; rerun them on a copy of the exact completed new fit, with
`TG16_EXPECT_REMOVED=4` while the four inherited DDR/SDRAM multicycles remain.
Do not claim a pass without reviewing every relevant path and corner.
