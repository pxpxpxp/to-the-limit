#!/usr/bin/env python3
"""Produce a conservative, machine-readable TG16 timing-audit draft.

Never marks pass automatically: a reviewer must inspect exception/false-path,
SDC, unconstrained endpoint, and per-corner timing reports before deciding.
"""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, datetime
p=argparse.ArgumentParser();p.add_argument('project',type=Path);p.add_argument('audit_log',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
project=a.project.resolve(); text=a.audit_log.read_text(errors='replace')
def sha(path):
 if not path.is_file(): return None
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
pat=re.compile(r'AUDIT (original|tightened) corner=(\d+) (\w+) (setup|hold) (count_slack|cut_count_slack)=(\d+)\s+([-+]?\d+(?:\.\d+)?)')
rows=[dict(mode=m,corner=int(c),path=path,kind=kind,category=cat,count=int(n),slack_ns=float(sl) if int(n) else None) for m,c,path,kind,cat,n,sl in pat.findall(text)]
cs=re.findall(r'AUDIT CORNER (original|tightened) (\d+) ([^\s]+)',text)
corners={mode:sorted([dict(index=int(n),name=name) for m,n,name in cs if m==mode],key=lambda x:x['index']) for mode in ('original','tightened')}
keys=('use_to_snapshot','use_to_all','ddram_to_snapshot','ddram_to_all','sdram_to_snapshot','sdram_to_all','all_to_snapshot','snapshot_to_all')
focused=[r for r in rows if r['mode']=='tightened' and r['path'] in keys]
problems=[]
if 'AUDIT FINISHED' not in text:problems.append('audit did not finish')
if 'AUDIT CLOCK REPORTS MATCH' not in text:problems.append('original/tightened clock reports not confirmed equal')
if not corners['original'] or corners['original']!=corners['tightened']:problems.append('missing or mismatched operating conditions')
for c in corners['tightened']:
 for path in keys:
  for kind in ('setup','hold'):
   for category in ('count_slack','cut_count_slack'):
    found=[r for r in focused if (r['corner'],r['path'],r['kind'],r['category'])==(c['index'],path,kind,category)]
    if not found:problems.append(f"missing {path}/{kind}/{category} at {c['name']}")
    elif category=='count_slack' and not found[0]['count']:problems.append(f"zero matched paths (inconclusive): {path}/{kind} at {c['name']}")
    elif category=='count_slack' and found[0]['slack_ns']<0:problems.append(f"negative slack {found[0]['slack_ns']} ns: {path}/{kind} at {c['name']}")
    elif category=='cut_count_slack' and found[0]['count']:problems.append(f"remaining false/cut paths: {path}/{kind} at {c['name']}")
manifest=project/'savestate/build-inputs.json'; inputs=json.loads(manifest.read_text()) if manifest.exists() else {}
bad=[f for f,h in inputs.items() if sha(project/f)!=h]
if not inputs or bad:problems.append(f'build-input manifest missing or mismatched ({len(bad)} items)')
reports=Path(__file__).resolve().parent/'reports'
ucp={}
for mode in ('original','tightened'):
 q=reports/f'{mode}_unconstrained.txt'
 ucp[mode]={'exists':q.exists(),'snapshot_name_occurrences':len(re.findall(r'ninja_savestate|ninja_states|ss_bram|ss_sdram',q.read_text(errors='replace'),re.I)) if q.exists() else None}
 if not q.exists():problems.append(f'{mode} unconstrained report missing')
if any(v['snapshot_name_occurrences'] for v in ucp.values() if v['exists']):problems.append('snapshot-related names appear in unconstrained report; manual review required')
cp=Path(__file__).resolve().parent/'compare_sdc.py'
removed_match=re.search(r'AUDIT EXCEPTION_REMOVALS (0|4|5)',text)
expected_removed=int(removed_match.group(1)) if removed_match else 5
sdc_cmp=subprocess.run(['python3',str(cp),str(reports/'original_sdc.txt'),str(reports/'tightened_sdc.txt'),str(expected_removed)],capture_output=True,text=True) if (reports/'original_sdc.txt').exists() and (reports/'tightened_sdc.txt').exists() else None
if sdc_cmp is None or sdc_cmp.returncode:problems.append('effective SDC comparison incomplete or differs beyond intended exceptions')
paths=['TurboGrafx16.sv','TurboGrafx16.qsf','TurboGrafx16.sdc','sys/sys_top.sdc','savestate/build-inputs.json','output_files/TurboGrafx16.fit.summary','output_files/TurboGrafx16.sta.summary','output_files/TurboGrafx16.sof','output_files/TurboGrafx16.rbf','quartus_fit.log','quartus_sta.log','quartus_asm.log']
hashes={f:sha(project/f) for f in paths}
for f in ('output_files/TurboGrafx16.fit.summary','output_files/TurboGrafx16.sta.summary','output_files/TurboGrafx16.rbf'):
 if hashes[f] is None:problems.append(f'missing artifact {f}')
fit_files=[project/'db/TurboGrafx16.routing.rdb']+sorted((project/'db').glob('TurboGrafx16.tiscmp.*.ddb'))
fit_dbs={str(x.relative_to(project)):sha(x) for x in fit_files if x.is_file()}
if not fit_dbs:problems.append('no routing/timing database identity found; verify fitted database identity')
sta_summary=project/'output_files/TurboGrafx16.sta.summary'
sta_slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',sta_summary.read_text(errors='replace'),re.M)] if sta_summary.exists() else []
if not sta_slacks:problems.append('original multicorner STA summary has no parsed slacks')
elif min(sta_slacks)<0:problems.append(f'original multicorner STA minimum slack is negative: {min(sta_slacks)} ns')
stage_logs={}
for stage in ('fit','sta','asm'):
 q=project/f'quartus_{stage}.log'; ok=q.is_file() and 'was successful' in q.read_text(errors='replace')
 stage_logs[stage]=ok
 if not ok:problems.append(f'quartus_{stage} success not established')
result={'status':'inconclusive_pending_manual_review','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'project':str(project),'audit_log':str(a.audit_log.resolve()),'audit_log_sha256':sha(a.audit_log),
 'source_and_artifact_sha256':hashes,'fit_database_sha256':fit_dbs,'manifest_count':len(inputs),'manifest_mismatches':bad,
 'original_sta_slack_count':len(sta_slacks),'original_sta_min_slack_ns':min(sta_slacks) if sta_slacks else None,'stage_success_markers':stage_logs,
 'corner_sets':corners,'clock_reports_identical':'AUDIT CLOCK REPORTS MATCH' in text,'unconstrained_report_triage':ucp,
 'audit_expected_removed_exceptions':expected_removed,
 'effective_sdc_comparison':None if sdc_cmp is None else {'exit_code':sdc_cmp.returncode,'output':sdc_cmp.stdout+sdc_cmp.stderr},
 'focused_snapshot_timing_rows':focused,'issues_requiring_review':problems,
 'explicit_limitations':['No FPGA timing report proves logical snapshot completeness, SD persistence, or physical MiSTer behavior.',
 'Full CD/peripheral state remains outside the interim snapshot; this draft is not a release signoff.']}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(a.output)
