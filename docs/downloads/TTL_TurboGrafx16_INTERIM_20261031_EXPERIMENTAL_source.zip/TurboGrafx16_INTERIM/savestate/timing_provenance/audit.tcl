# Supplemental post-fit TG16 snapshot timing audit, Quartus 23.1 Standard.
# Run from a COPY of the fitted project: quartus_sta -t /absolute/path/audit.tcl
# No project SDC/QSF or fitted database changes are written. The second pass
# temporarily loads a stricter SDC file in this audit directory only.
# Reports are diagnostic, NOT a replacement for the original full STA.
load_package ::quartus::project
load_package ::quartus::sta
set smoke [expr {[info exists ::env(TG16_AUDIT_SMOKE)] && $::env(TG16_AUDIT_SMOKE) eq "1"}]
set outdir [file normalize [file join [file dirname [info script]] reports]]
file mkdir $outdir
set core_sdc [file normalize TurboGrafx16.sdc]
set sys_sdc [file normalize sys/sys_top.sdc]
if {![file exists $core_sdc] || ![file exists $sys_sdc]} {error "Run from the fitted TG16 project copy"}
set fh [open $core_sdc r]; set lines [split [read $fh] "\n"]; close $fh
set tightened {}; set removed 0
foreach line $lines {
    if {[regexp {^set_multicycle_path -from \{emu\|(ddram|sdram)\|\*\}} $line] ||
        [regexp {^set_false_path -from \{emu\|use_sdr\}} $line]} {incr removed; continue}
    lappend tightened $line
}
set expected_removed 5
if {[info exists ::env(TG16_EXPECT_REMOVED)]} {set expected_removed $::env(TG16_EXPECT_REMOVED)}
if {$expected_removed ni {0 4 5} || $removed != $expected_removed} {error "Expected $expected_removed target exception commands, removed $removed; inspect source SDC"}
puts "AUDIT EXCEPTION_REMOVALS $removed"
set strict_file [file join $outdir tightened_analysis_only.sdc]
set fh [open $strict_file w]; puts $fh [join $tightened "\n"]; close $fh
project_open TurboGrafx16 -revision TurboGrafx16
set project_sdcs {}
foreach_in_collection a [get_all_global_assignments -name SDC_FILE] {
    set f [file normalize [lindex $a 2]]
    puts "AUDIT PROJECT SDC $f"
    lappend project_sdcs $f
}
if {[lsort $project_sdcs] ne [lsort [list $core_sdc $sys_sdc]]} {
    error "Unexpected project SDC files; strict pass would omit or duplicate constraints"
}
proc collection_required {label pattern} {
    set c [get_registers -nowarn $pattern]
    set n [get_collection_size $c]
    puts "AUDIT COLLECTION $label = $n ($pattern)"
    if {!$n} {error "Required collection $label is empty; inspect post-fit hierarchy/names. No timing conclusion."}
    return $c
}
proc audit_pass {mode outdir} {
    set u [collection_required use_sdr {*|use_sdr*}]
    set d [collection_required ddram {*|ddram:ddram|*}]
    set s [collection_required sdram {*|sdram:sdram|*}]
    set n [collection_required snapshot {*|ninja_savestate:ninja_states|*}]
    set all [get_registers *]
    puts "AUDIT COLLECTION all_registers = [get_collection_size $all]"
    set fh [open [file join $outdir ${mode}_collections.txt] w]
    foreach {name col} [list use_sdr $u ddram $d sdram $s snapshot $n] {
        puts $fh "--- $name ---"
        foreach_in_collection obj $col {puts $fh [get_object_info -name $obj]}
    }
    close $fh
    report_clocks -file [file join $outdir ${mode}_clocks.txt]
    report_sdc -file [file join $outdir ${mode}_sdc.txt]
    report_sdc -ignored -file [file join $outdir ${mode}_sdc_ignored.txt]
    if {!$::smoke} {report_ucp -file [file join $outdir ${mode}_unconstrained.txt]}
    set corner 0
    foreach_in_collection oc [get_available_operating_conditions] {
        set_operating_conditions $oc
        update_timing_netlist
        puts "AUDIT CORNER $mode $corner $oc"
        foreach spec [list [list use_to_snapshot $u $n] [list use_to_all $u $all] \
                           [list ddram_to_snapshot $d $n] [list ddram_to_all $d $all] \
                           [list sdram_to_snapshot $s $n] [list sdram_to_all $s $all] \
                           [list all_to_snapshot $all $n] [list snapshot_to_all $n $all]] {
            lassign $spec label src dst
            if {$::smoke && $label ne "use_to_snapshot" && $label ne "ddram_to_snapshot"} {continue}
            foreach type {setup hold} {
                set file [file join $outdir ${mode}_${corner}_${label}_${type}.txt]
                set result [report_timing -$type -from $src -to $dst -npaths 100 -nworst 1 -detail path_only -file $file]
                puts "AUDIT $mode corner=$corner $label $type count_slack=$result"
                if {$mode eq "original"} {
                    report_exceptions -$type -from $src -to $dst -npaths 100 -detail path_summary -file [file join $outdir ${mode}_${corner}_${label}_${type}_exceptions.txt]
                }
                # Even the tightened analysis may retain unrelated false
                # paths/clock groups; report rather than silently overlook.
                set cut [report_timing -$type -false_path -from $src -to $dst -npaths 100 -nworst 1 -detail path_only -file [file join $outdir ${mode}_${corner}_${label}_${type}_falsepaths.txt]]
                puts "AUDIT $mode corner=$corner $label $type cut_count_slack=$cut"
            }
        }
        incr corner
        if {$::smoke} {break}
    }
    if {!$corner} {error "No operating conditions returned; timing audit incomplete"}
}
# Pass 1: exact project constraints. Exception and cut-path reports show what
# is hidden, but a zero count may also mean names/paths were optimized away.
if {$smoke} {create_timing_netlist -post_map} else {create_timing_netlist}
read_sdc
update_timing_netlist
audit_pass original $outdir
delete_timing_netlist
# Pass 2: remove the five broad exceptions ONLY IN MEMORY in a temporary SDC.
# This tightens legacy paths as well as snapshot paths; a violation needs
# endpoint investigation, not a claim that all legacy logic is unsafe.
if {$smoke} {create_timing_netlist -post_map} else {create_timing_netlist}
read_sdc $sys_sdc
read_sdc $strict_file
read_sdc -hdl
update_timing_netlist
audit_pass tightened $outdir
set fh [open [file join $outdir original_clocks.txt] r]; set original_clocks [read $fh]; close $fh
set fh [open [file join $outdir tightened_clocks.txt] r]; set tightened_clocks [read $fh]; close $fh
if {$original_clocks ne $tightened_clocks} {error "Clock report mismatch between original and tightened constraints"}
puts "AUDIT CLOCK REPORTS MATCH"
delete_timing_netlist
project_close
puts "AUDIT FINISHED: inspect every count, uncovered endpoint, exception and corner report"
