LIBRARY ieee;
USE ieee.std_logic_1164.all;

ENTITY CEGen IS
	PORT
	(
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LOAD : in std_logic := '0';

		CLK       : in  STD_LOGIC;
		RST_N     : in  STD_LOGIC;

		IN_CLK    : in  integer;
		OUT_CLK   : in  integer;

		CE        : buffer STD_LOGIC
	);
END CEGen;

ARCHITECTURE SYN OF CEGen IS
-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_CE : STD_LOGIC;

BEGIN
process(CLK) begin
if rising_edge(CLK) then
if SS_SAVE = '1' then
SS_SH_CE <= CE;
end if;
end if;
end process;

	process( RST_N, CLK )
	variable CLK_SUM : integer;
	variable SS_SH_VAR_CLK_SUM : integer;
begin
if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_CLK_SUM := CLK_SUM;
end if;

		if RST_N = '0' then
			CLK_SUM := 0;
			CE <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CLK_SUM := SS_SH_VAR_CLK_SUM;
CE <= SS_SH_CE;
elsif SS_FREEZE = '0' then

			CE <= '0';
			CLK_SUM := CLK_SUM + OUT_CLK;
			if CLK_SUM >= IN_CLK then
				CLK_SUM := CLK_SUM - IN_CLK;
				CE <= '1';
			end if;
		
end if;
end if;
	end process;
END SYN;
