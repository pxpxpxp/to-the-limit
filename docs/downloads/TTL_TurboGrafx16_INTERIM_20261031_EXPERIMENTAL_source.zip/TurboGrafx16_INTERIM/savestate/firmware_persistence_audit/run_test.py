#!/usr/bin/env python3
"""Run the extracted MiSTer Main code with mocks and synthetic state data."""
from pathlib import Path
import argparse, shutil, struct, subprocess, tempfile, zlib
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--inspector',type=Path,help='Optional path to interim savestate/snapshot_file.py')
a=p.parse_args()
if a.inspector: a.inspector=a.inspector.resolve()
N=43777+579
with tempfile.TemporaryDirectory(prefix='tg16-firmware-test-') as td:
 t=Path(td); (t/'fixtures').mkdir()
 for variant in range(5):
  words=[(i*251+17+variant*19)&65535 for i in range(N)]
  crc=zlib.crc32(struct.pack(f'<{N}H',*words))
  header=((N+4)*2 << 32 | 123+variant,0x54474c5353000001,0x60fef42d3266aca5,(2 << 32)|0x1234abcd,(N << 32)|crc)
  (t/'fixtures'/f'fixture{variant}.ss').write_bytes(struct.pack('<5Q',*header)+struct.pack(f'<{N}Q',*words))
 for name in ('host_process_ss_test.cpp','process_ss.inc','file_path.inc'): shutil.copy2(HERE/name,t/name)
 subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','host_process_ss_test.cpp','-o','host_test'],cwd=t,check=True)
 subprocess.run([str(t/'host_test')],cwd=t,check=True)
 data=(t/'firmware_slot1.ss').read_bytes()
 assert len(data)==354888
 control,magic,schema,identity,check=struct.unpack_from('<5Q',data)
 assert control>>32==(N+4)*2 and control&0xffffffff==0
 assert magic==0x54474c5353000001 and schema==0x60fef42d3266aca5
 assert identity==(2<<32)|0x1234abcd and check>>32==N
 words=struct.unpack_from(f'<{N}Q',data,40)
 assert zlib.crc32(b''.join(struct.pack('<H',w&0xffff) for w in words))==check&0xffffffff
 print('PASS: independent Python header/length/schema/CRC verification',flush=True)
 if a.inspector:
  subprocess.run(['python3',str(a.inspector),str(t/'firmware_slot1.ss')],check=True)
