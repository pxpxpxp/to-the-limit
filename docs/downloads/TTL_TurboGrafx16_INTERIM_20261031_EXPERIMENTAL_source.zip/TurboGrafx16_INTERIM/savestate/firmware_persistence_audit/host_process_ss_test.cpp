// Host harness for *unmodified extracted* MiSTer Main process_ss and
// FileGenerateSavestatePath at commit 08271656799ede50358de1248f6ee878dd7ce5c4.
// Files, shmem, timers and UI are mocks; this is NOT an HPS/hardware test.
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <algorithm>
using std::string; using Bytes=std::vector<uint8_t>;
static constexpr uint32_t slot_size=0x80000;
static uint32_t ss_base=0x3f000000, ss_size=slot_size;
static char CoreName2[]="TurboGrafx16";
static std::map<string,Bytes> files;
static Bytes mapped[4]; static int saves[4]={}, failures=0, info_count=0;
struct fileTYPE {Bytes *contents=nullptr; size_t size=0; char name[1024]{};};
static fileTYPE sd_image[16];
static int is_apple2(){return 0;} static int is_arcade(){return 0;}
static const char* user_io_get_core_name(){return "TurboGrafx16";}
static void create_path(const char*,const char*){}
#define SAVESTATE_DIR "savestates"
#include "file_path.inc"
static void* shmem_map(uint32_t addr,uint32_t len){ assert(len==slot_size);assert(addr>=ss_base); auto i=(addr-ss_base)/slot_size; assert(i<4 && addr==ss_base+i*slot_size);mapped[i].resize(len);return mapped[i].data(); }
static int FileExists(const char* name){return files.count(name)!=0;}
static int FileOpen(fileTYPE* f,const char* name){auto it=files.find(name);if(it==files.end())return 0;f->contents=&it->second;return 1;}
static int FileReadAdv(fileTYPE* f,void* dest,uint32_t len){auto n=std::min<size_t>(len,f->contents->size());memcpy(dest,f->contents->data(),n);return n;}
static void FileClose(fileTYPE*){}
static int FileSave(const char* name,void* src,int n){if(failures){failures--;return 0;}string path(name);size_t at=path.rfind('_');assert(at!=string::npos);int slot=path.at(at+1)-'1';assert(slot>=0&&slot<4);saves[slot]++;files[path]=Bytes((uint8_t*)src,(uint8_t*)src+n);return n;}
static bool CheckTimer(unsigned long){return true;}
static unsigned long GetTimer(unsigned long){return 1;}
static void MenuHide(){} static void Info(const char*,int){info_count++;}
#include "process_ss.inc"
static Bytes read_file(const string& name){std::ifstream f(name,std::ios::binary);assert(f);return Bytes(std::istreambuf_iterator<char>(f),{});}
static uint32_t get32(const Bytes& b,int off){uint32_t x;memcpy(&x,b.data()+off,4);return x;}
static void set32(Bytes& b,int off,uint32_t v){memcpy(b.data()+off,&v,4);}
static string path(int slot){char p[1024];FileGenerateSavestatePath("games/Ninja Spirit.pce",p,slot);return p;}
int main(){
 assert(path(1)=="savestates/TurboGrafx16/Ninja Spirit_1.ss");assert(path(4)=="savestates/TurboGrafx16/Ninja Spirit_4.ss");
 for(int i=0;i<4;i++)files[path(i+1)]=read_file("fixtures/fixture"+std::to_string(i)+".ss");
 assert(process_ss("games/Ninja Spirit.pce",1));
 for(int i=0;i<4;i++){auto fixture=read_file("fixtures/fixture"+std::to_string(i)+".ss");assert(get32(mapped[i],0)==0xffffffff);assert(!memcmp(mapped[i].data()+4,fixture.data()+4,fixture.size()-4));}
 // Change data first. The actual firmware must not publish before counter commit.
 Bytes next=read_file("fixtures/fixture4.ss");memcpy(mapped[0].data()+4,next.data()+4,next.size()-4);
 process_ss(nullptr,1);assert(saves[0]==0);set32(mapped[0],0,0);process_ss(nullptr,1);
 assert(saves[0]==1 && files[path(1)].size()==354888);auto written=files[path(1)];
 std::ofstream saved("firmware_slot1.ss",std::ios::binary);saved.write((char*)written.data(),written.size());saved.close();
 // Reload same ROM: persisted bytes copied and change detector reset.
 assert(process_ss("games/Ninja Spirit.pce",1));assert(get32(mapped[0],0)==0xffffffff);assert(!memcmp(mapped[0].data()+4,written.data()+4,written.size()-4));
 // Firmware marks the generation seen before FileSave: no automatic retry on failure.
 int before=saves[1];set32(mapped[1],0,0);failures=1;int before_info=info_count;process_ss(nullptr,1);assert(saves[1]==before && info_count==before_info+1);process_ss(nullptr,1);assert(saves[1]==before);set32(mapped[1],0,1);process_ss(nullptr,1);assert(saves[1]==before+1);
 // Independent slot 3 and 4 commit and output names.
 for(int i=2;i<4;i++){int n=saves[i];set32(mapped[i],0,0);process_ss(nullptr,1);assert(saves[i]==n+1 && files[path(i+1)].size()==354888);}
 // Legacy unsuffixed state is read for slot 1 only if _1.ss is absent.
 files.erase(path(1));files[path(0)]=read_file("fixtures/fixture2.ss");assert(process_ss("games/Ninja Spirit.pce",1));auto legacy=files[path(0)];assert(!memcmp(mapped[0].data()+4,legacy.data()+4,legacy.size()-4));
 puts("PASS: official process_ss + path source: 4 mapped slots, commit-last, cold reimport, naming/legacy, write-failure no automatic retry");
}
