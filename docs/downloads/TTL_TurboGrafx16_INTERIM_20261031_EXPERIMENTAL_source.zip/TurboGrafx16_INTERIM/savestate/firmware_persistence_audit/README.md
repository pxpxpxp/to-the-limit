# MiSTer firmware save-state protocol — host evidence

This test extracts **unmodified functions** from official MiSTer Main commit
`08271656799ede50358de1248f6ee878dd7ce5c4`:

* `process_ss.inc`: [`user_io.cpp`, lines 2014–2137](https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/user_io.cpp#L2014-L2137); Git blob `0717aa0cda4561771d4d6601227f91099fbb7c4f`.
* `file_path.inc`: [`file_io.cpp`, lines 1014–1038](https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/file_io.cpp#L1014-L1038); Git blob `b7fd1cc2a91f5ab8fc739bac40ef09236e1896e1`.
* The upstream project is GPL-3.0; its complete license is included as `LICENSE`.

`run_test.py` builds a small C++17 harness around those functions with **mocked**
HPS DDR mapping, files, timers, UI and I/O. The test uses a mocked core name
`TurboGrafx16` solely to exercise formatting; actual Main normally derives the
name from the core configuration (`TGFX16` here) unless an override applies.
It creates synthetic data only—no
ROM, game save or user data. It checks four 512 KiB mapped slots, expected file
names, generation publication after payload, cold remapping/reimport, legacy
slot-1 filename fallback, and the firmware behavior when FileSave fails. It
independently verifies 354,888-byte length, schema `60fef42d3266aca5`, header
and payload CRC. The FPGA controller is **not** in this host harness; its own
simulation tests are separate. This does not test actual HPS, SD card, power
loss, Ninja Spirit, physical MiSTer hardware, firmware write durability, or
another Main version. FileSave is mocked here, including simulated failure.

Run with Python 3 and a C++17 compiler (`g++`):

```sh
python3 run_test.py
# Optionally also validate the generated file through the interim inspector:
python3 run_test.py --inspector /path/to/TurboGrafx16_INTERIM/savestate/snapshot_file.py
```

`validation.log` records the fresh run against the indicated interim inspector.
`SHA256SUMS` protects the evidence files; verify with `sha256sum -c SHA256SUMS`.

Current Main shows “Saving the state” **before** the write result is known and
marks a generation seen before FileSave, so failure is not automatically retried
unless a subsequent save changes that counter. It polls once per second. Exact
firmware version and storage behavior on the user's device are unknown. For
hardware testing, back up both `saves/` and `savestates/` and the existing RBF;
wait for storage activity and check the resulting file’s size, CRC and generation
with the inspector. Avoid saving the same slot again during a pending disk write;
keep backups and treat missing/error/no-op behavior as a failed test.

The firmware strips directory and final extension from the ROM name when naming
states. ROMs with the same basename in different directories or extensions can
therefore share state filenames. Use a uniquely named disposable ROM copy and
back up existing states before testing; ROM-identity rejection on load does not
prevent a new save from overwriting a colliding file.
