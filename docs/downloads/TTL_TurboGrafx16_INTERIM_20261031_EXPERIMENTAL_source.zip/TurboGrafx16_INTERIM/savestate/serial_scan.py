"""Replace random-access shadow multiplexers with local, word-wide scan chains.

Run automatically after serialize.py. The on-disk word map is unchanged. Each
module recirculates its chain on save and shifts imported words on load. Typed
shadow names become decoded wires, so transient enum encodings cannot damage
the stored bits while shifting.
"""
from pathlib import Path
import re,json
P=Path(__file__).resolve().parents[1]
ns={'__file__':str(P/'savestate/serialize.py')}
exec((P/'savestate/serialize.py').read_text().split('pkg=')[0],ns)
layout=json.loads((P/'savestate/serialized_layout.json').read_text())['fields']
manifest=json.loads((P/'savestate/register_manifest.json').read_text())
pkg=(P/'rtl/HUC6280/HUC6280_PKG.vhd').read_text()
for fn in manifest:
    f=P/'rtl'/fn;s=f.read_text();td=ns['types'](pkg+'\n'+s)
    rows=[x for x in layout if x['owner']==fn and 'kind' in x]
    base=min(x['address'] for x in rows);end=max(x['address'] for x in rows)
    width=(end-base+1)*16
    leaves={}
    for m in re.finditer(r'(?:signal|variable)\s+(SS_SH_\w+)\s*:\s*([^;]+);',s,re.I):
        for item in ns['flatten'](m[1],m[2],td):leaves[item[0]]=item
    proxies=dict((m[2],m[1]) for m in re.finditer(r'(SS_PROXY_\d+)\s*<=\s*(SS_SH_VAR_\w+)\s*;',s,re.I))
    def bits(row):
        lo=(row['address']-base)*16+row['bit_offset']
        return f'SS_CHAIN({lo+row["width"]-1} downto {lo})'
    def capture(row,variable=False):
        name,ty,total,kind,extra=leaves[row['field']]
        off=row['offset'];n=row['width']
        live=proxies[name] if variable else name.replace('SS_SH_','',1)
        if kind=='vector':val=f'std_logic_vector({live}({extra+off+n-1} downto {extra+off}))'
        elif kind=='bit':
            lo=(row['address']-base)*16+row['bit_offset'];return f'SS_CHAIN({lo}) <= {live};'
        elif kind=='int32':val=f'ss_integer_read({live},{off})'
        else:val=f'std_logic_vector(to_unsigned('+ (f"{ty}'pos({live})" if kind=='enum' else live)+f',{n}))'
        return f'{bits(row)} <= {val};'
    def decoded(name):
        pieces=sorted((x for x in rows if x['field']==name),key=lambda x:x['offset'],reverse=True)
        raw=' & '.join(bits(x) for x in pieces)
        _,ty,total,kind,extra=leaves[name]
        if kind=='bit':
            x=pieces[0];lo=(x['address']-base)*16+x['bit_offset'];return f'SS_CHAIN({lo})'
        if kind=='vector':return f'{ty}({raw})'
        if kind=='int32':return f'to_integer(signed({raw}))'
        val=f'to_integer(unsigned({raw}))'
        if kind=='enum':return f"{ty}'val({val})"
        return val
    # Remove the old capture/write process: SS_SH signals are now decoded wires.
    pat=r'process\(CLK\) begin\s*if rising_edge\(CLK\) then\s*if SS_SAVE = \'1\' then\s*SS_SH_.*?end process;'
    s,n=re.subn(pat,'',s,count=1,flags=re.S);assert n,fn
    # Process-local variable shadows remain small capture staging registers.
    # Restores consume chain bits directly, never the overwritten staging copy.
    def variable_process(m):
        z=m[0]
        if not re.search(r'variable\s+SS_SH_VAR_',z,re.I):return z
        z=re.sub(r"if SS_RWE = '1' then\s*case to_integer\(unsigned\(SS_RADDR\)\) is.*?end case;\s*end if;",'',z,flags=re.S)
        for name in proxies:
            if name in z:
                z=re.sub(r'(:=\s*)'+name+r'\s*;',lambda q:q[1]+decoded(name)+';',z)
        return z
    s=re.sub(r'\bprocess\s*\(.*?end\s+process\s*;',variable_process,s,flags=re.S|re.I)
    # Add the scan advance control throughout the hierarchy (RAMs ignore it).
    s=s.replace('SS_RADDR : in',"SS_RROTATE : in std_logic := '0';\n        SS_RADDR : in",1)
    s=s.replace('SS_RADDR => SS_RADDR,','SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR,')
    dec=f'''signal SS_CHAIN : std_logic_vector({width-1} downto 0);
signal SS_CAPTURE_DATA : std_logic_vector({width-1} downto 0);
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
'''
    s=s.replace('signal SS_LOCAL_RDO',dec+'signal SS_LOCAL_RDO',1)
    normal=[x for x in rows if not x['field'].startswith('SS_SH_VAR_')]
    variables=[x for x in rows if x['field'].startswith('SS_SH_VAR_')]
    selected=f'to_integer(unsigned(SS_RADDR)) >= {base} and to_integer(unsigned(SS_RADDR)) <= {end}'
    import_value='SS_RDI'+(f' & SS_CHAIN({width-1} downto 16)' if width>16 else '')
    rotate_value='SS_CHAIN(15 downto 0)'+(f' & SS_CHAIN({width-1} downto 16)' if width>16 else '')
    # Static, disjoint capture wires avoid a large sequence of partial
    # vector updates in the synthesis front end. All live state is frozen;
    # capture the entire vector after the variable staging proxies settle.
    body=''
    occupied=set()
    for row in rows:
        body+=capture(row,row['field'].startswith('SS_SH_VAR_')).replace('SS_CHAIN(','SS_CAPTURE_DATA(')+'\n'
        lo=(row['address']-base)*16+row['bit_offset']
        assert not occupied.intersection(range(lo,lo+row['width']))
        occupied.update(range(lo,lo+row['width']))
    pad_start=None
    for bit in range(width+1):
        if bit<width and bit not in occupied:
            if pad_start is None:pad_start=bit
        elif pad_start is not None:
            body+=f"SS_CAPTURE_DATA({bit-1} downto {pad_start}) <= (others => '0');\n"
            pad_start=None
    body+=f'''
process(CLK) begin
if rising_edge(CLK) then
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_RWE = '1' and ({selected}) then
SS_CHAIN <= {import_value};
elsif SS_RROTATE = '1' and ({selected}) then
SS_CHAIN <= {rotate_value};
end if;
end if;
end process;
'''
    # Vector slices and record fields are disjoint, single-driver decoded wires.
    for row in normal:
        name,ty,total,kind,extra=leaves[row['field']]
        if kind=='vector':
            off=row['offset'];n=row['width'];val=bits(row)
            if ty in ('unsigned','signed'):val=f'{ty}({val})'
            body+=f'{name}({extra+off+n-1} downto {extra+off}) <= {val};\n'
        elif kind=='bit':body+=f'{name} <= {decoded(name)};\n'
        elif row['offset']==0:
            expr=decoded(name)
            if kind=='enum':
                raw=' & '.join(bits(x) for x in sorted([x for x in rows if x['field']==name],key=lambda x:x['offset'],reverse=True))
                expr+=f" when to_integer(unsigned({raw})) <= {extra} else {ty}'val(0)"
            body+=f'{name} <= {expr};\n'
    pat=r'process\(all\) begin\s*SS_LOCAL_RDO <= .*?end process;'
    s,n=re.subn(pat,f"SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when {selected} else (others => '0');\n"+body,s,count=1,flags=re.S);assert n,fn
    f.write_text(s)
# dpram retains its small random-access read-latch map.
f=P/'rtl/dpram.vhd';s=f.read_text().replace('SS_RADDR : in',"SS_RROTATE : in std_logic := '0';\n        SS_RADDR : in",1);f.write_text(s)
print('Local recirculating scan chains generated; external word layout unchanged')
