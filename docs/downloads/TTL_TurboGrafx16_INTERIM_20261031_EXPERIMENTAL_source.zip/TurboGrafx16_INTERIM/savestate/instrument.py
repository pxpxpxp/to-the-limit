"""Instrument reviewed clocked VHDL state with one volatile shadow slot.

Source backups are retained so this transformation is reproducible. RAM contents
use the independent scan bus; RAM output latches are captured by dpram itself.
"""
from pathlib import Path
import re, json
P=Path(__file__).resolve().parents[1]
FILES=['pce_top.vhd','huc6260.vhd','huc6270.vhd','CEGen.vhd',
       *['HUC6280/'+x+'.vhd' for x in ['HUC6280','HUC6280_CPU','HUC6280_AG','HUC6280_ALU','HUC6280_MC','psg']]]
ports="""
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LOAD : in std_logic := '0';
"""
manifest={}
for fn in FILES:
    s=(P/'savestate/original-rtl'/fn).read_text()
    if fn=='huc6270.vhd':
        s=s.replace("(others=>'0'),'0',\"00\",'0','0',\"00\"", "(others=>'0'),'0',\"0000\",'0','0',\"00\"")
    # Expand concurrent clocked assignments into ordinary clocked processes.
    s=re.sub(r'(?m)^(\s*)(\w+)\s*<=\s*([^;]+?)\s+when\s+rising_edge\(\s*CLK\s*\)\s*;',
      lambda m:f'{m[1]}process(CLK) begin if rising_edge(CLK) then\n{m[2]} <= {m[3]};\nend if; end process;',s,flags=re.I)
    # Buffer ports permit reading registered outputs for capture in VHDL-93.
    ent_end=re.search(r'\bend\s+(?:entity\s+)?\w+\s*;',s,re.I).end()
    s=re.sub(r'\bout\b','buffer',s[:ent_end],flags=re.I)+s[ent_end:]
    s=re.sub(r'(\bport\s*\()',lambda m:m[1]+ports,s,count=1,flags=re.I)
    decl={}
    clean=re.sub(r'--[^\n]*','',s)
    for m in re.finditer(r'\bsignal\s+([\w,\s]+?)\s*:\s*([^;]+);',clean,re.I):
        ty=m[2].split(':=')[0].strip()
        for name in m[1].replace(' ','').replace('\n','').replace('\t','').split(','): decl[name.upper()]=ty
    for m in re.finditer(r'\b(\w+)\s*:\s*buffer\s+([^;\n]+)',clean,re.I):decl[m[1].upper()]=m[2].strip()
    for m in re.finditer(r'\balias\s+(\w+)\s*:\s*(.*?)\s+is\s+',clean,re.I):decl[m[1].upper()]=m[2].strip()
    used=set(); process_manifest=[]
    def instrument(m):
        z=m[0]; c=re.sub(r'--[^\n]*','',z)
        edge=re.search(r'rising_edge\s*\(\s*CLK\s*\)\s*then',z,re.I)
        if not edge:return z
        tail=z[edge.end():]
        # Last end-if closes the rising-edge arm (all reviewed processes).
        end=list(re.finditer(r'\bend\s+if\s*;',tail,re.I))[-1]
        body=tail[:end.start()]
        variables=[]
        for v in re.finditer(r'\bvariable\s+(\w+)\s*:\s*([^;]+);',z[:edge.start()],re.I):
            variables.append((v[1],v[2].split(':=')[0].strip()))
        lhs=re.findall(r'(?m)(?:^|;|\bthen\b|\belse\b|=>)\s*(\w+(?:\([^\n;]*?\))?(?:\.\w+(?:\([^\n;]*?\))?)?)\s*<=',re.sub(r'--[^\n]*','',body),re.I)
        roots=sorted(set(re.match(r'\w+',x)[0].upper() for x in lhs))
        restore=[]
        for root in roots:
            if root not in decl:raise ValueError((fn,root,'type not found'))
            used.add(root)
            if root=='CH':
                fields=sorted(set(re.search(r'\)\.(\w+)',x)[1].upper() for x in lhs if x.upper().startswith('CH(')))
                restore.append('for ss_i in 0 to 5 loop\n'+''.join(f'CH(ss_i).{f} <= SS_SH_CH(ss_i).{f};\n' for f in fields)+'end loop;')
            else:restore.append(f'{root} <= SS_SH_{root};')
        process_manifest.append(roots)
        result=z[:edge.end()]+'\nif SS_LOAD = \'1\' then\n'+''.join(f'{v} := SS_SH_VAR_{v};\n' for v,t in variables)+'\n'.join(restore)+"\nelsif SS_FREEZE = '0' then\n"+body+'\nend if;\n'+tail[end.start():]
        if variables:
            b=re.search(r'\bbegin\b',result,re.I)
            result=result[:b.start()]+''.join(f'variable SS_SH_VAR_{v} : {t};\n' for v,t in variables)+result[b.start():]
            b=re.search(r'\bbegin\b',result,re.I)
            result=result[:b.end()]+"\nif rising_edge(CLK) and SS_SAVE = '1' then\n"+''.join(f'SS_SH_VAR_{v} := {v};\n' for v,t in variables)+'end if;\n'+result[b.end():]
        return result
    s=re.sub(r'\bprocess\s*\(.*?end\s+process\s*;',instrument,s,flags=re.S|re.I)
    archbegin=re.search(r'\barchitecture\s+\w+\s+of\s+\w+\s+is\b',s,re.I).end()
    # Architecture declarations can include component port/end and functions;
    # first standalone begin in these reviewed files is architecture begin.
    b=re.search(r'(?m)^\s*begin\s*$',s[archbegin:],re.I).start()+archbegin
    shadows='\n-- Volatile register snapshot; independent of CPU reset.\n'+''.join(f'signal SS_SH_{n} : {decl[n]};\n' for n in sorted(used))
    s=s[:b]+shadows+s[b:]
    b=re.search(r'(?m)^\s*begin\s*$',s[archbegin:],re.I).end()+archbegin
    capture="\nprocess(CLK) begin\nif rising_edge(CLK) then\nif SS_SAVE = '1' then\n"+''.join(f'SS_SH_{n} <= {n};\n' for n in sorted(used))+"end if;\nend if;\nend process;\n"
    s=s[:b]+capture+s[b:]
    # Thread controls into every state-bearing child.
    s=re.sub(r'(entity\s+work\.(?:HUC6280(?:_CPU|_AG|_ALU|_MC)?|ALU|psg|huc6260|huc6270|CEGen)\b.*?port\s+map\s*\()',
      lambda m:m[1]+'\nSS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_LOAD => SS_LOAD,\n',s,flags=re.I|re.S)
    (P/'rtl'/fn).write_text(s)
    manifest[fn]={'signals':sorted(used),'processes':process_manifest}
(P/'savestate/register_manifest.json').write_text(json.dumps(manifest,indent=2))
print('Captured',sum(len(x['signals']) for x in manifest.values()),'signal roots')
