from pathlib import Path
import subprocess,tempfile,os
P=Path(__file__).resolve().parents[1];src=P/'tg16_interim_retry_1'
top=(src/'TurboGrafx16.sv').read_text();pce=(src/'rtl/pce_top.vhd').read_text();rtl=(src/'rtl/ninja_savestate.sv').read_text()
assert '.RESET(reset|cart_download|ss_fault_reset)' in top
assert '.SS_FREEZE(ss_freeze)' in top
assert "elsif SS_FREEZE = '0' then" in pce and 'RESET_N <= not RESET;' in pce
assert 'if(freeze && applying) fault_reset<=1;' in rtl
with tempfile.TemporaryDirectory(prefix='tg16-reset-audit-') as d:
 out=Path(d)/'test.vvp';subprocess.run(['iverilog','-g2012','-s','tb_interim_reset','-o',str(out),str(P/'tg16_reset_audit/tb_interim_reset.sv'),str(src/'rtl/ninja_savestate.sv')],check=True)
 subprocess.run(['vvp',str(out)],cwd=d,check=True)
