`timescale 1ns/1ps
module tb_interim_reset;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;reg [31:0] rom_id=32'h1234;reg [15:0] config_id=0;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we,reg_rotate;
 wire [3:0] error;wire [17:0] scan_addr;wire [15:0] scan_din;reg [15:0] scan_dout=16'h1234;
 reg normal_idle=1,ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;wire [28:0] ram_addr;wire [63:0] ram_din;
 ninja_savestate #(.REGISTER_WORDS(1)) dut(.*);
 // Semantics of the actual pce_top reset register when SS_LOAD is low.
 reg pce_reset_n=0;integer reset_observations=0,writes=0;reg [63:0] mem[0:65535];
 always @(posedge clk)begin
  if(load_pulse && !reset && !fault_reset)pce_reset_n<=1;
  else if(!freeze) begin pce_reset_n<=!(reset || fault_reset);if(reset || fault_reset)reset_observations<=reset_observations+1;end
  if(scan_we)writes<=writes+1;
 end
 always @(posedge ram_clk)begin
  ram_ready<=0;
  if(ram_rd&&!ram_busy)begin ram_dout<=mem[ram_addr-29'h7e00000];ram_ready<=1;end
  if(ram_we&&!ram_busy)mem[ram_addr-29'h7e00000]<=ram_din;
 end
 task trigger_save;begin @(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);end endtask
 task trigger_load;begin @(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);end endtask
 task pulse_reset(input integer expect_fault,input integer expect_seen);
 integer before_,i;begin
  before_=reset_observations;@(negedge clk);reset=1;@(negedge clk);reset=0;
  for(i=0;i<12;i=i+1)@(negedge clk);
  if((reset_observations-before_>0)!=(expect_seen!=0))$fatal(1,"reset observation mismatch expect=%0d seen=%0d",expect_seen,reset_observations-before_);
  if(freeze)$fatal(1,"reset failed to abort freeze");
 end endtask
 integer i;
 initial begin
  for(i=0;i<65536;i=i+1)mem[i]=0;
  repeat(4)@(negedge clk);reset=0;repeat(4)@(negedge clk);
  trigger_save();wait(dut.phase==5 && dut.index>10);pulse_reset(0,0);
  $display("PASS: capture short reset aborts controller but is not observed by pce reset sampler");
  // Create a valid actual full-size slot image, then interrupt its validation.
  repeat(20)@(negedge clk);trigger_save();wait(!freeze);@(negedge clk);if(error)$fatal(1,"priming save error %0d",error);
  $display("valid baseline image created");
  repeat(20)@(negedge clk);trigger_load();wait(dut.phase==5 && !dut.applying && dut.index>10);pulse_reset(0,0);
  $display("PASS: validation short reset aborts controller but is not observed by pce reset sampler");
  repeat(20)@(negedge clk);trigger_load();wait(dut.applying && scan_we);if(writes==0)@(negedge clk);
  pulse_reset(1,1);
  $display("PASS: apply short reset asserts fault_reset and is observed by pce reset sampler; writes before reset=%0d",writes);
  $finish;
 end
 initial begin #500000000;$fatal(1,"timeout");end
endmodule
