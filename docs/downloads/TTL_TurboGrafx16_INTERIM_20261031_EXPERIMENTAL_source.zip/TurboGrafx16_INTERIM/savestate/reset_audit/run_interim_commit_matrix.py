from pathlib import Path
import re,subprocess,tempfile
p=Path(__file__).resolve().parent
s=(p/'patched/TurboGrafx16.sv').read_text();expr=re.search(r'assign ss_load_commit\s*=\s*.*?;',s,re.S).group(0)
tb='''`timescale 1ns/1ps
module tb;reg clk=0;always #5 clk=~clk;
reg ss_load=0,reset=0,cart_download=0,ss_config_changed=0,ss_fault_reset=0,ss_reset_pending=0,ss_available=0;wire ss_load_commit;
'''+expr+'''
integer i;reg expected;reg committed=0;
always @(posedge clk) committed<=ss_load_commit;
initial begin
 for(i=0;i<128;i=i+1)begin
  @(negedge clk);{ss_load,reset,cart_download,ss_config_changed,ss_fault_reset,ss_reset_pending,ss_available}=i;
  expected=ss_load && ss_available && !(reset||cart_download||ss_config_changed||ss_fault_reset||ss_reset_pending);
  @(negedge clk);if(committed!==expected)$fatal(1,"commit mismatch inputs=%b",i);
 end
 $display("PASS: 128 actual commit-gate combinations at consuming edge, including reset, cold, config, fault and pending");$finish;
end
endmodule
'''
with tempfile.TemporaryDirectory(prefix='tg16-commit-matrix-') as d:
 t=Path(d)/'tb.sv';t.write_text(tb);v=Path(d)/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb','-o',str(v),str(t)],check=True);subprocess.run(['vvp',str(v)],check=True)
