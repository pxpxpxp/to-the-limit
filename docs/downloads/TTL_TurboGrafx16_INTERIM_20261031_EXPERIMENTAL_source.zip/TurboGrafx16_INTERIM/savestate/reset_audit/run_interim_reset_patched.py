from pathlib import Path
import re,subprocess,tempfile
P=Path(__file__).resolve().parents[1];src=P/'tg16_interim_retry_1';top=(P/'tg16_reset_audit/patched/TurboGrafx16.sv').read_text();pce=(src/'rtl/pce_top.vhd').read_text()
assert '.COLD_RESET(cart_download|ss_cold_pending)' in top and 'CLR_WE <= COLD_RESET;' in pce and 'CLR_A <= CLR_A + 1;' in pce
vdc=(src/'rtl/huc6270.vhd').read_text()
assert pce.count('address_b=> CLR_A')>=2 and pce.count('wren_b\t=> CLR_WE')>=2
assert 'CLR_A <= CLR_A + 1;' in vdc and 'CLR_WE <= CLR_MEM;' in vdc and "SAT_ADDR <= std_logic_vector(SPR_EVAL_X) when CLR_WE = '0' else std_logic_vector(CLR_A);" in vdc
assert '.RESET(reset|cart_download|ss_fault_reset|ss_reset_pending)' in top and "elsif SS_FREEZE = '0' then" in pce and 'RESET_N <= not RESET;' in pce
m=re.search(r'reg ss_reset_pending=0,ss_cold_pending=0;.*?\nend\n',top,re.S);assert m
commit=re.search(r'assign ss_load_commit\s*=\s*.*?;',top,re.S).group(0)
assert 'ss_reset_pending' in commit and '.enabled(ss_available && !ss_reset_pending)' in top
st='wire clk_sys=clk,ss_freeze=freeze,ss_load=load_pulse,ss_fault_reset=fault_reset;wire ss_config_changed=0,ss_available=enabled;wire ss_load_commit;\n'+m.group(0)+'\n'+commit

tb=(P/'tg16_reset_audit/tb_interim_reset_patched.sv').read_text().replace('// INSERT_DEFERRED_RESET',st)
with tempfile.TemporaryDirectory(prefix='tg16-reset-patch-') as d:
 path=Path(d)/'tb.sv';path.write_text(tb);out=Path(d)/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_interim_reset','-o',str(out),str(path),str(src/'rtl/ninja_savestate.sv')],check=True)
 subprocess.run(['vvp',str(out)],cwd=d,check=True)
