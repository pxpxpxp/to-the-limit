`timescale 1ns/1ps
module tb_interim_reset;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,cart_download=0,enabled=1,safe=1,save_button=0,load_button=0;
 wire ctrl_reset=reset||cart_download;
 reg [1:0] slot=0;reg [31:0] rom_id=32'h1234;reg [15:0] config_id=0;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we,reg_rotate;
 wire [3:0] error;wire [17:0] scan_addr;wire [15:0] scan_din;reg [15:0] scan_dout=16'h1234;
 reg normal_idle=1,ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;wire [28:0] ram_addr;wire [63:0] ram_din;
 wire ctrl_enabled=enabled && !ss_reset_pending;
 ninja_savestate #(.REGISTER_WORDS(1)) dut(.reset(ctrl_reset),.enabled(ctrl_enabled),.*);
 // INSERT_DEFERRED_RESET
 // Semantics of the actual pce_top reset register when SS_LOAD is low.
 reg [14:0] clear_addr=15'h2dad;reg clear_we=0;reg [32767:0] clear_seen=0;
reg [7:0] sat_addr=8'hb7;reg sat_we=0;reg [255:0] sat_seen=0;
reg pce_reset_n=0;integer reset_observations=0,writes=0,fault_observations=0,commit_observations=0,cold_observations=0;reg [63:0] mem[0:65535];
 always @(posedge clk)begin
  if(ss_load_commit)begin pce_reset_n<=1;commit_observations<=commit_observations+1;end
  else if(!freeze) begin pce_reset_n<=!(reset || cart_download || fault_reset || ss_reset_pending);if(reset || cart_download || fault_reset || ss_reset_pending)reset_observations<=reset_observations+1;end
  if(!freeze)begin
   clear_addr<=clear_addr+1'b1;clear_we<=cart_download||ss_cold_pending;
   if(clear_we)clear_seen[clear_addr]<=1;
   sat_addr<=sat_addr+1'b1;sat_we<=cart_download||ss_cold_pending;if(sat_we)sat_seen[sat_addr]<=1;
   if(cart_download||ss_cold_pending)cold_observations<=cold_observations+1;
   if(ss_cold_pending && ss_cold_count>2 && pce_reset_n!==0)$fatal(1,"machine released during cold sweep");
  end
  if(scan_we)writes<=writes+1;
  if(fault_reset)fault_observations<=fault_observations+1;
 end
 always @(posedge ram_clk)begin
  ram_ready<=0;
  if(ram_rd&&!ram_busy)begin ram_dout<=mem[ram_addr-29'h7e00000];ram_ready<=1;end
  if(ram_we&&!ram_busy)mem[ram_addr-29'h7e00000]<=ram_din;
 end
 task trigger_save;begin @(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);end endtask
 task trigger_load;begin @(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);end endtask
 task pulse_reset(input integer expect_fault,input integer expect_seen);
 integer before_,before_fault,i;begin
  before_=reset_observations;before_fault=fault_observations;@(negedge clk);reset=1;@(negedge clk);reset=0;
  for(i=0;i<12;i=i+1)@(negedge clk);
  if((reset_observations-before_>0)!=(expect_seen!=0))$fatal(1,"reset observation mismatch expect=%0d seen=%0d",expect_seen,reset_observations-before_);
  if((fault_observations-before_fault>0)!=(expect_fault!=0))$fatal(1,"fault_reset mismatch expected=%0d observed=%0d",expect_fault,fault_observations-before_fault);
  if(freeze)$fatal(1,"reset failed to abort freeze");
 end endtask
 integer i;
 initial begin
  for(i=0;i<65536;i=i+1)mem[i]=0;
  repeat(4)@(negedge clk);reset=0;repeat(4)@(negedge clk);
  trigger_save();wait(dut.phase==5 && dut.index>10);pulse_reset(0,1);
  $display("PASS: capture short reset aborts controller and is replayed to pce reset sampler");
  // A longer pulse must not be shortened and the deferred pulse must drain.
  repeat(20)@(negedge clk);trigger_save();wait(dut.phase==5 && dut.index>10);
  @(negedge clk);reset=1;repeat(5)@(negedge clk);
  if(pce_reset_n!==0)$fatal(1,"long reset not delivered");reset=0;
  repeat(12)@(negedge clk);if(pce_reset_n!==1 || ss_reset_pending)$fatal(1,"long reset did not release");
  $display("PASS: long reset is delivered and released");
  // A short cartridge-start pulse requires COLD_RESET replay too: pce's
  // CLR_WE and VDC clear logic are also frozen during this cycle.
  repeat(20)@(negedge clk);trigger_save();wait(dut.phase==5 && dut.index>10);
  begin: cold_pulse integer cold_before;cold_before=cold_observations;clear_seen=0;sat_seen=0;
   @(negedge clk);cart_download=1;@(negedge clk);cart_download=0;
   wait(ss_reset_pending && !freeze);
   @(negedge clk);save_button=1;@(negedge clk);save_button=0;
   @(negedge clk);load_button=1;@(negedge clk);load_button=0;
   repeat(5)begin @(negedge clk);if(freeze)$fatal(1,"request started while reset pending");end
   wait(!ss_cold_pending);if(cold_observations==cold_before || !(&clear_seen) || !(&sat_seen))$fatal(1,"short cold reset failed full clear sweep");
   wait(ss_reset_count==7 && ss_reset_pending);@(negedge clk);save_button=1;@(negedge clk);save_button=0;
   repeat(4)@(negedge clk);if(freeze)$fatal(1,"request started on pending-clear edge");
   repeat(5)@(negedge clk);
   // Once recovery has finished, a new edge must be accepted normally.
   trigger_save();wait(dut.phase==5 && dut.index>10);pulse_reset(0,1);
  end
  $display("PASS: full 32768-address RAM/VRAM and 256-address SAT cold sweeps, pending retry suppression, clear-edge suppression and fresh retry");
  // Create a valid actual full-size slot image, then interrupt its validation.
  repeat(20)@(negedge clk);trigger_save();wait(!freeze);@(negedge clk);if(error)$fatal(1,"priming save error %0d",error);
  $display("valid baseline image created");
  // The current on-disk format publishes its header last but overwrites the
  // old payload in place. Abort a replacement after data changed, and prove
  // the previous slot becomes CRC-invalid rather than silently loading it.
  scan_dout=16'h5678;repeat(20)@(negedge clk);trigger_save();wait(dut.phase==5 && dut.index>10);pulse_reset(0,1);
  begin: torn_save integer before_writes;before_writes=writes;
   repeat(20)@(negedge clk);trigger_load();wait(!freeze);@(negedge clk);
   if(error!=6 || writes!=before_writes)$fatal(1,"torn save did not reject without applying, error=%0d",error);
  end
  $display("PASS: interrupted replacement invalidates prior slot but CRC rejects before apply");
  scan_dout=16'h1234;repeat(20)@(negedge clk);trigger_save();wait(!freeze);@(negedge clk);if(error)$fatal(1,"second prime error");
  repeat(20)@(negedge clk);trigger_load();wait(dut.phase==5 && !dut.applying && dut.index>10);pulse_reset(0,1);
  $display("PASS: validation short reset aborts controller and is replayed to pce reset sampler");
  repeat(20)@(negedge clk);trigger_load();wait(dut.applying && scan_we);if(writes==0)@(negedge clk);
  pulse_reset(1,1);
  $display("PASS: apply short reset asserts fault_reset and is observed by pce reset sampler; writes before reset=%0d",writes);
  // Reset arriving on the consuming edge of a registered load pulse must
  // suppress the common commit, including SDRAM and backup bank switching.
  repeat(20)@(negedge clk);trigger_load();wait(load_pulse);@(negedge clk);reset=1;
  begin: same_edge integer c0;c0=commit_observations;@(negedge clk);
   if(commit_observations!=c0)$fatal(1,"stale commit occurred on reset edge");reset=0;repeat(12)@(negedge clk);
  end
  $display("PASS: reset on load-commit edge suppresses stale commit");
  $finish;
 end
 initial begin #500000000;$fatal(1,"timeout");end
endmodule
