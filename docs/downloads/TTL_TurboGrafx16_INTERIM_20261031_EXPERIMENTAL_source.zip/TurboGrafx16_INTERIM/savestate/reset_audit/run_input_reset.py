"""Exercise the exact extracted input-block RTL, including toggle priority."""
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parent

def run(src,patched):
 s=src.read_text();block=s[s.index('reg [3:0] joy_latch;'):s.index('wire snac =')]
 head='''`timescale 1ns/1ps
module dut(input clk_sys,reset,ss_reset_pending,ss_freeze,ss_load_commit,ss_save,ss_we,input [17:0] ss_addr,input [15:0] ss_din,input [1:0] joy_out,input [31:0] status,input [15:0] joy_data,joy_0,joy_1,joy_2,joy_3,joy_4,input [24:0] ps2_mouse);
'''
 tb='''
endmodule
module tb;
 reg clk_sys=0;always #5 clk_sys=~clk_sys;
 reg reset=0,ss_reset_pending=0,ss_freeze=0,ss_load_commit=0,ss_save=0,ss_we=0;
 reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg [1:0] joy_out=0;reg [31:0] status=0;
 reg [15:0] joy_data=0,joy_0=0,joy_1=0,joy_2=0,joy_3=0,joy_4=0;reg [24:0] ps2_mouse=0;
 dut u(.*);
 initial begin
  @(negedge clk_sys);u.input_block.high_buttons=1;ss_freeze=1;reset=1;
  @(negedge clk_sys);reset=0;ss_reset_pending=1;ss_freeze=0;joy_out=0;
  @(negedge clk_sys);if(u.input_block.high_buttons!==EXPECTED)$fatal(1,"frozen-reset replay");
  if(PATCHED)begin
   // A concurrent six-button toggle would set high_buttons without priority.
   u.input_block.high_buttons=0;u.input_block.last_gp=0;status[30:29]=2'b10;joy_out=2;ss_reset_pending=1;
   @(negedge clk_sys);if(u.input_block.high_buttons!==0)$fatal(1,"reset lost to toggle");
   ss_reset_pending=0;joy_out=0;@(negedge clk_sys);joy_out=2;
   @(negedge clk_sys);if(u.input_block.high_buttons!==1)$fatal(1,"ordinary toggle broken");
  end
  $display("PASS: TESTCASE");$finish;
 end
endmodule
'''.replace('EXPECTED',"1'b0" if patched else "1'b1").replace('PATCHED','1' if patched else '0').replace('TESTCASE','deferred high-button reset and toggle priority' if patched else 'original negative control: frozen reset lost')
 with tempfile.TemporaryDirectory(prefix='tg16-input-reset-') as d:
  f=Path(d)/'tb.sv';f.write_text(head+block+tb);v=Path(d)/'test.vvp'
  subprocess.run(['iverilog','-g2012','-s','tb','-o',str(v),str(f)],check=True);subprocess.run(['vvp',str(v)],check=True)
run(P.parent/'tg16_interim_retry_1/TurboGrafx16.sv',False)
run(P/'patched/TurboGrafx16.sv',True)
