#!/usr/bin/env python3
"""Run Quartus locally without assuming a previous executor's tool paths.

A successful map-only run is not a release. Full runs stop if multi-corner
TimeQuest fails; physical MiSTer and replay testing are separately required.
Set TGFX_QUARTUS_BIN to the directory containing the Quartus executables, or
put them on PATH. No host preload or allocator workaround is assumed.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time
P = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--map-only', action='store_true', help='synthesis only')
parser.add_argument('--resume-fit', action='store_true', help='use existing completed synthesis; verify captured inputs')
args = parser.parse_args()
bin_dir = os.environ.get('TGFX_QUARTUS_BIN')
def find_tool(name):
    p = Path(bin_dir) / name if bin_dir else None
    found = str(p) if p and p.is_file() and os.access(p, os.X_OK) else shutil.which(name)
    if not found: raise SystemExit(f'{name} not found; set TGFX_QUARTUS_BIN or PATH')
    return found
steps = [] if args.resume_fit else [('quartus_map',['TurboGrafx16'])]
if args.map_only and args.resume_fit: parser.error('--map-only and --resume-fit are mutually exclusive')
if not args.map_only:
    steps += [('quartus_fit',['--parallel=4','--effort=standard','--seed=2','--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16']),
              ('quartus_sta',['TurboGrafx16','-c','TurboGrafx16','--multicorner=on','--do_report_timing']),
              ('quartus_asm',['--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16'])]
for name,_ in steps: find_tool(name)
# Preserve the tracked input inventory used by the release packager; refresh
# hashes before launching tools, rather than trusting a previous build's hashes.
inputs=P/'savestate/build-inputs.json'
if inputs.is_file():
    names=json.loads(inputs.read_text())
    hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in names}
    if args.resume_fit:
        if hashes != names: raise SystemExit('Synthesis inputs changed; full map required')
        if 'Analysis & Synthesis was successful' not in (P/'quartus_map.log').read_text(errors='replace'): raise SystemExit('No successful map log to resume')
    else:
        inputs.write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
(P/'temp').mkdir(exist_ok=True)
env=os.environ.copy(); env['TMP']=env['TMPDIR']=str(P/'temp')
for name,cmd_args in steps:
    print('Starting',name,time.strftime('%H:%M:%S'),flush=True)
    log=P/(name+'.log')
    with log.open('w') as f:
        proc=subprocess.Popen([find_tool(name),*cmd_args],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT)
        started=time.monotonic()
        while True:
            try: proc.wait(timeout=30); break
            except subprocess.TimeoutExpired:
                print(name,'running',round(time.monotonic()-started),'s',flush=True)
    print(name,'exit',proc.returncode,flush=True)
    print('\n'.join(log.read_text(errors='replace').splitlines()[-8:]),flush=True)
    if proc.returncode: raise SystemExit(proc.returncode)
    if name=='quartus_sta':
        summary=P/'output_files/TurboGrafx16.sta.summary'
        slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',summary.read_text(),re.M)]
        if not slacks or min(slacks)<0: raise SystemExit('Missing or failing timing summary')
        print('Minimum reported timing slack:',min(slacks),'ns',flush=True)
print('Build steps complete; inspect reports and perform the separate functional/hardware validation.',flush=True)
