from pathlib import Path
import re
P=Path(__file__).resolve().parents[1]
s=(P/'savestate/original-rtl/dpram.vhd').read_text()
# Only the first entity/architecture (same-clock dpram) is extended.
a,b=s.split('LIBRARY ieee;',2)[1:]
a='LIBRARY ieee;'+a
a=a.replace('clock\t\t\t: in  STD_LOGIC ;', '''SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_WE : in std_logic := '0';
        SS_ADDR : in std_logic_vector(addr_width-1 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(data_width-1 downto 0) := (others => '0');
        SS_DO : out std_logic_vector(data_width-1 downto 0);
        clock : in STD_LOGIC;''')
a=a.replace('BEGIN\n\tq_a', '''signal sh_q0, sh_q1 : std_logic_vector(data_width-1 downto 0);
    signal replay : std_logic := '0';
    signal ma : std_logic_vector(addr_width-1 downto 0);
    signal md : std_logic_vector(data_width-1 downto 0);
    signal mw, ea, eb : std_logic;
BEGIN
    ma <= SS_ADDR when SS_FREEZE = '1' else address_a;
    md <= SS_DI when SS_FREEZE = '1' else data_a;
    mw <= SS_WE when SS_FREEZE = '1' else wren_a and cs_a;
    ea <= '1' when SS_FREEZE = '1' else enable_a;
    eb <= enable_b and not SS_FREEZE;
    SS_DO <= q0;
    process(clock) begin
      if rising_edge(clock) then
        replay <= SS_FREEZE;
        if SS_SAVE = '1' then
          if cs_a = '1' then sh_q0 <= q0; else sh_q0 <= (others => disable_value); end if;
          if cs_b = '1' then sh_q1 <= q1; else sh_q1 <= (others => disable_value); end if;
        end if;
      end if;
    end process;
    q_a''')
a=a.replace("q_a<= q0 when", "q_a<= sh_q0 when replay = '1' else q0 when")
a=a.replace("q_b<= q1 when", "q_b<= sh_q1 when replay = '1' else q1 when")
for x,y in [('address_a => address_a','address_a => ma'),('clocken0 => enable_a','clocken0 => ea'),('clocken1 => enable_b','clocken1 => eb'),('data_a => data_a','data_a => md'),('wren_a => wren_a and cs_a','wren_a => mw'),('wren_b => wren_b and cs_b','wren_b => wren_b and cs_b and not SS_FREEZE')]:a=a.replace(x,y)
(P/'rtl/dpram.vhd').write_text(a+'LIBRARY ieee;'+b)

busports='''
        SS_ADDR : in std_logic_vector(17 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_WE : in std_logic := '0';
        SS_DO : out std_logic_vector(15 downto 0);
'''
for fn,mems,children in [
 ('pce_top.vhd',{'RAM':(0,15,8),'VRAM0':(1,15,16)}, {'huc6270':'SS_VDC_DO','huc6260':'SS_VCE_DO'}),
 ('huc6270.vhd',{'SAT':(2,8,16),'SPR_LINE_BUF0':(3,9,9),'SPR_LINE_BUF1':(4,9,9)},{}),
 ('huc6260.vhd',{'ram':(5,9,9)}, {})]:
    f=P/'rtl'/fn;s=f.read_text();s=s.replace('SS_FREEZE : in',busports+'        SS_FREEZE : in',1)
    dec='';mux=[]
    for label,(region,aw,dw) in mems.items():
        q='SS_M_'+label.upper();sel=q+'_SEL'
        dec+=f'signal {q} : std_logic_vector({dw-1} downto 0);\nsignal {sel} : std_logic;\n'
        mux.append(f'std_logic_vector(resize(unsigned({q}),16)) when SS_ADDR(17 downto 15) = "{region:03b}" else ')
        pat=rf'((?m:^\s*){label}\s*:\s*entity\s+work\.dpram\b.*?port\s+map\s*\()'
        args=f"\nSS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_WE => {sel},\nSS_ADDR => SS_ADDR({aw-1} downto 0), SS_DI => SS_DI({dw-1} downto 0), SS_DO => {q},\n"
        s,n=re.subn(pat,lambda m:m[1]+args,s,count=1,flags=re.I|re.S);assert n,(fn,label)
        # Selection applies to writes only; all scan addresses may move.
        muxsel=f'{sel} <= SS_WE when SS_ADDR(17 downto 15) = "{region:03b}" else \'0\';\n'
        s=s.replace('end rtl;',muxsel+'end rtl;') if fn!='pce_top.vhd' else s.replace('end rtl;',muxsel+'end rtl;')
    for child,q in children.items():
        dec+=f'signal {q} : std_logic_vector(15 downto 0);\n'
        s=re.sub(rf'(entity\s+work\.{child}\b.*?port\s+map\s*\()',lambda m:m[1]+f'\nSS_ADDR => SS_ADDR, SS_DI => SS_DI, SS_WE => SS_WE, SS_DO => {q},\n',s,count=1,flags=re.I|re.S)
    if children:mux+=['SS_VDC_DO when SS_ADDR(17 downto 15) >= "010" and SS_ADDR(17 downto 15) <= "100" else ', 'SS_VCE_DO when SS_ADDR(17 downto 15) = "101" else ']
    # Some architectures use END RTL, case-insensitive insertion.
    arch=re.search(r'architecture\s+\w+\s+of\s+\w+\s+is',s,re.I).end();b0=re.search(r'(?m)^\s*begin\s*$',s[arch:],re.I).start()+arch
    s=s[:b0]+dec+s[b0:]
    end=re.search(r'end\s+rtl\s*;',s,re.I);s=s[:end.start()]+'\nSS_DO <= '+''.join(mux)+"(others => '0');\n"+s[end.start():]
    f.write_text(s)

# Read-only volume LUT output also has pipeline state. Other unused memories
# must not accept writes while the game is frozen.
for fn in ['pce_top.vhd','HUC6280/psg.vhd']:
    f=P/'rtl'/fn;s=f.read_text()
    def freeze_unscanned(m):
        z=m[0]
        if 'SS_FREEZE =>' not in z:
            z=re.sub(r'(port\s+map\s*\()',lambda q:q[1]+'SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE,\n',z,count=1,flags=re.I)
        return z
    s=re.sub(r'\w+\s*:\s*entity\s+work\.dpram\b.*?\);',freeze_unscanned,s,flags=re.I|re.S)
    f.write_text(s)

# Safe point chosen before the accelerated CPU's next commit pulse.
f=P/'rtl/HUC6280/HUC6280.vhd';s=f.read_text().replace('SS_FREEZE : in',"SS_SAFE : out std_logic;\n        SS_FREEZE : in",1)
s=s.replace('end rtl;',"SS_SAFE <= '1' when CPU_CLK_CNT = CPU_CYCLE_LAST and CPU_CE = '0' and WAIT_N = '1' else '0';\nend rtl;")
f.write_text(s)
f=P/'rtl/pce_top.vhd';s=f.read_text().replace('SS_FREEZE : in',"SS_SAFE : out std_logic;\n        SS_FREEZE : in",1)
s=s.replace('signal RESET_N', 'signal SS_CPU_SAFE : std_logic;\nsignal RESET_N',1)
s=re.sub(r'(entity work.HUC6280\s+port map\s*\()',lambda m:m[1]+'SS_SAFE => SS_CPU_SAFE,\n',s,count=1,flags=re.I)
s=s.replace('end rtl;',"SS_SAFE <= SS_CPU_SAFE and not CPU_CLKEN and ROM_RDY;\nend rtl;")
f.write_text(s)
print('RAM scan ports connected')
