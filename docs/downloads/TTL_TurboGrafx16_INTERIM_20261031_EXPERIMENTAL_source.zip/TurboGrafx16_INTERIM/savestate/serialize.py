"""Generate a deterministic, typed 16-bit register scan map from the working RTL.

Input is the preserved first working build, not the generated output. Every
shadow declaration must flatten successfully; unsupported types fail closed.
"""
from pathlib import Path
import re, json, math, hashlib
P=Path(__file__).resolve().parents[1]
B=P/'savestate/volatile-baseline'
manifest=json.loads((B/'savestate/register_manifest.json').read_text())
layout=[]; outputs={}; cursor=0
bus='''
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
'''
def clean(s): return re.sub(r'--[^\n]*','',s)
def types(s):
    s=clean(s); d={}
    for m in re.finditer(r'type\s+(\w+)\s+is\s+record(.*?)end\s+record',s,re.I|re.S):
        fields=[]
        for f in re.finditer(r'([\w, ]+)\s*:\s*([^;]+);',m[2]):
            fields += [(n.strip(),f[2].strip()) for n in f[1].split(',')]
        d[m[1].lower()]=('record',fields)
    for m in re.finditer(r'type\s+(\w+)\s+is\s+array\s*\(\s*(\d+)\s+(to|downto)\s+(\d+)\s*\)\s+of\s+([^;]+);',s,re.I):
        d[m[1].lower()]=('array',int(m[2]),int(m[4]),m[5].strip())
    for m in re.finditer(r'type\s+(\w+)\s+is\s*\(([^)]+)\)',s,re.I):
        d[m[1].lower()]=('enum',[x.strip() for x in m[2].split(',')])
    return d
def flatten(name,ty,td):
    ty=ty.strip()
    if ty.lower()=='integer':return [(name,ty,32,'int32',None)]
    if ty.lower()=='std_logic': return [(name,ty,1,'bit',None)]
    m=re.fullmatch(r'(std_logic_vector|unsigned|signed)\s*\((\d+)\s+downto\s+(\d+)\)',ty,re.I)
    if m:return [(name,m[1].lower(),int(m[2])-int(m[3])+1,'vector',int(m[3]))]
    m=re.fullmatch(r'integer\s+range\s+(\d+)\s+to\s+(\d+)',ty,re.I)
    if m:
        assert int(m[1])==0
        return [(name,ty,max(1,int(m[2]).bit_length()),'integer',int(m[2]))]
    t=td.get(ty.lower()); assert t,('unhandled type',name,ty)
    if t[0]=='record':return [x for field,ft in t[1] for x in flatten(name+'.'+field,ft,td)]
    if t[0]=='array':return [x for i in range(min(t[1],t[2]),max(t[1],t[2])+1) for x in flatten(f'{name}({i})',t[3],td)]
    return [(name,ty,max(1,(len(t[1])-1).bit_length()),'enum',len(t[1])-1)]
def words(owner,leaves):
    global cursor
    result=[];bitpos=cursor*16
    for name,ty,width,kind,extra in leaves:
        if kind=='int32' or (kind in ('enum','integer') and width>16-bitpos%16):
            bitpos=(bitpos+15)//16*16
        off=0
        while off<width:
            wordbit=bitpos%16;n=min(width-off,16-wordbit);address=bitpos//16
            if kind=='vector':
                field=f'{name}({extra+off+n-1} downto {extra+off})'
                read=f'std_logic_vector(resize(unsigned({field}),16))'
                val=f'SS_RDI({wordbit+n-1} downto {wordbit})'
                if ty in ('unsigned','signed'):val=f'{ty}({val})'
                write=f'{field} <= {val};'
            elif kind=='int32':
                assert wordbit==0 and n==16
                read=f'ss_integer_read({name},{off})'
                write=f'{name} <= ss_integer_write({name},SS_RDI,{off});'
            elif kind=='bit':
                read=f"(std_logic_vector(to_unsigned(0,15)) & {name})";write=f'{name} <= SS_RDI({wordbit});'
            else:
                assert off==0 and n==width
                read=f'std_logic_vector(to_unsigned('+ (f"{ty}'pos({name})" if kind=='enum' else name)+',16))'
                val=f'to_integer(unsigned(SS_RDI({wordbit+n-1} downto {wordbit})))'
                write=f'if {val} <= {extra} then {name} <= '+(f"{ty}'val({val})" if kind=='enum' else val)+'; end if;'
            if wordbit:read=f'std_logic_vector(shift_left(unsigned({read}),{wordbit}))'
            result.append((address,read,write))
            layout.append(dict(owner=owner,field=name,address=address,width=n,kind=kind,offset=off,bit_offset=wordbit))
            off+=n;bitpos+=n
    cursor=(bitpos+15)//16
    return result
def grouped(rows):
    groups={}
    for a,r,w in rows:groups.setdefault(a,[]).append((r,w))
    return groups

def read_mux(rows):
    cases=''.join(f'when {a} => SS_LOCAL_RDO <= '+ ' or '.join('('+r+')' for r,w in values)+';\n' for a,values in sorted(grouped(rows).items()))
    return '\nprocess(all) begin\nSS_LOCAL_RDO <= (others => \'0\');\ncase to_integer(unsigned(SS_RADDR)) is\n'+cases+'when others => null;\nend case;\nend process;\n'
def write_case(rows,variable=False):
    cases=''.join(f'when {a} => '+''.join((w.replace(' <= ',' := ') if variable else w)+'\n' for r,w in values) for a,values in sorted(grouped(rows).items()))
    return "\nif SS_RWE = '1' then\ncase to_integer(unsigned(SS_RADDR)) is\n"+cases+'when others => null;\nend case;\nend if;\n'
pkg=(B/'rtl/HUC6280/HUC6280_PKG.vhd').read_text()
for fn in manifest:
    s=(B/'rtl'/fn).read_text();td=types(pkg+'\n'+s)
    s=s.replace('SS_FREEZE : in',bus+'        SS_FREEZE : in',1)
    if 'use ieee.numeric_std.all;' not in s.lower():
        s=re.sub(r'(use\s+ieee.std_logic_1164.all;)',r'\1\nuse ieee.numeric_std.all;',s,count=1,flags=re.I)
    leaves=[]
    for m in re.finditer(r'signal\s+(SS_SH_\w+)\s*:\s*([^;]+);',s,re.I):leaves+=flatten(m[1],m[2],td)
    rows=words(fn,leaves)
    # The original single capture process owns all signal shadow registers.
    pat=r'(process\(CLK\) begin\s*if rising_edge\(CLK\) then\s*if SS_SAVE = \'1\' then\s*.*?)(end if;\s*end if;\s*end process;)'
    def cap(m):return m[1]+m[2].replace('end if;', 'end if;'+write_case(rows),1)
    s,n=re.subn(pat,cap,s,count=1,flags=re.S);assert n,fn
    # Process-local persistent variables retain their original VHDL semantics.
    # Only their shadow copies are imported; read proxies have one clock latency.
    vrows=[]; proxies=[]
    def variables(m):
        z=m[0]; decls=list(re.finditer(r'variable\s+(SS_SH_VAR_\w+)\s*:\s*([^;]+);',z,re.I))
        if not decls:return z
        # Variables recomputed outside the clocked arm are combinational
        # temporaries, not persistent state. Never restore those at a clock
        # edge: that would create a mixed combinational/registered driver.
        capture_end=z.find('end if;',z.find("and SS_SAVE = '1'"))+len('end if;')
        prefix=z[capture_end:]
        boundary=re.search(r'if\s+RST_N\s*=|(?:els)?if\s+rising_edge',prefix,re.I)
        combinational=prefix[:boundary.start()] if boundary else ''
        for d in decls:
            live=d[1].replace('SS_SH_VAR_','')
            if re.search(r'\b'+live+r'(?:\([^;]*?\))?\s*:=',combinational,re.I):
                z=re.sub(r'\b'+live+r'\s*:=\s*'+d[1]+r';','-- Derived combinational temporary is recomputed from restored inputs.',z,flags=re.I)
        vr=[]; assigns=[]
        for d in decls:
            proxy=f'SS_PROXY_{len(proxies)}';proxies.append((proxy,d[2]))
            rr=words(fn,flatten(d[1],d[2],td));vr+=rr
            vrows.extend((a,r.replace(d[1],proxy),w) for a,r,w in rr)
            assigns.append(f'{proxy} <= {d[1]};')
        start=re.search(r'\bbegin\b',z,re.I).end()
        z=z[:start]+"\nif rising_edge(CLK) then\n"+write_case(vr,True)+'\n'.join(assigns)+'\nend if;\n'+z[start:]
        return z
    s=re.sub(r'\bprocess\s*\(.*?end\s+process\s*;',variables,s,flags=re.S|re.I)
    arch=re.search(r'architecture\s+\w+\s+of\s+\w+\s+is',s,re.I).end()
    b=re.search(r'(?m)^\s*begin\s*$',s[arch:],re.I).start()+arch
    dec="""function ss_integer_read(v:integer; off:natural) return std_logic_vector is
+ variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
+function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
+ variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
+""".replace('\n+','\n')+"signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);\n"+''.join(f'signal {p} : {t};\n' for p,t in proxies)
    s=s[:b]+dec+s[b:]
    e=re.search(r'end\s+(?:rtl|syn)\s*;',s,re.I);s=s[:e.start()]+read_mux(rows+vrows)+'\nSS_RDO <= SS_LOCAL_RDO;\n'+s[e.start():]
    outputs[fn]=s
# RAM output latches are part of the serialized state too. Each instance gets
# an explicit base address; the immutable PSG lookup table needs only its latches.
ram_instances=[('pce_top.vhd','RAM',8),('pce_top.vhd','VRAM0',16),('huc6270.vhd','SAT',16),('huc6270.vhd','SPR_LINE_BUF0',9),('huc6270.vhd','SPR_LINE_BUF1',9),('huc6260.vhd','ram',9),('HUC6280/psg.vhd','VT',24)]
for fn,label,width in ram_instances:
    base=cursor;cursor+=2*math.ceil(width/16)
    layout.append(dict(owner=fn,field=label+'.RAM_read_latches',address=base,words=cursor-base,width=width))
    s=outputs[fn];q='SS_R_'+label.upper()
    s=re.sub(rf'(\b{label}\s*:\s*entity\s+work.dpram\s+generic\s+map\s*\()',rf'\g<1>SS_REG_BASE => {base}, ',s,count=1,flags=re.I)
    # Positional generic associations cannot follow named ones.
    pat=rf'(\b{label}\s*:\s*entity\s+work.dpram\s+generic\s+map\s*\()(.*?)(\)\s*port\s+map\s*\()'
    def gm(m):
        content=m[2].replace(f'SS_REG_BASE => {base}, ','')
        return m[1]+content+f', SS_REG_BASE => {base}'+m[3]+f'\nSS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => {q},\n'
    s,n=re.subn(pat,gm,s,count=1,flags=re.I|re.S);assert n,(fn,label)
    # Append child outputs into the OR tree. Every local mux defaults to zero.
    s=s.replace('signal SS_LOCAL_RDO',f'signal {q} : std_logic_vector(15 downto 0);\nsignal SS_LOCAL_RDO',1)
    s=s.replace('SS_RDO <= SS_LOCAL_RDO',f'SS_RDO <= {q} or SS_LOCAL_RDO',1) if 'SS_RDO <= SS_LOCAL_RDO' in s else s.replace(' or SS_LOCAL_RDO;',f' or {q} or SS_LOCAL_RDO;')
    outputs[fn]=s
# Thread the register bus through the state hierarchy.
children={'pce_top.vhd':['HUC6280','huc6260','huc6270'], 'HUC6280/HUC6280.vhd':['HUC6280_CPU','psg'], 'HUC6280/HUC6280_CPU.vhd':['HUC6280_AG','ALU','HUC6280_MC']}
for fn,names in children.items():
    s=outputs[fn]
    for child in names:
        q='SS_CHILD_'+child.upper()
        pat=rf'(entity\s+work\.{child}\b.*?port\s+map\s*\()'
        s,n=re.subn(pat,lambda m:m[1]+f'\nSS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => {q},\n',s,count=1,flags=re.I|re.S);assert n,(fn,child)
        s=s.replace('signal SS_LOCAL_RDO',f'signal {q} : std_logic_vector(15 downto 0);\nsignal SS_LOCAL_RDO',1)
        s=s.replace(' or SS_LOCAL_RDO;',f' or {q} or SS_LOCAL_RDO;') if ' or SS_LOCAL_RDO;' in s else s.replace('SS_RDO <= SS_LOCAL_RDO;',f'SS_RDO <= {q} or SS_LOCAL_RDO;')
    outputs[fn]=s
for fn,s in outputs.items():(P/'rtl'/fn).write_text(s)
# Parameterized dpram latch import/export. Its ordinary memory scan is unchanged.
s=(B/'rtl/dpram.vhd').read_text().replace('addr_width    : integer := 8;', 'SS_REG_BASE : integer := -1;\n        addr_width    : integer := 8;',1)
# Append the generic to preserve existing positional maps.
s=s.replace('SS_REG_BASE : integer := -1;\n        ','',1).replace("disable_value : std_logic := '1'", "disable_value : std_logic := '1';\n        SS_REG_BASE : integer := -1",1)
s=s.replace('SS_FREEZE : in',bus+'        SS_FREEZE : in',1).replace('USE ieee.std_logic_1164.all;', 'USE ieee.std_logic_1164.all;\nuse ieee.numeric_std.all;',1)
# Generate loops with static bounds: tools unroll each instance's actual width.
logic='''
    process(all) variable word:natural; begin
      SS_RDO <= (others => '0');
      word := to_integer(unsigned(SS_RADDR));
      if SS_REG_BASE >= 0 then
        for bitno in 0 to data_width-1 loop
          if word = SS_REG_BASE + bitno/16 then SS_RDO(bitno mod 16) <= sh_q0(bitno); end if;
          if word = SS_REG_BASE + (data_width+15)/16 + bitno/16 then SS_RDO(bitno mod 16) <= sh_q1(bitno); end if;
        end loop;
      end if;
    end process;
'''
s=s.replace('    ma <= SS_ADDR',logic+'    ma <= SS_ADDR',1)
s=s.replace("        replay <= SS_FREEZE;", """        replay <= SS_FREEZE;
        if SS_RWE = '1' and SS_REG_BASE >= 0 then
          for bitno in 0 to data_width-1 loop
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + bitno/16 then sh_q0(bitno) <= SS_RDI(bitno mod 16); end if;
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + (data_width+15)/16 + bitno/16 then sh_q1(bitno) <= SS_RDI(bitno mod 16); end if;
          end loop;
        end if;""",1)
(P/'rtl/dpram.vhd').write_text(s)
# Additional SystemVerilog state: input protocol and completed SDRAM ROM byte.
s=(B/'TurboGrafx16.sv').read_text()
decls=re.findall(r' reg\s+(\[[^]]+\])?\s*(ss_sh_\w+);',s)
svrows=[]
for ty,name in decls:
    width=int(re.search(r'\[(\d+):0\]',ty)[1])+1 if ty else 1
    svrows.append((cursor,name,width));layout.append(dict(owner='TurboGrafx16.sv',field=name,address=cursor,width=width));cursor+=1
svrows.append((cursor,'ss_rom_byte',8));layout.append(dict(owner='sdram.v',field='ss_rom_byte',address=cursor,width=8));cursor+=1
assert cursor<32768
schema=int(hashlib.sha256(json.dumps(layout,sort_keys=True).encode()+b'|hucard-backup-ram-1024-words-latch-config16-v2').hexdigest()[:16],16)
(P/'savestate/serialized_layout.json').write_text(json.dumps(dict(schema=f'{schema:016x}',register_words=cursor,fields=layout),indent=2)+'\n')
(P/'rtl/snapshot_layout.vh').write_text(f'localparam integer SS_REGISTER_WORDS = {cursor};\nlocalparam [63:0] SS_SCHEMA = 64\'h{schema:016x};\n')
(P/'savestate/sv_registers.json').write_text(json.dumps(svrows))
print(f'Serialized {len(layout)} fields, {cursor} 16-bit words; schema {schema:016x}')

import subprocess,sys
subprocess.run([sys.executable,str(P/'savestate/serial_scan.py')],check=True)
