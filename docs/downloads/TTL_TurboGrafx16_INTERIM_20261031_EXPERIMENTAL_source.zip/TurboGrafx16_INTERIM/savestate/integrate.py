from pathlib import Path
import re
P=Path(__file__).resolve().parents[1]
s=(P/'savestate/original-top.sv').read_text()
# This dedicated experimental build excludes SGX/cheats to leave fit headroom.
s=s.replace('localparam LITE = 0;', 'localparam LITE = 1;')
s=s.replace('use_sdr <= LITE ? ~status[6] : |sdram_sz[14:0];', 'use_sdr <= |sdram_sz[14:0];')
s=s.replace('assign HDMI_FREEZE = 0;', 'assign HDMI_FREEZE = ss_freeze;')
s=s.replace('"FS1,SGX,Load SuperGrafx;",','')
s=s.replace('"P2,Hardware;",','''"P3,Save States (HuCard);",
    "P3-;",
    "D8P3rA,Save State (F5);",
    "D7P3rB,Load State (F8);",
    "P3-,One volatile slot - Ninja Spirit test;",
    "P2,Hardware;",''')
s=s.replace('assign LED_USER  = cart_download | bk_state | bk_pending;', 'assign LED_USER = cart_download | bk_state | bk_pending | ss_freeze;')
s=s.replace('.status_menumask({en216p,', '.status_menumask({!ss_available | ss_freeze, !ss_valid | ss_freeze, en216p,')
old='''\told_ce <= ce_vid;
\tce_pix <= ~old_ce & ce_vid;'''
new='''    reg [7:0] interval_count=0, pixel_period=16, repeat_count=0;
    reg freeze_meta=0, freeze_video=0;
    freeze_meta <= ss_freeze; freeze_video <= freeze_meta;
    old_ce <= ce_vid;
    // Keep the existing MiSTer video_freezer supplied with pixel enables
    // while the emulated VCE is halted. HDMI retains its previous frame;
    // analog output generates black with continuous sync.
    if(~old_ce & ce_vid && !freeze_video) begin
        if(interval_count>=3 && interval_count<32) pixel_period<=interval_count+1'd1;
        interval_count<=0;
    end else if(interval_count<255) interval_count<=interval_count+1'd1;
    if(freeze_video) begin
        ce_pix <= (repeat_count==pixel_period-1'd1);
        if(repeat_count==pixel_period-1'd1) repeat_count<=0;
        else repeat_count<=repeat_count+1'd1;
    end else begin ce_pix<=~old_ce & ce_vid; repeat_count<=0; end'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('.RESET(reset|cart_download),','.RESET(reset|cart_download|ss_fault_reset),',1)
s=s.replace('.CLK(clk_sys),\n\t.CPU_TURBO', '''.CLK(clk_sys),
    .SS_FREEZE(ss_freeze), .SS_SAVE(ss_save), .SS_LOAD(ss_load),
    .SS_SAFE(ss_safe), .SS_ADDR(ss_addr), .SS_DI(ss_din),
    .SS_DO(ss_dout), .SS_WE(ss_we),
    .CPU_TURBO''',1)
# The ordinary DDR controller retains its own bus, multiplexed only while halted.
s=s.replace('ddram ddram\n(\n\t.*,', '''ddram ddram
(
    .DDRAM_CLK(DDRAM_CLK), .DDRAM_BUSY(DDRAM_BUSY | ss_take_ddr),
    .DDRAM_BURSTCNT(normal_burst), .DDRAM_ADDR(normal_addr),
    .DDRAM_DOUT(DDRAM_DOUT), .DDRAM_DOUT_READY(DDRAM_DOUT_READY & !ss_take_ddr),
    .DDRAM_RD(normal_rd), .DDRAM_DIN(normal_din), .DDRAM_BE(normal_be),
    .DDRAM_WE(normal_we),''')
s=s.replace('sdram sdram\n(\n\t.*,','''sdram sdram
(
    .*,
    .ss_save(ss_save), .ss_load(ss_load),''')
# Preserve serial controller protocol state. Live buttons remain live on resume.
start=s.index('always @(posedge clk_sys) begin : input_block')
stop=s.index('\nend',start)+4
block=s[start:stop]
globals={'joy_latch':'[3:0]', 'joy_port':'[2:0]','scan_counter':'[3:0]',
         **{f'joyrept_{i}':'[1:0]' for i in range(5)},'mouse_cnt':'[1:0]','ms_x':'[7:0]','ms_y':'[7:0]'}
locals={'last_gp':'[1:0]','high_buttons':'','mouse_to':'[14:0]','ms_stb':'','msr_x':'[7:0]','msr_y':'[7:0]'}
names={**globals,**locals}
pos=block.index('\n\tif (reset)')
decl=''.join(f'\n reg {t} ss_sh_{n};' for n,t in names.items())
capture='\n if(ss_save) begin\n'+''.join(f' ss_sh_{n} <= {n};\n' for n in names)+' end\n'
restore=' if(ss_load) begin\n'+''.join(f' {n} <= ss_sh_{n};\n' for n in names)+' end else if(!ss_freeze) begin\n'
block=block[:pos]+decl+capture+restore+block[pos:-3]+'\nend\nend'
s=s[:start]+block+s[stop:]
insert='''
// One volatile Ninja Spirit/HuCard save slot. Unsupported modes invalidate it.
wire ss_freeze, ss_save, ss_load, ss_safe, ss_valid, ss_fault_reset;
wire [17:0] ss_addr;
wire [15:0] ss_din, ss_dout;
wire ss_we, ss_take_ddr;
wire ss_available = use_sdr && !cd_en && !sgx && !populous[romwr_a[9]] && !ioctl_download && !status[13];
wire [7:0] normal_burst, normal_be;
wire [28:0] normal_addr, ss_ddr_addr;
wire [63:0] normal_din, ss_ddr_din;
wire normal_rd, normal_we, ss_ddr_rd, ss_ddr_we;
assign DDRAM_BURSTCNT = ss_take_ddr ? 8'd1 : normal_burst;
assign DDRAM_ADDR = ss_take_ddr ? ss_ddr_addr : normal_addr;
assign DDRAM_DIN = ss_take_ddr ? ss_ddr_din : normal_din;
assign DDRAM_BE = ss_take_ddr ? 8'h03 : normal_be;
assign DDRAM_RD = ss_take_ddr ? ss_ddr_rd : normal_rd;
assign DDRAM_WE = ss_take_ddr ? ss_ddr_we : normal_we;
reg ss_key_save=0, ss_key_load=0, ss_key_strobe=0;
reg [2:0] ss_old_config=0;
wire ss_config_changed = ss_old_config != {status[41],status[40:39]};
always @(posedge clk_sys) begin
 ss_key_save<=0; ss_key_load<=0; ss_key_strobe<=ps2_key[10];
 ss_old_config<={status[41],status[40:39]};
 if(ps2_key[10]!=ss_key_strobe && ps2_key[9] && !OSD_STATUS) begin
   if(ps2_key[8:0]==9'h003) ss_key_save<=1; // F5
   if(ps2_key[8:0]==9'h00a) ss_key_load<=1; // F8
 end
end
ninja_savestate ninja_states(
 .clk(clk_sys), .ram_clk(clk_ram),
 .reset(reset|cart_download|ss_config_changed),
 .enabled(ss_available),
 .safe(ss_safe), .save_button(status[42]|ss_key_save), .load_button(status[43]|ss_key_load),
 .freeze(ss_freeze), .save_pulse(ss_save), .load_pulse(ss_load),
 .valid(ss_valid), .fault_reset(ss_fault_reset),
 .scan_addr(ss_addr), .scan_dout(ss_dout), .scan_din(ss_din), .scan_we(ss_we),
 .ram_busy(DDRAM_BUSY), .ram_ready(DDRAM_DOUT_READY), .ram_dout(DDRAM_DOUT),
 .take_ddr(ss_take_ddr), .ram_addr(ss_ddr_addr), .ram_din(ss_ddr_din),
 .ram_rd(ss_ddr_rd), .ram_we(ss_ddr_we)
);
'''
s=s.replace('endmodule',insert+'\nendmodule')
s=s.replace('assign AUDIO_L = status[19:18] ? cmp_l : audio_l[17:2];','assign AUDIO_L = ss_freeze ? 16\'d0 : (status[19:18] ? cmp_l : audio_l[17:2]);')
s=s.replace('assign AUDIO_R = status[19:18] ? cmp_r : audio_r[17:2];','assign AUDIO_R = ss_freeze ? 16\'d0 : (status[19:18] ? cmp_r : audio_r[17:2]);')
(P/'TurboGrafx16.sv').write_text(s)
# SDRAM must keep refreshing. Only its last completed ROM byte is restored.
f=P/'rtl/sdram.v';s=(P/'savestate/original-rtl/sdram.v').read_text()
s=s.replace('input             init,','input ss_save, ss_load,\n\tinput             init,',1)
s=s.replace('// access manager','reg [7:0] ss_rom_byte;\nreg ss_save_m=0, ss_load_m=0;\n// access manager',1)
needle='if(q == STATE_READY && ~wr && ram_req) dout <= a[0] ? data_reg[15:8] : data_reg[7:0];'
s=s.replace(needle,needle+'''\n    ss_save_m <= ss_save; ss_load_m <= ss_load;
    if(ss_save && !ss_save_m) ss_rom_byte <= dout;
    if(ss_load && !ss_load_m) dout <= ss_rom_byte;''')
f.write_text(s)
q=P/'files.qip';s=q.read_text();line='set_global_assignment -name SYSTEMVERILOG_FILE rtl/ninja_savestate.sv\n'
if line not in s:q.write_text(s+line)
print('Top-level snapshot integration complete')
