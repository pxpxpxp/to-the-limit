# TurboGrafx HDL test results — 2026-10-30

All runs below used workspace-local, Debian-signature-verified GHDL 5.0.1 and
Icarus Verilog 12.0 (`../hdl_toolchain`). These are simulations, not physical
MiSTer, Quartus fit/timing, firmware SD persistence, or real Ninja Spirit tests.

## Frozen interim test copy

`../tg16_interim_sim` was copied from frozen `../tg16_interim` with build output
excluded. Production top, controller, DDR and schema hashes were checked against
the frozen source and are listed in `tested_interim_sha256.txt`. The video test
runner in the test copy alone has a tool-path override; two backup-testbench-only
compatibility fixes had already been applied to the interim tree.

* `interim_backup.log`: PASS; production backup logic extracted with a behavioral
  asymmetric RAM model; verifies byte packing, interrupted apply, two bank swaps,
  normal SD write, freeze and read-latch replay.
* `interim_controller.log`: PASS; controller with modeled RAM/DDRAM, four slots,
  binary export/import after reset, generation, rejection of corrupt and wrong
  ROM/config/schema/version, DDR stalls, scan rotation, interrupted apply.
* `interim_eligibility.log`: PASS; validation/apply abort on eligibility loss,
  followed by recovery. Repeats the controller scenarios.
* `interim_ddr_ownership.log`: PASS at 10 clock phases for normal-DDR drain,
  delayed responses, watchdog fail-stop, busy cancellation, abort edge.
* `interim_ddr_integration.log`: PASS using production `ddram` and cache with
  behavioral memories for normal-cache read, grant-edge/queued writes and late
  snapshot drain. Icarus emits inherited port width extension/pruning warnings.
* `interim_video_freeze.log`: PASS; production extracted pixel-repeat logic plus
  MiSTer video_freezer for cadence at three pixel periods.

The VHDL RTL, snapshot layout inventory, CPU workload and synthetic replay
scripts in this interim tree are byte-identical to those used by the candidate
runs below. The two modified interim RTL files (`ddram.sv`,
`ninja_savestate.sv`) are not instantiated by the VHDL CPU/replay tests; their
changed behavior is covered by the independent tests above.

## Candidate and recovered baseline

* `backup_prototype_retry2.log`: PASS, same directed backup bench. Two initial
  attempts failed solely from testbench syntax unsupported by Icarus 12; those
  compatibility changes are preserved in `iverilog_tb_compat.patch`.
* `controller_prototype.log`: PASS four-slot controller with modeled memories;
  candidate schema `60fef42d3266aca5`, 354,888-byte image.
* `eligibility_prototype.log`: PASS eligibility-loss validation/apply abort.
* `cpu_turbo.log`: PASS all 10 synthetic workloads, Off/reserved upstream
  lockstep and write traces, turbo changes, waits and timer/I/O cadence.
* `sdram_turbo_standalone.log`: PASS 900 reads, ROM-latch export/import and
  SDRAM refresh. This is a modeled bench, not physical SDRAM testing.
* `replay_prototype.log`: PASS synthetic HuCard PCE replay after reset and shadow
  overwrite, twice for modes 0, 1 and 2. Real CD/Arcade Card are stubbed; the
  production top, DDR, firmware and backup RAM are not part of that replay.
* `stress_prototype.log`: PASS the same synthetic +50% replay after repeated VRAM
  DMA and work-RAM mutation. The same exclusions apply.
* `controller_baseline.log`: PASS recovered pre-prototype four-slot controller
  with modeled RAM/DDRAM and 346,688-byte image.

`tested_source_sha256.txt` identifies key candidate files. No conclusion about
full peripheral completeness, Ninja Spirit behavior, persistence across a
physical power cycle, FPGA routing or timing follows from these tests.
