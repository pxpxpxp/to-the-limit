// Complete four-slot snapshots. Header word zero is MiSTer's commit/change word.
// The payload contains RAM AND every mapped register, including RAM read latches.
module ninja_savestate #(
 parameter integer REGISTER_WORDS=579,
 parameter [63:0] SCHEMA=64'h60fef42d3266aca5
)(
 input clk,ram_clk,reset,enabled,safe,
 input save_button,load_button,
 input [1:0] slot,
 input [31:0] rom_id,
 input [15:0] config_id,
 output reg freeze=0,save_pulse=0,load_pulse=0,
 output reg valid=0,fault_reset=0,
 output reg [3:0] error=0,
 output reg [17:0] scan_addr=0,
 input [15:0] scan_dout,
 output [15:0] scan_din,
 output scan_we,
 output reg_rotate,
 input normal_idle,ram_busy,ram_ready,
 input [63:0] ram_dout,
 output take_ddr,
 output [28:0] ram_addr,
 output [63:0] ram_din,
 output ram_rd,ram_we
);
 localparam integer RAM_WORDS=43777,WORDS=RAM_WORDS+REGISTER_WORDS,
                    IMAGE_WORDS=WORDS+5;
 localparam [63:0] MAGIC=64'h54474c5353000001; // TGLSS, format version 1
 localparam IDLE=0,WAIT_SAFE=1,SETTLE=2,PREP=3,ISSUE=4,RESPONSE=5,
            NEXT=6,SCAN=7,APPLY=8,RESTORE=9,WARM=10,REJECT=11,CAPTURE=12,ROTATE_SAVE=13;
 reg [3:0] state=IDLE,after_response=NEXT;
 reg loading=0,applying=0,old_save=0,old_load=0;
 reg [1:0] active_slot=0;
 reg [5:0] delay_count=0;
 reg [23:0] watchdog=0;
 reg [15:0] index=0;
 reg [2:0] phase=0; // 0=control,1=magic,2=schema,3=identity,4=CRC,5=payload,6=commit
 reg [31:0] crc=32'hffffffff,expected_crc=0,generation=0;
 reg [31:0] active_rom=0;
 reg [15:0] active_config=0;
 reg req=0;
 reg [63:0] payload=0,response=0;
 reg [15:0] mailbox_addr=0;
 reg mailbox_write=0;
 reg ack=0;
 (* async_reg="true" *) reg ack_meta=0,ack_sync=0;
 assign scan_din=response[15:0];
 assign scan_we=state==APPLY;
 assign reg_rotate=state==ROTATE_SAVE;
 function automatic [31:0] crc16(input [31:0] initial_crc,input [15:0] data);
   reg [31:0] c;integer b;begin c=initial_crc;
   for(b=0;b<16;b=b+1) c=(c>>1)^(((c[0]^data[b])!=0)?32'hedb88320:0);
   crc16=c;end
 endfunction
 function automatic [17:0] scan_location(input [15:0] n);
   if(n<8192) scan_location={3'd0,n[14:0]};
   else if(n<40960) scan_location=18'h08000+18'(n-8192);
   else if(n<41216) scan_location=18'h10000+18'(n-40960);
   else if(n<41728) scan_location=18'h18000+18'(n-41216);
   else if(n<42240) scan_location=18'h20000+18'(n-41728);
   else if(n<42752) scan_location=18'h28000+18'(n-42240);
   else if(n<RAM_WORDS) scan_location=18'h38000+18'(n-42752);
   else scan_location=18'h30000+18'(n-RAM_WORDS);
 endfunction
 always @(posedge clk) begin
   ack_meta<=ack;ack_sync<=ack_meta;
   old_save<=save_button;old_load<=load_button;
   save_pulse<=0;load_pulse<=0;fault_reset<=0;
   if(reset || !enabled) begin
     if(freeze && applying) fault_reset<=1;
     state<=IDLE;freeze<=0;valid<=0;watchdog<=0;
   end else begin
     if(state==IDLE) watchdog<=0;else watchdog<=watchdog+1'd1;
     if(&watchdog) begin
       state<=IDLE;freeze<=0;valid<=0;fault_reset<=applying;error<=4'd7;
     end else case(state)
       IDLE: if(req==ack_sync && ((save_button&&!old_save)||(load_button&&!old_load))) begin
         loading<=!(save_button&&!old_save);applying<=0;
         active_slot<=slot;active_rom<=rom_id;active_config<=config_id;
         error<=0;state<=WAIT_SAFE;
       end
       WAIT_SAFE: if(safe) begin
         freeze<=1;save_pulse<=1; // preserve live read latches even if validation rejects
         delay_count<=0;state<=SETTLE;
       end
       SETTLE: begin
         delay_count<=delay_count+1'd1;
         if(delay_count==31) begin phase<=0;index<=0;crc<=32'hffffffff;state<=PREP;end
       end
       PREP: begin
         mailbox_write<=!loading;after_response<=NEXT;state<=ISSUE;
         case(phase)
           0: begin mailbox_addr<=0;payload<=0;mailbox_write<=0;end // read generation; publish only at commit
           1: begin mailbox_addr<=1;payload<=MAGIC;end
           2: begin mailbox_addr<=2;payload<=SCHEMA;end
           3: begin mailbox_addr<=3;payload<={16'd0,active_config,active_rom};end
           4: begin mailbox_addr<=4;payload<={32'(WORDS),~crc};end
           5: begin scan_addr<=scan_location(index);state<=SCAN;end
           6: begin mailbox_addr<=0;payload<={32'((IMAGE_WORDS-1)*2),generation+32'd1};end
         endcase
       end
       SCAN: state<=CAPTURE;
       CAPTURE: begin // synchronous RAM read has now completed
         mailbox_addr<=index+16'd5;payload<={48'd0,scan_dout};
         if(!loading) crc<=crc16(crc,scan_dout);
         after_response<=NEXT;state<=ISSUE;
       end
       ISSUE: begin req<=!req;state<=RESPONSE;end
       RESPONSE: if(ack_sync==req) begin
         state<=after_response;
         if(!loading && phase==5 && index>=RAM_WORDS) state<=ROTATE_SAVE;
         if(phase==0) generation<=response[31:0];
         if(loading) case(phase)
           0: if(response[63:32] != (IMAGE_WORDS-1)*2) begin error<=1;state<=REJECT;end
           1: if(response!=MAGIC) begin error<=2;state<=REJECT;end
           2: if(response!=SCHEMA) begin error<=3;state<=REJECT;end
           3: if(response!={16'd0,active_config,active_rom}) begin error<=4;state<=REJECT;end
           4: begin
             expected_crc<=response[31:0];
             if(response[63:32]!=WORDS) begin error<=5;state<=REJECT;end
           end
           5: begin
             crc<=crc16(crc,response[15:0]);
             if(applying) state<=APPLY;
           end
         endcase
       end
       ROTATE_SAVE: state<=NEXT;
       APPLY: state<=NEXT;
       NEXT: begin
         if(phase==5) begin
           if(index==WORDS-1) begin
             if(loading) begin
               if((~crc)!=expected_crc) begin error<=6;state<=REJECT;end
               else if(!applying) begin
                 applying<=1;index<=0;crc<=32'hffffffff;state<=PREP;
               end else state<=RESTORE;
             end else begin phase<=4;state<=PREP;end
           end else begin index<=index+1'd1;state<=PREP;end
         end else if(phase==6) begin generation<=generation+1'd1;valid<=1;state<=WARM;delay_count<=0;end
         else if(phase==4) begin phase<=loading?3'd5:3'd6;state<=PREP;end
         else if(phase==3 && !loading) begin phase<=5;state<=PREP;end
         else begin phase<=phase+1'd1;state<=PREP;end
       end
       RESTORE: begin load_pulse<=1;valid<=1;state<=WARM;delay_count<=0;end
       WARM: begin delay_count<=delay_count+1'd1;if(delay_count==7) begin freeze<=0;state<=IDLE;end end
       REJECT: begin freeze<=0;valid<=0;fault_reset<=applying;state<=IDLE;end
       default:begin state<=IDLE;freeze<=0;valid<=0;end
     endcase
   end
 end
 // DDR ownership stays with snapshots until all accepted reads have been
 // drained. A stuck response deliberately holds ownership rather than routing
 // its eventual completion to the normal cache. Reset/retry requires external
 // intervention if the DDR controller never responds.
 (* async_reg="true" *) reg req_meta=0,req_sync=0,freeze_meta=0,freeze_sync=0;
 reg [1:0] dstate=0;
 reg [28:0] daddr=0;
 reg [63:0] ddata=0;
 reg dwrite=0,dread=0,owned=0;
 reg [2:0] release_guard=0;
 assign take_ddr=owned;
 assign ram_addr=daddr;assign ram_din=ddata;assign ram_rd=dread;assign ram_we=dwrite;
 always @(posedge ram_clk) begin
   req_meta<=req;req_sync<=req_meta;freeze_meta<=freeze;freeze_sync<=freeze_meta;
   if(!owned) begin
     // If an operation was aborted before arbitration granted ownership, its
     // request was never presented to DDR and can be acknowledged as canceled.
     if(!freeze_sync && req_sync!=ack) ack<=req_sync;
     if(freeze_sync && normal_idle && !ram_busy && !ram_ready) begin
       owned<=1;release_guard<=0;
     end
   end else begin
     case(dstate)
       0: if(req_sync!=ack) begin
         if(!freeze_sync) ack<=req_sync; // request not yet issued: cancel
         else if(!ram_busy) begin
           daddr<=29'h07e00000+{11'd0,active_slot,16'd0}+mailbox_addr;
           ddata<=payload;dwrite<=mailbox_write;dread<=!mailbox_write;dstate<=1;
         end
       end
       1: begin
         // Ready acceptance must take priority over abort: if !busy at this
         // edge the DDR command was accepted even if freeze just fell.
         if(!ram_busy) begin
           dwrite<=0;dread<=0;
           if(dwrite) begin ack<=req_sync;dstate<=0;end
           else if(ram_ready) begin response<=ram_dout;ack<=req_sync;dstate<=0;end
           else dstate<=2;
         end else if(!freeze_sync) begin
           dwrite<=0;dread<=0;ack<=req_sync;dstate<=0;
         end
       end
       2: if(ram_ready) begin response<=ram_dout;ack<=req_sync;dstate<=0;end
     endcase
     // The quiet guard lets synchronized request/freeze signals settle before
     // handing the bus back, and keeps late completion pulses out of cache.
     if(!freeze_sync && dstate==0 && req_sync==ack && !dread && !dwrite && !ram_ready) begin
       if(release_guard==3) begin owned<=0;release_guard<=0;end
       else release_guard<=release_guard+1'b1;
     end else release_guard<=0;
   end
 end
endmodule
