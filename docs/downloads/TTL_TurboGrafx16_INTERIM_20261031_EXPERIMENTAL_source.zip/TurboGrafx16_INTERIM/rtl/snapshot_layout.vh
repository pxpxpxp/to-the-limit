localparam integer SS_REGISTER_WORDS = 579;
localparam [63:0] SS_SCHEMA = 64'h60fef42d3266aca5;
