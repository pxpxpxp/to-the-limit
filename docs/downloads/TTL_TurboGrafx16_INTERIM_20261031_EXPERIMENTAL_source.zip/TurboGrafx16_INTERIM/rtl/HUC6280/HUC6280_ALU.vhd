library IEEE;
use IEEE.std_logic_1164.all;
use ieee.numeric_std.all;
library work;
use work.HUC6280_PKG.all;

entity ALU is
	port(
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LOAD : in std_logic := '0';
 
		CLK 	: in std_logic;
		EN 	: in std_logic;
		L   	: in std_logic_vector(7 downto 0); 
		R		: in std_logic_vector(7 downto 0); 
		CTRL	: in ALUCtrl_r;
		BCD	: in std_logic; 
		CI		: in std_logic; 
		VI		: in std_logic; 
		NI		: in std_logic; 
		CO		: buffer std_logic; 
		VO		: buffer std_logic; 
		NO		: buffer std_logic; 
		ZO		: buffer std_logic; 
		RES	: buffer std_logic_vector(7 downto 0)
	);
end ALU;

architecture rtl of ALU is

	signal IntL 	: std_logic_vector(7 downto 0);
	signal IntR 	: std_logic_vector(7 downto 0);
	signal CR 		: std_logic;
	signal ADDIn	: std_logic;
	signal BCDIn	: std_logic;
	signal CIIn		: std_logic;
	signal SavedC 	: std_logic;
	
	signal AddS 	: std_logic_vector(7 downto 0);
	signal AddCO 	: std_logic; 
	signal AddVO 	: std_logic; 
	signal Result 	: std_logic_vector(7 downto 0);

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_SAVEDC : std_logic;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_CHAIN : std_logic_vector(15 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(15 downto 0);
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin
	


	process(CTRL, CI, L, R, BCD, SavedC)
	begin
		CR <= CI; 
		BCDIn <= '0';
		case CTRL.fstOp is
			when "000" => 
				CR <= L(7);
				IntL <= L(6 downto 0) & "0";
				IntR <= x"00";
			when "001"=> 
				CR <= L(7);
				IntL <= L(6 downto 0) & CI;
				IntR <= x"00";
			when "010" => 
				CR <= L(0);
				IntL <= "0" & L(7 downto 1);
				IntR <= x"00";
			when "011" => 
				CR <= L(0);
				IntL <= CI & L(7 downto 1);
				IntR <= x"00";
			when "100" => 
				IntL <= L;
				IntR <= R;
				BCDIn <= BCD and CTRL.secOp(1) and CTRL.secOp(0);
			when "101" => 
				IntL <= L;
				IntR <= R;
			when "110" => 	-- INC/DEC LSB
				IntL <= L;
				IntR <= x"01";
				CR <= CTRL.secOp(2);
			when "111" => 	-- INC/DEC MSB
				IntL <= L;
				IntR <= x"00";
				CR <= SavedC;
			when others => null;
		end case;
	end process;
		
	CIIn <= CR or not CTRL.secOp(0);
	ADDIn <= not CTRL.secOp(2);
		
	AddSub: entity work.AddSubBCD
	port map (
		A     	=> IntL,
		B     	=> IntR, 
		CI     	=> CIIn, 
		ADD     	=> ADDIn, 
		BCD     	=> BCDIn,
		S     	=> AddS, 
		CO     	=> AddCO,
		VO     	=> AddVO
	);
	
	process(CLK)
	begin
		if rising_edge(CLK) then
if SS_LOAD = '1' then
SAVEDC <= SS_SH_SAVEDC;
elsif SS_FREEZE = '0' then

			if EN = '1' then
				SavedC <= AddCO;
			end if;
		
end if;
end if;
	end process;
	
	process(CTRL, CR, IntL, IntR, AddCO, AddS)
	begin
		case CTRL.secOp is
			when "000" => 
				CO <= CR;
				Result <= IntL or IntR;
			when "001"=> 
				CO <= CR;
				Result <= IntL and IntR;
			when "010" => 
				CO <= CR;
				Result <= IntL xor IntR;
			when "011" | "110" | "111" => 
				CO <= AddCO;
				Result <= AddS;
			when "100" => 
				CO <= CR;
				Result <= IntL;
			when "101" => 			--TRB,TSB
				CO <= CR;
				if CTRL.fc = '0' then
					Result <= IntR and (not IntL);
				else
					Result <= IntR or IntL;
				end if;
			when others => null;
		end case;
	end process;
	
	process(CTRL, VI, NI, IntR, Result, AddVO, BCDIn)
	begin
		VO <= VI; 
		NO <= Result(7); 
		case CTRL.secOp is
			when "001" => 					--AND
				if CTRL.fc = '1' then	--BIT
					VO <= IntR(6);
					NO <= IntR(7);
				end if;
			when "011" => 					-- ADC
				if BCDIn = '0' then
					VO <= AddVO;					
				end if;
			when "101" => 					--TRB,TSB
				VO <= IntR(6);
				NO <= IntR(7); 
			when "111" =>            	-- SBC
				if BCDIn = '0' then
					VO <= AddVO;
				end if;
			when others => null;
		end case;
	end process;
	
	
	ZO <= '1' when Result = x"00" else '0'; 
	
	RES <= Result;
	

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 420 and to_integer(unsigned(SS_RADDR)) <= 420 else (others => '0');
SS_CAPTURE_DATA(0) <= SAVEDC;
SS_CAPTURE_DATA(15 downto 1) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 420 and to_integer(unsigned(SS_RADDR)) <= 420) then
SS_CHAIN <= SS_RDI;
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 420 and to_integer(unsigned(SS_RADDR)) <= 420) then
SS_CHAIN <= SS_CHAIN(15 downto 0);
end if;
end if;
end process;
SS_SH_SAVEDC <= SS_CHAIN(0);


SS_RDO <= SS_LOCAL_RDO;
end rtl;