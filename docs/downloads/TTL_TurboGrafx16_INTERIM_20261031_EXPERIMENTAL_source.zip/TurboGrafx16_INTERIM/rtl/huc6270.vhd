library IEEE;
use IEEE.std_logic_1164.all;
use ieee.numeric_std.all;
library work;

entity HUC6270 is
	port(
        
        SS_ADDR : in std_logic_vector(17 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_WE : in std_logic := '0';
        SS_DO : out std_logic_vector(15 downto 0);
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LOAD : in std_logic := '0';
 
		CLK		: in std_logic;
		RST_N		: in std_logic;
		CLR_MEM	: in std_logic;
		  
		CPU_CE	: in std_logic;
		BYTEWORD : in std_logic;								-- 16-bit data = 0; 8-bit data = 1
		A			: in std_logic_vector(1 downto 0);		-- if 16-bit data, A(0) probably = 0 and should be ignored in any case
		DI			: in std_logic_vector(15 downto 0);
		DO			: buffer std_logic_vector(15 downto 0);
		CS_N		: in std_logic; 
		WR_N  	: in std_logic;
		RD_N  	: in std_logic;
		BUSY_N	: buffer std_logic;
		IRQ_N		: buffer std_logic;
		
		DCK_CE	: in std_logic;
		DCK_CE_F	: in std_logic;
		HSYNC_F	: in std_logic;
		HSYNC_R	: in std_logic;
		VSYNC_F	: in std_logic;
		VSYNC_R	: in std_logic;
		VD			: buffer std_logic_vector(8 downto 0);
		BORDER	: buffer std_logic;
		GRID		: buffer std_logic_vector(1 downto 0);
		SP64		: in std_logic := '0';

		RAM_A		: buffer std_logic_vector(15 downto 0);
		RAM_DI	: in std_logic_vector(15 downto 0);
		RAM_DO	: buffer std_logic_vector(15 downto 0);
		RAM_WE	: buffer std_logic;
		
		BG_EN		: in std_logic;
		SPR_EN	: in std_logic;
		
		IW_DBG 				: buffer std_logic_vector(1 downto 0);
		VM_DBG 				: buffer std_logic_vector(1 downto 0);
		CM_DBG 				: buffer std_logic;
		SCREEN_DBG 			: buffer std_logic_vector(2 downto 0);
		SOUR_DBG 			: buffer std_logic_vector(15 downto 0);
		DESR_DBG 			: buffer std_logic_vector(15 downto 0);
		LENR_DBG 			: buffer std_logic_vector(15 downto 0);
		SPR_X_DBG    		: buffer std_logic_vector(9 downto 0);
		SPR_Y_DBG    		: buffer std_logic_vector(9 downto 0);
		SPR_PC_DBG			: buffer std_logic_vector(10 downto 0);
		SPR_CG_DBG     	: buffer std_logic;
		SPR_PAL_DBG			: buffer std_logic_vector(3 downto 0);
		SPR_PRIO_DBG		: buffer std_logic; 
		SPR_CGX_DBG			: buffer std_logic; 
		SPR_CGY_DBG     	: buffer std_logic_vector(1 downto 0);
		SPR_HF_DBG     	: buffer std_logic;
		SPR_VF_DBG     	: buffer std_logic;
		HSW_END_POS_DBG 	: buffer unsigned(6 downto 0);
		HDS_END_POS_DBG 	: buffer unsigned(6 downto 0);
		HDISP_END_POS_DBG : buffer unsigned(6 downto 0);
		HSW_DBG				: buffer std_logic_vector(4 downto 0);
		HDS_DBG				: buffer std_logic_vector(6 downto 0);
		HDE_DBG 				: buffer std_logic_vector(6 downto 0);
		VDS_END_POS_DBG 	: buffer unsigned(9 downto 0);
		VDISP_END_POS_DBG : buffer unsigned(9 downto 0);
		VDE_END_POS_DBG 	: buffer unsigned(9 downto 0)
	);
end HUC6270;

architecture rtl of HUC6270 is

	--registers
	type reg_t is array (0 to 31) of std_logic_vector(15 downto 0);
	signal REGS				: reg_t;
	signal AR				: std_logic_vector(4 downto 0);
	signal VRR				: std_logic_vector(15 downto 0);
	alias MAWR				: std_logic_vector(15 downto 0) is REGS(0);
	alias MARR				: std_logic_vector(15 downto 0) is REGS(1);
	alias VWR				: std_logic_vector(15 downto 0) is REGS(2);
	alias RCR				: std_logic_vector(9 downto 0) is REGS(6)(9 downto 0);
	alias BXR				: std_logic_vector(9 downto 0) is REGS(7)(9 downto 0);
	alias BYR				: std_logic_vector(8 downto 0) is REGS(8)(8 downto 0);
	alias HSR_HSW			: std_logic_vector(4 downto 0) is REGS(10)(4 downto 0);
	alias HSR_HDS			: std_logic_vector(6 downto 0) is REGS(10)(14 downto 8);
	alias HDR_HDW			: std_logic_vector(6 downto 0) is REGS(11)(6 downto 0);
	alias HDR_HDE			: std_logic_vector(6 downto 0) is REGS(11)(14 downto 8);
	alias VPR_VSW			: std_logic_vector(4 downto 0) is REGS(12)(4 downto 0);
	alias VPR_VDS			: std_logic_vector(7 downto 0) is REGS(12)(15 downto 8);
	alias VDR_VDW			: std_logic_vector(8 downto 0) is REGS(13)(8 downto 0);
	alias VCR_VCR			: std_logic_vector(7 downto 0) is REGS(14)(7 downto 0);
	alias DCR_DSC			: std_logic is REGS(15)(0);
	alias DCR_DVC			: std_logic is REGS(15)(1);
	alias DCR_SID			: std_logic is REGS(15)(2);
	alias DCR_DID			: std_logic is REGS(15)(3);
	alias DCR_DSR			: std_logic is REGS(15)(4);
	alias SOUR				: std_logic_vector(15 downto 0) is REGS(16);
	alias DESR				: std_logic_vector(15 downto 0) is REGS(17);
	alias LENR				: std_logic_vector(15 downto 0) is REGS(18);
	alias DVSSR				: std_logic_vector(15 downto 0) is REGS(19);
	
	alias CR_IE_CC			: std_logic is REGS(5)(0);
	alias CR_IE_OC			: std_logic is REGS(5)(1);
	alias CR_IE_RC			: std_logic is REGS(5)(2);
	alias CR_IE_VC			: std_logic is REGS(5)(3);
	alias CR_SB				: std_logic is REGS(5)(6);
	alias CR_BB				: std_logic is REGS(5)(7);
	alias CR_IW				: std_logic_vector(1 downto 0) is REGS(5)(12 downto 11);
	alias MWR_VM			: std_logic_vector(1 downto 0) is REGS(9)(1 downto 0);
	alias MWR_SM			: std_logic_vector(1 downto 0) is REGS(9)(3 downto 2);
	alias MWR_SCREEN		: std_logic_vector(2 downto 0) is REGS(9)(6 downto 4);
	alias MWR_CM			: std_logic is REGS(9)(7);
	
	--internal registers
	signal VM				: std_logic_vector(1 downto 0);
	signal SM				: std_logic_vector(1 downto 0);
	signal SCREEN			: std_logic_vector(2 downto 0);
	signal CM				: std_logic;
	signal BB				: std_logic;
	signal SB				: std_logic;
	
	--I/O 
	signal IRQ_DMA			: std_logic;
	signal IRQ_COL			: std_logic;
	signal IRQ_OVF			: std_logic;
	signal IRQ_RCR			: std_logic;
	signal IRQ_DMAS		: std_logic;
	signal IRQ_VBL			: std_logic;
	signal IO_BYRL_SET	: std_logic;
	signal IO_BYRH_SET	: std_logic;
	signal IO_BYRL_WR,IO_BYRH_WR : std_logic;
	signal CPU_BUSY		: std_logic;
	signal CPU_BUSY_CLEAR: std_logic;
	signal CPURD_PEND 	: std_logic;
	signal CPUWR_PEND		: std_logic;
	signal CPURD_PEND2 	: std_logic;
	signal CPUWR_PEND2	: std_logic;
	signal CPURD_EXEC		: std_logic;
	signal CPUWR_EXEC		: std_logic;
	signal CPU_VRAM_ADDR	: std_logic_vector(15 downto 0);
	signal CPU_VRAM_DATA	: std_logic_vector(15 downto 0);
	signal DMA_PEND		: std_logic;
	signal DMA_WR			: std_logic;
	signal DMA_BUF			: std_logic_vector(15 downto 0);
	signal DMA_EXEC		: std_logic;
	signal DMAS_PEND		: std_logic;
	signal DMAS_EXEC		: std_logic;
	signal DMAS_SAT_ADDR	: std_logic_vector(7 downto 0);
	signal DMAS_VRAM_ADDR: std_logic_vector(15 downto 0);
	signal DMAS_SAT_WE	: std_logic;
	signal BXR_SET			: std_logic;
	signal BYRL_SET		: std_logic;
	signal BYRH_SET		: std_logic;
	signal VDISP_OLD		: std_logic;
	signal RD_N_OLD		: std_logic;
	signal SR_LATCH		: std_logic_vector(6 downto 0);
	
	--H/V counters
	signal DOT_CNT			: unsigned(2 downto 0);
	signal TILE_CNT		: unsigned(6 downto 0);
	signal DISP_CNT		: unsigned(9 downto 0);
	signal DISP_CNT_INC 	: std_logic;
	signal DISP_BREAK 	: std_logic;
	signal DISP_BREAK_EN	: std_logic;
	signal DISP_BREAK_LATCH: std_logic;
	signal TILE_ZERO		: std_logic;
	signal DOTS_REMAIN	: unsigned(2 downto 0);
	signal RC_CNT			: unsigned(9 downto 0);
	signal BURST			: std_logic;
	signal HSW_END_POS 	: unsigned(6 downto 0);
	signal HDS_END_POS 	: unsigned(6 downto 0);
	signal HDISP_END_POS : unsigned(6 downto 0);
	signal HDE_END_POS 	: unsigned(6 downto 0);
	signal VDS_END_POS 	: unsigned(9 downto 0);
	signal VDISP_END_POS : unsigned(9 downto 0);
	signal VDE_END_POS 	: unsigned(9 downto 0);
	signal VSW_END_POS 	: unsigned(9 downto 0);
	signal HSW				: std_logic_vector(4 downto 0);
	signal HDS				: std_logic_vector(6 downto 0);
	signal HDW				: std_logic_vector(6 downto 0);
	signal HDE				: std_logic_vector(6 downto 0);
	signal VSW				: std_logic_vector(4 downto 0);
	signal VDS				: std_logic_vector(7 downto 0);
	signal VDW				: std_logic_vector(8 downto 0);
	signal VDE				: std_logic_vector(7 downto 0);
	signal RES7M			: std_logic_vector(0 downto 0);
	signal HDISP			: std_logic;
	signal VDISP			: std_logic;
	
	--rendering
	type slot_t is ( CPU, BAT, CG0, CG1, SG0, SG1, SG2, SG3, NOP );
	signal SLOT				: slot_t;
	signal DISP 			: std_logic_vector(7 downto 0);
	signal BORD 			: std_logic_vector(7 downto 0);
	signal GRID_BG 		: std_logic_vector(7 downto 0);
	signal GRID_SP 		: std_logic_vector(7 downto 0);
	signal BG_X				: unsigned(9 downto 0);
	signal OFS_X			: unsigned(9 downto 0);
	signal OFS_Y			: unsigned(8 downto 0);
	signal BG_OUT_X		: unsigned(9 downto 0);
	signal BG_FETCH		: std_logic;
	signal BG_OUT 			: std_logic;
	signal BG_BAT_CC 		: std_logic_vector(11 downto 0);
	signal BG_BAT_COL 	: std_logic_vector(3 downto 0);
	signal BG_CH0 			: std_logic_vector(7 downto 0);
	signal BG_CH1 			: std_logic_vector(7 downto 0);
	signal BG_SR0 			: std_logic_vector(15 downto 0);
	signal BG_SR1 			: std_logic_vector(15 downto 0);
	signal BG_SR2 			: std_logic_vector(15 downto 0);
	signal BG_SR3 			: std_logic_vector(15 downto 0);
	type ShiftRegColor_t is array (0 to 1) of std_logic_vector(3 downto 0);
	signal BG_SRC 			: ShiftRegColor_t;
	type BGColorArray_t is array (0 to 7) of std_logic_vector(7 downto 0);
	signal BG_COLOR 		: BGColorArray_t;
	signal BG_RAM_ADDR	: std_logic_vector(15 downto 0);
	
	signal SPR_FETCH		: std_logic;
	signal SPR_FETCH_EN	: std_logic;
	signal SPR_CH0 		: std_logic_vector(15 downto 0);
	signal SPR_CH1 		: std_logic_vector(15 downto 0);
	signal SPR_CH2 		: std_logic_vector(15 downto 0);
	signal SPR_CH3 		: std_logic_vector(15 downto 0);
	signal SPR_RAM_ADDR	: std_logic_vector(15 downto 0);
	
	type Sprite_r is record
		X    		: std_logic_vector(9 downto 0);
		Y    		: std_logic_vector(9 downto 0);
		PC			: std_logic_vector(10 downto 0);
		CG     	: std_logic;
		PAL		: std_logic_vector(3 downto 0);
		PRIO		: std_logic; 
		CGX		: std_logic; 
		CGY     	: std_logic_vector(1 downto 0);
		HF     	: std_logic;
		VF     	: std_logic;
		SPR0    	: std_logic;
		TOP    	: std_logic;
		BOTTOM   : std_logic;
	end record;
	type SpriteCache_t is array (0 to 63) of Sprite_r;
	signal SPR_CACHE		: SpriteCache_t;
	signal SPR				: Sprite_r;
	signal SPR_EVAL 		: std_logic;
	signal SPR_EVAL_X		: unsigned(7 downto 0);
	signal SPR_EVAL_DONE : std_logic;
	signal SPR_EVAL_FULL : std_logic;
	signal SPR_EVAL_CNT	: unsigned(6 downto 0);
	signal SPR_FIND		: std_logic; 
	signal SPR_Y			: std_logic_vector(9 downto 0);
	signal SPR_X			: std_logic_vector(9 downto 0);
	signal SPR_PC			: std_logic_vector(10 downto 0);
	signal SPR_CG    		: std_logic;
	signal SPR_FETCH_CNT	: unsigned(6 downto 0);
	signal SPR_FETCH_DONE: std_logic; 
	signal SPR_FETCH_W   : std_logic;
	signal SPR_OUT_X		: unsigned(9 downto 0);

	signal SPR_CE			: std_logic;
	signal SPR_MAX			: integer range 0 to 63;
	signal FETCH_DOT		: unsigned(2 downto 0);
	signal FETCH_CE		: std_logic;
	signal FDOT_CNT		: unsigned(2 downto 0);

	signal SPR_TILE_X    : unsigned(9 downto 0);
	signal SPR_TILE_P0	: std_logic_vector(15 downto 0);
	signal SPR_TILE_P1	: std_logic_vector(15 downto 0);
	signal SPR_TILE_P2	: std_logic_vector(15 downto 0);
	signal SPR_TILE_P3	: std_logic_vector(15 downto 0);
	signal SPR_TILE_HF 	: std_logic;
	signal SPR_TILE_PAL	: std_logic_vector(3 downto 0); 
	signal SPR_TILE_PRIO : std_logic;
	signal SPR_TILE_SPR0 : std_logic;
	signal SPR_TILE_LEFT : std_logic;
	signal SPR_TILE_RIGTH: std_logic;
	signal SPR_TILE_TOP 	: std_logic;
	signal SPR_TILE_BOTTOM: std_logic;
	signal SPR_TILE_SAVE : std_logic;
	signal SPR_TILE_PIX_SET  : std_logic_vector(559 downto 0);
	signal SPR_TILE_SPR0_SET : std_logic_vector(559 downto 0);
	signal SPR_TILE_FRAME    : std_logic_vector(559 downto 0);
	type bufArray_t is array (0 to 1) of std_logic_vector(8 downto 0);
	signal SPR_LINE_ADDR	: bufArray_t; 
	signal SPR_LINE_D		: bufArray_t; 
	signal SPR_LINE_Q		: bufArray_t; 
	signal SPR_LINE_WE 	: std_logic_vector(1 downto 0);
	signal SPR_LINE_CLR 	: std_logic;
	type SPColorArray_t is array (0 to 7) of std_logic_vector(8 downto 0);
	signal SPR_COLOR		: SPColorArray_t; 

	signal SAT_ADDR		: std_logic_vector(7 downto 0);
	signal SAT_Q			: std_logic_vector(15 downto 0);
	signal CLR_A			: unsigned(7 downto 0);
	signal CLR_WE			: std_logic;

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_AR : std_logic_vector(4 downto 0);
signal SS_SH_BB : std_logic;
signal SS_SH_BG_BAT_CC : std_logic_vector(11 downto 0);
signal SS_SH_BG_BAT_COL : std_logic_vector(3 downto 0);
signal SS_SH_BG_CH0 : std_logic_vector(7 downto 0);
signal SS_SH_BG_CH1 : std_logic_vector(7 downto 0);
signal SS_SH_BG_COLOR : BGColorArray_t;
signal SS_SH_BG_FETCH : std_logic;
signal SS_SH_BG_OUT : std_logic;
signal SS_SH_BG_OUT_X : unsigned(9 downto 0);
signal SS_SH_BG_SR0 : std_logic_vector(15 downto 0);
signal SS_SH_BG_SR1 : std_logic_vector(15 downto 0);
signal SS_SH_BG_SR2 : std_logic_vector(15 downto 0);
signal SS_SH_BG_SR3 : std_logic_vector(15 downto 0);
signal SS_SH_BG_SRC : ShiftRegColor_t;
signal SS_SH_BG_X : unsigned(9 downto 0);
signal SS_SH_BORD : std_logic_vector(7 downto 0);
signal SS_SH_BURST : std_logic;
signal SS_SH_BXR_SET : std_logic;
signal SS_SH_BYRH_SET : std_logic;
signal SS_SH_BYRL_SET : std_logic;
signal SS_SH_CLR_A : unsigned(7 downto 0);
signal SS_SH_CLR_WE : std_logic;
signal SS_SH_CM : std_logic;
signal SS_SH_CPURD_EXEC : std_logic;
signal SS_SH_CPURD_PEND : std_logic;
signal SS_SH_CPURD_PEND2 : std_logic;
signal SS_SH_CPUWR_EXEC : std_logic;
signal SS_SH_CPUWR_PEND : std_logic;
signal SS_SH_CPUWR_PEND2 : std_logic;
signal SS_SH_CPU_BUSY : std_logic;
signal SS_SH_CPU_BUSY_CLEAR : std_logic;
signal SS_SH_CPU_VRAM_ADDR : std_logic_vector(15 downto 0);
signal SS_SH_CPU_VRAM_DATA : std_logic_vector(15 downto 0);
signal SS_SH_DESR : std_logic_vector(15 downto 0);
signal SS_SH_DISP : std_logic_vector(7 downto 0);
signal SS_SH_DISP_BREAK_EN : std_logic;
signal SS_SH_DISP_BREAK_LATCH : std_logic;
signal SS_SH_DISP_CNT : unsigned(9 downto 0);
signal SS_SH_DISP_CNT_INC : std_logic;
signal SS_SH_DMAS_EXEC : std_logic;
signal SS_SH_DMAS_PEND : std_logic;
signal SS_SH_DMAS_SAT_ADDR : std_logic_vector(7 downto 0);
signal SS_SH_DMAS_VRAM_ADDR : std_logic_vector(15 downto 0);
signal SS_SH_DMA_BUF : std_logic_vector(15 downto 0);
signal SS_SH_DMA_EXEC : std_logic;
signal SS_SH_DMA_PEND : std_logic;
signal SS_SH_DMA_WR : std_logic;
signal SS_SH_DOTS_REMAIN : unsigned(2 downto 0);
signal SS_SH_DOT_CNT : unsigned(2 downto 0);
signal SS_SH_FETCH_CE : std_logic;
signal SS_SH_FETCH_DOT : unsigned(2 downto 0);
signal SS_SH_GRID_BG : std_logic_vector(7 downto 0);
signal SS_SH_GRID_SP : std_logic_vector(7 downto 0);
signal SS_SH_HDE : std_logic_vector(6 downto 0);
signal SS_SH_HDS : std_logic_vector(6 downto 0);
signal SS_SH_HDW : std_logic_vector(6 downto 0);
signal SS_SH_HSW : std_logic_vector(4 downto 0);
signal SS_SH_IO_BYRH_SET : std_logic;
signal SS_SH_IO_BYRH_WR : std_logic;
signal SS_SH_IO_BYRL_SET : std_logic;
signal SS_SH_IO_BYRL_WR : std_logic;
signal SS_SH_IRQ_COL : std_logic;
signal SS_SH_IRQ_DMA : std_logic;
signal SS_SH_IRQ_DMAS : std_logic;
signal SS_SH_IRQ_OVF : std_logic;
signal SS_SH_IRQ_RCR : std_logic;
signal SS_SH_IRQ_VBL : std_logic;
signal SS_SH_LENR : std_logic_vector(15 downto 0);
signal SS_SH_MARR : std_logic_vector(15 downto 0);
signal SS_SH_MAWR : std_logic_vector(15 downto 0);
signal SS_SH_OFS_X : unsigned(9 downto 0);
signal SS_SH_OFS_Y : unsigned(8 downto 0);
signal SS_SH_RC_CNT : unsigned(9 downto 0);
signal SS_SH_RD_N_OLD : std_logic;
signal SS_SH_REGS : reg_t;
signal SS_SH_RES7M : std_logic_vector(0 downto 0);
signal SS_SH_SB : std_logic;
signal SS_SH_SCREEN : std_logic_vector(2 downto 0);
signal SS_SH_SM : std_logic_vector(1 downto 0);
signal SS_SH_SOUR : std_logic_vector(15 downto 0);
signal SS_SH_SPR_CACHE : SpriteCache_t;
signal SS_SH_SPR_CG : std_logic;
signal SS_SH_SPR_CH0 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_CH1 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_CH2 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_COLOR : SPColorArray_t;
signal SS_SH_SPR_EVAL : std_logic;
signal SS_SH_SPR_EVAL_CNT : unsigned(6 downto 0);
signal SS_SH_SPR_EVAL_DONE : std_logic;
signal SS_SH_SPR_EVAL_FULL : std_logic;
signal SS_SH_SPR_EVAL_X : unsigned(7 downto 0);
signal SS_SH_SPR_FETCH : std_logic;
signal SS_SH_SPR_FETCH_CNT : unsigned(6 downto 0);
signal SS_SH_SPR_FETCH_DONE : std_logic;
signal SS_SH_SPR_FETCH_EN : std_logic;
signal SS_SH_SPR_FETCH_W : std_logic;
signal SS_SH_SPR_FIND : std_logic;
signal SS_SH_SPR_LINE_ADDR : bufArray_t;
signal SS_SH_SPR_LINE_CLR : std_logic;
signal SS_SH_SPR_LINE_D : bufArray_t;
signal SS_SH_SPR_LINE_WE : std_logic_vector(1 downto 0);
signal SS_SH_SPR_OUT_X : unsigned(9 downto 0);
signal SS_SH_SPR_PC : std_logic_vector(10 downto 0);
signal SS_SH_SPR_TILE_BOTTOM : std_logic;
signal SS_SH_SPR_TILE_FRAME : std_logic_vector(559 downto 0);
signal SS_SH_SPR_TILE_HF : std_logic;
signal SS_SH_SPR_TILE_LEFT : std_logic;
signal SS_SH_SPR_TILE_P0 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_TILE_P1 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_TILE_P2 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_TILE_P3 : std_logic_vector(15 downto 0);
signal SS_SH_SPR_TILE_PAL : std_logic_vector(3 downto 0);
signal SS_SH_SPR_TILE_PIX_SET : std_logic_vector(559 downto 0);
signal SS_SH_SPR_TILE_PRIO : std_logic;
signal SS_SH_SPR_TILE_RIGTH : std_logic;
signal SS_SH_SPR_TILE_SAVE : std_logic;
signal SS_SH_SPR_TILE_SPR0 : std_logic;
signal SS_SH_SPR_TILE_SPR0_SET : std_logic_vector(559 downto 0);
signal SS_SH_SPR_TILE_TOP : std_logic;
signal SS_SH_SPR_TILE_X : unsigned(9 downto 0);
signal SS_SH_SPR_X : std_logic_vector(9 downto 0);
signal SS_SH_SPR_Y : std_logic_vector(9 downto 0);
signal SS_SH_SR_LATCH : std_logic_vector(6 downto 0);
signal SS_SH_TILE_CNT : unsigned(6 downto 0);
signal SS_SH_TILE_ZERO : std_logic;
signal SS_SH_VDE : std_logic_vector(7 downto 0);
signal SS_SH_VDISP : std_logic;
signal SS_SH_VDISP_OLD : std_logic;
signal SS_SH_VDS : std_logic_vector(7 downto 0);
signal SS_SH_VDW : std_logic_vector(8 downto 0);
signal SS_SH_VM : std_logic_vector(1 downto 0);
signal SS_SH_VRR : std_logic_vector(15 downto 0);
signal SS_SH_VSW : std_logic_vector(4 downto 0);
signal SS_M_SAT : std_logic_vector(15 downto 0);
signal SS_M_SAT_SEL : std_logic;
signal SS_M_SPR_LINE_BUF0 : std_logic_vector(8 downto 0);
signal SS_M_SPR_LINE_BUF0_SEL : std_logic;
signal SS_M_SPR_LINE_BUF1 : std_logic_vector(8 downto 0);
signal SS_M_SPR_LINE_BUF1_SEL : std_logic;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_R_SAT : std_logic_vector(15 downto 0);
signal SS_R_SPR_LINE_BUF0 : std_logic_vector(15 downto 0);
signal SS_R_SPR_LINE_BUF1 : std_logic_vector(15 downto 0);
signal SS_CHAIN : std_logic_vector(6175 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(6175 downto 0);
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);
signal SS_PROXY_0 : std_logic;
signal SS_PROXY_1 : unsigned(9 downto 0);
signal SS_PROXY_2 : unsigned(8 downto 0);
signal SS_PROXY_3 : unsigned(8 downto 0);
signal SS_PROXY_4 : std_logic_vector(5 downto 0);
signal SS_PROXY_5 : unsigned(5 downto 0);
signal SS_PROXY_6 : unsigned(5 downto 0);
signal SS_PROXY_7 : std_logic_vector(2 downto 0);
signal SS_PROXY_8 : std_logic_vector(3 downto 0);
signal SS_PROXY_9 : unsigned(9 downto 0);
signal SS_PROXY_10 : unsigned(3 downto 0);
signal SS_PROXY_11 : unsigned(3 downto 0);
signal SS_PROXY_12 : unsigned(3 downto 0);

begin



	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			DOT_CNT <= (others=>'0');
			TILE_CNT <= (others=>'0');
			DOTS_REMAIN <= (others=>'0');
			HSW <= (others=>'0');
			HDW <= "0011111";
			HDS <= (others=>'0');
			HDE <= (others=>'0');
			CM <= '0';
			RES7M <= "0";
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CM <= SS_SH_CM;
DOTS_REMAIN <= SS_SH_DOTS_REMAIN;
DOT_CNT <= SS_SH_DOT_CNT;
FETCH_CE <= SS_SH_FETCH_CE;
FETCH_DOT <= SS_SH_FETCH_DOT;
HDE <= SS_SH_HDE;
HDS <= SS_SH_HDS;
HDW <= SS_SH_HDW;
HSW <= SS_SH_HSW;
RES7M <= SS_SH_RES7M;
TILE_CNT <= SS_SH_TILE_CNT;
TILE_ZERO <= SS_SH_TILE_ZERO;
elsif SS_FREEZE = '0' then


			FETCH_CE <= not FETCH_CE;
			if FETCH_CE = '1' then
				FETCH_DOT <= FETCH_DOT + 1;
			end if;

			if SPR_FETCH = '0' then
				FETCH_CE  <= '0';
				FETCH_DOT <= (others=>'0');
			end if;

			if DCK_CE = '1' then
				DOT_CNT <= DOT_CNT + 1;
				if DOT_CNT = 7 then
					TILE_CNT <= TILE_CNT + 1;
					TILE_ZERO <= '0';
				end if; 
				if (TILE_CNT = HDE_END_POS and DOT_CNT = 7) or HSYNC_F = '1' then
					DOT_CNT <= (others=>'0');
					TILE_CNT <= (others=>'0');
					
					DOTS_REMAIN <= DOT_CNT;
					
					if HSYNC_F = '1' then
						HSW <= "00011";
						TILE_ZERO <= '1';
					else 
						HSW <= HSR_HSW;
					end if; 
					HDS <= HSR_HDS;
					HDW <= HDR_HDW;
					HDE <= HDR_HDE;
					RES7M <= "0";

					CM <= MWR_CM;
				end if; 
			end if; 
			
			if DCK_CE = '0' and HSYNC_F = '1' then
				RES7M <= "1";
			end if; 
		
end if;
end if;
	end process;
	
	FDOT_CNT <= DOT_CNT when SP64 = '0' else FETCH_DOT;
	SPR_CE   <= DCK_CE  when SP64 = '0' else FETCH_CE;
	SPR_MAX  <= 15      when SP64 = '0' else 63;

	HSW_END_POS <= "00"&unsigned(HSW) + ("000000"&unsigned(RES7M));
	HDS_END_POS <= ("00"&unsigned(HSW)) + ("000000"&unsigned(RES7M)) + 1 + unsigned(HDS);
	HDISP_END_POS <= ("00"&unsigned(HSW)) + ("000000"&unsigned(RES7M)) + 1 + unsigned(HDS) + 1 + unsigned(HDW);
	HDE_END_POS <= ("00"&unsigned(HSW)) + ("000000"&unsigned(RES7M)) + 1 + unsigned(HDS) + 1 + unsigned(HDW) + 1 + unsigned(HDE);
	
	VSW_END_POS <= ("00000"&unsigned(VSW));
	VDS_END_POS <= ("00000"&unsigned(VSW)) + 1 + ("00"&unsigned(VDS)) + 1;
	VDISP_END_POS <= ("00000"&unsigned(VSW)) + 1 + ("00"&unsigned(VDS)) + 2 + ("0"&unsigned(VDW));
	VDE_END_POS <= ("00000"&unsigned(VSW)) + 1 + ("00"&unsigned(VDS)) + 2 + ("0"&unsigned(VDW)) + 1 + ("00"&unsigned(VDE)) - 1;
	
	DISP_BREAK <= '1' when DISP_CNT_INC = '1' and HSYNC_F = '1' else '0';
	process(CLK, RST_N)
	variable RC_CNT_UPDATED : std_logic;
	variable SS_SH_VAR_RC_CNT_UPDATED : std_logic;
begin
if rising_edge(CLK) then


SS_PROXY_0 <= SS_SH_VAR_RC_CNT_UPDATED;
end if;

if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_RC_CNT_UPDATED := RC_CNT_UPDATED;
end if;

		if RST_N = '0' then
			DISP_CNT <= (others=>'0');
			DISP_CNT_INC <= '0';
			VDISP <= '0';
			BURST <= '1';
			BG_FETCH <= '0';
			BG_OUT <= '0';
			RC_CNT <= "00"&x"40";
			RC_CNT_UPDATED := '0';
			
			VSW <= (others=>'0');
			VDS <= (others=>'0');
			VDW <= (others=>'0');
			VDE <= (others=>'0');
			VM <= (others=>'0');
			SM <= (others=>'0');
			SCREEN <= (others=>'0');
			BB <= '0';
			SB <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
RC_CNT_UPDATED := SS_CHAIN(5968);
BB <= SS_SH_BB;
BG_FETCH <= SS_SH_BG_FETCH;
BG_OUT <= SS_SH_BG_OUT;
BURST <= SS_SH_BURST;
DISP_BREAK_EN <= SS_SH_DISP_BREAK_EN;
DISP_BREAK_LATCH <= SS_SH_DISP_BREAK_LATCH;
DISP_CNT <= SS_SH_DISP_CNT;
DISP_CNT_INC <= SS_SH_DISP_CNT_INC;
RC_CNT <= SS_SH_RC_CNT;
SB <= SS_SH_SB;
SCREEN <= SS_SH_SCREEN;
SM <= SS_SH_SM;
VDE <= SS_SH_VDE;
VDISP <= SS_SH_VDISP;
VDS <= SS_SH_VDS;
VDW <= SS_SH_VDW;
VM <= SS_SH_VM;
VSW <= SS_SH_VSW;
elsif SS_FREEZE = '0' then

			if DCK_CE = '1' then
				if VSYNC_F = '1' then
					VDISP <= '0';
					DISP_CNT <= (others=>'0');
					VSW <= VPR_VSW;
					VDS <= VPR_VDS;
					VDW <= VDR_VDW;
					VDE <= VCR_VCR;
					VM <= MWR_VM;
					SM <= MWR_SM;
					SCREEN <= MWR_SCREEN;
				else
					if DOT_CNT = 7 then
						DISP_BREAK_LATCH <= '0';
					end if;
					if TILE_CNT = HSW_END_POS and DOT_CNT = 7 then
						DISP_CNT_INC <= '1';
						DISP_BREAK_EN <= '1';
					end if;
					if TILE_CNT = HDISP_END_POS and DOT_CNT = 7 then
						DISP_BREAK_EN <= '0';
					end if;
					if DISP_BREAK = '1' then--(TILE_CNT = HDE_END_POS and DOT_CNT = 7 and DISP_CNT_INC = '1') or 
						DISP_CNT <= DISP_CNT + 1;
						DISP_CNT_INC <= '0';
						if DISP_CNT = VSW_END_POS then
							BURST <= not (CR_SB or CR_BB);
						end if;
						if DISP_CNT = VDS_END_POS then
							VDISP <= '1';
						end if;
						if DISP_CNT = VDISP_END_POS then
							VDISP <= '0';
						end if;
						if DISP_CNT = VDE_END_POS then
							DISP_CNT <= (others=>'0');
							VSW <= VPR_VSW;
							VDS <= VPR_VDS;
							VDW <= VDR_VDW;
							VDE <= VCR_VCR;
							VM <= MWR_VM;
							SM <= MWR_SM;
							SCREEN <= MWR_SCREEN;
						end if;
						
						DISP_BREAK_LATCH <= DISP_BREAK_EN;
						DISP_BREAK_EN <= '0';
					end if;
				end if;

				
				if TILE_CNT = HDS_END_POS - 2 and DOT_CNT = 7 and DISP_CNT > VDS_END_POS and DISP_CNT <= VDISP_END_POS then
					BG_FETCH <= '1';
				elsif (TILE_CNT = HDISP_END_POS and DOT_CNT = 7) or (TILE_CNT = 0 and DOT_CNT = 7 and DISP_BREAK_LATCH = '1') then
					BG_FETCH <= '0';
				end if;
				
				if TILE_CNT = HDS_END_POS and DOT_CNT = 7 and DISP_CNT > VDS_END_POS and DISP_CNT <= VDISP_END_POS then
					BG_OUT <= '1';
				elsif (TILE_CNT = HDISP_END_POS and DOT_CNT = 7) or (TILE_CNT = 0 and DOT_CNT = 7 and DISP_BREAK_LATCH = '1') then
					BG_OUT <= '0';
				end if;

				if (TILE_CNT = HDISP_END_POS and DOT_CNT = 7) or (DISP_BREAK = '1' and RC_CNT_UPDATED = '0') then
					if DISP_CNT = VDS_END_POS - 1 then
						RC_CNT <= "00"&x"40";
					else
						RC_CNT <= RC_CNT + 1;
					end if; 
				end if;
				if DISP_BREAK = '1' then
					RC_CNT_UPDATED := '0';
				end if;
				if TILE_CNT = HDISP_END_POS and DOT_CNT = 7 then
					RC_CNT_UPDATED := '1';
				end if;
				
				if TILE_CNT = HDS_END_POS - 3 and DOT_CNT = 6 then
					BB <= CR_BB;
					SB <= CR_SB;
				end if;
			end if; 
		
end if;
end if;
	end process;
	
	process(DOT_CNT, FDOT_CNT, DOTS_REMAIN, TILE_ZERO, TILE_CNT, BURST, DMAS_EXEC, DMA_EXEC, BG_FETCH, SPR_FETCH, SPR_FETCH_EN, VM, CM, SM, SPR, BB, SP64)
	begin
		if TILE_ZERO = '1' and DOT_CNT <= DOTS_REMAIN and SP64 = '0' then
			--first several cycles in HSYNC are empty, i.e. without access the memory, N=dots%8
			SLOT <= NOP;
		elsif DMAS_EXEC = '1' then
			case DOT_CNT(1 downto 0) is
				when "00" => SLOT <= NOP;
				when "01" => SLOT <= NOP;
				when "10" => SLOT <= NOP;
				when others => SLOT <= CPU;
			end case;
		elsif DMA_EXEC = '1' then
			case DOT_CNT(1 downto 0) is
				when "00" => SLOT <= CPU;
				when "01" => SLOT <= NOP;
				when "10" => SLOT <= CPU;
				when others => SLOT <= NOP;
			end case;
		elsif BG_FETCH = '1' then
			if BB = '0' then
				--| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
				--|  CPU  |  CPU  |  CPU  |  CPU  |
				case DOT_CNT(1 downto 0) is
					when "00" => SLOT <= CPU;
					when "01" => SLOT <= NOP;
					when "10" => SLOT <= CPU;
					when others => SLOT <= NOP;
				end case;
			else
			case VM is
				when "00" => 
					case DOT_CNT(2 downto 0) is
						when "000" => SLOT <= CPU;
						when "001" => SLOT <= BAT;
						when "010" => SLOT <= CPU;
						when "011" => SLOT <= NOP;
						when "100" => SLOT <= CPU;
						when "101" => SLOT <= CG0;
						when "110" => SLOT <= CPU;
						when others => SLOT <= CG1;
					end case;
				when "01" | "10" => 
					case DOT_CNT(2 downto 0) is
						when "000" => SLOT <= NOP;
						when "001" => SLOT <= BAT;
						when "010" => SLOT <= NOP;
						when "011" => SLOT <= CPU;
						when "100" => SLOT <= NOP;
						when "101" => SLOT <= CG0;
						when "110" => SLOT <= NOP;
						when others => SLOT <= CG1;
					end case;
				when others =>
					case DOT_CNT(2 downto 0) is
						when "000" => SLOT <= NOP;
						when "001" => SLOT <= NOP;
						when "010" => SLOT <= NOP;
						when "011" => SLOT <= BAT;
						when "100" => SLOT <= NOP;
						when "101" => SLOT <= NOP;
						when "110" => SLOT <= NOP;
						when others => 
							if CM = '0' then 
								SLOT <= CG0;
							else
								SLOT <= CG1;
							end if; 
					end case;
			end case;
			end if; 
		elsif SPR_FETCH = '1' then
			if SPR_FETCH_EN = '0' then
				--if there are no partially or fully sprites in the row for fetching, 
				--then the cycles are replaced by CPU slots
				--| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
				--|  CPU  |  CPU  |  CPU  |  CPU  |
				case DOT_CNT(1 downto 0) is
					when "00" => SLOT <= CPU;
					when "01" => SLOT <= NOP;
					when "10" => SLOT <= CPU;
					when others => SLOT <= NOP;
				end case;
			else
				case SM is
					when "00" => 
						--| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
						--|SG0|SG1|SG2|SG3|SG0|SG1|SG2|SG3|
						case FDOT_CNT(1 downto 0) is
							when "00" => SLOT <= SG0;
							when "01" => SLOT <= SG1;
							when "10" => SLOT <= SG2;
							when others => SLOT <= SG3;
						end case;
					when "01" => 
						--| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
						--|  SG0  |  SG1  |  SG0  |  SG1  |
						--| (SG2) | (SG3) | (SG2) | (SG3) |
						case FDOT_CNT(1 downto 0) is
							when "01" => 
								if SPR.CG = '0' then
									SLOT <= SG0;
								else
									SLOT <= SG2;
								end if; 
							when "11" => 
								if SPR.CG = '0' then
									SLOT <= SG1;
								else
									SLOT <= SG3;
								end if; 
							when others => 
								SLOT <= NOP;
						end case;
					when "10" => 
						--| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
						--|  SG0  |  SG1  |  SG2  |  SG3  |
						case FDOT_CNT(1 downto 0) is
							when "01" => 
								if FDOT_CNT(2) = '0' then
									SLOT <= SG0;
								else
									SLOT <= SG2;
								end if; 
							when "11" => 
								if FDOT_CNT(2) = '0' then
									SLOT <= SG1;
								else
									SLOT <= SG3;
								end if; 
							when others => 
								SLOT <= NOP;
						end case;
					when others =>
						case FDOT_CNT(1 downto 0) is
							when "11" => 
								case unsigned(TILE_CNT(0 downto 0)&FDOT_CNT(2 downto 2)) is
									when "00" => SLOT <= SG0;
									when "01" => SLOT <= SG1;
									when "10" => SLOT <= SG2;
									when others => SLOT <= SG3;
								end case;
							when others => 
								SLOT <= NOP;
						end case;
				end case;
			end if; 
		else
			case DOT_CNT(1 downto 0) is
				when "00" => SLOT <= CPU;
				when "01" => SLOT <= NOP;
				when "10" => SLOT <= CPU;
				when others => SLOT <= NOP;
			end case;
		end if; 
	end process;
	
	--BG
	process(CLK, RST_N, SLOT, BG_X, OFS_Y, OFS_X, SCREEN, BG_BAT_CC)
	variable BG_OFS_X : unsigned(9 downto 0);
	variable BG_OFS_Y : unsigned(8 downto 0);
	variable NEW_OFS_Y : unsigned(8 downto 0);
	variable SS_SH_VAR_BG_OFS_X : unsigned(9 downto 0);
variable SS_SH_VAR_BG_OFS_Y : unsigned(8 downto 0);
variable SS_SH_VAR_NEW_OFS_Y : unsigned(8 downto 0);
begin
if rising_edge(CLK) then


SS_PROXY_1 <= SS_SH_VAR_BG_OFS_X;
SS_PROXY_2 <= SS_SH_VAR_BG_OFS_Y;
SS_PROXY_3 <= SS_SH_VAR_NEW_OFS_Y;
end if;

if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_BG_OFS_X := BG_OFS_X;
SS_SH_VAR_BG_OFS_Y := BG_OFS_Y;
SS_SH_VAR_NEW_OFS_Y := NEW_OFS_Y;
end if;

		BG_OFS_X := resize(BG_X + unsigned(OFS_X), BG_OFS_X'length);
		if SCREEN(2) = '0' then
			BG_OFS_Y := "0" & OFS_Y(7 downto 0);
		else
			BG_OFS_Y := OFS_Y;
		end if;
		
		case SLOT is
			when BAT =>
				case SCREEN(1 downto 0) is
					when "00" =>	BG_RAM_ADDR <= "00000" & std_logic_vector(BG_OFS_Y(8 downto 3)) & std_logic_vector(BG_OFS_X(7 downto 3));
					when "01" =>	BG_RAM_ADDR <= "0000" & std_logic_vector(BG_OFS_Y(8 downto 3)) & std_logic_vector(BG_OFS_X(8 downto 3));
					when others =>	BG_RAM_ADDR <= "000" & std_logic_vector(BG_OFS_Y(8 downto 3)) & std_logic_vector(BG_OFS_X(9 downto 3));
				end case;
			when CG0 =>
				BG_RAM_ADDR <= BG_BAT_CC & "0" & std_logic_vector(BG_OFS_Y(2 downto 0));
			when CG1 =>
				BG_RAM_ADDR <= BG_BAT_CC & "1" & std_logic_vector(BG_OFS_Y(2 downto 0));
			when others =>
				BG_RAM_ADDR <= (others=>'0');
		end case;
				
		if RST_N = '0' then
			BG_X <= (others=>'0');
			OFS_X <= (others=>'0');
			OFS_Y <= (others=>'0');
			BG_BAT_CC <= (others=>'0');
			BG_BAT_COL <= (others=>'0');
			BG_CH0 <= (others=>'0');
			BG_CH1 <= (others=>'0');
			BG_SR0 <= (others=>'0');
			BG_SR1 <= (others=>'0');
			BG_SR2 <= (others=>'0');
			BG_SR3 <= (others=>'0');
			BG_SRC <= (others=>(others=>'0'));
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
-- Derived combinational temporary is recomputed from restored inputs.
-- Derived combinational temporary is recomputed from restored inputs.
NEW_OFS_Y := unsigned(SS_CHAIN(6024 downto 6016));
BG_BAT_CC <= SS_SH_BG_BAT_CC;
BG_BAT_COL <= SS_SH_BG_BAT_COL;
BG_CH0 <= SS_SH_BG_CH0;
BG_CH1 <= SS_SH_BG_CH1;
BG_SR0 <= SS_SH_BG_SR0;
BG_SR1 <= SS_SH_BG_SR1;
BG_SR2 <= SS_SH_BG_SR2;
BG_SR3 <= SS_SH_BG_SR3;
BG_SRC <= SS_SH_BG_SRC;
BG_X <= SS_SH_BG_X;
OFS_X <= SS_SH_OFS_X;
OFS_Y <= SS_SH_OFS_Y;
elsif SS_FREEZE = '0' then

			if DCK_CE = '1' then
				case SLOT is
					when BAT =>
						BG_BAT_CC <= RAM_DI(11 downto 0);
						BG_BAT_COL <= RAM_DI(15 downto 12);
					when CG0 =>
						BG_CH0 <= RAM_DI(7 downto 0);
						BG_CH1 <= RAM_DI(15 downto 8);
					when CG1 =>
					when others => null;
				end case;
				
				if SLOT = CG1 or (SLOT = CG0 and VM = "11") then
					if SLOT = CG0 and VM = "11" then
						BG_SR0 <= BG_SR0(7 downto 0) & RAM_DI(7 downto 0);
						BG_SR1 <= BG_SR1(7 downto 0) & RAM_DI(15 downto 8);
						BG_SR2 <= (others=>'0');
						BG_SR3 <= (others=>'0');
					elsif SLOT = CG1 and VM = "11" then
						BG_SR0 <= (others=>'0');
						BG_SR1 <= (others=>'0');
						BG_SR2 <= BG_SR2(7 downto 0) & RAM_DI(7 downto 0);
						BG_SR3 <= BG_SR3(7 downto 0) & RAM_DI(15 downto 8);
					else
						BG_SR0 <= BG_SR0(7 downto 0) & BG_CH0;
						BG_SR1 <= BG_SR1(7 downto 0) & BG_CH1;
						BG_SR2 <= BG_SR2(7 downto 0) & RAM_DI(7 downto 0);
						BG_SR3 <= BG_SR3(7 downto 0) & RAM_DI(15 downto 8);
					end if; 
					BG_SRC(1) <= BG_SRC(0); 
					BG_SRC(0) <= BG_BAT_COL;
					
					BG_X <= BG_X + 8;
				end if; 
				
				if TILE_CNT = HDS_END_POS - 2 and DOT_CNT = 7 then
					BG_X <= (others=>'0');
				end if; 
				
				if TILE_CNT = HDS_END_POS - 3 and DOT_CNT = 7 and DISP_CNT = VDS_END_POS + 1 then
					OFS_Y <= unsigned(BYR);
				elsif TILE_CNT = HDS_END_POS - 3 and DOT_CNT = 7 then
					if BYRL_SET = '1' or BYRH_SET = '1' then
						NEW_OFS_Y := unsigned(BYR);
					else
						NEW_OFS_Y := OFS_Y;
					end if;
					OFS_Y <= NEW_OFS_Y + 1;
				end if; 
				
				if BXR_SET = '1' then
					OFS_X <= unsigned(BXR);
				end if; 
			end if; 
		
end if;
end if;
	end process;
	
	--Sprites
	DMAS_SAT_WE <= DCK_CE when DMAS_EXEC = '1' and SLOT = CPU else '0'; 
	SAT_ADDR <= std_logic_vector(SPR_EVAL_X) when CLR_WE = '0' else std_logic_vector(CLR_A);
	
	SAT : entity work.dpram generic map (8,16, SS_REG_BASE => 549)
	port map(
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_R_SAT,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_WE => SS_M_SAT_SEL,
SS_ADDR => SS_ADDR(7 downto 0), SS_DI => SS_DI(15 downto 0), SS_DO => SS_M_SAT,

		clock		=> CLK,
		
		data_a	=> RAM_DI,
		address_a=> DMAS_SAT_ADDR,
		wren_a	=> DMAS_SAT_WE,
		
		address_b=> SAT_ADDR,
		data_b   => (others => '0'),
		wren_b   => CLR_WE,
		q_b		=> SAT_Q
	);

	process(CLK) begin if rising_edge(CLK) then
if SS_LOAD = '1' then
CLR_A <= SS_SH_CLR_A;
elsif SS_FREEZE = '0' then

CLR_A <= CLR_A + 1;

end if;
end if; end process;
	process(CLK) begin if rising_edge(CLK) then
if SS_LOAD = '1' then
CLR_WE <= SS_SH_CLR_WE;
elsif SS_FREEZE = '0' then

CLR_WE <= CLR_MEM;

end if;
end if; end process;

	SPR <= SPR_CACHE(to_integer(SPR_FETCH_CNT(5 downto 0)));
	process(CLK, RST_N, SLOT, RC_CNT, SPR, SPR_FETCH_W)
	variable SPR_H : std_logic_vector(5 downto 0);
	variable SPR_OFS_Y : unsigned(5 downto 0);
	variable SPR_LINE : unsigned(5 downto 0);
	variable SPR_TILE_N : std_logic_vector(2 downto 0);
	variable SS_SH_VAR_SPR_H : std_logic_vector(5 downto 0);
variable SS_SH_VAR_SPR_OFS_Y : unsigned(5 downto 0);
variable SS_SH_VAR_SPR_LINE : unsigned(5 downto 0);
variable SS_SH_VAR_SPR_TILE_N : std_logic_vector(2 downto 0);
begin
if rising_edge(CLK) then


SS_PROXY_4 <= SS_SH_VAR_SPR_H;
SS_PROXY_5 <= SS_SH_VAR_SPR_OFS_Y;
SS_PROXY_6 <= SS_SH_VAR_SPR_LINE;
SS_PROXY_7 <= SS_SH_VAR_SPR_TILE_N;
end if;

if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_SPR_H := SPR_H;
SS_SH_VAR_SPR_OFS_Y := SPR_OFS_Y;
SS_SH_VAR_SPR_LINE := SPR_LINE;
SS_SH_VAR_SPR_TILE_N := SPR_TILE_N;
end if;

		SPR_OFS_Y := RC_CNT(5 downto 0) - unsigned(SPR.Y(5 downto 0)) - 1;
		SPR_LINE := SPR_OFS_Y xor (5 downto 0 => SPR.VF);
		if SPR.CGX = '0' then
			SPR_TILE_N(0) := SPR.PC(1);
		else
			SPR_TILE_N(0) := SPR_FETCH_W xor SPR.HF;
		end if;
		case SPR.CGY is
			when "00" =>   SPR_TILE_N(2 downto 1) := SPR.PC(3 downto 2);
			when "01" =>   SPR_TILE_N(2 downto 1) := SPR.PC(3)   & SPR_LINE(4);
			when others => SPR_TILE_N(2 downto 1) := SPR_LINE(5) & SPR_LINE(4);
		end case;
		
		case SLOT is
			when SG0 =>
				SPR_RAM_ADDR <= SPR.PC(10 downto 4) & SPR_TILE_N & "00" & std_logic_vector(SPR_LINE(3 downto 0));
			when SG1 =>
				SPR_RAM_ADDR <= SPR.PC(10 downto 4) & SPR_TILE_N & "01" & std_logic_vector(SPR_LINE(3 downto 0));
			when SG2 =>
				SPR_RAM_ADDR <= SPR.PC(10 downto 4) & SPR_TILE_N & "10" & std_logic_vector(SPR_LINE(3 downto 0));
			when SG3 =>
				SPR_RAM_ADDR <= SPR.PC(10 downto 4) & SPR_TILE_N & "11" & std_logic_vector(SPR_LINE(3 downto 0));
			when others =>
				SPR_RAM_ADDR <= (others=>'0');
		end case;
		
		if RST_N = '0' then
			SPR_EVAL <= '0';
			SPR_EVAL_X <= (others=>'0');
			SPR_EVAL_DONE <= '0';
			SPR_EVAL_FULL <= '0';
			SPR_EVAL_CNT <= (others=>'0');
			SPR_FIND <= '0';
			SPR_CACHE <= (others=>((others=>'0'),(others=>'0'),(others=>'0'),'0',"0000",'0','0',"00",'0','0','0','0','0'));
			SPR_Y <= (others=>'0');
			SPR_X <= (others=>'0');
			SPR_PC <= (others=>'0');
			SPR_CG <= '0';
			SPR_FETCH <= '0';
			SPR_FETCH_EN <= '0';
			SPR_FETCH_W <= '0';
			SPR_FETCH_DONE <= '0';
			SPR_CH0 <= (others=>'0');
			SPR_CH1 <= (others=>'0');
			SPR_CH2 <= (others=>'0');
			--SPR_CH3 <= (others=>'0');
			SPR_TILE_X <= (others=>'0');
			SPR_TILE_P0 <= (others=>'0');
			SPR_TILE_P1 <= (others=>'0');
			SPR_TILE_P2 <= (others=>'0');
			SPR_TILE_P3 <= (others=>'0');
			SPR_TILE_HF <= '0';
			SPR_TILE_PAL <= (others=>'0');
			SPR_TILE_PRIO <= '0';
			SPR_TILE_SPR0 <= '0';
			SPR_TILE_SAVE <= '0';
			IRQ_OVF <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
SPR_H := std_logic_vector(SS_CHAIN(6037 downto 6032));
-- Derived combinational temporary is recomputed from restored inputs.
-- Derived combinational temporary is recomputed from restored inputs.
-- Derived combinational temporary is recomputed from restored inputs.
IRQ_OVF <= SS_SH_IRQ_OVF;
SPR_CACHE <= SS_SH_SPR_CACHE;
SPR_CG <= SS_SH_SPR_CG;
SPR_CH0 <= SS_SH_SPR_CH0;
SPR_CH1 <= SS_SH_SPR_CH1;
SPR_CH2 <= SS_SH_SPR_CH2;
SPR_EVAL <= SS_SH_SPR_EVAL;
SPR_EVAL_CNT <= SS_SH_SPR_EVAL_CNT;
SPR_EVAL_DONE <= SS_SH_SPR_EVAL_DONE;
SPR_EVAL_FULL <= SS_SH_SPR_EVAL_FULL;
SPR_EVAL_X <= SS_SH_SPR_EVAL_X;
SPR_FETCH <= SS_SH_SPR_FETCH;
SPR_FETCH_CNT <= SS_SH_SPR_FETCH_CNT;
SPR_FETCH_DONE <= SS_SH_SPR_FETCH_DONE;
SPR_FETCH_EN <= SS_SH_SPR_FETCH_EN;
SPR_FETCH_W <= SS_SH_SPR_FETCH_W;
SPR_FIND <= SS_SH_SPR_FIND;
SPR_PC <= SS_SH_SPR_PC;
SPR_TILE_BOTTOM <= SS_SH_SPR_TILE_BOTTOM;
SPR_TILE_HF <= SS_SH_SPR_TILE_HF;
SPR_TILE_LEFT <= SS_SH_SPR_TILE_LEFT;
SPR_TILE_P0 <= SS_SH_SPR_TILE_P0;
SPR_TILE_P1 <= SS_SH_SPR_TILE_P1;
SPR_TILE_P2 <= SS_SH_SPR_TILE_P2;
SPR_TILE_P3 <= SS_SH_SPR_TILE_P3;
SPR_TILE_PAL <= SS_SH_SPR_TILE_PAL;
SPR_TILE_PRIO <= SS_SH_SPR_TILE_PRIO;
SPR_TILE_RIGTH <= SS_SH_SPR_TILE_RIGTH;
SPR_TILE_SAVE <= SS_SH_SPR_TILE_SAVE;
SPR_TILE_SPR0 <= SS_SH_SPR_TILE_SPR0;
SPR_TILE_TOP <= SS_SH_SPR_TILE_TOP;
SPR_TILE_X <= SS_SH_SPR_TILE_X;
SPR_X <= SS_SH_SPR_X;
SPR_Y <= SS_SH_SPR_Y;
elsif SS_FREEZE = '0' then

			SPR_TILE_SAVE <= '0';
			if DCK_CE = '1' then
				if TILE_CNT = HDS_END_POS and DOT_CNT = 3 and DISP_CNT >= VDS_END_POS and DISP_CNT < VDISP_END_POS then
					SPR_EVAL <= '1';
					SPR_EVAL_X <= (others=>'0');
					SPR_EVAL_CNT <= (others=>'0');
					SPR_EVAL_DONE <= '0';
					SPR_EVAL_FULL <= '0';
					SPR_FIND <= '0';
				elsif (DOT_CNT = 7 and TILE_CNT = HDISP_END_POS) or (DOT_CNT = 7 and TILE_CNT = 0 and DISP_BREAK_LATCH = '1') then
					SPR_EVAL <= '0';
				end if;
				
				if ((DOT_CNT = 7 and TILE_CNT = HDISP_END_POS                and DISP_CNT >= VDS_END_POS and DISP_CNT <  VDISP_END_POS) or 
				    (DOT_CNT = 7 and TILE_CNT = 0 and DISP_BREAK_LATCH = '1' and DISP_CNT >  VDS_END_POS and DISP_CNT <= VDISP_END_POS)) and SPR_FETCH = '0' then
					SPR_FETCH <= '1';
					SPR_FETCH_EN <= CR_SB and SPR_FIND;
					SPR_FETCH_CNT <= (others=>'0');
					SPR_FETCH_W <= '0';
					SPR_FETCH_DONE <= '0';
				elsif TILE_CNT = HDS_END_POS - 2 and DOT_CNT = 7 then
					SPR_FETCH <= '0';
				end if;

				if SPR_EVAL = '1' then
					if SPR_EVAL_DONE = '0' then
						case SPR_EVAL_X(1 downto 0) is
							when "00" =>
								SPR_Y <= SAT_Q(9 downto 0);
							when "01" =>
								SPR_X <= SAT_Q(9 downto 0);
							when "10" =>
								SPR_CG <= SAT_Q(0);
								SPR_PC <= SAT_Q(10 downto 0);
							when others =>
								SPR_H := SAT_Q(13)&(SAT_Q(13) or SAT_Q(12))&"1111";
								if RC_CNT >= unsigned(SPR_Y) and RC_CNT <= unsigned(SPR_Y) + unsigned(SPR_H) then
									SPR_FIND <= '1';
									if SPR_EVAL_FULL = '0' then
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).X <= SPR_X;
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).Y <= SPR_Y;
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).PC <= SPR_PC;
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).CG <= SPR_CG;
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).PAL <= SAT_Q(3 downto 0);
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).PRIO <= SAT_Q(7);
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).CGX <= SAT_Q(8);
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).CGY <= SAT_Q(13 downto 12);
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).HF <= SAT_Q(11);
										SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).VF <= SAT_Q(15);
										if SPR_EVAL_X(7 downto 2) = "000000" then
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).SPR0 <= '1';
										else
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).SPR0 <= '0';
										end if;
										if RC_CNT = unsigned(SPR_Y) then
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).TOP <= '1';
										else
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).TOP <= '0';
										end if;
										if RC_CNT = unsigned(SPR_Y) + unsigned(SPR_H) then
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).BOTTOM <= '1';
										else
											SPR_CACHE(to_integer(SPR_EVAL_CNT(5 downto 0))).BOTTOM <= '0';
										end if;
										
										SPR_EVAL_CNT <= SPR_EVAL_CNT + 1;
										if SPR_EVAL_CNT = SPR_MAX then
											SPR_EVAL_FULL <= '1';
										end if;
									else
										if CR_IE_OC = '1' then
											IRQ_OVF <= '1';
										end if;
									end if; 
								end if; 
						end case;
						SPR_EVAL_X <= SPR_EVAL_X + 1;
						if SPR_EVAL_X = x"FF" then
							SPR_EVAL_DONE <= '1';
						end if; 
					end if; 
				end if; 
			end if;

			if SPR_CE = '1' then
				if SPR_FETCH = '1' then
					if SPR_FETCH_DONE = '0' and SPR_FIND = '1' then
						case SLOT is
							when SG0 =>
								SPR_CH0 <= RAM_DI;
							when SG1 =>
								SPR_CH1 <= RAM_DI;
							when SG2 =>
								SPR_CH2 <= RAM_DI;
							when SG3 =>
								--SPR_CH3 <= RAM_DI;
							when others => null;
						end case;
						
						if (SM = "01" and SPR.CG = '0' and SLOT = SG1) or SLOT = SG3 then
							SPR_FETCH_W <= '1';
							if SPR_FETCH_W = SPR.CGX then
								SPR_FETCH_W <= '0';
								if SPR_FETCH_CNT = SPR_EVAL_CNT - 1 then
									SPR_FETCH_DONE <= '1';
									SPR_FETCH_EN <= '0';
								else
									SPR_FETCH_CNT <= SPR_FETCH_CNT + 1;
								end if; 
							end if; 
							
							if (SM = "01" and SPR.PC(0) = '1') then		-- when it's 4-color mode
																						-- then if bit 0 of SATB sprint pattern address = '1', then switch SG0/SG1 slot to SG2/SG3						

								SPR_TILE_P0 <= SPR_CH2;
								SPR_TILE_P1 <= RAM_DI;
								SPR_TILE_P2 <= (others=>'0');
								SPR_TILE_P3 <= (others=>'0');
							elsif SM = "01" and SPR.CG = '0' then
								SPR_TILE_P0 <= SPR_CH0;
								SPR_TILE_P1 <= RAM_DI;
								SPR_TILE_P2 <= (others=>'0');
								SPR_TILE_P3 <= (others=>'0');
							elsif SM = "01" and SPR.CG = '1' then
								SPR_TILE_P0 <= (others=>'0');
								SPR_TILE_P1 <= (others=>'0');
								SPR_TILE_P2 <= SPR_CH2;
								SPR_TILE_P3 <= RAM_DI;
							else
								SPR_TILE_P0 <= SPR_CH0;
								SPR_TILE_P1 <= SPR_CH1;
								SPR_TILE_P2 <= SPR_CH2;
								SPR_TILE_P3 <= RAM_DI;
							end if;
							SPR_TILE_X <= unsigned(SPR.X) - 32 + (SPR_FETCH_W&"0000");
							SPR_TILE_HF <= SPR.HF;
							SPR_TILE_PAL <= SPR.PAL;
							SPR_TILE_PRIO <= SPR.PRIO;
							SPR_TILE_SPR0 <= SPR.SPR0;
							SPR_TILE_SAVE <= '1';
							
							SPR_TILE_LEFT <= not SPR.CGX or not SPR_FETCH_W;
							SPR_TILE_RIGTH <= not SPR.CGX or SPR_FETCH_W;
							SPR_TILE_TOP <= SPR.TOP;
							SPR_TILE_BOTTOM <= SPR.BOTTOM;
						end if;
					end if;
				end if;
			end if; 
			
			if CS_N = '0' and RD_N = '0' and CPU_CE = '1' and A(1) = '0' and (BYTEWORD = '0' or A(0) = '0') then
				IRQ_OVF <= '0';						
			end if; 
		
end if;
end if;
	end process;
	
	process(CLK, RST_N)
	variable COLOR : std_logic_vector(3 downto 0);
	variable SPR_LINE_X : unsigned(9 downto 0);
	variable N : unsigned(3 downto 0);
	variable SPR_TILE_PIX : unsigned(3 downto 0);
	
	variable SS_SH_VAR_COLOR : std_logic_vector(3 downto 0);
variable SS_SH_VAR_SPR_LINE_X : unsigned(9 downto 0);
variable SS_SH_VAR_N : unsigned(3 downto 0);
variable SS_SH_VAR_SPR_TILE_PIX : unsigned(3 downto 0);
begin
if rising_edge(CLK) then


SS_PROXY_8 <= SS_SH_VAR_COLOR;
SS_PROXY_9 <= SS_SH_VAR_SPR_LINE_X;
SS_PROXY_10 <= SS_SH_VAR_N;
SS_PROXY_11 <= SS_SH_VAR_SPR_TILE_PIX;
end if;

if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_COLOR := COLOR;
SS_SH_VAR_SPR_LINE_X := SPR_LINE_X;
SS_SH_VAR_N := N;
SS_SH_VAR_SPR_TILE_PIX := SPR_TILE_PIX;
end if;

		if RST_N = '0' then
			SPR_TILE_PIX := (others=>'0');
			SPR_LINE_WE <= (others=>'0');
			SPR_TILE_PIX_SET <= (others=>'0');
			SPR_TILE_SPR0_SET <= (others=>'0');
			SPR_OUT_X <= (others=>'0');
			SPR_LINE_CLR <= '0';
			IRQ_COL <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
COLOR := std_logic_vector(SS_CHAIN(6099 downto 6096));
SPR_LINE_X := unsigned(SS_CHAIN(6121 downto 6112));
N := unsigned(SS_CHAIN(6131 downto 6128));
SPR_TILE_PIX := unsigned(SS_CHAIN(6147 downto 6144));
IRQ_COL <= SS_SH_IRQ_COL;
SPR_LINE_ADDR <= SS_SH_SPR_LINE_ADDR;
SPR_LINE_CLR <= SS_SH_SPR_LINE_CLR;
SPR_LINE_D <= SS_SH_SPR_LINE_D;
SPR_LINE_WE <= SS_SH_SPR_LINE_WE;
SPR_OUT_X <= SS_SH_SPR_OUT_X;
SPR_TILE_FRAME <= SS_SH_SPR_TILE_FRAME;
SPR_TILE_PIX_SET <= SS_SH_SPR_TILE_PIX_SET;
SPR_TILE_SPR0_SET <= SS_SH_SPR_TILE_SPR0_SET;
elsif SS_FREEZE = '0' then

			SPR_LINE_WE <= (others=>'0');
			if SPR_TILE_SAVE = '1' or SPR_TILE_PIX /= 0 then
				for i in 0 to 1 loop
					N := SPR_TILE_PIX xor (3 downto 0 => not SPR_TILE_HF);
					COLOR := SPR_TILE_P3(to_integer(N)) & SPR_TILE_P2(to_integer(N)) & SPR_TILE_P1(to_integer(N)) & SPR_TILE_P0(to_integer(N));
					SPR_LINE_X := SPR_TILE_X + SPR_TILE_PIX;
					if SPR_LINE_X(9 downto 8) /= "11" and COLOR /= "0000" then
						if SPR_TILE_PIX_SET(to_integer(SPR_LINE_X)) = '0' then
							SPR_LINE_D(to_integer(SPR_LINE_X(0 downto 0))) <= SPR_TILE_PRIO & SPR_TILE_PAL & COLOR;
							SPR_LINE_ADDR(to_integer(SPR_LINE_X(0 downto 0))) <= std_logic_vector(SPR_LINE_X(9 downto 1));
							SPR_LINE_WE(to_integer(SPR_LINE_X(0 downto 0))) <= '1';
							SPR_TILE_PIX_SET(to_integer(SPR_LINE_X)) <= '1';
							SPR_TILE_SPR0_SET(to_integer(SPR_LINE_X)) <= SPR_TILE_SPR0;
						end if;
						if SPR_TILE_SPR0_SET(to_integer(SPR_LINE_X)) = '1' then
							if CR_IE_CC = '1' then
								IRQ_COL <= '1';
							end if;
						end if; 
					end if;

					if (SPR_TILE_PIX = 0 and SPR_TILE_LEFT = '1') or (SPR_TILE_PIX = 15 and SPR_TILE_RIGTH = '1') or 
						SPR_TILE_TOP = '1' or SPR_TILE_BOTTOM = '1' then
						SPR_TILE_FRAME(to_integer(SPR_LINE_X)) <= '1';
					end if; 

					SPR_TILE_PIX := SPR_TILE_PIX + 1;
				end loop;
			end if; 
			
			if DCK_CE = '1' then
				if TILE_CNT = HDS_END_POS and DOT_CNT = 7 then
					SPR_OUT_X <= (others=>'0');
					SPR_LINE_CLR <= '1';
				elsif (TILE_CNT = HDISP_END_POS and DOT_CNT = 7) or (DOT_CNT = 7 and TILE_CNT = 0 and DISP_BREAK_LATCH = '1') then
					SPR_LINE_CLR <= '0';
				end if;
				
				if SPR_LINE_CLR = '1' then
					SPR_TILE_PIX_SET(to_integer(SPR_OUT_X)) <= '0';
					SPR_TILE_SPR0_SET(to_integer(SPR_OUT_X)) <= '0';
					SPR_TILE_FRAME(to_integer(SPR_OUT_X)) <= '0';
					SPR_OUT_X <= SPR_OUT_X + 1;
				end if;
			end if;
			
			if CS_N = '0' and RD_N = '0' and CPU_CE = '1' and A(1) = '0' and (BYTEWORD = '0' or A(0) = '0') then
				IRQ_COL <= '0';
			end if; 
		
end if;
end if;
	end process;
	
	SPR_LINE_BUF0 : entity work.dpram generic map (9,9, SS_REG_BASE => 551)
	port map(
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_R_SPR_LINE_BUF0,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_WE => SS_M_SPR_LINE_BUF0_SEL,
SS_ADDR => SS_ADDR(8 downto 0), SS_DI => SS_DI(8 downto 0), SS_DO => SS_M_SPR_LINE_BUF0,

		clock		=> CLK,

		address_a=> SPR_LINE_ADDR(0),
		data_a	=> SPR_LINE_D(0),
		wren_a	=> SPR_LINE_WE(0),

		address_b=> std_logic_vector(SPR_OUT_X(9 downto 1)),
		wren_b	=> SPR_LINE_CLR and DCK_CE and not SPR_OUT_X(0),
		q_b		=> SPR_LINE_Q(0)
	);
	
	SPR_LINE_BUF1 : entity work.dpram generic map (9,9, SS_REG_BASE => 553)
	port map(
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_R_SPR_LINE_BUF1,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_WE => SS_M_SPR_LINE_BUF1_SEL,
SS_ADDR => SS_ADDR(8 downto 0), SS_DI => SS_DI(8 downto 0), SS_DO => SS_M_SPR_LINE_BUF1,

		clock		=> CLK,

		address_a=> SPR_LINE_ADDR(1),
		data_a	=> SPR_LINE_D(1),
		wren_a	=> SPR_LINE_WE(1),

		address_b=> std_logic_vector(SPR_OUT_X(9 downto 1)),
		wren_b	=> SPR_LINE_CLR and DCK_CE and SPR_OUT_X(0),
		q_b		=> SPR_LINE_Q(1)
	);

	process(CLK, RST_N)
	variable PX : unsigned(3 downto 0);
	variable GX,GY : unsigned(2 downto 0);
	variable SS_SH_VAR_PX : unsigned(3 downto 0);
begin
if rising_edge(CLK) then


SS_PROXY_12 <= SS_SH_VAR_PX;
end if;

if rising_edge(CLK) and SS_SAVE = '1' then
SS_SH_VAR_PX := PX;
end if;

		if RST_N = '0' then
			BG_OUT_X <= (others=>'0');
			BG_COLOR <= (others=>(others=>'0'));
			SPR_COLOR <= (others=>(others=>'0'));
			DISP <= (others=>'0');
			BORD <= (others=>'1');
			GRID_BG <= (others=>'0');
			GRID_SP <= (others=>'0');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
PX := unsigned(SS_CHAIN(6163 downto 6160));
BG_COLOR <= SS_SH_BG_COLOR;
BG_OUT_X <= SS_SH_BG_OUT_X;
BORD <= SS_SH_BORD;
DISP <= SS_SH_DISP;
GRID_BG <= SS_SH_GRID_BG;
GRID_SP <= SS_SH_GRID_SP;
SPR_COLOR <= SS_SH_SPR_COLOR;
elsif SS_FREEZE = '0' then

			if DCK_CE = '1' then
				BG_COLOR(7) <= (others=>'0');
				SPR_COLOR(7) <= (others=>'0');
				DISP(7) <= '0';
				BORD(7) <= '1';
				GRID_BG(7) <= '0';
				GRID_SP(7) <= '0';
				if HSYNC_F = '1' then
					BG_OUT_X <= (others=>'0');
				elsif BG_OUT = '1' and VDISP = '1' then
					PX := not (("0"&BG_OUT_X(2 downto 0)) + ("0"&unsigned(OFS_X(2 downto 0))));
					BG_COLOR(7) <= BG_SRC(to_integer(PX(3 downto 3))) & 
										BG_SR3(to_integer(PX(3 downto 0))) & 
										BG_SR2(to_integer(PX(3 downto 0))) & 
										BG_SR1(to_integer(PX(3 downto 0))) & 
										BG_SR0(to_integer(PX(3 downto 0)));
					SPR_COLOR(7) <= SPR_LINE_Q(to_integer(SPR_OUT_X(0 downto 0)));
					DISP(7) <= not BURST;
					BORD(7) <= '0';
					
					GX := BG_OUT_X(2 downto 0) + unsigned(OFS_X(2 downto 0));
					GY := OFS_Y(2 downto 0);
					if GX = 7 or GY = 7 then
						GRID_BG(7) <= '1';
					end if; 
					
					if SPR_TILE_FRAME(to_integer(unsigned(BG_OUT_X))) = '1' then
						GRID_SP(7) <= '1';
					end if; 
					
					BG_OUT_X <= BG_OUT_X + 1;
				end if; 
				
				for i in 0 to 6 loop
					BG_COLOR(i) <= BG_COLOR(i+1);
					SPR_COLOR(i) <= SPR_COLOR(i+1);
					DISP(i) <= DISP(i+1);
					BORD(i) <= BORD(i+1);
					GRID_BG(i) <= GRID_BG(i+1);
					GRID_SP(i) <= GRID_SP(i+1);
				end loop;
			end if; 
		
end if;
end if;
	end process;

	BORDER <= BORD(0);
	GRID <= GRID_SP(0)&GRID_BG(0);
	

	process(BG_OUT, DISP, BG_COLOR, SPR_COLOR, BB, SB, BG_EN, SPR_EN)
	begin
		if DISP(0) = '0' then
			VD <= "1"&x"00";
		elsif SPR_COLOR(0)(3 downto 0) /= "0000" and SPR_COLOR(0)(8) = '1' and SB = '1' and SPR_EN = '1' then
			VD <= "1" & SPR_COLOR(0)(7 downto 0);
		elsif BG_COLOR(0)(3 downto 0) /= "0000" and BB = '1' and BG_EN = '1' then
			VD <= "0" & BG_COLOR(0);
		elsif SPR_COLOR(0)(3 downto 0) /= "0000" and SPR_COLOR(0)(8) = '0' and SB = '1' and SPR_EN = '1' then
			VD <= "1" & SPR_COLOR(0)(7 downto 0);
		else
			VD <= "0"&x"00";
		end if; 
	end process;
		
	
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			AR <= (others=>'0');
			REGS <= (others=>(others=>'0'));
			
			CPURD_PEND <= '0';
			CPUWR_PEND <= '0';
			CPURD_PEND2 <= '0';
			CPUWR_PEND2 <= '0';
			DMA_PEND <= '0';
			DMAS_PEND <= '0';
			DMAS_SAT_ADDR <= (others=>'0');
			DMAS_VRAM_ADDR <= (others=>'0');
			CPU_BUSY <= '0';
			IRQ_DMA <= '0';
			IRQ_RCR <= '0';
			IRQ_DMAS <= '0';
			IRQ_VBL <= '0';
			IO_BYRL_SET <= '0';
			IO_BYRH_SET <= '0';
						
			CPURD_EXEC <= '0';
			CPUWR_EXEC <= '0';
			DMA_EXEC <= '0';
			DMAS_EXEC <= '0';
			DMA_WR <= '0';
			BYRL_SET <= '0';
			BYRH_SET <= '0';
			VDISP_OLD <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
AR <= SS_SH_AR;
BXR_SET <= SS_SH_BXR_SET;
BYRH_SET <= SS_SH_BYRH_SET;
BYRL_SET <= SS_SH_BYRL_SET;
CPURD_EXEC <= SS_SH_CPURD_EXEC;
CPURD_PEND <= SS_SH_CPURD_PEND;
CPURD_PEND2 <= SS_SH_CPURD_PEND2;
CPUWR_EXEC <= SS_SH_CPUWR_EXEC;
CPUWR_PEND <= SS_SH_CPUWR_PEND;
CPUWR_PEND2 <= SS_SH_CPUWR_PEND2;
CPU_BUSY <= SS_SH_CPU_BUSY;
CPU_BUSY_CLEAR <= SS_SH_CPU_BUSY_CLEAR;
CPU_VRAM_ADDR <= SS_SH_CPU_VRAM_ADDR;
CPU_VRAM_DATA <= SS_SH_CPU_VRAM_DATA;
DESR <= SS_SH_DESR;
DMAS_EXEC <= SS_SH_DMAS_EXEC;
DMAS_PEND <= SS_SH_DMAS_PEND;
DMAS_SAT_ADDR <= SS_SH_DMAS_SAT_ADDR;
DMAS_VRAM_ADDR <= SS_SH_DMAS_VRAM_ADDR;
DMA_BUF <= SS_SH_DMA_BUF;
DMA_EXEC <= SS_SH_DMA_EXEC;
DMA_PEND <= SS_SH_DMA_PEND;
DMA_WR <= SS_SH_DMA_WR;
IO_BYRH_SET <= SS_SH_IO_BYRH_SET;
IO_BYRH_WR <= SS_SH_IO_BYRH_WR;
IO_BYRL_SET <= SS_SH_IO_BYRL_SET;
IO_BYRL_WR <= SS_SH_IO_BYRL_WR;
IRQ_DMA <= SS_SH_IRQ_DMA;
IRQ_DMAS <= SS_SH_IRQ_DMAS;
IRQ_RCR <= SS_SH_IRQ_RCR;
IRQ_VBL <= SS_SH_IRQ_VBL;
LENR <= SS_SH_LENR;
MARR <= SS_SH_MARR;
MAWR <= SS_SH_MAWR;
REGS <= SS_SH_REGS;
SOUR <= SS_SH_SOUR;
VDISP_OLD <= SS_SH_VDISP_OLD;
VRR <= SS_SH_VRR;
elsif SS_FREEZE = '0' then

			IO_BYRL_WR <= '0';
			IO_BYRH_WR <= '0';
			if CS_N = '0' and WR_N = '0' and CPU_CE = '1' then
				case A(1) is
					when '0' =>
						if (BYTEWORD = '0' or A(0) = '0') then		-- if 16-bit access or 8-bit access to "00"
							AR <= DI(4 downto 0);
						end if;
						
					when '1' =>
						case AR is
							when "00000" =>
								if BYTEWORD = '0' then
									REGS(0)(15 downto 0) <= DI(15 downto 0);
								elsif A(0) = '0' then
									REGS(0)(7 downto 0) <= DI(7 downto 0);
								else
									REGS(0)(15 downto 8) <= DI(7 downto 0);
								end if;
							when "00001" =>
								if CPU_BUSY = '0' then
									if BYTEWORD = '0' then
										REGS(1)(15 downto 0) <= DI(15 downto 0);
										CPURD_PEND <= '1';
										CPU_BUSY <= '1';
									elsif A(0) = '0' then
										REGS(1)(7 downto 0) <= DI(7 downto 0);
									else
										REGS(1)(15 downto 8) <= DI(7 downto 0);
										CPURD_PEND <= '1';
										CPU_BUSY <= '1';
									end if;
								end if;
							when "00010" =>
								if CPU_BUSY = '0' then
									if BYTEWORD = '0' then
										REGS(2)(15 downto 0) <= DI(15 downto 0);
										CPUWR_PEND <= '1';
										CPU_BUSY <= '1';
									elsif A(0) = '0' then
										REGS(2)(7 downto 0) <= DI(7 downto 0);
									else
										REGS(2)(15 downto 8) <= DI(7 downto 0);
										CPUWR_PEND <= '1';
										CPU_BUSY <= '1';
									end if;
								end if;
							when "01000" =>
								if BYTEWORD = '0' then
									IO_BYRL_WR <= '1';
									IO_BYRH_WR <= '1';
								elsif A(0) = '0' then
									IO_BYRL_WR <= '1';
								else
									IO_BYRH_WR <= '1';
								end if;
							when "10010" =>
								if (BYTEWORD = '0' or A(0) = '1') then	-- if 16-bit access or 8-bit access to "11"
									DMA_PEND <= '1';
								end if;
							when "10011" =>
								if (BYTEWORD = '0' or A(0) = '1') then	-- if 16-bit access or 8-bit access to "11"
									DMAS_PEND <= '1';
								end if;
							when others => null;
						end case;
						if AR >= "00011" then
							if BYTEWORD = '0' then
								REGS(to_integer(unsigned(AR)))(15 downto 0) <= DI(15 downto 0);
							elsif A(0) = '0' then
								REGS(to_integer(unsigned(AR)))(7 downto 0) <= DI(7 downto 0);
							else
								REGS(to_integer(unsigned(AR)))(15 downto 8) <= DI(7 downto 0);
							end if;
						end if;
						
					when others => null;
				end case;
			elsif CS_N = '0' and RD_N = '0' and CPU_CE = '1' then
				case A(1) is
					when '0' =>
						if (BYTEWORD = '0' or A(0) = '0') then		-- if 16-bit access or 8-bit access to "00"
							if SR_LATCH(5) = '1' then
								IRQ_VBL <= '0';	
							end if;
							if SR_LATCH(4) = '1' then
								IRQ_DMA <= '0';
							end if;
							if SR_LATCH(3) = '1' then
								IRQ_DMAS <= '0';
							end if;
							if SR_LATCH(2) = '1' then
								IRQ_RCR <= '0';
							end if;
						end if;
					when '1' =>
						if (BYTEWORD = '0' or A(0) = '1') then		-- if 16-bit access or 8-bit access to "11"
							if AR = "0" & x"2" then
								CPURD_PEND <= '1';
								CPU_BUSY <= '1';						
							end if;
						end if;
					when others => null;
				end case;
			end if; 
			
			if IO_BYRL_WR = '1' then
				IO_BYRL_SET <= '1';
			end if; 
			if IO_BYRH_WR = '1' then
				IO_BYRH_SET <= '1';
			end if;
			
			if DCK_CE = '1' then
				if DOT_CNT(0) = '1' then
					if CPUWR_PEND = '1' then
						CPUWR_PEND <= '0';
						CPUWR_PEND2 <= '1';
					elsif CPUWR_PEND2 = '1' then
						CPUWR_PEND2 <= '0';
						CPU_VRAM_ADDR <= MAWR;
						CPU_VRAM_DATA <= VWR;
						case CR_IW is
							when "00" => MAWR <= std_logic_vector(unsigned(MAWR) + 1);
							when "01" => MAWR <= std_logic_vector(unsigned(MAWR) + 32);
							when "10" => MAWR <= std_logic_vector(unsigned(MAWR) + 64);
							when others => MAWR <= std_logic_vector(unsigned(MAWR) + 128);
						end case;
						CPUWR_EXEC <= '1';
					end if; 
					
					if CPURD_PEND = '1' then
						CPURD_PEND <= '0';
						CPURD_PEND2 <= '1';
					elsif CPURD_PEND2 = '1' then
						CPURD_PEND2 <= '0';
						CPU_VRAM_ADDR <= MARR;
						case CR_IW is
							when "00" => MARR <= std_logic_vector(unsigned(MARR) + 1);
							when "01" => MARR <= std_logic_vector(unsigned(MARR) + 32);
							when "10" => MARR <= std_logic_vector(unsigned(MARR) + 64);
							when others => MARR <= std_logic_vector(unsigned(MARR) + 128);
						end case;
						CPURD_EXEC <= '1';
					end if; 
				end if; 
				
				if DMA_PEND = '1' and (BURST = '1' or VDISP = '0') then
					DMA_PEND <= '0';
					DMA_EXEC <= '1';
				elsif DMA_EXEC = '1' and BURST = '0' and VDISP = '1' then
					DMA_EXEC <= '0';
				end if; 
			
				if SLOT = CPU then
					if DMAS_EXEC = '1' then
						DMAS_SAT_ADDR <= std_logic_vector(unsigned(DMAS_SAT_ADDR) + 1);
						DMAS_VRAM_ADDR <= std_logic_vector(unsigned(DMAS_VRAM_ADDR) + 1);
						if DMAS_SAT_ADDR = x"FF" then
							DMAS_EXEC <= '0';
							if DCR_DSC = '1' then 
								IRQ_DMAS <= '1';
							end if;
						end if;
					elsif DMA_EXEC = '1' then
						if DMA_WR = '0' then
							DMA_BUF <= RAM_DI;
							DMA_WR <= '1';
						else
							if DCR_SID = '0' then
								SOUR <= std_logic_vector(unsigned(SOUR) + 1);
							else
								SOUR <= std_logic_vector(unsigned(SOUR) - 1);
							end if;
							if DCR_DID = '0' then
								DESR <= std_logic_vector(unsigned(DESR) + 1);
							else
								DESR <= std_logic_vector(unsigned(DESR) - 1);
							end if;
							LENR <= std_logic_vector(unsigned(LENR) - 1);
							if LENR = x"0000" then
								DMA_EXEC <= '0';
								if DCR_DVC = '1' then 
									IRQ_DMA <= '1';
								end if;
							end if;
							DMA_WR <= '0';
						end if;
					elsif CPUWR_EXEC = '1' then
						CPUWR_EXEC <= '0';
						CPU_BUSY_CLEAR <= '1';
					elsif CPURD_EXEC = '1' then
						CPURD_EXEC <= '0';
						VRR <= RAM_DI;
						CPU_BUSY_CLEAR <= '1';
					end if;
				end if;
				
				if CPU_BUSY_CLEAR = '1' then
					CPU_BUSY_CLEAR <= '0';
					CPU_BUSY <= '0';
				end if;
				
				if TILE_CNT = HDS_END_POS - 2 and DOT_CNT = 7 then
					VDISP_OLD <= VDISP;
					if VDISP = '0' and VDISP_OLD = '1' then
						if CR_IE_VC = '1' then
							IRQ_VBL <= '1';
						end if;
						if DCR_DSR = '1' or DMAS_PEND = '1' then
							DMAS_PEND <= '0';
							DMAS_VRAM_ADDR <= DVSSR;
							DMAS_SAT_ADDR <= (others=>'0');
							DMAS_EXEC <= '1';
						end if;
					end if;
				end if;
				
				if TILE_CNT = HDISP_END_POS and DOT_CNT = 1 and RC_CNT = unsigned(RCR) and CR_IE_RC = '1' then
					IRQ_RCR <= '1';
				end if;
				
				if TILE_CNT = HDS_END_POS - 3 and DOT_CNT = 7 then
					BXR_SET <= '1';
				else 
					BXR_SET <= '0';
				end if; 
				
				if TILE_CNT = HDS_END_POS - 3 and DOT_CNT = 7 then
					BYRL_SET <= '0';
					BYRH_SET <= '0';
				end if;
			end if;
				
			if DCK_CE_F = '1' then
				--sync BYRx latches to dot clock
				if IO_BYRL_SET = '1' then
					IO_BYRL_SET <= '0';
					BYRL_SET <= '1';
				end if; 
				
				if IO_BYRH_SET = '1' then
					IO_BYRH_SET <= '0';
					BYRH_SET <= '1';
				end if;
			end if;
		
end if;
end if;
	end process;
	
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			SR_LATCH <= (others=>'0');
			RD_N_OLD <= '1';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
RD_N_OLD <= SS_SH_RD_N_OLD;
SR_LATCH <= SS_SH_SR_LATCH;
elsif SS_FREEZE = '0' then

			RD_N_OLD <= RD_N;
			if RD_N = '0' and RD_N_OLD = '1' then
				SR_LATCH <= CPU_BUSY & IRQ_VBL & IRQ_DMA & IRQ_DMAS & IRQ_RCR & IRQ_OVF & IRQ_COL;
			end if;
		
end if;
end if;
	end process;

	process(A, BYTEWORD, SR_LATCH, VRR)
	begin
		DO <= x"0000";
		case A(1) is
			when '0' =>
				DO <= "000000000" & SR_LATCH;
			when '1' =>
				DO <= VRR(15 downto 0);
				if (BYTEWORD = '1' and A(0) = '1') then
					DO <= "00000000"  & VRR(15 downto 8);
				end if;
			when others => null;
		end case;
	end process;
	
	IRQ_N <= not (IRQ_COL or IRQ_OVF or IRQ_RCR or IRQ_DMAS or IRQ_DMA or IRQ_VBL);
	BUSY_N <= '0' when CPU_BUSY = '1' and CS_N = '0' and (RD_N = '0' or WR_N = '0') and A(1) = '1' and (AR = "00010" or AR = "00001" or AR = "00000") else '1';
	
		
	process(SLOT, BG_RAM_ADDR, SPR_RAM_ADDR, DCK_CE, DMAS_VRAM_ADDR, DMAS_EXEC, DMA_EXEC, DMA_WR, SOUR, DESR, DMA_BUF, CPUWR_EXEC, CPU_VRAM_ADDR, CPU_VRAM_DATA)
	begin
		RAM_DO <= x"0000";
		RAM_WE <= '0';
		case SLOT is
			when BAT | CG0 | CG1 =>
				RAM_A <= BG_RAM_ADDR;
			when SG0 | SG1 | SG2 | SG3 =>
				RAM_A <= SPR_RAM_ADDR;
			when CPU =>
				if DMAS_EXEC = '1' then
					RAM_A <= DMAS_VRAM_ADDR;
				elsif DMA_EXEC = '1' then
					if DMA_WR = '0' then
						RAM_A <= SOUR;
					else
						RAM_A <= DESR;
						RAM_DO <= DMA_BUF;
						RAM_WE <= DCK_CE;
					end if;
				elsif CPUWR_EXEC = '1' then
					RAM_A <= CPU_VRAM_ADDR;
					RAM_DO <= CPU_VRAM_DATA;
					RAM_WE <= DCK_CE;
				else
					RAM_A <= CPU_VRAM_ADDR;
				end if; 
			when others =>
				RAM_A <= x"0000";
		end case;
	end process;
	
	IW_DBG <= CR_IW;
	VM_DBG <= VM;
	CM_DBG <= CM;
	SCREEN_DBG <= SCREEN;
	SOUR_DBG <= SOUR;
	DESR_DBG <= DESR;
	LENR_DBG <= LENR;
	
	SPR_X_DBG <= SPR.X;
	SPR_Y_DBG <= SPR.Y;
	SPR_PC_DBG <= SPR.PC;
	SPR_CG_DBG <= SPR.CG;
	SPR_PAL_DBG <= SPR.PAL;
	SPR_PRIO_DBG <= SPR.PRIO;
	SPR_CGX_DBG <= SPR.CGX;
	SPR_CGY_DBG <= SPR.CGY;
	SPR_HF_DBG <= SPR.HF;
	SPR_VF_DBG <= SPR.VF;
	
	HSW_END_POS_DBG <= HSW_END_POS;
	HDS_END_POS_DBG <= HDS_END_POS;
	HDISP_END_POS_DBG <= HDISP_END_POS;
	HSW_DBG <= HSW;
	HDS_DBG <= HDS;
	HDE_DBG <= HDE;
	
	VDS_END_POS_DBG <= VDS_END_POS;
	VDISP_END_POS_DBG <= VDISP_END_POS;
	VDE_END_POS_DBG <= VDE_END_POS;
	
SS_M_SAT_SEL <= SS_WE when SS_ADDR(17 downto 15) = "010" else '0';
SS_M_SPR_LINE_BUF0_SEL <= SS_WE when SS_ADDR(17 downto 15) = "011" else '0';
SS_M_SPR_LINE_BUF1_SEL <= SS_WE when SS_ADDR(17 downto 15) = "100" else '0';

SS_DO <= std_logic_vector(resize(unsigned(SS_M_SAT),16)) when SS_ADDR(17 downto 15) = "010" else std_logic_vector(resize(unsigned(SS_M_SPR_LINE_BUF0),16)) when SS_ADDR(17 downto 15) = "011" else std_logic_vector(resize(unsigned(SS_M_SPR_LINE_BUF1),16)) when SS_ADDR(17 downto 15) = "100" else (others => '0');

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 12 and to_integer(unsigned(SS_RADDR)) <= 397 else (others => '0');
SS_CAPTURE_DATA(4 downto 0) <= std_logic_vector(AR(4 downto 0));
SS_CAPTURE_DATA(5) <= BB;
SS_CAPTURE_DATA(15 downto 6) <= std_logic_vector(BG_BAT_CC(9 downto 0));
SS_CAPTURE_DATA(17 downto 16) <= std_logic_vector(BG_BAT_CC(11 downto 10));
SS_CAPTURE_DATA(21 downto 18) <= std_logic_vector(BG_BAT_COL(3 downto 0));
SS_CAPTURE_DATA(29 downto 22) <= std_logic_vector(BG_CH0(7 downto 0));
SS_CAPTURE_DATA(31 downto 30) <= std_logic_vector(BG_CH1(1 downto 0));
SS_CAPTURE_DATA(37 downto 32) <= std_logic_vector(BG_CH1(7 downto 2));
SS_CAPTURE_DATA(45 downto 38) <= std_logic_vector(BG_COLOR(0)(7 downto 0));
SS_CAPTURE_DATA(47 downto 46) <= std_logic_vector(BG_COLOR(1)(1 downto 0));
SS_CAPTURE_DATA(53 downto 48) <= std_logic_vector(BG_COLOR(1)(7 downto 2));
SS_CAPTURE_DATA(61 downto 54) <= std_logic_vector(BG_COLOR(2)(7 downto 0));
SS_CAPTURE_DATA(63 downto 62) <= std_logic_vector(BG_COLOR(3)(1 downto 0));
SS_CAPTURE_DATA(69 downto 64) <= std_logic_vector(BG_COLOR(3)(7 downto 2));
SS_CAPTURE_DATA(77 downto 70) <= std_logic_vector(BG_COLOR(4)(7 downto 0));
SS_CAPTURE_DATA(79 downto 78) <= std_logic_vector(BG_COLOR(5)(1 downto 0));
SS_CAPTURE_DATA(85 downto 80) <= std_logic_vector(BG_COLOR(5)(7 downto 2));
SS_CAPTURE_DATA(93 downto 86) <= std_logic_vector(BG_COLOR(6)(7 downto 0));
SS_CAPTURE_DATA(95 downto 94) <= std_logic_vector(BG_COLOR(7)(1 downto 0));
SS_CAPTURE_DATA(101 downto 96) <= std_logic_vector(BG_COLOR(7)(7 downto 2));
SS_CAPTURE_DATA(102) <= BG_FETCH;
SS_CAPTURE_DATA(103) <= BG_OUT;
SS_CAPTURE_DATA(111 downto 104) <= std_logic_vector(BG_OUT_X(7 downto 0));
SS_CAPTURE_DATA(113 downto 112) <= std_logic_vector(BG_OUT_X(9 downto 8));
SS_CAPTURE_DATA(127 downto 114) <= std_logic_vector(BG_SR0(13 downto 0));
SS_CAPTURE_DATA(129 downto 128) <= std_logic_vector(BG_SR0(15 downto 14));
SS_CAPTURE_DATA(143 downto 130) <= std_logic_vector(BG_SR1(13 downto 0));
SS_CAPTURE_DATA(145 downto 144) <= std_logic_vector(BG_SR1(15 downto 14));
SS_CAPTURE_DATA(159 downto 146) <= std_logic_vector(BG_SR2(13 downto 0));
SS_CAPTURE_DATA(161 downto 160) <= std_logic_vector(BG_SR2(15 downto 14));
SS_CAPTURE_DATA(175 downto 162) <= std_logic_vector(BG_SR3(13 downto 0));
SS_CAPTURE_DATA(177 downto 176) <= std_logic_vector(BG_SR3(15 downto 14));
SS_CAPTURE_DATA(181 downto 178) <= std_logic_vector(BG_SRC(0)(3 downto 0));
SS_CAPTURE_DATA(185 downto 182) <= std_logic_vector(BG_SRC(1)(3 downto 0));
SS_CAPTURE_DATA(191 downto 186) <= std_logic_vector(BG_X(5 downto 0));
SS_CAPTURE_DATA(195 downto 192) <= std_logic_vector(BG_X(9 downto 6));
SS_CAPTURE_DATA(203 downto 196) <= std_logic_vector(BORD(7 downto 0));
SS_CAPTURE_DATA(204) <= BURST;
SS_CAPTURE_DATA(205) <= BXR_SET;
SS_CAPTURE_DATA(206) <= BYRH_SET;
SS_CAPTURE_DATA(207) <= BYRL_SET;
SS_CAPTURE_DATA(215 downto 208) <= std_logic_vector(CLR_A(7 downto 0));
SS_CAPTURE_DATA(216) <= CLR_WE;
SS_CAPTURE_DATA(217) <= CM;
SS_CAPTURE_DATA(218) <= CPURD_EXEC;
SS_CAPTURE_DATA(219) <= CPURD_PEND;
SS_CAPTURE_DATA(220) <= CPURD_PEND2;
SS_CAPTURE_DATA(221) <= CPUWR_EXEC;
SS_CAPTURE_DATA(222) <= CPUWR_PEND;
SS_CAPTURE_DATA(223) <= CPUWR_PEND2;
SS_CAPTURE_DATA(224) <= CPU_BUSY;
SS_CAPTURE_DATA(225) <= CPU_BUSY_CLEAR;
SS_CAPTURE_DATA(239 downto 226) <= std_logic_vector(CPU_VRAM_ADDR(13 downto 0));
SS_CAPTURE_DATA(241 downto 240) <= std_logic_vector(CPU_VRAM_ADDR(15 downto 14));
SS_CAPTURE_DATA(255 downto 242) <= std_logic_vector(CPU_VRAM_DATA(13 downto 0));
SS_CAPTURE_DATA(257 downto 256) <= std_logic_vector(CPU_VRAM_DATA(15 downto 14));
SS_CAPTURE_DATA(271 downto 258) <= std_logic_vector(DESR(13 downto 0));
SS_CAPTURE_DATA(273 downto 272) <= std_logic_vector(DESR(15 downto 14));
SS_CAPTURE_DATA(281 downto 274) <= std_logic_vector(DISP(7 downto 0));
SS_CAPTURE_DATA(282) <= DISP_BREAK_EN;
SS_CAPTURE_DATA(283) <= DISP_BREAK_LATCH;
SS_CAPTURE_DATA(287 downto 284) <= std_logic_vector(DISP_CNT(3 downto 0));
SS_CAPTURE_DATA(293 downto 288) <= std_logic_vector(DISP_CNT(9 downto 4));
SS_CAPTURE_DATA(294) <= DISP_CNT_INC;
SS_CAPTURE_DATA(295) <= DMAS_EXEC;
SS_CAPTURE_DATA(296) <= DMAS_PEND;
SS_CAPTURE_DATA(303 downto 297) <= std_logic_vector(DMAS_SAT_ADDR(6 downto 0));
SS_CAPTURE_DATA(304 downto 304) <= std_logic_vector(DMAS_SAT_ADDR(7 downto 7));
SS_CAPTURE_DATA(319 downto 305) <= std_logic_vector(DMAS_VRAM_ADDR(14 downto 0));
SS_CAPTURE_DATA(320 downto 320) <= std_logic_vector(DMAS_VRAM_ADDR(15 downto 15));
SS_CAPTURE_DATA(335 downto 321) <= std_logic_vector(DMA_BUF(14 downto 0));
SS_CAPTURE_DATA(336 downto 336) <= std_logic_vector(DMA_BUF(15 downto 15));
SS_CAPTURE_DATA(337) <= DMA_EXEC;
SS_CAPTURE_DATA(338) <= DMA_PEND;
SS_CAPTURE_DATA(339) <= DMA_WR;
SS_CAPTURE_DATA(342 downto 340) <= std_logic_vector(DOTS_REMAIN(2 downto 0));
SS_CAPTURE_DATA(345 downto 343) <= std_logic_vector(DOT_CNT(2 downto 0));
SS_CAPTURE_DATA(346) <= FETCH_CE;
SS_CAPTURE_DATA(349 downto 347) <= std_logic_vector(FETCH_DOT(2 downto 0));
SS_CAPTURE_DATA(351 downto 350) <= std_logic_vector(GRID_BG(1 downto 0));
SS_CAPTURE_DATA(357 downto 352) <= std_logic_vector(GRID_BG(7 downto 2));
SS_CAPTURE_DATA(365 downto 358) <= std_logic_vector(GRID_SP(7 downto 0));
SS_CAPTURE_DATA(367 downto 366) <= std_logic_vector(HDE(1 downto 0));
SS_CAPTURE_DATA(372 downto 368) <= std_logic_vector(HDE(6 downto 2));
SS_CAPTURE_DATA(379 downto 373) <= std_logic_vector(HDS(6 downto 0));
SS_CAPTURE_DATA(383 downto 380) <= std_logic_vector(HDW(3 downto 0));
SS_CAPTURE_DATA(386 downto 384) <= std_logic_vector(HDW(6 downto 4));
SS_CAPTURE_DATA(391 downto 387) <= std_logic_vector(HSW(4 downto 0));
SS_CAPTURE_DATA(392) <= IO_BYRH_SET;
SS_CAPTURE_DATA(393) <= IO_BYRH_WR;
SS_CAPTURE_DATA(394) <= IO_BYRL_SET;
SS_CAPTURE_DATA(395) <= IO_BYRL_WR;
SS_CAPTURE_DATA(396) <= IRQ_COL;
SS_CAPTURE_DATA(397) <= IRQ_DMA;
SS_CAPTURE_DATA(398) <= IRQ_DMAS;
SS_CAPTURE_DATA(399) <= IRQ_OVF;
SS_CAPTURE_DATA(400) <= IRQ_RCR;
SS_CAPTURE_DATA(401) <= IRQ_VBL;
SS_CAPTURE_DATA(415 downto 402) <= std_logic_vector(LENR(13 downto 0));
SS_CAPTURE_DATA(417 downto 416) <= std_logic_vector(LENR(15 downto 14));
SS_CAPTURE_DATA(431 downto 418) <= std_logic_vector(MARR(13 downto 0));
SS_CAPTURE_DATA(433 downto 432) <= std_logic_vector(MARR(15 downto 14));
SS_CAPTURE_DATA(447 downto 434) <= std_logic_vector(MAWR(13 downto 0));
SS_CAPTURE_DATA(449 downto 448) <= std_logic_vector(MAWR(15 downto 14));
SS_CAPTURE_DATA(459 downto 450) <= std_logic_vector(OFS_X(9 downto 0));
SS_CAPTURE_DATA(463 downto 460) <= std_logic_vector(OFS_Y(3 downto 0));
SS_CAPTURE_DATA(468 downto 464) <= std_logic_vector(OFS_Y(8 downto 4));
SS_CAPTURE_DATA(478 downto 469) <= std_logic_vector(RC_CNT(9 downto 0));
SS_CAPTURE_DATA(479) <= RD_N_OLD;
SS_CAPTURE_DATA(495 downto 480) <= std_logic_vector(REGS(0)(15 downto 0));
SS_CAPTURE_DATA(511 downto 496) <= std_logic_vector(REGS(1)(15 downto 0));
SS_CAPTURE_DATA(527 downto 512) <= std_logic_vector(REGS(2)(15 downto 0));
SS_CAPTURE_DATA(543 downto 528) <= std_logic_vector(REGS(3)(15 downto 0));
SS_CAPTURE_DATA(559 downto 544) <= std_logic_vector(REGS(4)(15 downto 0));
SS_CAPTURE_DATA(575 downto 560) <= std_logic_vector(REGS(5)(15 downto 0));
SS_CAPTURE_DATA(591 downto 576) <= std_logic_vector(REGS(6)(15 downto 0));
SS_CAPTURE_DATA(607 downto 592) <= std_logic_vector(REGS(7)(15 downto 0));
SS_CAPTURE_DATA(623 downto 608) <= std_logic_vector(REGS(8)(15 downto 0));
SS_CAPTURE_DATA(639 downto 624) <= std_logic_vector(REGS(9)(15 downto 0));
SS_CAPTURE_DATA(655 downto 640) <= std_logic_vector(REGS(10)(15 downto 0));
SS_CAPTURE_DATA(671 downto 656) <= std_logic_vector(REGS(11)(15 downto 0));
SS_CAPTURE_DATA(687 downto 672) <= std_logic_vector(REGS(12)(15 downto 0));
SS_CAPTURE_DATA(703 downto 688) <= std_logic_vector(REGS(13)(15 downto 0));
SS_CAPTURE_DATA(719 downto 704) <= std_logic_vector(REGS(14)(15 downto 0));
SS_CAPTURE_DATA(735 downto 720) <= std_logic_vector(REGS(15)(15 downto 0));
SS_CAPTURE_DATA(751 downto 736) <= std_logic_vector(REGS(16)(15 downto 0));
SS_CAPTURE_DATA(767 downto 752) <= std_logic_vector(REGS(17)(15 downto 0));
SS_CAPTURE_DATA(783 downto 768) <= std_logic_vector(REGS(18)(15 downto 0));
SS_CAPTURE_DATA(799 downto 784) <= std_logic_vector(REGS(19)(15 downto 0));
SS_CAPTURE_DATA(815 downto 800) <= std_logic_vector(REGS(20)(15 downto 0));
SS_CAPTURE_DATA(831 downto 816) <= std_logic_vector(REGS(21)(15 downto 0));
SS_CAPTURE_DATA(847 downto 832) <= std_logic_vector(REGS(22)(15 downto 0));
SS_CAPTURE_DATA(863 downto 848) <= std_logic_vector(REGS(23)(15 downto 0));
SS_CAPTURE_DATA(879 downto 864) <= std_logic_vector(REGS(24)(15 downto 0));
SS_CAPTURE_DATA(895 downto 880) <= std_logic_vector(REGS(25)(15 downto 0));
SS_CAPTURE_DATA(911 downto 896) <= std_logic_vector(REGS(26)(15 downto 0));
SS_CAPTURE_DATA(927 downto 912) <= std_logic_vector(REGS(27)(15 downto 0));
SS_CAPTURE_DATA(943 downto 928) <= std_logic_vector(REGS(28)(15 downto 0));
SS_CAPTURE_DATA(959 downto 944) <= std_logic_vector(REGS(29)(15 downto 0));
SS_CAPTURE_DATA(975 downto 960) <= std_logic_vector(REGS(30)(15 downto 0));
SS_CAPTURE_DATA(991 downto 976) <= std_logic_vector(REGS(31)(15 downto 0));
SS_CAPTURE_DATA(992 downto 992) <= std_logic_vector(RES7M(0 downto 0));
SS_CAPTURE_DATA(993) <= SB;
SS_CAPTURE_DATA(996 downto 994) <= std_logic_vector(SCREEN(2 downto 0));
SS_CAPTURE_DATA(998 downto 997) <= std_logic_vector(SM(1 downto 0));
SS_CAPTURE_DATA(1007 downto 999) <= std_logic_vector(SOUR(8 downto 0));
SS_CAPTURE_DATA(1014 downto 1008) <= std_logic_vector(SOUR(15 downto 9));
SS_CAPTURE_DATA(1023 downto 1015) <= std_logic_vector(SPR_CACHE(0).X(8 downto 0));
SS_CAPTURE_DATA(1024 downto 1024) <= std_logic_vector(SPR_CACHE(0).X(9 downto 9));
SS_CAPTURE_DATA(1034 downto 1025) <= std_logic_vector(SPR_CACHE(0).Y(9 downto 0));
SS_CAPTURE_DATA(1039 downto 1035) <= std_logic_vector(SPR_CACHE(0).PC(4 downto 0));
SS_CAPTURE_DATA(1045 downto 1040) <= std_logic_vector(SPR_CACHE(0).PC(10 downto 5));
SS_CAPTURE_DATA(1046) <= SPR_CACHE(0).CG;
SS_CAPTURE_DATA(1050 downto 1047) <= std_logic_vector(SPR_CACHE(0).PAL(3 downto 0));
SS_CAPTURE_DATA(1051) <= SPR_CACHE(0).PRIO;
SS_CAPTURE_DATA(1052) <= SPR_CACHE(0).CGX;
SS_CAPTURE_DATA(1054 downto 1053) <= std_logic_vector(SPR_CACHE(0).CGY(1 downto 0));
SS_CAPTURE_DATA(1055) <= SPR_CACHE(0).HF;
SS_CAPTURE_DATA(1056) <= SPR_CACHE(0).VF;
SS_CAPTURE_DATA(1057) <= SPR_CACHE(0).SPR0;
SS_CAPTURE_DATA(1058) <= SPR_CACHE(0).TOP;
SS_CAPTURE_DATA(1059) <= SPR_CACHE(0).BOTTOM;
SS_CAPTURE_DATA(1069 downto 1060) <= std_logic_vector(SPR_CACHE(1).X(9 downto 0));
SS_CAPTURE_DATA(1071 downto 1070) <= std_logic_vector(SPR_CACHE(1).Y(1 downto 0));
SS_CAPTURE_DATA(1079 downto 1072) <= std_logic_vector(SPR_CACHE(1).Y(9 downto 2));
SS_CAPTURE_DATA(1087 downto 1080) <= std_logic_vector(SPR_CACHE(1).PC(7 downto 0));
SS_CAPTURE_DATA(1090 downto 1088) <= std_logic_vector(SPR_CACHE(1).PC(10 downto 8));
SS_CAPTURE_DATA(1091) <= SPR_CACHE(1).CG;
SS_CAPTURE_DATA(1095 downto 1092) <= std_logic_vector(SPR_CACHE(1).PAL(3 downto 0));
SS_CAPTURE_DATA(1096) <= SPR_CACHE(1).PRIO;
SS_CAPTURE_DATA(1097) <= SPR_CACHE(1).CGX;
SS_CAPTURE_DATA(1099 downto 1098) <= std_logic_vector(SPR_CACHE(1).CGY(1 downto 0));
SS_CAPTURE_DATA(1100) <= SPR_CACHE(1).HF;
SS_CAPTURE_DATA(1101) <= SPR_CACHE(1).VF;
SS_CAPTURE_DATA(1102) <= SPR_CACHE(1).SPR0;
SS_CAPTURE_DATA(1103) <= SPR_CACHE(1).TOP;
SS_CAPTURE_DATA(1104) <= SPR_CACHE(1).BOTTOM;
SS_CAPTURE_DATA(1114 downto 1105) <= std_logic_vector(SPR_CACHE(2).X(9 downto 0));
SS_CAPTURE_DATA(1119 downto 1115) <= std_logic_vector(SPR_CACHE(2).Y(4 downto 0));
SS_CAPTURE_DATA(1124 downto 1120) <= std_logic_vector(SPR_CACHE(2).Y(9 downto 5));
SS_CAPTURE_DATA(1135 downto 1125) <= std_logic_vector(SPR_CACHE(2).PC(10 downto 0));
SS_CAPTURE_DATA(1136) <= SPR_CACHE(2).CG;
SS_CAPTURE_DATA(1140 downto 1137) <= std_logic_vector(SPR_CACHE(2).PAL(3 downto 0));
SS_CAPTURE_DATA(1141) <= SPR_CACHE(2).PRIO;
SS_CAPTURE_DATA(1142) <= SPR_CACHE(2).CGX;
SS_CAPTURE_DATA(1144 downto 1143) <= std_logic_vector(SPR_CACHE(2).CGY(1 downto 0));
SS_CAPTURE_DATA(1145) <= SPR_CACHE(2).HF;
SS_CAPTURE_DATA(1146) <= SPR_CACHE(2).VF;
SS_CAPTURE_DATA(1147) <= SPR_CACHE(2).SPR0;
SS_CAPTURE_DATA(1148) <= SPR_CACHE(2).TOP;
SS_CAPTURE_DATA(1149) <= SPR_CACHE(2).BOTTOM;
SS_CAPTURE_DATA(1151 downto 1150) <= std_logic_vector(SPR_CACHE(3).X(1 downto 0));
SS_CAPTURE_DATA(1159 downto 1152) <= std_logic_vector(SPR_CACHE(3).X(9 downto 2));
SS_CAPTURE_DATA(1167 downto 1160) <= std_logic_vector(SPR_CACHE(3).Y(7 downto 0));
SS_CAPTURE_DATA(1169 downto 1168) <= std_logic_vector(SPR_CACHE(3).Y(9 downto 8));
SS_CAPTURE_DATA(1180 downto 1170) <= std_logic_vector(SPR_CACHE(3).PC(10 downto 0));
SS_CAPTURE_DATA(1181) <= SPR_CACHE(3).CG;
SS_CAPTURE_DATA(1183 downto 1182) <= std_logic_vector(SPR_CACHE(3).PAL(1 downto 0));
SS_CAPTURE_DATA(1185 downto 1184) <= std_logic_vector(SPR_CACHE(3).PAL(3 downto 2));
SS_CAPTURE_DATA(1186) <= SPR_CACHE(3).PRIO;
SS_CAPTURE_DATA(1187) <= SPR_CACHE(3).CGX;
SS_CAPTURE_DATA(1189 downto 1188) <= std_logic_vector(SPR_CACHE(3).CGY(1 downto 0));
SS_CAPTURE_DATA(1190) <= SPR_CACHE(3).HF;
SS_CAPTURE_DATA(1191) <= SPR_CACHE(3).VF;
SS_CAPTURE_DATA(1192) <= SPR_CACHE(3).SPR0;
SS_CAPTURE_DATA(1193) <= SPR_CACHE(3).TOP;
SS_CAPTURE_DATA(1194) <= SPR_CACHE(3).BOTTOM;
SS_CAPTURE_DATA(1199 downto 1195) <= std_logic_vector(SPR_CACHE(4).X(4 downto 0));
SS_CAPTURE_DATA(1204 downto 1200) <= std_logic_vector(SPR_CACHE(4).X(9 downto 5));
SS_CAPTURE_DATA(1214 downto 1205) <= std_logic_vector(SPR_CACHE(4).Y(9 downto 0));
SS_CAPTURE_DATA(1215 downto 1215) <= std_logic_vector(SPR_CACHE(4).PC(0 downto 0));
SS_CAPTURE_DATA(1225 downto 1216) <= std_logic_vector(SPR_CACHE(4).PC(10 downto 1));
SS_CAPTURE_DATA(1226) <= SPR_CACHE(4).CG;
SS_CAPTURE_DATA(1230 downto 1227) <= std_logic_vector(SPR_CACHE(4).PAL(3 downto 0));
SS_CAPTURE_DATA(1231) <= SPR_CACHE(4).PRIO;
SS_CAPTURE_DATA(1232) <= SPR_CACHE(4).CGX;
SS_CAPTURE_DATA(1234 downto 1233) <= std_logic_vector(SPR_CACHE(4).CGY(1 downto 0));
SS_CAPTURE_DATA(1235) <= SPR_CACHE(4).HF;
SS_CAPTURE_DATA(1236) <= SPR_CACHE(4).VF;
SS_CAPTURE_DATA(1237) <= SPR_CACHE(4).SPR0;
SS_CAPTURE_DATA(1238) <= SPR_CACHE(4).TOP;
SS_CAPTURE_DATA(1239) <= SPR_CACHE(4).BOTTOM;
SS_CAPTURE_DATA(1247 downto 1240) <= std_logic_vector(SPR_CACHE(5).X(7 downto 0));
SS_CAPTURE_DATA(1249 downto 1248) <= std_logic_vector(SPR_CACHE(5).X(9 downto 8));
SS_CAPTURE_DATA(1259 downto 1250) <= std_logic_vector(SPR_CACHE(5).Y(9 downto 0));
SS_CAPTURE_DATA(1263 downto 1260) <= std_logic_vector(SPR_CACHE(5).PC(3 downto 0));
SS_CAPTURE_DATA(1270 downto 1264) <= std_logic_vector(SPR_CACHE(5).PC(10 downto 4));
SS_CAPTURE_DATA(1271) <= SPR_CACHE(5).CG;
SS_CAPTURE_DATA(1275 downto 1272) <= std_logic_vector(SPR_CACHE(5).PAL(3 downto 0));
SS_CAPTURE_DATA(1276) <= SPR_CACHE(5).PRIO;
SS_CAPTURE_DATA(1277) <= SPR_CACHE(5).CGX;
SS_CAPTURE_DATA(1279 downto 1278) <= std_logic_vector(SPR_CACHE(5).CGY(1 downto 0));
SS_CAPTURE_DATA(1280) <= SPR_CACHE(5).HF;
SS_CAPTURE_DATA(1281) <= SPR_CACHE(5).VF;
SS_CAPTURE_DATA(1282) <= SPR_CACHE(5).SPR0;
SS_CAPTURE_DATA(1283) <= SPR_CACHE(5).TOP;
SS_CAPTURE_DATA(1284) <= SPR_CACHE(5).BOTTOM;
SS_CAPTURE_DATA(1294 downto 1285) <= std_logic_vector(SPR_CACHE(6).X(9 downto 0));
SS_CAPTURE_DATA(1295 downto 1295) <= std_logic_vector(SPR_CACHE(6).Y(0 downto 0));
SS_CAPTURE_DATA(1304 downto 1296) <= std_logic_vector(SPR_CACHE(6).Y(9 downto 1));
SS_CAPTURE_DATA(1311 downto 1305) <= std_logic_vector(SPR_CACHE(6).PC(6 downto 0));
SS_CAPTURE_DATA(1315 downto 1312) <= std_logic_vector(SPR_CACHE(6).PC(10 downto 7));
SS_CAPTURE_DATA(1316) <= SPR_CACHE(6).CG;
SS_CAPTURE_DATA(1320 downto 1317) <= std_logic_vector(SPR_CACHE(6).PAL(3 downto 0));
SS_CAPTURE_DATA(1321) <= SPR_CACHE(6).PRIO;
SS_CAPTURE_DATA(1322) <= SPR_CACHE(6).CGX;
SS_CAPTURE_DATA(1324 downto 1323) <= std_logic_vector(SPR_CACHE(6).CGY(1 downto 0));
SS_CAPTURE_DATA(1325) <= SPR_CACHE(6).HF;
SS_CAPTURE_DATA(1326) <= SPR_CACHE(6).VF;
SS_CAPTURE_DATA(1327) <= SPR_CACHE(6).SPR0;
SS_CAPTURE_DATA(1328) <= SPR_CACHE(6).TOP;
SS_CAPTURE_DATA(1329) <= SPR_CACHE(6).BOTTOM;
SS_CAPTURE_DATA(1339 downto 1330) <= std_logic_vector(SPR_CACHE(7).X(9 downto 0));
SS_CAPTURE_DATA(1343 downto 1340) <= std_logic_vector(SPR_CACHE(7).Y(3 downto 0));
SS_CAPTURE_DATA(1349 downto 1344) <= std_logic_vector(SPR_CACHE(7).Y(9 downto 4));
SS_CAPTURE_DATA(1359 downto 1350) <= std_logic_vector(SPR_CACHE(7).PC(9 downto 0));
SS_CAPTURE_DATA(1360 downto 1360) <= std_logic_vector(SPR_CACHE(7).PC(10 downto 10));
SS_CAPTURE_DATA(1361) <= SPR_CACHE(7).CG;
SS_CAPTURE_DATA(1365 downto 1362) <= std_logic_vector(SPR_CACHE(7).PAL(3 downto 0));
SS_CAPTURE_DATA(1366) <= SPR_CACHE(7).PRIO;
SS_CAPTURE_DATA(1367) <= SPR_CACHE(7).CGX;
SS_CAPTURE_DATA(1369 downto 1368) <= std_logic_vector(SPR_CACHE(7).CGY(1 downto 0));
SS_CAPTURE_DATA(1370) <= SPR_CACHE(7).HF;
SS_CAPTURE_DATA(1371) <= SPR_CACHE(7).VF;
SS_CAPTURE_DATA(1372) <= SPR_CACHE(7).SPR0;
SS_CAPTURE_DATA(1373) <= SPR_CACHE(7).TOP;
SS_CAPTURE_DATA(1374) <= SPR_CACHE(7).BOTTOM;
SS_CAPTURE_DATA(1375 downto 1375) <= std_logic_vector(SPR_CACHE(8).X(0 downto 0));
SS_CAPTURE_DATA(1384 downto 1376) <= std_logic_vector(SPR_CACHE(8).X(9 downto 1));
SS_CAPTURE_DATA(1391 downto 1385) <= std_logic_vector(SPR_CACHE(8).Y(6 downto 0));
SS_CAPTURE_DATA(1394 downto 1392) <= std_logic_vector(SPR_CACHE(8).Y(9 downto 7));
SS_CAPTURE_DATA(1405 downto 1395) <= std_logic_vector(SPR_CACHE(8).PC(10 downto 0));
SS_CAPTURE_DATA(1406) <= SPR_CACHE(8).CG;
SS_CAPTURE_DATA(1407 downto 1407) <= std_logic_vector(SPR_CACHE(8).PAL(0 downto 0));
SS_CAPTURE_DATA(1410 downto 1408) <= std_logic_vector(SPR_CACHE(8).PAL(3 downto 1));
SS_CAPTURE_DATA(1411) <= SPR_CACHE(8).PRIO;
SS_CAPTURE_DATA(1412) <= SPR_CACHE(8).CGX;
SS_CAPTURE_DATA(1414 downto 1413) <= std_logic_vector(SPR_CACHE(8).CGY(1 downto 0));
SS_CAPTURE_DATA(1415) <= SPR_CACHE(8).HF;
SS_CAPTURE_DATA(1416) <= SPR_CACHE(8).VF;
SS_CAPTURE_DATA(1417) <= SPR_CACHE(8).SPR0;
SS_CAPTURE_DATA(1418) <= SPR_CACHE(8).TOP;
SS_CAPTURE_DATA(1419) <= SPR_CACHE(8).BOTTOM;
SS_CAPTURE_DATA(1423 downto 1420) <= std_logic_vector(SPR_CACHE(9).X(3 downto 0));
SS_CAPTURE_DATA(1429 downto 1424) <= std_logic_vector(SPR_CACHE(9).X(9 downto 4));
SS_CAPTURE_DATA(1439 downto 1430) <= std_logic_vector(SPR_CACHE(9).Y(9 downto 0));
SS_CAPTURE_DATA(1450 downto 1440) <= std_logic_vector(SPR_CACHE(9).PC(10 downto 0));
SS_CAPTURE_DATA(1451) <= SPR_CACHE(9).CG;
SS_CAPTURE_DATA(1455 downto 1452) <= std_logic_vector(SPR_CACHE(9).PAL(3 downto 0));
SS_CAPTURE_DATA(1456) <= SPR_CACHE(9).PRIO;
SS_CAPTURE_DATA(1457) <= SPR_CACHE(9).CGX;
SS_CAPTURE_DATA(1459 downto 1458) <= std_logic_vector(SPR_CACHE(9).CGY(1 downto 0));
SS_CAPTURE_DATA(1460) <= SPR_CACHE(9).HF;
SS_CAPTURE_DATA(1461) <= SPR_CACHE(9).VF;
SS_CAPTURE_DATA(1462) <= SPR_CACHE(9).SPR0;
SS_CAPTURE_DATA(1463) <= SPR_CACHE(9).TOP;
SS_CAPTURE_DATA(1464) <= SPR_CACHE(9).BOTTOM;
SS_CAPTURE_DATA(1471 downto 1465) <= std_logic_vector(SPR_CACHE(10).X(6 downto 0));
SS_CAPTURE_DATA(1474 downto 1472) <= std_logic_vector(SPR_CACHE(10).X(9 downto 7));
SS_CAPTURE_DATA(1484 downto 1475) <= std_logic_vector(SPR_CACHE(10).Y(9 downto 0));
SS_CAPTURE_DATA(1487 downto 1485) <= std_logic_vector(SPR_CACHE(10).PC(2 downto 0));
SS_CAPTURE_DATA(1495 downto 1488) <= std_logic_vector(SPR_CACHE(10).PC(10 downto 3));
SS_CAPTURE_DATA(1496) <= SPR_CACHE(10).CG;
SS_CAPTURE_DATA(1500 downto 1497) <= std_logic_vector(SPR_CACHE(10).PAL(3 downto 0));
SS_CAPTURE_DATA(1501) <= SPR_CACHE(10).PRIO;
SS_CAPTURE_DATA(1502) <= SPR_CACHE(10).CGX;
SS_CAPTURE_DATA(1503 downto 1503) <= std_logic_vector(SPR_CACHE(10).CGY(0 downto 0));
SS_CAPTURE_DATA(1504 downto 1504) <= std_logic_vector(SPR_CACHE(10).CGY(1 downto 1));
SS_CAPTURE_DATA(1505) <= SPR_CACHE(10).HF;
SS_CAPTURE_DATA(1506) <= SPR_CACHE(10).VF;
SS_CAPTURE_DATA(1507) <= SPR_CACHE(10).SPR0;
SS_CAPTURE_DATA(1508) <= SPR_CACHE(10).TOP;
SS_CAPTURE_DATA(1509) <= SPR_CACHE(10).BOTTOM;
SS_CAPTURE_DATA(1519 downto 1510) <= std_logic_vector(SPR_CACHE(11).X(9 downto 0));
SS_CAPTURE_DATA(1529 downto 1520) <= std_logic_vector(SPR_CACHE(11).Y(9 downto 0));
SS_CAPTURE_DATA(1535 downto 1530) <= std_logic_vector(SPR_CACHE(11).PC(5 downto 0));
SS_CAPTURE_DATA(1540 downto 1536) <= std_logic_vector(SPR_CACHE(11).PC(10 downto 6));
SS_CAPTURE_DATA(1541) <= SPR_CACHE(11).CG;
SS_CAPTURE_DATA(1545 downto 1542) <= std_logic_vector(SPR_CACHE(11).PAL(3 downto 0));
SS_CAPTURE_DATA(1546) <= SPR_CACHE(11).PRIO;
SS_CAPTURE_DATA(1547) <= SPR_CACHE(11).CGX;
SS_CAPTURE_DATA(1549 downto 1548) <= std_logic_vector(SPR_CACHE(11).CGY(1 downto 0));
SS_CAPTURE_DATA(1550) <= SPR_CACHE(11).HF;
SS_CAPTURE_DATA(1551) <= SPR_CACHE(11).VF;
SS_CAPTURE_DATA(1552) <= SPR_CACHE(11).SPR0;
SS_CAPTURE_DATA(1553) <= SPR_CACHE(11).TOP;
SS_CAPTURE_DATA(1554) <= SPR_CACHE(11).BOTTOM;
SS_CAPTURE_DATA(1564 downto 1555) <= std_logic_vector(SPR_CACHE(12).X(9 downto 0));
SS_CAPTURE_DATA(1567 downto 1565) <= std_logic_vector(SPR_CACHE(12).Y(2 downto 0));
SS_CAPTURE_DATA(1574 downto 1568) <= std_logic_vector(SPR_CACHE(12).Y(9 downto 3));
SS_CAPTURE_DATA(1583 downto 1575) <= std_logic_vector(SPR_CACHE(12).PC(8 downto 0));
SS_CAPTURE_DATA(1585 downto 1584) <= std_logic_vector(SPR_CACHE(12).PC(10 downto 9));
SS_CAPTURE_DATA(1586) <= SPR_CACHE(12).CG;
SS_CAPTURE_DATA(1590 downto 1587) <= std_logic_vector(SPR_CACHE(12).PAL(3 downto 0));
SS_CAPTURE_DATA(1591) <= SPR_CACHE(12).PRIO;
SS_CAPTURE_DATA(1592) <= SPR_CACHE(12).CGX;
SS_CAPTURE_DATA(1594 downto 1593) <= std_logic_vector(SPR_CACHE(12).CGY(1 downto 0));
SS_CAPTURE_DATA(1595) <= SPR_CACHE(12).HF;
SS_CAPTURE_DATA(1596) <= SPR_CACHE(12).VF;
SS_CAPTURE_DATA(1597) <= SPR_CACHE(12).SPR0;
SS_CAPTURE_DATA(1598) <= SPR_CACHE(12).TOP;
SS_CAPTURE_DATA(1599) <= SPR_CACHE(12).BOTTOM;
SS_CAPTURE_DATA(1609 downto 1600) <= std_logic_vector(SPR_CACHE(13).X(9 downto 0));
SS_CAPTURE_DATA(1615 downto 1610) <= std_logic_vector(SPR_CACHE(13).Y(5 downto 0));
SS_CAPTURE_DATA(1619 downto 1616) <= std_logic_vector(SPR_CACHE(13).Y(9 downto 6));
SS_CAPTURE_DATA(1630 downto 1620) <= std_logic_vector(SPR_CACHE(13).PC(10 downto 0));
SS_CAPTURE_DATA(1631) <= SPR_CACHE(13).CG;
SS_CAPTURE_DATA(1635 downto 1632) <= std_logic_vector(SPR_CACHE(13).PAL(3 downto 0));
SS_CAPTURE_DATA(1636) <= SPR_CACHE(13).PRIO;
SS_CAPTURE_DATA(1637) <= SPR_CACHE(13).CGX;
SS_CAPTURE_DATA(1639 downto 1638) <= std_logic_vector(SPR_CACHE(13).CGY(1 downto 0));
SS_CAPTURE_DATA(1640) <= SPR_CACHE(13).HF;
SS_CAPTURE_DATA(1641) <= SPR_CACHE(13).VF;
SS_CAPTURE_DATA(1642) <= SPR_CACHE(13).SPR0;
SS_CAPTURE_DATA(1643) <= SPR_CACHE(13).TOP;
SS_CAPTURE_DATA(1644) <= SPR_CACHE(13).BOTTOM;
SS_CAPTURE_DATA(1647 downto 1645) <= std_logic_vector(SPR_CACHE(14).X(2 downto 0));
SS_CAPTURE_DATA(1654 downto 1648) <= std_logic_vector(SPR_CACHE(14).X(9 downto 3));
SS_CAPTURE_DATA(1663 downto 1655) <= std_logic_vector(SPR_CACHE(14).Y(8 downto 0));
SS_CAPTURE_DATA(1664 downto 1664) <= std_logic_vector(SPR_CACHE(14).Y(9 downto 9));
SS_CAPTURE_DATA(1675 downto 1665) <= std_logic_vector(SPR_CACHE(14).PC(10 downto 0));
SS_CAPTURE_DATA(1676) <= SPR_CACHE(14).CG;
SS_CAPTURE_DATA(1679 downto 1677) <= std_logic_vector(SPR_CACHE(14).PAL(2 downto 0));
SS_CAPTURE_DATA(1680 downto 1680) <= std_logic_vector(SPR_CACHE(14).PAL(3 downto 3));
SS_CAPTURE_DATA(1681) <= SPR_CACHE(14).PRIO;
SS_CAPTURE_DATA(1682) <= SPR_CACHE(14).CGX;
SS_CAPTURE_DATA(1684 downto 1683) <= std_logic_vector(SPR_CACHE(14).CGY(1 downto 0));
SS_CAPTURE_DATA(1685) <= SPR_CACHE(14).HF;
SS_CAPTURE_DATA(1686) <= SPR_CACHE(14).VF;
SS_CAPTURE_DATA(1687) <= SPR_CACHE(14).SPR0;
SS_CAPTURE_DATA(1688) <= SPR_CACHE(14).TOP;
SS_CAPTURE_DATA(1689) <= SPR_CACHE(14).BOTTOM;
SS_CAPTURE_DATA(1695 downto 1690) <= std_logic_vector(SPR_CACHE(15).X(5 downto 0));
SS_CAPTURE_DATA(1699 downto 1696) <= std_logic_vector(SPR_CACHE(15).X(9 downto 6));
SS_CAPTURE_DATA(1709 downto 1700) <= std_logic_vector(SPR_CACHE(15).Y(9 downto 0));
SS_CAPTURE_DATA(1711 downto 1710) <= std_logic_vector(SPR_CACHE(15).PC(1 downto 0));
SS_CAPTURE_DATA(1720 downto 1712) <= std_logic_vector(SPR_CACHE(15).PC(10 downto 2));
SS_CAPTURE_DATA(1721) <= SPR_CACHE(15).CG;
SS_CAPTURE_DATA(1725 downto 1722) <= std_logic_vector(SPR_CACHE(15).PAL(3 downto 0));
SS_CAPTURE_DATA(1726) <= SPR_CACHE(15).PRIO;
SS_CAPTURE_DATA(1727) <= SPR_CACHE(15).CGX;
SS_CAPTURE_DATA(1729 downto 1728) <= std_logic_vector(SPR_CACHE(15).CGY(1 downto 0));
SS_CAPTURE_DATA(1730) <= SPR_CACHE(15).HF;
SS_CAPTURE_DATA(1731) <= SPR_CACHE(15).VF;
SS_CAPTURE_DATA(1732) <= SPR_CACHE(15).SPR0;
SS_CAPTURE_DATA(1733) <= SPR_CACHE(15).TOP;
SS_CAPTURE_DATA(1734) <= SPR_CACHE(15).BOTTOM;
SS_CAPTURE_DATA(1743 downto 1735) <= std_logic_vector(SPR_CACHE(16).X(8 downto 0));
SS_CAPTURE_DATA(1744 downto 1744) <= std_logic_vector(SPR_CACHE(16).X(9 downto 9));
SS_CAPTURE_DATA(1754 downto 1745) <= std_logic_vector(SPR_CACHE(16).Y(9 downto 0));
SS_CAPTURE_DATA(1759 downto 1755) <= std_logic_vector(SPR_CACHE(16).PC(4 downto 0));
SS_CAPTURE_DATA(1765 downto 1760) <= std_logic_vector(SPR_CACHE(16).PC(10 downto 5));
SS_CAPTURE_DATA(1766) <= SPR_CACHE(16).CG;
SS_CAPTURE_DATA(1770 downto 1767) <= std_logic_vector(SPR_CACHE(16).PAL(3 downto 0));
SS_CAPTURE_DATA(1771) <= SPR_CACHE(16).PRIO;
SS_CAPTURE_DATA(1772) <= SPR_CACHE(16).CGX;
SS_CAPTURE_DATA(1774 downto 1773) <= std_logic_vector(SPR_CACHE(16).CGY(1 downto 0));
SS_CAPTURE_DATA(1775) <= SPR_CACHE(16).HF;
SS_CAPTURE_DATA(1776) <= SPR_CACHE(16).VF;
SS_CAPTURE_DATA(1777) <= SPR_CACHE(16).SPR0;
SS_CAPTURE_DATA(1778) <= SPR_CACHE(16).TOP;
SS_CAPTURE_DATA(1779) <= SPR_CACHE(16).BOTTOM;
SS_CAPTURE_DATA(1789 downto 1780) <= std_logic_vector(SPR_CACHE(17).X(9 downto 0));
SS_CAPTURE_DATA(1791 downto 1790) <= std_logic_vector(SPR_CACHE(17).Y(1 downto 0));
SS_CAPTURE_DATA(1799 downto 1792) <= std_logic_vector(SPR_CACHE(17).Y(9 downto 2));
SS_CAPTURE_DATA(1807 downto 1800) <= std_logic_vector(SPR_CACHE(17).PC(7 downto 0));
SS_CAPTURE_DATA(1810 downto 1808) <= std_logic_vector(SPR_CACHE(17).PC(10 downto 8));
SS_CAPTURE_DATA(1811) <= SPR_CACHE(17).CG;
SS_CAPTURE_DATA(1815 downto 1812) <= std_logic_vector(SPR_CACHE(17).PAL(3 downto 0));
SS_CAPTURE_DATA(1816) <= SPR_CACHE(17).PRIO;
SS_CAPTURE_DATA(1817) <= SPR_CACHE(17).CGX;
SS_CAPTURE_DATA(1819 downto 1818) <= std_logic_vector(SPR_CACHE(17).CGY(1 downto 0));
SS_CAPTURE_DATA(1820) <= SPR_CACHE(17).HF;
SS_CAPTURE_DATA(1821) <= SPR_CACHE(17).VF;
SS_CAPTURE_DATA(1822) <= SPR_CACHE(17).SPR0;
SS_CAPTURE_DATA(1823) <= SPR_CACHE(17).TOP;
SS_CAPTURE_DATA(1824) <= SPR_CACHE(17).BOTTOM;
SS_CAPTURE_DATA(1834 downto 1825) <= std_logic_vector(SPR_CACHE(18).X(9 downto 0));
SS_CAPTURE_DATA(1839 downto 1835) <= std_logic_vector(SPR_CACHE(18).Y(4 downto 0));
SS_CAPTURE_DATA(1844 downto 1840) <= std_logic_vector(SPR_CACHE(18).Y(9 downto 5));
SS_CAPTURE_DATA(1855 downto 1845) <= std_logic_vector(SPR_CACHE(18).PC(10 downto 0));
SS_CAPTURE_DATA(1856) <= SPR_CACHE(18).CG;
SS_CAPTURE_DATA(1860 downto 1857) <= std_logic_vector(SPR_CACHE(18).PAL(3 downto 0));
SS_CAPTURE_DATA(1861) <= SPR_CACHE(18).PRIO;
SS_CAPTURE_DATA(1862) <= SPR_CACHE(18).CGX;
SS_CAPTURE_DATA(1864 downto 1863) <= std_logic_vector(SPR_CACHE(18).CGY(1 downto 0));
SS_CAPTURE_DATA(1865) <= SPR_CACHE(18).HF;
SS_CAPTURE_DATA(1866) <= SPR_CACHE(18).VF;
SS_CAPTURE_DATA(1867) <= SPR_CACHE(18).SPR0;
SS_CAPTURE_DATA(1868) <= SPR_CACHE(18).TOP;
SS_CAPTURE_DATA(1869) <= SPR_CACHE(18).BOTTOM;
SS_CAPTURE_DATA(1871 downto 1870) <= std_logic_vector(SPR_CACHE(19).X(1 downto 0));
SS_CAPTURE_DATA(1879 downto 1872) <= std_logic_vector(SPR_CACHE(19).X(9 downto 2));
SS_CAPTURE_DATA(1887 downto 1880) <= std_logic_vector(SPR_CACHE(19).Y(7 downto 0));
SS_CAPTURE_DATA(1889 downto 1888) <= std_logic_vector(SPR_CACHE(19).Y(9 downto 8));
SS_CAPTURE_DATA(1900 downto 1890) <= std_logic_vector(SPR_CACHE(19).PC(10 downto 0));
SS_CAPTURE_DATA(1901) <= SPR_CACHE(19).CG;
SS_CAPTURE_DATA(1903 downto 1902) <= std_logic_vector(SPR_CACHE(19).PAL(1 downto 0));
SS_CAPTURE_DATA(1905 downto 1904) <= std_logic_vector(SPR_CACHE(19).PAL(3 downto 2));
SS_CAPTURE_DATA(1906) <= SPR_CACHE(19).PRIO;
SS_CAPTURE_DATA(1907) <= SPR_CACHE(19).CGX;
SS_CAPTURE_DATA(1909 downto 1908) <= std_logic_vector(SPR_CACHE(19).CGY(1 downto 0));
SS_CAPTURE_DATA(1910) <= SPR_CACHE(19).HF;
SS_CAPTURE_DATA(1911) <= SPR_CACHE(19).VF;
SS_CAPTURE_DATA(1912) <= SPR_CACHE(19).SPR0;
SS_CAPTURE_DATA(1913) <= SPR_CACHE(19).TOP;
SS_CAPTURE_DATA(1914) <= SPR_CACHE(19).BOTTOM;
SS_CAPTURE_DATA(1919 downto 1915) <= std_logic_vector(SPR_CACHE(20).X(4 downto 0));
SS_CAPTURE_DATA(1924 downto 1920) <= std_logic_vector(SPR_CACHE(20).X(9 downto 5));
SS_CAPTURE_DATA(1934 downto 1925) <= std_logic_vector(SPR_CACHE(20).Y(9 downto 0));
SS_CAPTURE_DATA(1935 downto 1935) <= std_logic_vector(SPR_CACHE(20).PC(0 downto 0));
SS_CAPTURE_DATA(1945 downto 1936) <= std_logic_vector(SPR_CACHE(20).PC(10 downto 1));
SS_CAPTURE_DATA(1946) <= SPR_CACHE(20).CG;
SS_CAPTURE_DATA(1950 downto 1947) <= std_logic_vector(SPR_CACHE(20).PAL(3 downto 0));
SS_CAPTURE_DATA(1951) <= SPR_CACHE(20).PRIO;
SS_CAPTURE_DATA(1952) <= SPR_CACHE(20).CGX;
SS_CAPTURE_DATA(1954 downto 1953) <= std_logic_vector(SPR_CACHE(20).CGY(1 downto 0));
SS_CAPTURE_DATA(1955) <= SPR_CACHE(20).HF;
SS_CAPTURE_DATA(1956) <= SPR_CACHE(20).VF;
SS_CAPTURE_DATA(1957) <= SPR_CACHE(20).SPR0;
SS_CAPTURE_DATA(1958) <= SPR_CACHE(20).TOP;
SS_CAPTURE_DATA(1959) <= SPR_CACHE(20).BOTTOM;
SS_CAPTURE_DATA(1967 downto 1960) <= std_logic_vector(SPR_CACHE(21).X(7 downto 0));
SS_CAPTURE_DATA(1969 downto 1968) <= std_logic_vector(SPR_CACHE(21).X(9 downto 8));
SS_CAPTURE_DATA(1979 downto 1970) <= std_logic_vector(SPR_CACHE(21).Y(9 downto 0));
SS_CAPTURE_DATA(1983 downto 1980) <= std_logic_vector(SPR_CACHE(21).PC(3 downto 0));
SS_CAPTURE_DATA(1990 downto 1984) <= std_logic_vector(SPR_CACHE(21).PC(10 downto 4));
SS_CAPTURE_DATA(1991) <= SPR_CACHE(21).CG;
SS_CAPTURE_DATA(1995 downto 1992) <= std_logic_vector(SPR_CACHE(21).PAL(3 downto 0));
SS_CAPTURE_DATA(1996) <= SPR_CACHE(21).PRIO;
SS_CAPTURE_DATA(1997) <= SPR_CACHE(21).CGX;
SS_CAPTURE_DATA(1999 downto 1998) <= std_logic_vector(SPR_CACHE(21).CGY(1 downto 0));
SS_CAPTURE_DATA(2000) <= SPR_CACHE(21).HF;
SS_CAPTURE_DATA(2001) <= SPR_CACHE(21).VF;
SS_CAPTURE_DATA(2002) <= SPR_CACHE(21).SPR0;
SS_CAPTURE_DATA(2003) <= SPR_CACHE(21).TOP;
SS_CAPTURE_DATA(2004) <= SPR_CACHE(21).BOTTOM;
SS_CAPTURE_DATA(2014 downto 2005) <= std_logic_vector(SPR_CACHE(22).X(9 downto 0));
SS_CAPTURE_DATA(2015 downto 2015) <= std_logic_vector(SPR_CACHE(22).Y(0 downto 0));
SS_CAPTURE_DATA(2024 downto 2016) <= std_logic_vector(SPR_CACHE(22).Y(9 downto 1));
SS_CAPTURE_DATA(2031 downto 2025) <= std_logic_vector(SPR_CACHE(22).PC(6 downto 0));
SS_CAPTURE_DATA(2035 downto 2032) <= std_logic_vector(SPR_CACHE(22).PC(10 downto 7));
SS_CAPTURE_DATA(2036) <= SPR_CACHE(22).CG;
SS_CAPTURE_DATA(2040 downto 2037) <= std_logic_vector(SPR_CACHE(22).PAL(3 downto 0));
SS_CAPTURE_DATA(2041) <= SPR_CACHE(22).PRIO;
SS_CAPTURE_DATA(2042) <= SPR_CACHE(22).CGX;
SS_CAPTURE_DATA(2044 downto 2043) <= std_logic_vector(SPR_CACHE(22).CGY(1 downto 0));
SS_CAPTURE_DATA(2045) <= SPR_CACHE(22).HF;
SS_CAPTURE_DATA(2046) <= SPR_CACHE(22).VF;
SS_CAPTURE_DATA(2047) <= SPR_CACHE(22).SPR0;
SS_CAPTURE_DATA(2048) <= SPR_CACHE(22).TOP;
SS_CAPTURE_DATA(2049) <= SPR_CACHE(22).BOTTOM;
SS_CAPTURE_DATA(2059 downto 2050) <= std_logic_vector(SPR_CACHE(23).X(9 downto 0));
SS_CAPTURE_DATA(2063 downto 2060) <= std_logic_vector(SPR_CACHE(23).Y(3 downto 0));
SS_CAPTURE_DATA(2069 downto 2064) <= std_logic_vector(SPR_CACHE(23).Y(9 downto 4));
SS_CAPTURE_DATA(2079 downto 2070) <= std_logic_vector(SPR_CACHE(23).PC(9 downto 0));
SS_CAPTURE_DATA(2080 downto 2080) <= std_logic_vector(SPR_CACHE(23).PC(10 downto 10));
SS_CAPTURE_DATA(2081) <= SPR_CACHE(23).CG;
SS_CAPTURE_DATA(2085 downto 2082) <= std_logic_vector(SPR_CACHE(23).PAL(3 downto 0));
SS_CAPTURE_DATA(2086) <= SPR_CACHE(23).PRIO;
SS_CAPTURE_DATA(2087) <= SPR_CACHE(23).CGX;
SS_CAPTURE_DATA(2089 downto 2088) <= std_logic_vector(SPR_CACHE(23).CGY(1 downto 0));
SS_CAPTURE_DATA(2090) <= SPR_CACHE(23).HF;
SS_CAPTURE_DATA(2091) <= SPR_CACHE(23).VF;
SS_CAPTURE_DATA(2092) <= SPR_CACHE(23).SPR0;
SS_CAPTURE_DATA(2093) <= SPR_CACHE(23).TOP;
SS_CAPTURE_DATA(2094) <= SPR_CACHE(23).BOTTOM;
SS_CAPTURE_DATA(2095 downto 2095) <= std_logic_vector(SPR_CACHE(24).X(0 downto 0));
SS_CAPTURE_DATA(2104 downto 2096) <= std_logic_vector(SPR_CACHE(24).X(9 downto 1));
SS_CAPTURE_DATA(2111 downto 2105) <= std_logic_vector(SPR_CACHE(24).Y(6 downto 0));
SS_CAPTURE_DATA(2114 downto 2112) <= std_logic_vector(SPR_CACHE(24).Y(9 downto 7));
SS_CAPTURE_DATA(2125 downto 2115) <= std_logic_vector(SPR_CACHE(24).PC(10 downto 0));
SS_CAPTURE_DATA(2126) <= SPR_CACHE(24).CG;
SS_CAPTURE_DATA(2127 downto 2127) <= std_logic_vector(SPR_CACHE(24).PAL(0 downto 0));
SS_CAPTURE_DATA(2130 downto 2128) <= std_logic_vector(SPR_CACHE(24).PAL(3 downto 1));
SS_CAPTURE_DATA(2131) <= SPR_CACHE(24).PRIO;
SS_CAPTURE_DATA(2132) <= SPR_CACHE(24).CGX;
SS_CAPTURE_DATA(2134 downto 2133) <= std_logic_vector(SPR_CACHE(24).CGY(1 downto 0));
SS_CAPTURE_DATA(2135) <= SPR_CACHE(24).HF;
SS_CAPTURE_DATA(2136) <= SPR_CACHE(24).VF;
SS_CAPTURE_DATA(2137) <= SPR_CACHE(24).SPR0;
SS_CAPTURE_DATA(2138) <= SPR_CACHE(24).TOP;
SS_CAPTURE_DATA(2139) <= SPR_CACHE(24).BOTTOM;
SS_CAPTURE_DATA(2143 downto 2140) <= std_logic_vector(SPR_CACHE(25).X(3 downto 0));
SS_CAPTURE_DATA(2149 downto 2144) <= std_logic_vector(SPR_CACHE(25).X(9 downto 4));
SS_CAPTURE_DATA(2159 downto 2150) <= std_logic_vector(SPR_CACHE(25).Y(9 downto 0));
SS_CAPTURE_DATA(2170 downto 2160) <= std_logic_vector(SPR_CACHE(25).PC(10 downto 0));
SS_CAPTURE_DATA(2171) <= SPR_CACHE(25).CG;
SS_CAPTURE_DATA(2175 downto 2172) <= std_logic_vector(SPR_CACHE(25).PAL(3 downto 0));
SS_CAPTURE_DATA(2176) <= SPR_CACHE(25).PRIO;
SS_CAPTURE_DATA(2177) <= SPR_CACHE(25).CGX;
SS_CAPTURE_DATA(2179 downto 2178) <= std_logic_vector(SPR_CACHE(25).CGY(1 downto 0));
SS_CAPTURE_DATA(2180) <= SPR_CACHE(25).HF;
SS_CAPTURE_DATA(2181) <= SPR_CACHE(25).VF;
SS_CAPTURE_DATA(2182) <= SPR_CACHE(25).SPR0;
SS_CAPTURE_DATA(2183) <= SPR_CACHE(25).TOP;
SS_CAPTURE_DATA(2184) <= SPR_CACHE(25).BOTTOM;
SS_CAPTURE_DATA(2191 downto 2185) <= std_logic_vector(SPR_CACHE(26).X(6 downto 0));
SS_CAPTURE_DATA(2194 downto 2192) <= std_logic_vector(SPR_CACHE(26).X(9 downto 7));
SS_CAPTURE_DATA(2204 downto 2195) <= std_logic_vector(SPR_CACHE(26).Y(9 downto 0));
SS_CAPTURE_DATA(2207 downto 2205) <= std_logic_vector(SPR_CACHE(26).PC(2 downto 0));
SS_CAPTURE_DATA(2215 downto 2208) <= std_logic_vector(SPR_CACHE(26).PC(10 downto 3));
SS_CAPTURE_DATA(2216) <= SPR_CACHE(26).CG;
SS_CAPTURE_DATA(2220 downto 2217) <= std_logic_vector(SPR_CACHE(26).PAL(3 downto 0));
SS_CAPTURE_DATA(2221) <= SPR_CACHE(26).PRIO;
SS_CAPTURE_DATA(2222) <= SPR_CACHE(26).CGX;
SS_CAPTURE_DATA(2223 downto 2223) <= std_logic_vector(SPR_CACHE(26).CGY(0 downto 0));
SS_CAPTURE_DATA(2224 downto 2224) <= std_logic_vector(SPR_CACHE(26).CGY(1 downto 1));
SS_CAPTURE_DATA(2225) <= SPR_CACHE(26).HF;
SS_CAPTURE_DATA(2226) <= SPR_CACHE(26).VF;
SS_CAPTURE_DATA(2227) <= SPR_CACHE(26).SPR0;
SS_CAPTURE_DATA(2228) <= SPR_CACHE(26).TOP;
SS_CAPTURE_DATA(2229) <= SPR_CACHE(26).BOTTOM;
SS_CAPTURE_DATA(2239 downto 2230) <= std_logic_vector(SPR_CACHE(27).X(9 downto 0));
SS_CAPTURE_DATA(2249 downto 2240) <= std_logic_vector(SPR_CACHE(27).Y(9 downto 0));
SS_CAPTURE_DATA(2255 downto 2250) <= std_logic_vector(SPR_CACHE(27).PC(5 downto 0));
SS_CAPTURE_DATA(2260 downto 2256) <= std_logic_vector(SPR_CACHE(27).PC(10 downto 6));
SS_CAPTURE_DATA(2261) <= SPR_CACHE(27).CG;
SS_CAPTURE_DATA(2265 downto 2262) <= std_logic_vector(SPR_CACHE(27).PAL(3 downto 0));
SS_CAPTURE_DATA(2266) <= SPR_CACHE(27).PRIO;
SS_CAPTURE_DATA(2267) <= SPR_CACHE(27).CGX;
SS_CAPTURE_DATA(2269 downto 2268) <= std_logic_vector(SPR_CACHE(27).CGY(1 downto 0));
SS_CAPTURE_DATA(2270) <= SPR_CACHE(27).HF;
SS_CAPTURE_DATA(2271) <= SPR_CACHE(27).VF;
SS_CAPTURE_DATA(2272) <= SPR_CACHE(27).SPR0;
SS_CAPTURE_DATA(2273) <= SPR_CACHE(27).TOP;
SS_CAPTURE_DATA(2274) <= SPR_CACHE(27).BOTTOM;
SS_CAPTURE_DATA(2284 downto 2275) <= std_logic_vector(SPR_CACHE(28).X(9 downto 0));
SS_CAPTURE_DATA(2287 downto 2285) <= std_logic_vector(SPR_CACHE(28).Y(2 downto 0));
SS_CAPTURE_DATA(2294 downto 2288) <= std_logic_vector(SPR_CACHE(28).Y(9 downto 3));
SS_CAPTURE_DATA(2303 downto 2295) <= std_logic_vector(SPR_CACHE(28).PC(8 downto 0));
SS_CAPTURE_DATA(2305 downto 2304) <= std_logic_vector(SPR_CACHE(28).PC(10 downto 9));
SS_CAPTURE_DATA(2306) <= SPR_CACHE(28).CG;
SS_CAPTURE_DATA(2310 downto 2307) <= std_logic_vector(SPR_CACHE(28).PAL(3 downto 0));
SS_CAPTURE_DATA(2311) <= SPR_CACHE(28).PRIO;
SS_CAPTURE_DATA(2312) <= SPR_CACHE(28).CGX;
SS_CAPTURE_DATA(2314 downto 2313) <= std_logic_vector(SPR_CACHE(28).CGY(1 downto 0));
SS_CAPTURE_DATA(2315) <= SPR_CACHE(28).HF;
SS_CAPTURE_DATA(2316) <= SPR_CACHE(28).VF;
SS_CAPTURE_DATA(2317) <= SPR_CACHE(28).SPR0;
SS_CAPTURE_DATA(2318) <= SPR_CACHE(28).TOP;
SS_CAPTURE_DATA(2319) <= SPR_CACHE(28).BOTTOM;
SS_CAPTURE_DATA(2329 downto 2320) <= std_logic_vector(SPR_CACHE(29).X(9 downto 0));
SS_CAPTURE_DATA(2335 downto 2330) <= std_logic_vector(SPR_CACHE(29).Y(5 downto 0));
SS_CAPTURE_DATA(2339 downto 2336) <= std_logic_vector(SPR_CACHE(29).Y(9 downto 6));
SS_CAPTURE_DATA(2350 downto 2340) <= std_logic_vector(SPR_CACHE(29).PC(10 downto 0));
SS_CAPTURE_DATA(2351) <= SPR_CACHE(29).CG;
SS_CAPTURE_DATA(2355 downto 2352) <= std_logic_vector(SPR_CACHE(29).PAL(3 downto 0));
SS_CAPTURE_DATA(2356) <= SPR_CACHE(29).PRIO;
SS_CAPTURE_DATA(2357) <= SPR_CACHE(29).CGX;
SS_CAPTURE_DATA(2359 downto 2358) <= std_logic_vector(SPR_CACHE(29).CGY(1 downto 0));
SS_CAPTURE_DATA(2360) <= SPR_CACHE(29).HF;
SS_CAPTURE_DATA(2361) <= SPR_CACHE(29).VF;
SS_CAPTURE_DATA(2362) <= SPR_CACHE(29).SPR0;
SS_CAPTURE_DATA(2363) <= SPR_CACHE(29).TOP;
SS_CAPTURE_DATA(2364) <= SPR_CACHE(29).BOTTOM;
SS_CAPTURE_DATA(2367 downto 2365) <= std_logic_vector(SPR_CACHE(30).X(2 downto 0));
SS_CAPTURE_DATA(2374 downto 2368) <= std_logic_vector(SPR_CACHE(30).X(9 downto 3));
SS_CAPTURE_DATA(2383 downto 2375) <= std_logic_vector(SPR_CACHE(30).Y(8 downto 0));
SS_CAPTURE_DATA(2384 downto 2384) <= std_logic_vector(SPR_CACHE(30).Y(9 downto 9));
SS_CAPTURE_DATA(2395 downto 2385) <= std_logic_vector(SPR_CACHE(30).PC(10 downto 0));
SS_CAPTURE_DATA(2396) <= SPR_CACHE(30).CG;
SS_CAPTURE_DATA(2399 downto 2397) <= std_logic_vector(SPR_CACHE(30).PAL(2 downto 0));
SS_CAPTURE_DATA(2400 downto 2400) <= std_logic_vector(SPR_CACHE(30).PAL(3 downto 3));
SS_CAPTURE_DATA(2401) <= SPR_CACHE(30).PRIO;
SS_CAPTURE_DATA(2402) <= SPR_CACHE(30).CGX;
SS_CAPTURE_DATA(2404 downto 2403) <= std_logic_vector(SPR_CACHE(30).CGY(1 downto 0));
SS_CAPTURE_DATA(2405) <= SPR_CACHE(30).HF;
SS_CAPTURE_DATA(2406) <= SPR_CACHE(30).VF;
SS_CAPTURE_DATA(2407) <= SPR_CACHE(30).SPR0;
SS_CAPTURE_DATA(2408) <= SPR_CACHE(30).TOP;
SS_CAPTURE_DATA(2409) <= SPR_CACHE(30).BOTTOM;
SS_CAPTURE_DATA(2415 downto 2410) <= std_logic_vector(SPR_CACHE(31).X(5 downto 0));
SS_CAPTURE_DATA(2419 downto 2416) <= std_logic_vector(SPR_CACHE(31).X(9 downto 6));
SS_CAPTURE_DATA(2429 downto 2420) <= std_logic_vector(SPR_CACHE(31).Y(9 downto 0));
SS_CAPTURE_DATA(2431 downto 2430) <= std_logic_vector(SPR_CACHE(31).PC(1 downto 0));
SS_CAPTURE_DATA(2440 downto 2432) <= std_logic_vector(SPR_CACHE(31).PC(10 downto 2));
SS_CAPTURE_DATA(2441) <= SPR_CACHE(31).CG;
SS_CAPTURE_DATA(2445 downto 2442) <= std_logic_vector(SPR_CACHE(31).PAL(3 downto 0));
SS_CAPTURE_DATA(2446) <= SPR_CACHE(31).PRIO;
SS_CAPTURE_DATA(2447) <= SPR_CACHE(31).CGX;
SS_CAPTURE_DATA(2449 downto 2448) <= std_logic_vector(SPR_CACHE(31).CGY(1 downto 0));
SS_CAPTURE_DATA(2450) <= SPR_CACHE(31).HF;
SS_CAPTURE_DATA(2451) <= SPR_CACHE(31).VF;
SS_CAPTURE_DATA(2452) <= SPR_CACHE(31).SPR0;
SS_CAPTURE_DATA(2453) <= SPR_CACHE(31).TOP;
SS_CAPTURE_DATA(2454) <= SPR_CACHE(31).BOTTOM;
SS_CAPTURE_DATA(2463 downto 2455) <= std_logic_vector(SPR_CACHE(32).X(8 downto 0));
SS_CAPTURE_DATA(2464 downto 2464) <= std_logic_vector(SPR_CACHE(32).X(9 downto 9));
SS_CAPTURE_DATA(2474 downto 2465) <= std_logic_vector(SPR_CACHE(32).Y(9 downto 0));
SS_CAPTURE_DATA(2479 downto 2475) <= std_logic_vector(SPR_CACHE(32).PC(4 downto 0));
SS_CAPTURE_DATA(2485 downto 2480) <= std_logic_vector(SPR_CACHE(32).PC(10 downto 5));
SS_CAPTURE_DATA(2486) <= SPR_CACHE(32).CG;
SS_CAPTURE_DATA(2490 downto 2487) <= std_logic_vector(SPR_CACHE(32).PAL(3 downto 0));
SS_CAPTURE_DATA(2491) <= SPR_CACHE(32).PRIO;
SS_CAPTURE_DATA(2492) <= SPR_CACHE(32).CGX;
SS_CAPTURE_DATA(2494 downto 2493) <= std_logic_vector(SPR_CACHE(32).CGY(1 downto 0));
SS_CAPTURE_DATA(2495) <= SPR_CACHE(32).HF;
SS_CAPTURE_DATA(2496) <= SPR_CACHE(32).VF;
SS_CAPTURE_DATA(2497) <= SPR_CACHE(32).SPR0;
SS_CAPTURE_DATA(2498) <= SPR_CACHE(32).TOP;
SS_CAPTURE_DATA(2499) <= SPR_CACHE(32).BOTTOM;
SS_CAPTURE_DATA(2509 downto 2500) <= std_logic_vector(SPR_CACHE(33).X(9 downto 0));
SS_CAPTURE_DATA(2511 downto 2510) <= std_logic_vector(SPR_CACHE(33).Y(1 downto 0));
SS_CAPTURE_DATA(2519 downto 2512) <= std_logic_vector(SPR_CACHE(33).Y(9 downto 2));
SS_CAPTURE_DATA(2527 downto 2520) <= std_logic_vector(SPR_CACHE(33).PC(7 downto 0));
SS_CAPTURE_DATA(2530 downto 2528) <= std_logic_vector(SPR_CACHE(33).PC(10 downto 8));
SS_CAPTURE_DATA(2531) <= SPR_CACHE(33).CG;
SS_CAPTURE_DATA(2535 downto 2532) <= std_logic_vector(SPR_CACHE(33).PAL(3 downto 0));
SS_CAPTURE_DATA(2536) <= SPR_CACHE(33).PRIO;
SS_CAPTURE_DATA(2537) <= SPR_CACHE(33).CGX;
SS_CAPTURE_DATA(2539 downto 2538) <= std_logic_vector(SPR_CACHE(33).CGY(1 downto 0));
SS_CAPTURE_DATA(2540) <= SPR_CACHE(33).HF;
SS_CAPTURE_DATA(2541) <= SPR_CACHE(33).VF;
SS_CAPTURE_DATA(2542) <= SPR_CACHE(33).SPR0;
SS_CAPTURE_DATA(2543) <= SPR_CACHE(33).TOP;
SS_CAPTURE_DATA(2544) <= SPR_CACHE(33).BOTTOM;
SS_CAPTURE_DATA(2554 downto 2545) <= std_logic_vector(SPR_CACHE(34).X(9 downto 0));
SS_CAPTURE_DATA(2559 downto 2555) <= std_logic_vector(SPR_CACHE(34).Y(4 downto 0));
SS_CAPTURE_DATA(2564 downto 2560) <= std_logic_vector(SPR_CACHE(34).Y(9 downto 5));
SS_CAPTURE_DATA(2575 downto 2565) <= std_logic_vector(SPR_CACHE(34).PC(10 downto 0));
SS_CAPTURE_DATA(2576) <= SPR_CACHE(34).CG;
SS_CAPTURE_DATA(2580 downto 2577) <= std_logic_vector(SPR_CACHE(34).PAL(3 downto 0));
SS_CAPTURE_DATA(2581) <= SPR_CACHE(34).PRIO;
SS_CAPTURE_DATA(2582) <= SPR_CACHE(34).CGX;
SS_CAPTURE_DATA(2584 downto 2583) <= std_logic_vector(SPR_CACHE(34).CGY(1 downto 0));
SS_CAPTURE_DATA(2585) <= SPR_CACHE(34).HF;
SS_CAPTURE_DATA(2586) <= SPR_CACHE(34).VF;
SS_CAPTURE_DATA(2587) <= SPR_CACHE(34).SPR0;
SS_CAPTURE_DATA(2588) <= SPR_CACHE(34).TOP;
SS_CAPTURE_DATA(2589) <= SPR_CACHE(34).BOTTOM;
SS_CAPTURE_DATA(2591 downto 2590) <= std_logic_vector(SPR_CACHE(35).X(1 downto 0));
SS_CAPTURE_DATA(2599 downto 2592) <= std_logic_vector(SPR_CACHE(35).X(9 downto 2));
SS_CAPTURE_DATA(2607 downto 2600) <= std_logic_vector(SPR_CACHE(35).Y(7 downto 0));
SS_CAPTURE_DATA(2609 downto 2608) <= std_logic_vector(SPR_CACHE(35).Y(9 downto 8));
SS_CAPTURE_DATA(2620 downto 2610) <= std_logic_vector(SPR_CACHE(35).PC(10 downto 0));
SS_CAPTURE_DATA(2621) <= SPR_CACHE(35).CG;
SS_CAPTURE_DATA(2623 downto 2622) <= std_logic_vector(SPR_CACHE(35).PAL(1 downto 0));
SS_CAPTURE_DATA(2625 downto 2624) <= std_logic_vector(SPR_CACHE(35).PAL(3 downto 2));
SS_CAPTURE_DATA(2626) <= SPR_CACHE(35).PRIO;
SS_CAPTURE_DATA(2627) <= SPR_CACHE(35).CGX;
SS_CAPTURE_DATA(2629 downto 2628) <= std_logic_vector(SPR_CACHE(35).CGY(1 downto 0));
SS_CAPTURE_DATA(2630) <= SPR_CACHE(35).HF;
SS_CAPTURE_DATA(2631) <= SPR_CACHE(35).VF;
SS_CAPTURE_DATA(2632) <= SPR_CACHE(35).SPR0;
SS_CAPTURE_DATA(2633) <= SPR_CACHE(35).TOP;
SS_CAPTURE_DATA(2634) <= SPR_CACHE(35).BOTTOM;
SS_CAPTURE_DATA(2639 downto 2635) <= std_logic_vector(SPR_CACHE(36).X(4 downto 0));
SS_CAPTURE_DATA(2644 downto 2640) <= std_logic_vector(SPR_CACHE(36).X(9 downto 5));
SS_CAPTURE_DATA(2654 downto 2645) <= std_logic_vector(SPR_CACHE(36).Y(9 downto 0));
SS_CAPTURE_DATA(2655 downto 2655) <= std_logic_vector(SPR_CACHE(36).PC(0 downto 0));
SS_CAPTURE_DATA(2665 downto 2656) <= std_logic_vector(SPR_CACHE(36).PC(10 downto 1));
SS_CAPTURE_DATA(2666) <= SPR_CACHE(36).CG;
SS_CAPTURE_DATA(2670 downto 2667) <= std_logic_vector(SPR_CACHE(36).PAL(3 downto 0));
SS_CAPTURE_DATA(2671) <= SPR_CACHE(36).PRIO;
SS_CAPTURE_DATA(2672) <= SPR_CACHE(36).CGX;
SS_CAPTURE_DATA(2674 downto 2673) <= std_logic_vector(SPR_CACHE(36).CGY(1 downto 0));
SS_CAPTURE_DATA(2675) <= SPR_CACHE(36).HF;
SS_CAPTURE_DATA(2676) <= SPR_CACHE(36).VF;
SS_CAPTURE_DATA(2677) <= SPR_CACHE(36).SPR0;
SS_CAPTURE_DATA(2678) <= SPR_CACHE(36).TOP;
SS_CAPTURE_DATA(2679) <= SPR_CACHE(36).BOTTOM;
SS_CAPTURE_DATA(2687 downto 2680) <= std_logic_vector(SPR_CACHE(37).X(7 downto 0));
SS_CAPTURE_DATA(2689 downto 2688) <= std_logic_vector(SPR_CACHE(37).X(9 downto 8));
SS_CAPTURE_DATA(2699 downto 2690) <= std_logic_vector(SPR_CACHE(37).Y(9 downto 0));
SS_CAPTURE_DATA(2703 downto 2700) <= std_logic_vector(SPR_CACHE(37).PC(3 downto 0));
SS_CAPTURE_DATA(2710 downto 2704) <= std_logic_vector(SPR_CACHE(37).PC(10 downto 4));
SS_CAPTURE_DATA(2711) <= SPR_CACHE(37).CG;
SS_CAPTURE_DATA(2715 downto 2712) <= std_logic_vector(SPR_CACHE(37).PAL(3 downto 0));
SS_CAPTURE_DATA(2716) <= SPR_CACHE(37).PRIO;
SS_CAPTURE_DATA(2717) <= SPR_CACHE(37).CGX;
SS_CAPTURE_DATA(2719 downto 2718) <= std_logic_vector(SPR_CACHE(37).CGY(1 downto 0));
SS_CAPTURE_DATA(2720) <= SPR_CACHE(37).HF;
SS_CAPTURE_DATA(2721) <= SPR_CACHE(37).VF;
SS_CAPTURE_DATA(2722) <= SPR_CACHE(37).SPR0;
SS_CAPTURE_DATA(2723) <= SPR_CACHE(37).TOP;
SS_CAPTURE_DATA(2724) <= SPR_CACHE(37).BOTTOM;
SS_CAPTURE_DATA(2734 downto 2725) <= std_logic_vector(SPR_CACHE(38).X(9 downto 0));
SS_CAPTURE_DATA(2735 downto 2735) <= std_logic_vector(SPR_CACHE(38).Y(0 downto 0));
SS_CAPTURE_DATA(2744 downto 2736) <= std_logic_vector(SPR_CACHE(38).Y(9 downto 1));
SS_CAPTURE_DATA(2751 downto 2745) <= std_logic_vector(SPR_CACHE(38).PC(6 downto 0));
SS_CAPTURE_DATA(2755 downto 2752) <= std_logic_vector(SPR_CACHE(38).PC(10 downto 7));
SS_CAPTURE_DATA(2756) <= SPR_CACHE(38).CG;
SS_CAPTURE_DATA(2760 downto 2757) <= std_logic_vector(SPR_CACHE(38).PAL(3 downto 0));
SS_CAPTURE_DATA(2761) <= SPR_CACHE(38).PRIO;
SS_CAPTURE_DATA(2762) <= SPR_CACHE(38).CGX;
SS_CAPTURE_DATA(2764 downto 2763) <= std_logic_vector(SPR_CACHE(38).CGY(1 downto 0));
SS_CAPTURE_DATA(2765) <= SPR_CACHE(38).HF;
SS_CAPTURE_DATA(2766) <= SPR_CACHE(38).VF;
SS_CAPTURE_DATA(2767) <= SPR_CACHE(38).SPR0;
SS_CAPTURE_DATA(2768) <= SPR_CACHE(38).TOP;
SS_CAPTURE_DATA(2769) <= SPR_CACHE(38).BOTTOM;
SS_CAPTURE_DATA(2779 downto 2770) <= std_logic_vector(SPR_CACHE(39).X(9 downto 0));
SS_CAPTURE_DATA(2783 downto 2780) <= std_logic_vector(SPR_CACHE(39).Y(3 downto 0));
SS_CAPTURE_DATA(2789 downto 2784) <= std_logic_vector(SPR_CACHE(39).Y(9 downto 4));
SS_CAPTURE_DATA(2799 downto 2790) <= std_logic_vector(SPR_CACHE(39).PC(9 downto 0));
SS_CAPTURE_DATA(2800 downto 2800) <= std_logic_vector(SPR_CACHE(39).PC(10 downto 10));
SS_CAPTURE_DATA(2801) <= SPR_CACHE(39).CG;
SS_CAPTURE_DATA(2805 downto 2802) <= std_logic_vector(SPR_CACHE(39).PAL(3 downto 0));
SS_CAPTURE_DATA(2806) <= SPR_CACHE(39).PRIO;
SS_CAPTURE_DATA(2807) <= SPR_CACHE(39).CGX;
SS_CAPTURE_DATA(2809 downto 2808) <= std_logic_vector(SPR_CACHE(39).CGY(1 downto 0));
SS_CAPTURE_DATA(2810) <= SPR_CACHE(39).HF;
SS_CAPTURE_DATA(2811) <= SPR_CACHE(39).VF;
SS_CAPTURE_DATA(2812) <= SPR_CACHE(39).SPR0;
SS_CAPTURE_DATA(2813) <= SPR_CACHE(39).TOP;
SS_CAPTURE_DATA(2814) <= SPR_CACHE(39).BOTTOM;
SS_CAPTURE_DATA(2815 downto 2815) <= std_logic_vector(SPR_CACHE(40).X(0 downto 0));
SS_CAPTURE_DATA(2824 downto 2816) <= std_logic_vector(SPR_CACHE(40).X(9 downto 1));
SS_CAPTURE_DATA(2831 downto 2825) <= std_logic_vector(SPR_CACHE(40).Y(6 downto 0));
SS_CAPTURE_DATA(2834 downto 2832) <= std_logic_vector(SPR_CACHE(40).Y(9 downto 7));
SS_CAPTURE_DATA(2845 downto 2835) <= std_logic_vector(SPR_CACHE(40).PC(10 downto 0));
SS_CAPTURE_DATA(2846) <= SPR_CACHE(40).CG;
SS_CAPTURE_DATA(2847 downto 2847) <= std_logic_vector(SPR_CACHE(40).PAL(0 downto 0));
SS_CAPTURE_DATA(2850 downto 2848) <= std_logic_vector(SPR_CACHE(40).PAL(3 downto 1));
SS_CAPTURE_DATA(2851) <= SPR_CACHE(40).PRIO;
SS_CAPTURE_DATA(2852) <= SPR_CACHE(40).CGX;
SS_CAPTURE_DATA(2854 downto 2853) <= std_logic_vector(SPR_CACHE(40).CGY(1 downto 0));
SS_CAPTURE_DATA(2855) <= SPR_CACHE(40).HF;
SS_CAPTURE_DATA(2856) <= SPR_CACHE(40).VF;
SS_CAPTURE_DATA(2857) <= SPR_CACHE(40).SPR0;
SS_CAPTURE_DATA(2858) <= SPR_CACHE(40).TOP;
SS_CAPTURE_DATA(2859) <= SPR_CACHE(40).BOTTOM;
SS_CAPTURE_DATA(2863 downto 2860) <= std_logic_vector(SPR_CACHE(41).X(3 downto 0));
SS_CAPTURE_DATA(2869 downto 2864) <= std_logic_vector(SPR_CACHE(41).X(9 downto 4));
SS_CAPTURE_DATA(2879 downto 2870) <= std_logic_vector(SPR_CACHE(41).Y(9 downto 0));
SS_CAPTURE_DATA(2890 downto 2880) <= std_logic_vector(SPR_CACHE(41).PC(10 downto 0));
SS_CAPTURE_DATA(2891) <= SPR_CACHE(41).CG;
SS_CAPTURE_DATA(2895 downto 2892) <= std_logic_vector(SPR_CACHE(41).PAL(3 downto 0));
SS_CAPTURE_DATA(2896) <= SPR_CACHE(41).PRIO;
SS_CAPTURE_DATA(2897) <= SPR_CACHE(41).CGX;
SS_CAPTURE_DATA(2899 downto 2898) <= std_logic_vector(SPR_CACHE(41).CGY(1 downto 0));
SS_CAPTURE_DATA(2900) <= SPR_CACHE(41).HF;
SS_CAPTURE_DATA(2901) <= SPR_CACHE(41).VF;
SS_CAPTURE_DATA(2902) <= SPR_CACHE(41).SPR0;
SS_CAPTURE_DATA(2903) <= SPR_CACHE(41).TOP;
SS_CAPTURE_DATA(2904) <= SPR_CACHE(41).BOTTOM;
SS_CAPTURE_DATA(2911 downto 2905) <= std_logic_vector(SPR_CACHE(42).X(6 downto 0));
SS_CAPTURE_DATA(2914 downto 2912) <= std_logic_vector(SPR_CACHE(42).X(9 downto 7));
SS_CAPTURE_DATA(2924 downto 2915) <= std_logic_vector(SPR_CACHE(42).Y(9 downto 0));
SS_CAPTURE_DATA(2927 downto 2925) <= std_logic_vector(SPR_CACHE(42).PC(2 downto 0));
SS_CAPTURE_DATA(2935 downto 2928) <= std_logic_vector(SPR_CACHE(42).PC(10 downto 3));
SS_CAPTURE_DATA(2936) <= SPR_CACHE(42).CG;
SS_CAPTURE_DATA(2940 downto 2937) <= std_logic_vector(SPR_CACHE(42).PAL(3 downto 0));
SS_CAPTURE_DATA(2941) <= SPR_CACHE(42).PRIO;
SS_CAPTURE_DATA(2942) <= SPR_CACHE(42).CGX;
SS_CAPTURE_DATA(2943 downto 2943) <= std_logic_vector(SPR_CACHE(42).CGY(0 downto 0));
SS_CAPTURE_DATA(2944 downto 2944) <= std_logic_vector(SPR_CACHE(42).CGY(1 downto 1));
SS_CAPTURE_DATA(2945) <= SPR_CACHE(42).HF;
SS_CAPTURE_DATA(2946) <= SPR_CACHE(42).VF;
SS_CAPTURE_DATA(2947) <= SPR_CACHE(42).SPR0;
SS_CAPTURE_DATA(2948) <= SPR_CACHE(42).TOP;
SS_CAPTURE_DATA(2949) <= SPR_CACHE(42).BOTTOM;
SS_CAPTURE_DATA(2959 downto 2950) <= std_logic_vector(SPR_CACHE(43).X(9 downto 0));
SS_CAPTURE_DATA(2969 downto 2960) <= std_logic_vector(SPR_CACHE(43).Y(9 downto 0));
SS_CAPTURE_DATA(2975 downto 2970) <= std_logic_vector(SPR_CACHE(43).PC(5 downto 0));
SS_CAPTURE_DATA(2980 downto 2976) <= std_logic_vector(SPR_CACHE(43).PC(10 downto 6));
SS_CAPTURE_DATA(2981) <= SPR_CACHE(43).CG;
SS_CAPTURE_DATA(2985 downto 2982) <= std_logic_vector(SPR_CACHE(43).PAL(3 downto 0));
SS_CAPTURE_DATA(2986) <= SPR_CACHE(43).PRIO;
SS_CAPTURE_DATA(2987) <= SPR_CACHE(43).CGX;
SS_CAPTURE_DATA(2989 downto 2988) <= std_logic_vector(SPR_CACHE(43).CGY(1 downto 0));
SS_CAPTURE_DATA(2990) <= SPR_CACHE(43).HF;
SS_CAPTURE_DATA(2991) <= SPR_CACHE(43).VF;
SS_CAPTURE_DATA(2992) <= SPR_CACHE(43).SPR0;
SS_CAPTURE_DATA(2993) <= SPR_CACHE(43).TOP;
SS_CAPTURE_DATA(2994) <= SPR_CACHE(43).BOTTOM;
SS_CAPTURE_DATA(3004 downto 2995) <= std_logic_vector(SPR_CACHE(44).X(9 downto 0));
SS_CAPTURE_DATA(3007 downto 3005) <= std_logic_vector(SPR_CACHE(44).Y(2 downto 0));
SS_CAPTURE_DATA(3014 downto 3008) <= std_logic_vector(SPR_CACHE(44).Y(9 downto 3));
SS_CAPTURE_DATA(3023 downto 3015) <= std_logic_vector(SPR_CACHE(44).PC(8 downto 0));
SS_CAPTURE_DATA(3025 downto 3024) <= std_logic_vector(SPR_CACHE(44).PC(10 downto 9));
SS_CAPTURE_DATA(3026) <= SPR_CACHE(44).CG;
SS_CAPTURE_DATA(3030 downto 3027) <= std_logic_vector(SPR_CACHE(44).PAL(3 downto 0));
SS_CAPTURE_DATA(3031) <= SPR_CACHE(44).PRIO;
SS_CAPTURE_DATA(3032) <= SPR_CACHE(44).CGX;
SS_CAPTURE_DATA(3034 downto 3033) <= std_logic_vector(SPR_CACHE(44).CGY(1 downto 0));
SS_CAPTURE_DATA(3035) <= SPR_CACHE(44).HF;
SS_CAPTURE_DATA(3036) <= SPR_CACHE(44).VF;
SS_CAPTURE_DATA(3037) <= SPR_CACHE(44).SPR0;
SS_CAPTURE_DATA(3038) <= SPR_CACHE(44).TOP;
SS_CAPTURE_DATA(3039) <= SPR_CACHE(44).BOTTOM;
SS_CAPTURE_DATA(3049 downto 3040) <= std_logic_vector(SPR_CACHE(45).X(9 downto 0));
SS_CAPTURE_DATA(3055 downto 3050) <= std_logic_vector(SPR_CACHE(45).Y(5 downto 0));
SS_CAPTURE_DATA(3059 downto 3056) <= std_logic_vector(SPR_CACHE(45).Y(9 downto 6));
SS_CAPTURE_DATA(3070 downto 3060) <= std_logic_vector(SPR_CACHE(45).PC(10 downto 0));
SS_CAPTURE_DATA(3071) <= SPR_CACHE(45).CG;
SS_CAPTURE_DATA(3075 downto 3072) <= std_logic_vector(SPR_CACHE(45).PAL(3 downto 0));
SS_CAPTURE_DATA(3076) <= SPR_CACHE(45).PRIO;
SS_CAPTURE_DATA(3077) <= SPR_CACHE(45).CGX;
SS_CAPTURE_DATA(3079 downto 3078) <= std_logic_vector(SPR_CACHE(45).CGY(1 downto 0));
SS_CAPTURE_DATA(3080) <= SPR_CACHE(45).HF;
SS_CAPTURE_DATA(3081) <= SPR_CACHE(45).VF;
SS_CAPTURE_DATA(3082) <= SPR_CACHE(45).SPR0;
SS_CAPTURE_DATA(3083) <= SPR_CACHE(45).TOP;
SS_CAPTURE_DATA(3084) <= SPR_CACHE(45).BOTTOM;
SS_CAPTURE_DATA(3087 downto 3085) <= std_logic_vector(SPR_CACHE(46).X(2 downto 0));
SS_CAPTURE_DATA(3094 downto 3088) <= std_logic_vector(SPR_CACHE(46).X(9 downto 3));
SS_CAPTURE_DATA(3103 downto 3095) <= std_logic_vector(SPR_CACHE(46).Y(8 downto 0));
SS_CAPTURE_DATA(3104 downto 3104) <= std_logic_vector(SPR_CACHE(46).Y(9 downto 9));
SS_CAPTURE_DATA(3115 downto 3105) <= std_logic_vector(SPR_CACHE(46).PC(10 downto 0));
SS_CAPTURE_DATA(3116) <= SPR_CACHE(46).CG;
SS_CAPTURE_DATA(3119 downto 3117) <= std_logic_vector(SPR_CACHE(46).PAL(2 downto 0));
SS_CAPTURE_DATA(3120 downto 3120) <= std_logic_vector(SPR_CACHE(46).PAL(3 downto 3));
SS_CAPTURE_DATA(3121) <= SPR_CACHE(46).PRIO;
SS_CAPTURE_DATA(3122) <= SPR_CACHE(46).CGX;
SS_CAPTURE_DATA(3124 downto 3123) <= std_logic_vector(SPR_CACHE(46).CGY(1 downto 0));
SS_CAPTURE_DATA(3125) <= SPR_CACHE(46).HF;
SS_CAPTURE_DATA(3126) <= SPR_CACHE(46).VF;
SS_CAPTURE_DATA(3127) <= SPR_CACHE(46).SPR0;
SS_CAPTURE_DATA(3128) <= SPR_CACHE(46).TOP;
SS_CAPTURE_DATA(3129) <= SPR_CACHE(46).BOTTOM;
SS_CAPTURE_DATA(3135 downto 3130) <= std_logic_vector(SPR_CACHE(47).X(5 downto 0));
SS_CAPTURE_DATA(3139 downto 3136) <= std_logic_vector(SPR_CACHE(47).X(9 downto 6));
SS_CAPTURE_DATA(3149 downto 3140) <= std_logic_vector(SPR_CACHE(47).Y(9 downto 0));
SS_CAPTURE_DATA(3151 downto 3150) <= std_logic_vector(SPR_CACHE(47).PC(1 downto 0));
SS_CAPTURE_DATA(3160 downto 3152) <= std_logic_vector(SPR_CACHE(47).PC(10 downto 2));
SS_CAPTURE_DATA(3161) <= SPR_CACHE(47).CG;
SS_CAPTURE_DATA(3165 downto 3162) <= std_logic_vector(SPR_CACHE(47).PAL(3 downto 0));
SS_CAPTURE_DATA(3166) <= SPR_CACHE(47).PRIO;
SS_CAPTURE_DATA(3167) <= SPR_CACHE(47).CGX;
SS_CAPTURE_DATA(3169 downto 3168) <= std_logic_vector(SPR_CACHE(47).CGY(1 downto 0));
SS_CAPTURE_DATA(3170) <= SPR_CACHE(47).HF;
SS_CAPTURE_DATA(3171) <= SPR_CACHE(47).VF;
SS_CAPTURE_DATA(3172) <= SPR_CACHE(47).SPR0;
SS_CAPTURE_DATA(3173) <= SPR_CACHE(47).TOP;
SS_CAPTURE_DATA(3174) <= SPR_CACHE(47).BOTTOM;
SS_CAPTURE_DATA(3183 downto 3175) <= std_logic_vector(SPR_CACHE(48).X(8 downto 0));
SS_CAPTURE_DATA(3184 downto 3184) <= std_logic_vector(SPR_CACHE(48).X(9 downto 9));
SS_CAPTURE_DATA(3194 downto 3185) <= std_logic_vector(SPR_CACHE(48).Y(9 downto 0));
SS_CAPTURE_DATA(3199 downto 3195) <= std_logic_vector(SPR_CACHE(48).PC(4 downto 0));
SS_CAPTURE_DATA(3205 downto 3200) <= std_logic_vector(SPR_CACHE(48).PC(10 downto 5));
SS_CAPTURE_DATA(3206) <= SPR_CACHE(48).CG;
SS_CAPTURE_DATA(3210 downto 3207) <= std_logic_vector(SPR_CACHE(48).PAL(3 downto 0));
SS_CAPTURE_DATA(3211) <= SPR_CACHE(48).PRIO;
SS_CAPTURE_DATA(3212) <= SPR_CACHE(48).CGX;
SS_CAPTURE_DATA(3214 downto 3213) <= std_logic_vector(SPR_CACHE(48).CGY(1 downto 0));
SS_CAPTURE_DATA(3215) <= SPR_CACHE(48).HF;
SS_CAPTURE_DATA(3216) <= SPR_CACHE(48).VF;
SS_CAPTURE_DATA(3217) <= SPR_CACHE(48).SPR0;
SS_CAPTURE_DATA(3218) <= SPR_CACHE(48).TOP;
SS_CAPTURE_DATA(3219) <= SPR_CACHE(48).BOTTOM;
SS_CAPTURE_DATA(3229 downto 3220) <= std_logic_vector(SPR_CACHE(49).X(9 downto 0));
SS_CAPTURE_DATA(3231 downto 3230) <= std_logic_vector(SPR_CACHE(49).Y(1 downto 0));
SS_CAPTURE_DATA(3239 downto 3232) <= std_logic_vector(SPR_CACHE(49).Y(9 downto 2));
SS_CAPTURE_DATA(3247 downto 3240) <= std_logic_vector(SPR_CACHE(49).PC(7 downto 0));
SS_CAPTURE_DATA(3250 downto 3248) <= std_logic_vector(SPR_CACHE(49).PC(10 downto 8));
SS_CAPTURE_DATA(3251) <= SPR_CACHE(49).CG;
SS_CAPTURE_DATA(3255 downto 3252) <= std_logic_vector(SPR_CACHE(49).PAL(3 downto 0));
SS_CAPTURE_DATA(3256) <= SPR_CACHE(49).PRIO;
SS_CAPTURE_DATA(3257) <= SPR_CACHE(49).CGX;
SS_CAPTURE_DATA(3259 downto 3258) <= std_logic_vector(SPR_CACHE(49).CGY(1 downto 0));
SS_CAPTURE_DATA(3260) <= SPR_CACHE(49).HF;
SS_CAPTURE_DATA(3261) <= SPR_CACHE(49).VF;
SS_CAPTURE_DATA(3262) <= SPR_CACHE(49).SPR0;
SS_CAPTURE_DATA(3263) <= SPR_CACHE(49).TOP;
SS_CAPTURE_DATA(3264) <= SPR_CACHE(49).BOTTOM;
SS_CAPTURE_DATA(3274 downto 3265) <= std_logic_vector(SPR_CACHE(50).X(9 downto 0));
SS_CAPTURE_DATA(3279 downto 3275) <= std_logic_vector(SPR_CACHE(50).Y(4 downto 0));
SS_CAPTURE_DATA(3284 downto 3280) <= std_logic_vector(SPR_CACHE(50).Y(9 downto 5));
SS_CAPTURE_DATA(3295 downto 3285) <= std_logic_vector(SPR_CACHE(50).PC(10 downto 0));
SS_CAPTURE_DATA(3296) <= SPR_CACHE(50).CG;
SS_CAPTURE_DATA(3300 downto 3297) <= std_logic_vector(SPR_CACHE(50).PAL(3 downto 0));
SS_CAPTURE_DATA(3301) <= SPR_CACHE(50).PRIO;
SS_CAPTURE_DATA(3302) <= SPR_CACHE(50).CGX;
SS_CAPTURE_DATA(3304 downto 3303) <= std_logic_vector(SPR_CACHE(50).CGY(1 downto 0));
SS_CAPTURE_DATA(3305) <= SPR_CACHE(50).HF;
SS_CAPTURE_DATA(3306) <= SPR_CACHE(50).VF;
SS_CAPTURE_DATA(3307) <= SPR_CACHE(50).SPR0;
SS_CAPTURE_DATA(3308) <= SPR_CACHE(50).TOP;
SS_CAPTURE_DATA(3309) <= SPR_CACHE(50).BOTTOM;
SS_CAPTURE_DATA(3311 downto 3310) <= std_logic_vector(SPR_CACHE(51).X(1 downto 0));
SS_CAPTURE_DATA(3319 downto 3312) <= std_logic_vector(SPR_CACHE(51).X(9 downto 2));
SS_CAPTURE_DATA(3327 downto 3320) <= std_logic_vector(SPR_CACHE(51).Y(7 downto 0));
SS_CAPTURE_DATA(3329 downto 3328) <= std_logic_vector(SPR_CACHE(51).Y(9 downto 8));
SS_CAPTURE_DATA(3340 downto 3330) <= std_logic_vector(SPR_CACHE(51).PC(10 downto 0));
SS_CAPTURE_DATA(3341) <= SPR_CACHE(51).CG;
SS_CAPTURE_DATA(3343 downto 3342) <= std_logic_vector(SPR_CACHE(51).PAL(1 downto 0));
SS_CAPTURE_DATA(3345 downto 3344) <= std_logic_vector(SPR_CACHE(51).PAL(3 downto 2));
SS_CAPTURE_DATA(3346) <= SPR_CACHE(51).PRIO;
SS_CAPTURE_DATA(3347) <= SPR_CACHE(51).CGX;
SS_CAPTURE_DATA(3349 downto 3348) <= std_logic_vector(SPR_CACHE(51).CGY(1 downto 0));
SS_CAPTURE_DATA(3350) <= SPR_CACHE(51).HF;
SS_CAPTURE_DATA(3351) <= SPR_CACHE(51).VF;
SS_CAPTURE_DATA(3352) <= SPR_CACHE(51).SPR0;
SS_CAPTURE_DATA(3353) <= SPR_CACHE(51).TOP;
SS_CAPTURE_DATA(3354) <= SPR_CACHE(51).BOTTOM;
SS_CAPTURE_DATA(3359 downto 3355) <= std_logic_vector(SPR_CACHE(52).X(4 downto 0));
SS_CAPTURE_DATA(3364 downto 3360) <= std_logic_vector(SPR_CACHE(52).X(9 downto 5));
SS_CAPTURE_DATA(3374 downto 3365) <= std_logic_vector(SPR_CACHE(52).Y(9 downto 0));
SS_CAPTURE_DATA(3375 downto 3375) <= std_logic_vector(SPR_CACHE(52).PC(0 downto 0));
SS_CAPTURE_DATA(3385 downto 3376) <= std_logic_vector(SPR_CACHE(52).PC(10 downto 1));
SS_CAPTURE_DATA(3386) <= SPR_CACHE(52).CG;
SS_CAPTURE_DATA(3390 downto 3387) <= std_logic_vector(SPR_CACHE(52).PAL(3 downto 0));
SS_CAPTURE_DATA(3391) <= SPR_CACHE(52).PRIO;
SS_CAPTURE_DATA(3392) <= SPR_CACHE(52).CGX;
SS_CAPTURE_DATA(3394 downto 3393) <= std_logic_vector(SPR_CACHE(52).CGY(1 downto 0));
SS_CAPTURE_DATA(3395) <= SPR_CACHE(52).HF;
SS_CAPTURE_DATA(3396) <= SPR_CACHE(52).VF;
SS_CAPTURE_DATA(3397) <= SPR_CACHE(52).SPR0;
SS_CAPTURE_DATA(3398) <= SPR_CACHE(52).TOP;
SS_CAPTURE_DATA(3399) <= SPR_CACHE(52).BOTTOM;
SS_CAPTURE_DATA(3407 downto 3400) <= std_logic_vector(SPR_CACHE(53).X(7 downto 0));
SS_CAPTURE_DATA(3409 downto 3408) <= std_logic_vector(SPR_CACHE(53).X(9 downto 8));
SS_CAPTURE_DATA(3419 downto 3410) <= std_logic_vector(SPR_CACHE(53).Y(9 downto 0));
SS_CAPTURE_DATA(3423 downto 3420) <= std_logic_vector(SPR_CACHE(53).PC(3 downto 0));
SS_CAPTURE_DATA(3430 downto 3424) <= std_logic_vector(SPR_CACHE(53).PC(10 downto 4));
SS_CAPTURE_DATA(3431) <= SPR_CACHE(53).CG;
SS_CAPTURE_DATA(3435 downto 3432) <= std_logic_vector(SPR_CACHE(53).PAL(3 downto 0));
SS_CAPTURE_DATA(3436) <= SPR_CACHE(53).PRIO;
SS_CAPTURE_DATA(3437) <= SPR_CACHE(53).CGX;
SS_CAPTURE_DATA(3439 downto 3438) <= std_logic_vector(SPR_CACHE(53).CGY(1 downto 0));
SS_CAPTURE_DATA(3440) <= SPR_CACHE(53).HF;
SS_CAPTURE_DATA(3441) <= SPR_CACHE(53).VF;
SS_CAPTURE_DATA(3442) <= SPR_CACHE(53).SPR0;
SS_CAPTURE_DATA(3443) <= SPR_CACHE(53).TOP;
SS_CAPTURE_DATA(3444) <= SPR_CACHE(53).BOTTOM;
SS_CAPTURE_DATA(3454 downto 3445) <= std_logic_vector(SPR_CACHE(54).X(9 downto 0));
SS_CAPTURE_DATA(3455 downto 3455) <= std_logic_vector(SPR_CACHE(54).Y(0 downto 0));
SS_CAPTURE_DATA(3464 downto 3456) <= std_logic_vector(SPR_CACHE(54).Y(9 downto 1));
SS_CAPTURE_DATA(3471 downto 3465) <= std_logic_vector(SPR_CACHE(54).PC(6 downto 0));
SS_CAPTURE_DATA(3475 downto 3472) <= std_logic_vector(SPR_CACHE(54).PC(10 downto 7));
SS_CAPTURE_DATA(3476) <= SPR_CACHE(54).CG;
SS_CAPTURE_DATA(3480 downto 3477) <= std_logic_vector(SPR_CACHE(54).PAL(3 downto 0));
SS_CAPTURE_DATA(3481) <= SPR_CACHE(54).PRIO;
SS_CAPTURE_DATA(3482) <= SPR_CACHE(54).CGX;
SS_CAPTURE_DATA(3484 downto 3483) <= std_logic_vector(SPR_CACHE(54).CGY(1 downto 0));
SS_CAPTURE_DATA(3485) <= SPR_CACHE(54).HF;
SS_CAPTURE_DATA(3486) <= SPR_CACHE(54).VF;
SS_CAPTURE_DATA(3487) <= SPR_CACHE(54).SPR0;
SS_CAPTURE_DATA(3488) <= SPR_CACHE(54).TOP;
SS_CAPTURE_DATA(3489) <= SPR_CACHE(54).BOTTOM;
SS_CAPTURE_DATA(3499 downto 3490) <= std_logic_vector(SPR_CACHE(55).X(9 downto 0));
SS_CAPTURE_DATA(3503 downto 3500) <= std_logic_vector(SPR_CACHE(55).Y(3 downto 0));
SS_CAPTURE_DATA(3509 downto 3504) <= std_logic_vector(SPR_CACHE(55).Y(9 downto 4));
SS_CAPTURE_DATA(3519 downto 3510) <= std_logic_vector(SPR_CACHE(55).PC(9 downto 0));
SS_CAPTURE_DATA(3520 downto 3520) <= std_logic_vector(SPR_CACHE(55).PC(10 downto 10));
SS_CAPTURE_DATA(3521) <= SPR_CACHE(55).CG;
SS_CAPTURE_DATA(3525 downto 3522) <= std_logic_vector(SPR_CACHE(55).PAL(3 downto 0));
SS_CAPTURE_DATA(3526) <= SPR_CACHE(55).PRIO;
SS_CAPTURE_DATA(3527) <= SPR_CACHE(55).CGX;
SS_CAPTURE_DATA(3529 downto 3528) <= std_logic_vector(SPR_CACHE(55).CGY(1 downto 0));
SS_CAPTURE_DATA(3530) <= SPR_CACHE(55).HF;
SS_CAPTURE_DATA(3531) <= SPR_CACHE(55).VF;
SS_CAPTURE_DATA(3532) <= SPR_CACHE(55).SPR0;
SS_CAPTURE_DATA(3533) <= SPR_CACHE(55).TOP;
SS_CAPTURE_DATA(3534) <= SPR_CACHE(55).BOTTOM;
SS_CAPTURE_DATA(3535 downto 3535) <= std_logic_vector(SPR_CACHE(56).X(0 downto 0));
SS_CAPTURE_DATA(3544 downto 3536) <= std_logic_vector(SPR_CACHE(56).X(9 downto 1));
SS_CAPTURE_DATA(3551 downto 3545) <= std_logic_vector(SPR_CACHE(56).Y(6 downto 0));
SS_CAPTURE_DATA(3554 downto 3552) <= std_logic_vector(SPR_CACHE(56).Y(9 downto 7));
SS_CAPTURE_DATA(3565 downto 3555) <= std_logic_vector(SPR_CACHE(56).PC(10 downto 0));
SS_CAPTURE_DATA(3566) <= SPR_CACHE(56).CG;
SS_CAPTURE_DATA(3567 downto 3567) <= std_logic_vector(SPR_CACHE(56).PAL(0 downto 0));
SS_CAPTURE_DATA(3570 downto 3568) <= std_logic_vector(SPR_CACHE(56).PAL(3 downto 1));
SS_CAPTURE_DATA(3571) <= SPR_CACHE(56).PRIO;
SS_CAPTURE_DATA(3572) <= SPR_CACHE(56).CGX;
SS_CAPTURE_DATA(3574 downto 3573) <= std_logic_vector(SPR_CACHE(56).CGY(1 downto 0));
SS_CAPTURE_DATA(3575) <= SPR_CACHE(56).HF;
SS_CAPTURE_DATA(3576) <= SPR_CACHE(56).VF;
SS_CAPTURE_DATA(3577) <= SPR_CACHE(56).SPR0;
SS_CAPTURE_DATA(3578) <= SPR_CACHE(56).TOP;
SS_CAPTURE_DATA(3579) <= SPR_CACHE(56).BOTTOM;
SS_CAPTURE_DATA(3583 downto 3580) <= std_logic_vector(SPR_CACHE(57).X(3 downto 0));
SS_CAPTURE_DATA(3589 downto 3584) <= std_logic_vector(SPR_CACHE(57).X(9 downto 4));
SS_CAPTURE_DATA(3599 downto 3590) <= std_logic_vector(SPR_CACHE(57).Y(9 downto 0));
SS_CAPTURE_DATA(3610 downto 3600) <= std_logic_vector(SPR_CACHE(57).PC(10 downto 0));
SS_CAPTURE_DATA(3611) <= SPR_CACHE(57).CG;
SS_CAPTURE_DATA(3615 downto 3612) <= std_logic_vector(SPR_CACHE(57).PAL(3 downto 0));
SS_CAPTURE_DATA(3616) <= SPR_CACHE(57).PRIO;
SS_CAPTURE_DATA(3617) <= SPR_CACHE(57).CGX;
SS_CAPTURE_DATA(3619 downto 3618) <= std_logic_vector(SPR_CACHE(57).CGY(1 downto 0));
SS_CAPTURE_DATA(3620) <= SPR_CACHE(57).HF;
SS_CAPTURE_DATA(3621) <= SPR_CACHE(57).VF;
SS_CAPTURE_DATA(3622) <= SPR_CACHE(57).SPR0;
SS_CAPTURE_DATA(3623) <= SPR_CACHE(57).TOP;
SS_CAPTURE_DATA(3624) <= SPR_CACHE(57).BOTTOM;
SS_CAPTURE_DATA(3631 downto 3625) <= std_logic_vector(SPR_CACHE(58).X(6 downto 0));
SS_CAPTURE_DATA(3634 downto 3632) <= std_logic_vector(SPR_CACHE(58).X(9 downto 7));
SS_CAPTURE_DATA(3644 downto 3635) <= std_logic_vector(SPR_CACHE(58).Y(9 downto 0));
SS_CAPTURE_DATA(3647 downto 3645) <= std_logic_vector(SPR_CACHE(58).PC(2 downto 0));
SS_CAPTURE_DATA(3655 downto 3648) <= std_logic_vector(SPR_CACHE(58).PC(10 downto 3));
SS_CAPTURE_DATA(3656) <= SPR_CACHE(58).CG;
SS_CAPTURE_DATA(3660 downto 3657) <= std_logic_vector(SPR_CACHE(58).PAL(3 downto 0));
SS_CAPTURE_DATA(3661) <= SPR_CACHE(58).PRIO;
SS_CAPTURE_DATA(3662) <= SPR_CACHE(58).CGX;
SS_CAPTURE_DATA(3663 downto 3663) <= std_logic_vector(SPR_CACHE(58).CGY(0 downto 0));
SS_CAPTURE_DATA(3664 downto 3664) <= std_logic_vector(SPR_CACHE(58).CGY(1 downto 1));
SS_CAPTURE_DATA(3665) <= SPR_CACHE(58).HF;
SS_CAPTURE_DATA(3666) <= SPR_CACHE(58).VF;
SS_CAPTURE_DATA(3667) <= SPR_CACHE(58).SPR0;
SS_CAPTURE_DATA(3668) <= SPR_CACHE(58).TOP;
SS_CAPTURE_DATA(3669) <= SPR_CACHE(58).BOTTOM;
SS_CAPTURE_DATA(3679 downto 3670) <= std_logic_vector(SPR_CACHE(59).X(9 downto 0));
SS_CAPTURE_DATA(3689 downto 3680) <= std_logic_vector(SPR_CACHE(59).Y(9 downto 0));
SS_CAPTURE_DATA(3695 downto 3690) <= std_logic_vector(SPR_CACHE(59).PC(5 downto 0));
SS_CAPTURE_DATA(3700 downto 3696) <= std_logic_vector(SPR_CACHE(59).PC(10 downto 6));
SS_CAPTURE_DATA(3701) <= SPR_CACHE(59).CG;
SS_CAPTURE_DATA(3705 downto 3702) <= std_logic_vector(SPR_CACHE(59).PAL(3 downto 0));
SS_CAPTURE_DATA(3706) <= SPR_CACHE(59).PRIO;
SS_CAPTURE_DATA(3707) <= SPR_CACHE(59).CGX;
SS_CAPTURE_DATA(3709 downto 3708) <= std_logic_vector(SPR_CACHE(59).CGY(1 downto 0));
SS_CAPTURE_DATA(3710) <= SPR_CACHE(59).HF;
SS_CAPTURE_DATA(3711) <= SPR_CACHE(59).VF;
SS_CAPTURE_DATA(3712) <= SPR_CACHE(59).SPR0;
SS_CAPTURE_DATA(3713) <= SPR_CACHE(59).TOP;
SS_CAPTURE_DATA(3714) <= SPR_CACHE(59).BOTTOM;
SS_CAPTURE_DATA(3724 downto 3715) <= std_logic_vector(SPR_CACHE(60).X(9 downto 0));
SS_CAPTURE_DATA(3727 downto 3725) <= std_logic_vector(SPR_CACHE(60).Y(2 downto 0));
SS_CAPTURE_DATA(3734 downto 3728) <= std_logic_vector(SPR_CACHE(60).Y(9 downto 3));
SS_CAPTURE_DATA(3743 downto 3735) <= std_logic_vector(SPR_CACHE(60).PC(8 downto 0));
SS_CAPTURE_DATA(3745 downto 3744) <= std_logic_vector(SPR_CACHE(60).PC(10 downto 9));
SS_CAPTURE_DATA(3746) <= SPR_CACHE(60).CG;
SS_CAPTURE_DATA(3750 downto 3747) <= std_logic_vector(SPR_CACHE(60).PAL(3 downto 0));
SS_CAPTURE_DATA(3751) <= SPR_CACHE(60).PRIO;
SS_CAPTURE_DATA(3752) <= SPR_CACHE(60).CGX;
SS_CAPTURE_DATA(3754 downto 3753) <= std_logic_vector(SPR_CACHE(60).CGY(1 downto 0));
SS_CAPTURE_DATA(3755) <= SPR_CACHE(60).HF;
SS_CAPTURE_DATA(3756) <= SPR_CACHE(60).VF;
SS_CAPTURE_DATA(3757) <= SPR_CACHE(60).SPR0;
SS_CAPTURE_DATA(3758) <= SPR_CACHE(60).TOP;
SS_CAPTURE_DATA(3759) <= SPR_CACHE(60).BOTTOM;
SS_CAPTURE_DATA(3769 downto 3760) <= std_logic_vector(SPR_CACHE(61).X(9 downto 0));
SS_CAPTURE_DATA(3775 downto 3770) <= std_logic_vector(SPR_CACHE(61).Y(5 downto 0));
SS_CAPTURE_DATA(3779 downto 3776) <= std_logic_vector(SPR_CACHE(61).Y(9 downto 6));
SS_CAPTURE_DATA(3790 downto 3780) <= std_logic_vector(SPR_CACHE(61).PC(10 downto 0));
SS_CAPTURE_DATA(3791) <= SPR_CACHE(61).CG;
SS_CAPTURE_DATA(3795 downto 3792) <= std_logic_vector(SPR_CACHE(61).PAL(3 downto 0));
SS_CAPTURE_DATA(3796) <= SPR_CACHE(61).PRIO;
SS_CAPTURE_DATA(3797) <= SPR_CACHE(61).CGX;
SS_CAPTURE_DATA(3799 downto 3798) <= std_logic_vector(SPR_CACHE(61).CGY(1 downto 0));
SS_CAPTURE_DATA(3800) <= SPR_CACHE(61).HF;
SS_CAPTURE_DATA(3801) <= SPR_CACHE(61).VF;
SS_CAPTURE_DATA(3802) <= SPR_CACHE(61).SPR0;
SS_CAPTURE_DATA(3803) <= SPR_CACHE(61).TOP;
SS_CAPTURE_DATA(3804) <= SPR_CACHE(61).BOTTOM;
SS_CAPTURE_DATA(3807 downto 3805) <= std_logic_vector(SPR_CACHE(62).X(2 downto 0));
SS_CAPTURE_DATA(3814 downto 3808) <= std_logic_vector(SPR_CACHE(62).X(9 downto 3));
SS_CAPTURE_DATA(3823 downto 3815) <= std_logic_vector(SPR_CACHE(62).Y(8 downto 0));
SS_CAPTURE_DATA(3824 downto 3824) <= std_logic_vector(SPR_CACHE(62).Y(9 downto 9));
SS_CAPTURE_DATA(3835 downto 3825) <= std_logic_vector(SPR_CACHE(62).PC(10 downto 0));
SS_CAPTURE_DATA(3836) <= SPR_CACHE(62).CG;
SS_CAPTURE_DATA(3839 downto 3837) <= std_logic_vector(SPR_CACHE(62).PAL(2 downto 0));
SS_CAPTURE_DATA(3840 downto 3840) <= std_logic_vector(SPR_CACHE(62).PAL(3 downto 3));
SS_CAPTURE_DATA(3841) <= SPR_CACHE(62).PRIO;
SS_CAPTURE_DATA(3842) <= SPR_CACHE(62).CGX;
SS_CAPTURE_DATA(3844 downto 3843) <= std_logic_vector(SPR_CACHE(62).CGY(1 downto 0));
SS_CAPTURE_DATA(3845) <= SPR_CACHE(62).HF;
SS_CAPTURE_DATA(3846) <= SPR_CACHE(62).VF;
SS_CAPTURE_DATA(3847) <= SPR_CACHE(62).SPR0;
SS_CAPTURE_DATA(3848) <= SPR_CACHE(62).TOP;
SS_CAPTURE_DATA(3849) <= SPR_CACHE(62).BOTTOM;
SS_CAPTURE_DATA(3855 downto 3850) <= std_logic_vector(SPR_CACHE(63).X(5 downto 0));
SS_CAPTURE_DATA(3859 downto 3856) <= std_logic_vector(SPR_CACHE(63).X(9 downto 6));
SS_CAPTURE_DATA(3869 downto 3860) <= std_logic_vector(SPR_CACHE(63).Y(9 downto 0));
SS_CAPTURE_DATA(3871 downto 3870) <= std_logic_vector(SPR_CACHE(63).PC(1 downto 0));
SS_CAPTURE_DATA(3880 downto 3872) <= std_logic_vector(SPR_CACHE(63).PC(10 downto 2));
SS_CAPTURE_DATA(3881) <= SPR_CACHE(63).CG;
SS_CAPTURE_DATA(3885 downto 3882) <= std_logic_vector(SPR_CACHE(63).PAL(3 downto 0));
SS_CAPTURE_DATA(3886) <= SPR_CACHE(63).PRIO;
SS_CAPTURE_DATA(3887) <= SPR_CACHE(63).CGX;
SS_CAPTURE_DATA(3889 downto 3888) <= std_logic_vector(SPR_CACHE(63).CGY(1 downto 0));
SS_CAPTURE_DATA(3890) <= SPR_CACHE(63).HF;
SS_CAPTURE_DATA(3891) <= SPR_CACHE(63).VF;
SS_CAPTURE_DATA(3892) <= SPR_CACHE(63).SPR0;
SS_CAPTURE_DATA(3893) <= SPR_CACHE(63).TOP;
SS_CAPTURE_DATA(3894) <= SPR_CACHE(63).BOTTOM;
SS_CAPTURE_DATA(3895) <= SPR_CG;
SS_CAPTURE_DATA(3903 downto 3896) <= std_logic_vector(SPR_CH0(7 downto 0));
SS_CAPTURE_DATA(3911 downto 3904) <= std_logic_vector(SPR_CH0(15 downto 8));
SS_CAPTURE_DATA(3919 downto 3912) <= std_logic_vector(SPR_CH1(7 downto 0));
SS_CAPTURE_DATA(3927 downto 3920) <= std_logic_vector(SPR_CH1(15 downto 8));
SS_CAPTURE_DATA(3935 downto 3928) <= std_logic_vector(SPR_CH2(7 downto 0));
SS_CAPTURE_DATA(3943 downto 3936) <= std_logic_vector(SPR_CH2(15 downto 8));
SS_CAPTURE_DATA(3951 downto 3944) <= std_logic_vector(SPR_COLOR(0)(7 downto 0));
SS_CAPTURE_DATA(3952 downto 3952) <= std_logic_vector(SPR_COLOR(0)(8 downto 8));
SS_CAPTURE_DATA(3961 downto 3953) <= std_logic_vector(SPR_COLOR(1)(8 downto 0));
SS_CAPTURE_DATA(3967 downto 3962) <= std_logic_vector(SPR_COLOR(2)(5 downto 0));
SS_CAPTURE_DATA(3970 downto 3968) <= std_logic_vector(SPR_COLOR(2)(8 downto 6));
SS_CAPTURE_DATA(3979 downto 3971) <= std_logic_vector(SPR_COLOR(3)(8 downto 0));
SS_CAPTURE_DATA(3983 downto 3980) <= std_logic_vector(SPR_COLOR(4)(3 downto 0));
SS_CAPTURE_DATA(3988 downto 3984) <= std_logic_vector(SPR_COLOR(4)(8 downto 4));
SS_CAPTURE_DATA(3997 downto 3989) <= std_logic_vector(SPR_COLOR(5)(8 downto 0));
SS_CAPTURE_DATA(3999 downto 3998) <= std_logic_vector(SPR_COLOR(6)(1 downto 0));
SS_CAPTURE_DATA(4006 downto 4000) <= std_logic_vector(SPR_COLOR(6)(8 downto 2));
SS_CAPTURE_DATA(4015 downto 4007) <= std_logic_vector(SPR_COLOR(7)(8 downto 0));
SS_CAPTURE_DATA(4016) <= SPR_EVAL;
SS_CAPTURE_DATA(4023 downto 4017) <= std_logic_vector(SPR_EVAL_CNT(6 downto 0));
SS_CAPTURE_DATA(4024) <= SPR_EVAL_DONE;
SS_CAPTURE_DATA(4025) <= SPR_EVAL_FULL;
SS_CAPTURE_DATA(4031 downto 4026) <= std_logic_vector(SPR_EVAL_X(5 downto 0));
SS_CAPTURE_DATA(4033 downto 4032) <= std_logic_vector(SPR_EVAL_X(7 downto 6));
SS_CAPTURE_DATA(4034) <= SPR_FETCH;
SS_CAPTURE_DATA(4041 downto 4035) <= std_logic_vector(SPR_FETCH_CNT(6 downto 0));
SS_CAPTURE_DATA(4042) <= SPR_FETCH_DONE;
SS_CAPTURE_DATA(4043) <= SPR_FETCH_EN;
SS_CAPTURE_DATA(4044) <= SPR_FETCH_W;
SS_CAPTURE_DATA(4045) <= SPR_FIND;
SS_CAPTURE_DATA(4047 downto 4046) <= std_logic_vector(SPR_LINE_ADDR(0)(1 downto 0));
SS_CAPTURE_DATA(4054 downto 4048) <= std_logic_vector(SPR_LINE_ADDR(0)(8 downto 2));
SS_CAPTURE_DATA(4063 downto 4055) <= std_logic_vector(SPR_LINE_ADDR(1)(8 downto 0));
SS_CAPTURE_DATA(4064) <= SPR_LINE_CLR;
SS_CAPTURE_DATA(4073 downto 4065) <= std_logic_vector(SPR_LINE_D(0)(8 downto 0));
SS_CAPTURE_DATA(4079 downto 4074) <= std_logic_vector(SPR_LINE_D(1)(5 downto 0));
SS_CAPTURE_DATA(4082 downto 4080) <= std_logic_vector(SPR_LINE_D(1)(8 downto 6));
SS_CAPTURE_DATA(4084 downto 4083) <= std_logic_vector(SPR_LINE_WE(1 downto 0));
SS_CAPTURE_DATA(4094 downto 4085) <= std_logic_vector(SPR_OUT_X(9 downto 0));
SS_CAPTURE_DATA(4095 downto 4095) <= std_logic_vector(SPR_PC(0 downto 0));
SS_CAPTURE_DATA(4105 downto 4096) <= std_logic_vector(SPR_PC(10 downto 1));
SS_CAPTURE_DATA(4106) <= SPR_TILE_BOTTOM;
SS_CAPTURE_DATA(4111 downto 4107) <= std_logic_vector(SPR_TILE_FRAME(4 downto 0));
SS_CAPTURE_DATA(4127 downto 4112) <= std_logic_vector(SPR_TILE_FRAME(20 downto 5));
SS_CAPTURE_DATA(4143 downto 4128) <= std_logic_vector(SPR_TILE_FRAME(36 downto 21));
SS_CAPTURE_DATA(4159 downto 4144) <= std_logic_vector(SPR_TILE_FRAME(52 downto 37));
SS_CAPTURE_DATA(4175 downto 4160) <= std_logic_vector(SPR_TILE_FRAME(68 downto 53));
SS_CAPTURE_DATA(4191 downto 4176) <= std_logic_vector(SPR_TILE_FRAME(84 downto 69));
SS_CAPTURE_DATA(4207 downto 4192) <= std_logic_vector(SPR_TILE_FRAME(100 downto 85));
SS_CAPTURE_DATA(4223 downto 4208) <= std_logic_vector(SPR_TILE_FRAME(116 downto 101));
SS_CAPTURE_DATA(4239 downto 4224) <= std_logic_vector(SPR_TILE_FRAME(132 downto 117));
SS_CAPTURE_DATA(4255 downto 4240) <= std_logic_vector(SPR_TILE_FRAME(148 downto 133));
SS_CAPTURE_DATA(4271 downto 4256) <= std_logic_vector(SPR_TILE_FRAME(164 downto 149));
SS_CAPTURE_DATA(4287 downto 4272) <= std_logic_vector(SPR_TILE_FRAME(180 downto 165));
SS_CAPTURE_DATA(4303 downto 4288) <= std_logic_vector(SPR_TILE_FRAME(196 downto 181));
SS_CAPTURE_DATA(4319 downto 4304) <= std_logic_vector(SPR_TILE_FRAME(212 downto 197));
SS_CAPTURE_DATA(4335 downto 4320) <= std_logic_vector(SPR_TILE_FRAME(228 downto 213));
SS_CAPTURE_DATA(4351 downto 4336) <= std_logic_vector(SPR_TILE_FRAME(244 downto 229));
SS_CAPTURE_DATA(4367 downto 4352) <= std_logic_vector(SPR_TILE_FRAME(260 downto 245));
SS_CAPTURE_DATA(4383 downto 4368) <= std_logic_vector(SPR_TILE_FRAME(276 downto 261));
SS_CAPTURE_DATA(4399 downto 4384) <= std_logic_vector(SPR_TILE_FRAME(292 downto 277));
SS_CAPTURE_DATA(4415 downto 4400) <= std_logic_vector(SPR_TILE_FRAME(308 downto 293));
SS_CAPTURE_DATA(4431 downto 4416) <= std_logic_vector(SPR_TILE_FRAME(324 downto 309));
SS_CAPTURE_DATA(4447 downto 4432) <= std_logic_vector(SPR_TILE_FRAME(340 downto 325));
SS_CAPTURE_DATA(4463 downto 4448) <= std_logic_vector(SPR_TILE_FRAME(356 downto 341));
SS_CAPTURE_DATA(4479 downto 4464) <= std_logic_vector(SPR_TILE_FRAME(372 downto 357));
SS_CAPTURE_DATA(4495 downto 4480) <= std_logic_vector(SPR_TILE_FRAME(388 downto 373));
SS_CAPTURE_DATA(4511 downto 4496) <= std_logic_vector(SPR_TILE_FRAME(404 downto 389));
SS_CAPTURE_DATA(4527 downto 4512) <= std_logic_vector(SPR_TILE_FRAME(420 downto 405));
SS_CAPTURE_DATA(4543 downto 4528) <= std_logic_vector(SPR_TILE_FRAME(436 downto 421));
SS_CAPTURE_DATA(4559 downto 4544) <= std_logic_vector(SPR_TILE_FRAME(452 downto 437));
SS_CAPTURE_DATA(4575 downto 4560) <= std_logic_vector(SPR_TILE_FRAME(468 downto 453));
SS_CAPTURE_DATA(4591 downto 4576) <= std_logic_vector(SPR_TILE_FRAME(484 downto 469));
SS_CAPTURE_DATA(4607 downto 4592) <= std_logic_vector(SPR_TILE_FRAME(500 downto 485));
SS_CAPTURE_DATA(4623 downto 4608) <= std_logic_vector(SPR_TILE_FRAME(516 downto 501));
SS_CAPTURE_DATA(4639 downto 4624) <= std_logic_vector(SPR_TILE_FRAME(532 downto 517));
SS_CAPTURE_DATA(4655 downto 4640) <= std_logic_vector(SPR_TILE_FRAME(548 downto 533));
SS_CAPTURE_DATA(4666 downto 4656) <= std_logic_vector(SPR_TILE_FRAME(559 downto 549));
SS_CAPTURE_DATA(4667) <= SPR_TILE_HF;
SS_CAPTURE_DATA(4668) <= SPR_TILE_LEFT;
SS_CAPTURE_DATA(4671 downto 4669) <= std_logic_vector(SPR_TILE_P0(2 downto 0));
SS_CAPTURE_DATA(4684 downto 4672) <= std_logic_vector(SPR_TILE_P0(15 downto 3));
SS_CAPTURE_DATA(4687 downto 4685) <= std_logic_vector(SPR_TILE_P1(2 downto 0));
SS_CAPTURE_DATA(4700 downto 4688) <= std_logic_vector(SPR_TILE_P1(15 downto 3));
SS_CAPTURE_DATA(4703 downto 4701) <= std_logic_vector(SPR_TILE_P2(2 downto 0));
SS_CAPTURE_DATA(4716 downto 4704) <= std_logic_vector(SPR_TILE_P2(15 downto 3));
SS_CAPTURE_DATA(4719 downto 4717) <= std_logic_vector(SPR_TILE_P3(2 downto 0));
SS_CAPTURE_DATA(4732 downto 4720) <= std_logic_vector(SPR_TILE_P3(15 downto 3));
SS_CAPTURE_DATA(4735 downto 4733) <= std_logic_vector(SPR_TILE_PAL(2 downto 0));
SS_CAPTURE_DATA(4736 downto 4736) <= std_logic_vector(SPR_TILE_PAL(3 downto 3));
SS_CAPTURE_DATA(4751 downto 4737) <= std_logic_vector(SPR_TILE_PIX_SET(14 downto 0));
SS_CAPTURE_DATA(4767 downto 4752) <= std_logic_vector(SPR_TILE_PIX_SET(30 downto 15));
SS_CAPTURE_DATA(4783 downto 4768) <= std_logic_vector(SPR_TILE_PIX_SET(46 downto 31));
SS_CAPTURE_DATA(4799 downto 4784) <= std_logic_vector(SPR_TILE_PIX_SET(62 downto 47));
SS_CAPTURE_DATA(4815 downto 4800) <= std_logic_vector(SPR_TILE_PIX_SET(78 downto 63));
SS_CAPTURE_DATA(4831 downto 4816) <= std_logic_vector(SPR_TILE_PIX_SET(94 downto 79));
SS_CAPTURE_DATA(4847 downto 4832) <= std_logic_vector(SPR_TILE_PIX_SET(110 downto 95));
SS_CAPTURE_DATA(4863 downto 4848) <= std_logic_vector(SPR_TILE_PIX_SET(126 downto 111));
SS_CAPTURE_DATA(4879 downto 4864) <= std_logic_vector(SPR_TILE_PIX_SET(142 downto 127));
SS_CAPTURE_DATA(4895 downto 4880) <= std_logic_vector(SPR_TILE_PIX_SET(158 downto 143));
SS_CAPTURE_DATA(4911 downto 4896) <= std_logic_vector(SPR_TILE_PIX_SET(174 downto 159));
SS_CAPTURE_DATA(4927 downto 4912) <= std_logic_vector(SPR_TILE_PIX_SET(190 downto 175));
SS_CAPTURE_DATA(4943 downto 4928) <= std_logic_vector(SPR_TILE_PIX_SET(206 downto 191));
SS_CAPTURE_DATA(4959 downto 4944) <= std_logic_vector(SPR_TILE_PIX_SET(222 downto 207));
SS_CAPTURE_DATA(4975 downto 4960) <= std_logic_vector(SPR_TILE_PIX_SET(238 downto 223));
SS_CAPTURE_DATA(4991 downto 4976) <= std_logic_vector(SPR_TILE_PIX_SET(254 downto 239));
SS_CAPTURE_DATA(5007 downto 4992) <= std_logic_vector(SPR_TILE_PIX_SET(270 downto 255));
SS_CAPTURE_DATA(5023 downto 5008) <= std_logic_vector(SPR_TILE_PIX_SET(286 downto 271));
SS_CAPTURE_DATA(5039 downto 5024) <= std_logic_vector(SPR_TILE_PIX_SET(302 downto 287));
SS_CAPTURE_DATA(5055 downto 5040) <= std_logic_vector(SPR_TILE_PIX_SET(318 downto 303));
SS_CAPTURE_DATA(5071 downto 5056) <= std_logic_vector(SPR_TILE_PIX_SET(334 downto 319));
SS_CAPTURE_DATA(5087 downto 5072) <= std_logic_vector(SPR_TILE_PIX_SET(350 downto 335));
SS_CAPTURE_DATA(5103 downto 5088) <= std_logic_vector(SPR_TILE_PIX_SET(366 downto 351));
SS_CAPTURE_DATA(5119 downto 5104) <= std_logic_vector(SPR_TILE_PIX_SET(382 downto 367));
SS_CAPTURE_DATA(5135 downto 5120) <= std_logic_vector(SPR_TILE_PIX_SET(398 downto 383));
SS_CAPTURE_DATA(5151 downto 5136) <= std_logic_vector(SPR_TILE_PIX_SET(414 downto 399));
SS_CAPTURE_DATA(5167 downto 5152) <= std_logic_vector(SPR_TILE_PIX_SET(430 downto 415));
SS_CAPTURE_DATA(5183 downto 5168) <= std_logic_vector(SPR_TILE_PIX_SET(446 downto 431));
SS_CAPTURE_DATA(5199 downto 5184) <= std_logic_vector(SPR_TILE_PIX_SET(462 downto 447));
SS_CAPTURE_DATA(5215 downto 5200) <= std_logic_vector(SPR_TILE_PIX_SET(478 downto 463));
SS_CAPTURE_DATA(5231 downto 5216) <= std_logic_vector(SPR_TILE_PIX_SET(494 downto 479));
SS_CAPTURE_DATA(5247 downto 5232) <= std_logic_vector(SPR_TILE_PIX_SET(510 downto 495));
SS_CAPTURE_DATA(5263 downto 5248) <= std_logic_vector(SPR_TILE_PIX_SET(526 downto 511));
SS_CAPTURE_DATA(5279 downto 5264) <= std_logic_vector(SPR_TILE_PIX_SET(542 downto 527));
SS_CAPTURE_DATA(5295 downto 5280) <= std_logic_vector(SPR_TILE_PIX_SET(558 downto 543));
SS_CAPTURE_DATA(5296 downto 5296) <= std_logic_vector(SPR_TILE_PIX_SET(559 downto 559));
SS_CAPTURE_DATA(5297) <= SPR_TILE_PRIO;
SS_CAPTURE_DATA(5298) <= SPR_TILE_RIGTH;
SS_CAPTURE_DATA(5299) <= SPR_TILE_SAVE;
SS_CAPTURE_DATA(5300) <= SPR_TILE_SPR0;
SS_CAPTURE_DATA(5311 downto 5301) <= std_logic_vector(SPR_TILE_SPR0_SET(10 downto 0));
SS_CAPTURE_DATA(5327 downto 5312) <= std_logic_vector(SPR_TILE_SPR0_SET(26 downto 11));
SS_CAPTURE_DATA(5343 downto 5328) <= std_logic_vector(SPR_TILE_SPR0_SET(42 downto 27));
SS_CAPTURE_DATA(5359 downto 5344) <= std_logic_vector(SPR_TILE_SPR0_SET(58 downto 43));
SS_CAPTURE_DATA(5375 downto 5360) <= std_logic_vector(SPR_TILE_SPR0_SET(74 downto 59));
SS_CAPTURE_DATA(5391 downto 5376) <= std_logic_vector(SPR_TILE_SPR0_SET(90 downto 75));
SS_CAPTURE_DATA(5407 downto 5392) <= std_logic_vector(SPR_TILE_SPR0_SET(106 downto 91));
SS_CAPTURE_DATA(5423 downto 5408) <= std_logic_vector(SPR_TILE_SPR0_SET(122 downto 107));
SS_CAPTURE_DATA(5439 downto 5424) <= std_logic_vector(SPR_TILE_SPR0_SET(138 downto 123));
SS_CAPTURE_DATA(5455 downto 5440) <= std_logic_vector(SPR_TILE_SPR0_SET(154 downto 139));
SS_CAPTURE_DATA(5471 downto 5456) <= std_logic_vector(SPR_TILE_SPR0_SET(170 downto 155));
SS_CAPTURE_DATA(5487 downto 5472) <= std_logic_vector(SPR_TILE_SPR0_SET(186 downto 171));
SS_CAPTURE_DATA(5503 downto 5488) <= std_logic_vector(SPR_TILE_SPR0_SET(202 downto 187));
SS_CAPTURE_DATA(5519 downto 5504) <= std_logic_vector(SPR_TILE_SPR0_SET(218 downto 203));
SS_CAPTURE_DATA(5535 downto 5520) <= std_logic_vector(SPR_TILE_SPR0_SET(234 downto 219));
SS_CAPTURE_DATA(5551 downto 5536) <= std_logic_vector(SPR_TILE_SPR0_SET(250 downto 235));
SS_CAPTURE_DATA(5567 downto 5552) <= std_logic_vector(SPR_TILE_SPR0_SET(266 downto 251));
SS_CAPTURE_DATA(5583 downto 5568) <= std_logic_vector(SPR_TILE_SPR0_SET(282 downto 267));
SS_CAPTURE_DATA(5599 downto 5584) <= std_logic_vector(SPR_TILE_SPR0_SET(298 downto 283));
SS_CAPTURE_DATA(5615 downto 5600) <= std_logic_vector(SPR_TILE_SPR0_SET(314 downto 299));
SS_CAPTURE_DATA(5631 downto 5616) <= std_logic_vector(SPR_TILE_SPR0_SET(330 downto 315));
SS_CAPTURE_DATA(5647 downto 5632) <= std_logic_vector(SPR_TILE_SPR0_SET(346 downto 331));
SS_CAPTURE_DATA(5663 downto 5648) <= std_logic_vector(SPR_TILE_SPR0_SET(362 downto 347));
SS_CAPTURE_DATA(5679 downto 5664) <= std_logic_vector(SPR_TILE_SPR0_SET(378 downto 363));
SS_CAPTURE_DATA(5695 downto 5680) <= std_logic_vector(SPR_TILE_SPR0_SET(394 downto 379));
SS_CAPTURE_DATA(5711 downto 5696) <= std_logic_vector(SPR_TILE_SPR0_SET(410 downto 395));
SS_CAPTURE_DATA(5727 downto 5712) <= std_logic_vector(SPR_TILE_SPR0_SET(426 downto 411));
SS_CAPTURE_DATA(5743 downto 5728) <= std_logic_vector(SPR_TILE_SPR0_SET(442 downto 427));
SS_CAPTURE_DATA(5759 downto 5744) <= std_logic_vector(SPR_TILE_SPR0_SET(458 downto 443));
SS_CAPTURE_DATA(5775 downto 5760) <= std_logic_vector(SPR_TILE_SPR0_SET(474 downto 459));
SS_CAPTURE_DATA(5791 downto 5776) <= std_logic_vector(SPR_TILE_SPR0_SET(490 downto 475));
SS_CAPTURE_DATA(5807 downto 5792) <= std_logic_vector(SPR_TILE_SPR0_SET(506 downto 491));
SS_CAPTURE_DATA(5823 downto 5808) <= std_logic_vector(SPR_TILE_SPR0_SET(522 downto 507));
SS_CAPTURE_DATA(5839 downto 5824) <= std_logic_vector(SPR_TILE_SPR0_SET(538 downto 523));
SS_CAPTURE_DATA(5855 downto 5840) <= std_logic_vector(SPR_TILE_SPR0_SET(554 downto 539));
SS_CAPTURE_DATA(5860 downto 5856) <= std_logic_vector(SPR_TILE_SPR0_SET(559 downto 555));
SS_CAPTURE_DATA(5861) <= SPR_TILE_TOP;
SS_CAPTURE_DATA(5871 downto 5862) <= std_logic_vector(SPR_TILE_X(9 downto 0));
SS_CAPTURE_DATA(5881 downto 5872) <= std_logic_vector(SPR_X(9 downto 0));
SS_CAPTURE_DATA(5887 downto 5882) <= std_logic_vector(SPR_Y(5 downto 0));
SS_CAPTURE_DATA(5891 downto 5888) <= std_logic_vector(SPR_Y(9 downto 6));
SS_CAPTURE_DATA(5898 downto 5892) <= std_logic_vector(SR_LATCH(6 downto 0));
SS_CAPTURE_DATA(5903 downto 5899) <= std_logic_vector(TILE_CNT(4 downto 0));
SS_CAPTURE_DATA(5905 downto 5904) <= std_logic_vector(TILE_CNT(6 downto 5));
SS_CAPTURE_DATA(5906) <= TILE_ZERO;
SS_CAPTURE_DATA(5914 downto 5907) <= std_logic_vector(VDE(7 downto 0));
SS_CAPTURE_DATA(5915) <= VDISP;
SS_CAPTURE_DATA(5916) <= VDISP_OLD;
SS_CAPTURE_DATA(5919 downto 5917) <= std_logic_vector(VDS(2 downto 0));
SS_CAPTURE_DATA(5924 downto 5920) <= std_logic_vector(VDS(7 downto 3));
SS_CAPTURE_DATA(5933 downto 5925) <= std_logic_vector(VDW(8 downto 0));
SS_CAPTURE_DATA(5935 downto 5934) <= std_logic_vector(VM(1 downto 0));
SS_CAPTURE_DATA(5951 downto 5936) <= std_logic_vector(VRR(15 downto 0));
SS_CAPTURE_DATA(5956 downto 5952) <= std_logic_vector(VSW(4 downto 0));
SS_CAPTURE_DATA(5968) <= SS_PROXY_0;
SS_CAPTURE_DATA(5993 downto 5984) <= std_logic_vector(SS_PROXY_1(9 downto 0));
SS_CAPTURE_DATA(6008 downto 6000) <= std_logic_vector(SS_PROXY_2(8 downto 0));
SS_CAPTURE_DATA(6024 downto 6016) <= std_logic_vector(SS_PROXY_3(8 downto 0));
SS_CAPTURE_DATA(6037 downto 6032) <= std_logic_vector(SS_PROXY_4(5 downto 0));
SS_CAPTURE_DATA(6053 downto 6048) <= std_logic_vector(SS_PROXY_5(5 downto 0));
SS_CAPTURE_DATA(6069 downto 6064) <= std_logic_vector(SS_PROXY_6(5 downto 0));
SS_CAPTURE_DATA(6082 downto 6080) <= std_logic_vector(SS_PROXY_7(2 downto 0));
SS_CAPTURE_DATA(6099 downto 6096) <= std_logic_vector(SS_PROXY_8(3 downto 0));
SS_CAPTURE_DATA(6121 downto 6112) <= std_logic_vector(SS_PROXY_9(9 downto 0));
SS_CAPTURE_DATA(6131 downto 6128) <= std_logic_vector(SS_PROXY_10(3 downto 0));
SS_CAPTURE_DATA(6147 downto 6144) <= std_logic_vector(SS_PROXY_11(3 downto 0));
SS_CAPTURE_DATA(6163 downto 6160) <= std_logic_vector(SS_PROXY_12(3 downto 0));
SS_CAPTURE_DATA(5967 downto 5957) <= (others => '0');
SS_CAPTURE_DATA(5983 downto 5969) <= (others => '0');
SS_CAPTURE_DATA(5999 downto 5994) <= (others => '0');
SS_CAPTURE_DATA(6015 downto 6009) <= (others => '0');
SS_CAPTURE_DATA(6031 downto 6025) <= (others => '0');
SS_CAPTURE_DATA(6047 downto 6038) <= (others => '0');
SS_CAPTURE_DATA(6063 downto 6054) <= (others => '0');
SS_CAPTURE_DATA(6079 downto 6070) <= (others => '0');
SS_CAPTURE_DATA(6095 downto 6083) <= (others => '0');
SS_CAPTURE_DATA(6111 downto 6100) <= (others => '0');
SS_CAPTURE_DATA(6127 downto 6122) <= (others => '0');
SS_CAPTURE_DATA(6143 downto 6132) <= (others => '0');
SS_CAPTURE_DATA(6159 downto 6148) <= (others => '0');
SS_CAPTURE_DATA(6175 downto 6164) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 12 and to_integer(unsigned(SS_RADDR)) <= 397) then
SS_CHAIN <= SS_RDI & SS_CHAIN(6175 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 12 and to_integer(unsigned(SS_RADDR)) <= 397) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(6175 downto 16);
end if;
end if;
end process;
SS_SH_AR(4 downto 0) <= SS_CHAIN(4 downto 0);
SS_SH_BB <= SS_CHAIN(5);
SS_SH_BG_BAT_CC(9 downto 0) <= SS_CHAIN(15 downto 6);
SS_SH_BG_BAT_CC(11 downto 10) <= SS_CHAIN(17 downto 16);
SS_SH_BG_BAT_COL(3 downto 0) <= SS_CHAIN(21 downto 18);
SS_SH_BG_CH0(7 downto 0) <= SS_CHAIN(29 downto 22);
SS_SH_BG_CH1(1 downto 0) <= SS_CHAIN(31 downto 30);
SS_SH_BG_CH1(7 downto 2) <= SS_CHAIN(37 downto 32);
SS_SH_BG_COLOR(0)(7 downto 0) <= SS_CHAIN(45 downto 38);
SS_SH_BG_COLOR(1)(1 downto 0) <= SS_CHAIN(47 downto 46);
SS_SH_BG_COLOR(1)(7 downto 2) <= SS_CHAIN(53 downto 48);
SS_SH_BG_COLOR(2)(7 downto 0) <= SS_CHAIN(61 downto 54);
SS_SH_BG_COLOR(3)(1 downto 0) <= SS_CHAIN(63 downto 62);
SS_SH_BG_COLOR(3)(7 downto 2) <= SS_CHAIN(69 downto 64);
SS_SH_BG_COLOR(4)(7 downto 0) <= SS_CHAIN(77 downto 70);
SS_SH_BG_COLOR(5)(1 downto 0) <= SS_CHAIN(79 downto 78);
SS_SH_BG_COLOR(5)(7 downto 2) <= SS_CHAIN(85 downto 80);
SS_SH_BG_COLOR(6)(7 downto 0) <= SS_CHAIN(93 downto 86);
SS_SH_BG_COLOR(7)(1 downto 0) <= SS_CHAIN(95 downto 94);
SS_SH_BG_COLOR(7)(7 downto 2) <= SS_CHAIN(101 downto 96);
SS_SH_BG_FETCH <= SS_CHAIN(102);
SS_SH_BG_OUT <= SS_CHAIN(103);
SS_SH_BG_OUT_X(7 downto 0) <= unsigned(SS_CHAIN(111 downto 104));
SS_SH_BG_OUT_X(9 downto 8) <= unsigned(SS_CHAIN(113 downto 112));
SS_SH_BG_SR0(13 downto 0) <= SS_CHAIN(127 downto 114);
SS_SH_BG_SR0(15 downto 14) <= SS_CHAIN(129 downto 128);
SS_SH_BG_SR1(13 downto 0) <= SS_CHAIN(143 downto 130);
SS_SH_BG_SR1(15 downto 14) <= SS_CHAIN(145 downto 144);
SS_SH_BG_SR2(13 downto 0) <= SS_CHAIN(159 downto 146);
SS_SH_BG_SR2(15 downto 14) <= SS_CHAIN(161 downto 160);
SS_SH_BG_SR3(13 downto 0) <= SS_CHAIN(175 downto 162);
SS_SH_BG_SR3(15 downto 14) <= SS_CHAIN(177 downto 176);
SS_SH_BG_SRC(0)(3 downto 0) <= SS_CHAIN(181 downto 178);
SS_SH_BG_SRC(1)(3 downto 0) <= SS_CHAIN(185 downto 182);
SS_SH_BG_X(5 downto 0) <= unsigned(SS_CHAIN(191 downto 186));
SS_SH_BG_X(9 downto 6) <= unsigned(SS_CHAIN(195 downto 192));
SS_SH_BORD(7 downto 0) <= SS_CHAIN(203 downto 196);
SS_SH_BURST <= SS_CHAIN(204);
SS_SH_BXR_SET <= SS_CHAIN(205);
SS_SH_BYRH_SET <= SS_CHAIN(206);
SS_SH_BYRL_SET <= SS_CHAIN(207);
SS_SH_CLR_A(7 downto 0) <= unsigned(SS_CHAIN(215 downto 208));
SS_SH_CLR_WE <= SS_CHAIN(216);
SS_SH_CM <= SS_CHAIN(217);
SS_SH_CPURD_EXEC <= SS_CHAIN(218);
SS_SH_CPURD_PEND <= SS_CHAIN(219);
SS_SH_CPURD_PEND2 <= SS_CHAIN(220);
SS_SH_CPUWR_EXEC <= SS_CHAIN(221);
SS_SH_CPUWR_PEND <= SS_CHAIN(222);
SS_SH_CPUWR_PEND2 <= SS_CHAIN(223);
SS_SH_CPU_BUSY <= SS_CHAIN(224);
SS_SH_CPU_BUSY_CLEAR <= SS_CHAIN(225);
SS_SH_CPU_VRAM_ADDR(13 downto 0) <= SS_CHAIN(239 downto 226);
SS_SH_CPU_VRAM_ADDR(15 downto 14) <= SS_CHAIN(241 downto 240);
SS_SH_CPU_VRAM_DATA(13 downto 0) <= SS_CHAIN(255 downto 242);
SS_SH_CPU_VRAM_DATA(15 downto 14) <= SS_CHAIN(257 downto 256);
SS_SH_DESR(13 downto 0) <= SS_CHAIN(271 downto 258);
SS_SH_DESR(15 downto 14) <= SS_CHAIN(273 downto 272);
SS_SH_DISP(7 downto 0) <= SS_CHAIN(281 downto 274);
SS_SH_DISP_BREAK_EN <= SS_CHAIN(282);
SS_SH_DISP_BREAK_LATCH <= SS_CHAIN(283);
SS_SH_DISP_CNT(3 downto 0) <= unsigned(SS_CHAIN(287 downto 284));
SS_SH_DISP_CNT(9 downto 4) <= unsigned(SS_CHAIN(293 downto 288));
SS_SH_DISP_CNT_INC <= SS_CHAIN(294);
SS_SH_DMAS_EXEC <= SS_CHAIN(295);
SS_SH_DMAS_PEND <= SS_CHAIN(296);
SS_SH_DMAS_SAT_ADDR(6 downto 0) <= SS_CHAIN(303 downto 297);
SS_SH_DMAS_SAT_ADDR(7 downto 7) <= SS_CHAIN(304 downto 304);
SS_SH_DMAS_VRAM_ADDR(14 downto 0) <= SS_CHAIN(319 downto 305);
SS_SH_DMAS_VRAM_ADDR(15 downto 15) <= SS_CHAIN(320 downto 320);
SS_SH_DMA_BUF(14 downto 0) <= SS_CHAIN(335 downto 321);
SS_SH_DMA_BUF(15 downto 15) <= SS_CHAIN(336 downto 336);
SS_SH_DMA_EXEC <= SS_CHAIN(337);
SS_SH_DMA_PEND <= SS_CHAIN(338);
SS_SH_DMA_WR <= SS_CHAIN(339);
SS_SH_DOTS_REMAIN(2 downto 0) <= unsigned(SS_CHAIN(342 downto 340));
SS_SH_DOT_CNT(2 downto 0) <= unsigned(SS_CHAIN(345 downto 343));
SS_SH_FETCH_CE <= SS_CHAIN(346);
SS_SH_FETCH_DOT(2 downto 0) <= unsigned(SS_CHAIN(349 downto 347));
SS_SH_GRID_BG(1 downto 0) <= SS_CHAIN(351 downto 350);
SS_SH_GRID_BG(7 downto 2) <= SS_CHAIN(357 downto 352);
SS_SH_GRID_SP(7 downto 0) <= SS_CHAIN(365 downto 358);
SS_SH_HDE(1 downto 0) <= SS_CHAIN(367 downto 366);
SS_SH_HDE(6 downto 2) <= SS_CHAIN(372 downto 368);
SS_SH_HDS(6 downto 0) <= SS_CHAIN(379 downto 373);
SS_SH_HDW(3 downto 0) <= SS_CHAIN(383 downto 380);
SS_SH_HDW(6 downto 4) <= SS_CHAIN(386 downto 384);
SS_SH_HSW(4 downto 0) <= SS_CHAIN(391 downto 387);
SS_SH_IO_BYRH_SET <= SS_CHAIN(392);
SS_SH_IO_BYRH_WR <= SS_CHAIN(393);
SS_SH_IO_BYRL_SET <= SS_CHAIN(394);
SS_SH_IO_BYRL_WR <= SS_CHAIN(395);
SS_SH_IRQ_COL <= SS_CHAIN(396);
SS_SH_IRQ_DMA <= SS_CHAIN(397);
SS_SH_IRQ_DMAS <= SS_CHAIN(398);
SS_SH_IRQ_OVF <= SS_CHAIN(399);
SS_SH_IRQ_RCR <= SS_CHAIN(400);
SS_SH_IRQ_VBL <= SS_CHAIN(401);
SS_SH_LENR(13 downto 0) <= SS_CHAIN(415 downto 402);
SS_SH_LENR(15 downto 14) <= SS_CHAIN(417 downto 416);
SS_SH_MARR(13 downto 0) <= SS_CHAIN(431 downto 418);
SS_SH_MARR(15 downto 14) <= SS_CHAIN(433 downto 432);
SS_SH_MAWR(13 downto 0) <= SS_CHAIN(447 downto 434);
SS_SH_MAWR(15 downto 14) <= SS_CHAIN(449 downto 448);
SS_SH_OFS_X(9 downto 0) <= unsigned(SS_CHAIN(459 downto 450));
SS_SH_OFS_Y(3 downto 0) <= unsigned(SS_CHAIN(463 downto 460));
SS_SH_OFS_Y(8 downto 4) <= unsigned(SS_CHAIN(468 downto 464));
SS_SH_RC_CNT(9 downto 0) <= unsigned(SS_CHAIN(478 downto 469));
SS_SH_RD_N_OLD <= SS_CHAIN(479);
SS_SH_REGS(0)(15 downto 0) <= SS_CHAIN(495 downto 480);
SS_SH_REGS(1)(15 downto 0) <= SS_CHAIN(511 downto 496);
SS_SH_REGS(2)(15 downto 0) <= SS_CHAIN(527 downto 512);
SS_SH_REGS(3)(15 downto 0) <= SS_CHAIN(543 downto 528);
SS_SH_REGS(4)(15 downto 0) <= SS_CHAIN(559 downto 544);
SS_SH_REGS(5)(15 downto 0) <= SS_CHAIN(575 downto 560);
SS_SH_REGS(6)(15 downto 0) <= SS_CHAIN(591 downto 576);
SS_SH_REGS(7)(15 downto 0) <= SS_CHAIN(607 downto 592);
SS_SH_REGS(8)(15 downto 0) <= SS_CHAIN(623 downto 608);
SS_SH_REGS(9)(15 downto 0) <= SS_CHAIN(639 downto 624);
SS_SH_REGS(10)(15 downto 0) <= SS_CHAIN(655 downto 640);
SS_SH_REGS(11)(15 downto 0) <= SS_CHAIN(671 downto 656);
SS_SH_REGS(12)(15 downto 0) <= SS_CHAIN(687 downto 672);
SS_SH_REGS(13)(15 downto 0) <= SS_CHAIN(703 downto 688);
SS_SH_REGS(14)(15 downto 0) <= SS_CHAIN(719 downto 704);
SS_SH_REGS(15)(15 downto 0) <= SS_CHAIN(735 downto 720);
SS_SH_REGS(16)(15 downto 0) <= SS_CHAIN(751 downto 736);
SS_SH_REGS(17)(15 downto 0) <= SS_CHAIN(767 downto 752);
SS_SH_REGS(18)(15 downto 0) <= SS_CHAIN(783 downto 768);
SS_SH_REGS(19)(15 downto 0) <= SS_CHAIN(799 downto 784);
SS_SH_REGS(20)(15 downto 0) <= SS_CHAIN(815 downto 800);
SS_SH_REGS(21)(15 downto 0) <= SS_CHAIN(831 downto 816);
SS_SH_REGS(22)(15 downto 0) <= SS_CHAIN(847 downto 832);
SS_SH_REGS(23)(15 downto 0) <= SS_CHAIN(863 downto 848);
SS_SH_REGS(24)(15 downto 0) <= SS_CHAIN(879 downto 864);
SS_SH_REGS(25)(15 downto 0) <= SS_CHAIN(895 downto 880);
SS_SH_REGS(26)(15 downto 0) <= SS_CHAIN(911 downto 896);
SS_SH_REGS(27)(15 downto 0) <= SS_CHAIN(927 downto 912);
SS_SH_REGS(28)(15 downto 0) <= SS_CHAIN(943 downto 928);
SS_SH_REGS(29)(15 downto 0) <= SS_CHAIN(959 downto 944);
SS_SH_REGS(30)(15 downto 0) <= SS_CHAIN(975 downto 960);
SS_SH_REGS(31)(15 downto 0) <= SS_CHAIN(991 downto 976);
SS_SH_RES7M(0 downto 0) <= SS_CHAIN(992 downto 992);
SS_SH_SB <= SS_CHAIN(993);
SS_SH_SCREEN(2 downto 0) <= SS_CHAIN(996 downto 994);
SS_SH_SM(1 downto 0) <= SS_CHAIN(998 downto 997);
SS_SH_SOUR(8 downto 0) <= SS_CHAIN(1007 downto 999);
SS_SH_SOUR(15 downto 9) <= SS_CHAIN(1014 downto 1008);
SS_SH_SPR_CACHE(0).X(8 downto 0) <= SS_CHAIN(1023 downto 1015);
SS_SH_SPR_CACHE(0).X(9 downto 9) <= SS_CHAIN(1024 downto 1024);
SS_SH_SPR_CACHE(0).Y(9 downto 0) <= SS_CHAIN(1034 downto 1025);
SS_SH_SPR_CACHE(0).PC(4 downto 0) <= SS_CHAIN(1039 downto 1035);
SS_SH_SPR_CACHE(0).PC(10 downto 5) <= SS_CHAIN(1045 downto 1040);
SS_SH_SPR_CACHE(0).CG <= SS_CHAIN(1046);
SS_SH_SPR_CACHE(0).PAL(3 downto 0) <= SS_CHAIN(1050 downto 1047);
SS_SH_SPR_CACHE(0).PRIO <= SS_CHAIN(1051);
SS_SH_SPR_CACHE(0).CGX <= SS_CHAIN(1052);
SS_SH_SPR_CACHE(0).CGY(1 downto 0) <= SS_CHAIN(1054 downto 1053);
SS_SH_SPR_CACHE(0).HF <= SS_CHAIN(1055);
SS_SH_SPR_CACHE(0).VF <= SS_CHAIN(1056);
SS_SH_SPR_CACHE(0).SPR0 <= SS_CHAIN(1057);
SS_SH_SPR_CACHE(0).TOP <= SS_CHAIN(1058);
SS_SH_SPR_CACHE(0).BOTTOM <= SS_CHAIN(1059);
SS_SH_SPR_CACHE(1).X(9 downto 0) <= SS_CHAIN(1069 downto 1060);
SS_SH_SPR_CACHE(1).Y(1 downto 0) <= SS_CHAIN(1071 downto 1070);
SS_SH_SPR_CACHE(1).Y(9 downto 2) <= SS_CHAIN(1079 downto 1072);
SS_SH_SPR_CACHE(1).PC(7 downto 0) <= SS_CHAIN(1087 downto 1080);
SS_SH_SPR_CACHE(1).PC(10 downto 8) <= SS_CHAIN(1090 downto 1088);
SS_SH_SPR_CACHE(1).CG <= SS_CHAIN(1091);
SS_SH_SPR_CACHE(1).PAL(3 downto 0) <= SS_CHAIN(1095 downto 1092);
SS_SH_SPR_CACHE(1).PRIO <= SS_CHAIN(1096);
SS_SH_SPR_CACHE(1).CGX <= SS_CHAIN(1097);
SS_SH_SPR_CACHE(1).CGY(1 downto 0) <= SS_CHAIN(1099 downto 1098);
SS_SH_SPR_CACHE(1).HF <= SS_CHAIN(1100);
SS_SH_SPR_CACHE(1).VF <= SS_CHAIN(1101);
SS_SH_SPR_CACHE(1).SPR0 <= SS_CHAIN(1102);
SS_SH_SPR_CACHE(1).TOP <= SS_CHAIN(1103);
SS_SH_SPR_CACHE(1).BOTTOM <= SS_CHAIN(1104);
SS_SH_SPR_CACHE(2).X(9 downto 0) <= SS_CHAIN(1114 downto 1105);
SS_SH_SPR_CACHE(2).Y(4 downto 0) <= SS_CHAIN(1119 downto 1115);
SS_SH_SPR_CACHE(2).Y(9 downto 5) <= SS_CHAIN(1124 downto 1120);
SS_SH_SPR_CACHE(2).PC(10 downto 0) <= SS_CHAIN(1135 downto 1125);
SS_SH_SPR_CACHE(2).CG <= SS_CHAIN(1136);
SS_SH_SPR_CACHE(2).PAL(3 downto 0) <= SS_CHAIN(1140 downto 1137);
SS_SH_SPR_CACHE(2).PRIO <= SS_CHAIN(1141);
SS_SH_SPR_CACHE(2).CGX <= SS_CHAIN(1142);
SS_SH_SPR_CACHE(2).CGY(1 downto 0) <= SS_CHAIN(1144 downto 1143);
SS_SH_SPR_CACHE(2).HF <= SS_CHAIN(1145);
SS_SH_SPR_CACHE(2).VF <= SS_CHAIN(1146);
SS_SH_SPR_CACHE(2).SPR0 <= SS_CHAIN(1147);
SS_SH_SPR_CACHE(2).TOP <= SS_CHAIN(1148);
SS_SH_SPR_CACHE(2).BOTTOM <= SS_CHAIN(1149);
SS_SH_SPR_CACHE(3).X(1 downto 0) <= SS_CHAIN(1151 downto 1150);
SS_SH_SPR_CACHE(3).X(9 downto 2) <= SS_CHAIN(1159 downto 1152);
SS_SH_SPR_CACHE(3).Y(7 downto 0) <= SS_CHAIN(1167 downto 1160);
SS_SH_SPR_CACHE(3).Y(9 downto 8) <= SS_CHAIN(1169 downto 1168);
SS_SH_SPR_CACHE(3).PC(10 downto 0) <= SS_CHAIN(1180 downto 1170);
SS_SH_SPR_CACHE(3).CG <= SS_CHAIN(1181);
SS_SH_SPR_CACHE(3).PAL(1 downto 0) <= SS_CHAIN(1183 downto 1182);
SS_SH_SPR_CACHE(3).PAL(3 downto 2) <= SS_CHAIN(1185 downto 1184);
SS_SH_SPR_CACHE(3).PRIO <= SS_CHAIN(1186);
SS_SH_SPR_CACHE(3).CGX <= SS_CHAIN(1187);
SS_SH_SPR_CACHE(3).CGY(1 downto 0) <= SS_CHAIN(1189 downto 1188);
SS_SH_SPR_CACHE(3).HF <= SS_CHAIN(1190);
SS_SH_SPR_CACHE(3).VF <= SS_CHAIN(1191);
SS_SH_SPR_CACHE(3).SPR0 <= SS_CHAIN(1192);
SS_SH_SPR_CACHE(3).TOP <= SS_CHAIN(1193);
SS_SH_SPR_CACHE(3).BOTTOM <= SS_CHAIN(1194);
SS_SH_SPR_CACHE(4).X(4 downto 0) <= SS_CHAIN(1199 downto 1195);
SS_SH_SPR_CACHE(4).X(9 downto 5) <= SS_CHAIN(1204 downto 1200);
SS_SH_SPR_CACHE(4).Y(9 downto 0) <= SS_CHAIN(1214 downto 1205);
SS_SH_SPR_CACHE(4).PC(0 downto 0) <= SS_CHAIN(1215 downto 1215);
SS_SH_SPR_CACHE(4).PC(10 downto 1) <= SS_CHAIN(1225 downto 1216);
SS_SH_SPR_CACHE(4).CG <= SS_CHAIN(1226);
SS_SH_SPR_CACHE(4).PAL(3 downto 0) <= SS_CHAIN(1230 downto 1227);
SS_SH_SPR_CACHE(4).PRIO <= SS_CHAIN(1231);
SS_SH_SPR_CACHE(4).CGX <= SS_CHAIN(1232);
SS_SH_SPR_CACHE(4).CGY(1 downto 0) <= SS_CHAIN(1234 downto 1233);
SS_SH_SPR_CACHE(4).HF <= SS_CHAIN(1235);
SS_SH_SPR_CACHE(4).VF <= SS_CHAIN(1236);
SS_SH_SPR_CACHE(4).SPR0 <= SS_CHAIN(1237);
SS_SH_SPR_CACHE(4).TOP <= SS_CHAIN(1238);
SS_SH_SPR_CACHE(4).BOTTOM <= SS_CHAIN(1239);
SS_SH_SPR_CACHE(5).X(7 downto 0) <= SS_CHAIN(1247 downto 1240);
SS_SH_SPR_CACHE(5).X(9 downto 8) <= SS_CHAIN(1249 downto 1248);
SS_SH_SPR_CACHE(5).Y(9 downto 0) <= SS_CHAIN(1259 downto 1250);
SS_SH_SPR_CACHE(5).PC(3 downto 0) <= SS_CHAIN(1263 downto 1260);
SS_SH_SPR_CACHE(5).PC(10 downto 4) <= SS_CHAIN(1270 downto 1264);
SS_SH_SPR_CACHE(5).CG <= SS_CHAIN(1271);
SS_SH_SPR_CACHE(5).PAL(3 downto 0) <= SS_CHAIN(1275 downto 1272);
SS_SH_SPR_CACHE(5).PRIO <= SS_CHAIN(1276);
SS_SH_SPR_CACHE(5).CGX <= SS_CHAIN(1277);
SS_SH_SPR_CACHE(5).CGY(1 downto 0) <= SS_CHAIN(1279 downto 1278);
SS_SH_SPR_CACHE(5).HF <= SS_CHAIN(1280);
SS_SH_SPR_CACHE(5).VF <= SS_CHAIN(1281);
SS_SH_SPR_CACHE(5).SPR0 <= SS_CHAIN(1282);
SS_SH_SPR_CACHE(5).TOP <= SS_CHAIN(1283);
SS_SH_SPR_CACHE(5).BOTTOM <= SS_CHAIN(1284);
SS_SH_SPR_CACHE(6).X(9 downto 0) <= SS_CHAIN(1294 downto 1285);
SS_SH_SPR_CACHE(6).Y(0 downto 0) <= SS_CHAIN(1295 downto 1295);
SS_SH_SPR_CACHE(6).Y(9 downto 1) <= SS_CHAIN(1304 downto 1296);
SS_SH_SPR_CACHE(6).PC(6 downto 0) <= SS_CHAIN(1311 downto 1305);
SS_SH_SPR_CACHE(6).PC(10 downto 7) <= SS_CHAIN(1315 downto 1312);
SS_SH_SPR_CACHE(6).CG <= SS_CHAIN(1316);
SS_SH_SPR_CACHE(6).PAL(3 downto 0) <= SS_CHAIN(1320 downto 1317);
SS_SH_SPR_CACHE(6).PRIO <= SS_CHAIN(1321);
SS_SH_SPR_CACHE(6).CGX <= SS_CHAIN(1322);
SS_SH_SPR_CACHE(6).CGY(1 downto 0) <= SS_CHAIN(1324 downto 1323);
SS_SH_SPR_CACHE(6).HF <= SS_CHAIN(1325);
SS_SH_SPR_CACHE(6).VF <= SS_CHAIN(1326);
SS_SH_SPR_CACHE(6).SPR0 <= SS_CHAIN(1327);
SS_SH_SPR_CACHE(6).TOP <= SS_CHAIN(1328);
SS_SH_SPR_CACHE(6).BOTTOM <= SS_CHAIN(1329);
SS_SH_SPR_CACHE(7).X(9 downto 0) <= SS_CHAIN(1339 downto 1330);
SS_SH_SPR_CACHE(7).Y(3 downto 0) <= SS_CHAIN(1343 downto 1340);
SS_SH_SPR_CACHE(7).Y(9 downto 4) <= SS_CHAIN(1349 downto 1344);
SS_SH_SPR_CACHE(7).PC(9 downto 0) <= SS_CHAIN(1359 downto 1350);
SS_SH_SPR_CACHE(7).PC(10 downto 10) <= SS_CHAIN(1360 downto 1360);
SS_SH_SPR_CACHE(7).CG <= SS_CHAIN(1361);
SS_SH_SPR_CACHE(7).PAL(3 downto 0) <= SS_CHAIN(1365 downto 1362);
SS_SH_SPR_CACHE(7).PRIO <= SS_CHAIN(1366);
SS_SH_SPR_CACHE(7).CGX <= SS_CHAIN(1367);
SS_SH_SPR_CACHE(7).CGY(1 downto 0) <= SS_CHAIN(1369 downto 1368);
SS_SH_SPR_CACHE(7).HF <= SS_CHAIN(1370);
SS_SH_SPR_CACHE(7).VF <= SS_CHAIN(1371);
SS_SH_SPR_CACHE(7).SPR0 <= SS_CHAIN(1372);
SS_SH_SPR_CACHE(7).TOP <= SS_CHAIN(1373);
SS_SH_SPR_CACHE(7).BOTTOM <= SS_CHAIN(1374);
SS_SH_SPR_CACHE(8).X(0 downto 0) <= SS_CHAIN(1375 downto 1375);
SS_SH_SPR_CACHE(8).X(9 downto 1) <= SS_CHAIN(1384 downto 1376);
SS_SH_SPR_CACHE(8).Y(6 downto 0) <= SS_CHAIN(1391 downto 1385);
SS_SH_SPR_CACHE(8).Y(9 downto 7) <= SS_CHAIN(1394 downto 1392);
SS_SH_SPR_CACHE(8).PC(10 downto 0) <= SS_CHAIN(1405 downto 1395);
SS_SH_SPR_CACHE(8).CG <= SS_CHAIN(1406);
SS_SH_SPR_CACHE(8).PAL(0 downto 0) <= SS_CHAIN(1407 downto 1407);
SS_SH_SPR_CACHE(8).PAL(3 downto 1) <= SS_CHAIN(1410 downto 1408);
SS_SH_SPR_CACHE(8).PRIO <= SS_CHAIN(1411);
SS_SH_SPR_CACHE(8).CGX <= SS_CHAIN(1412);
SS_SH_SPR_CACHE(8).CGY(1 downto 0) <= SS_CHAIN(1414 downto 1413);
SS_SH_SPR_CACHE(8).HF <= SS_CHAIN(1415);
SS_SH_SPR_CACHE(8).VF <= SS_CHAIN(1416);
SS_SH_SPR_CACHE(8).SPR0 <= SS_CHAIN(1417);
SS_SH_SPR_CACHE(8).TOP <= SS_CHAIN(1418);
SS_SH_SPR_CACHE(8).BOTTOM <= SS_CHAIN(1419);
SS_SH_SPR_CACHE(9).X(3 downto 0) <= SS_CHAIN(1423 downto 1420);
SS_SH_SPR_CACHE(9).X(9 downto 4) <= SS_CHAIN(1429 downto 1424);
SS_SH_SPR_CACHE(9).Y(9 downto 0) <= SS_CHAIN(1439 downto 1430);
SS_SH_SPR_CACHE(9).PC(10 downto 0) <= SS_CHAIN(1450 downto 1440);
SS_SH_SPR_CACHE(9).CG <= SS_CHAIN(1451);
SS_SH_SPR_CACHE(9).PAL(3 downto 0) <= SS_CHAIN(1455 downto 1452);
SS_SH_SPR_CACHE(9).PRIO <= SS_CHAIN(1456);
SS_SH_SPR_CACHE(9).CGX <= SS_CHAIN(1457);
SS_SH_SPR_CACHE(9).CGY(1 downto 0) <= SS_CHAIN(1459 downto 1458);
SS_SH_SPR_CACHE(9).HF <= SS_CHAIN(1460);
SS_SH_SPR_CACHE(9).VF <= SS_CHAIN(1461);
SS_SH_SPR_CACHE(9).SPR0 <= SS_CHAIN(1462);
SS_SH_SPR_CACHE(9).TOP <= SS_CHAIN(1463);
SS_SH_SPR_CACHE(9).BOTTOM <= SS_CHAIN(1464);
SS_SH_SPR_CACHE(10).X(6 downto 0) <= SS_CHAIN(1471 downto 1465);
SS_SH_SPR_CACHE(10).X(9 downto 7) <= SS_CHAIN(1474 downto 1472);
SS_SH_SPR_CACHE(10).Y(9 downto 0) <= SS_CHAIN(1484 downto 1475);
SS_SH_SPR_CACHE(10).PC(2 downto 0) <= SS_CHAIN(1487 downto 1485);
SS_SH_SPR_CACHE(10).PC(10 downto 3) <= SS_CHAIN(1495 downto 1488);
SS_SH_SPR_CACHE(10).CG <= SS_CHAIN(1496);
SS_SH_SPR_CACHE(10).PAL(3 downto 0) <= SS_CHAIN(1500 downto 1497);
SS_SH_SPR_CACHE(10).PRIO <= SS_CHAIN(1501);
SS_SH_SPR_CACHE(10).CGX <= SS_CHAIN(1502);
SS_SH_SPR_CACHE(10).CGY(0 downto 0) <= SS_CHAIN(1503 downto 1503);
SS_SH_SPR_CACHE(10).CGY(1 downto 1) <= SS_CHAIN(1504 downto 1504);
SS_SH_SPR_CACHE(10).HF <= SS_CHAIN(1505);
SS_SH_SPR_CACHE(10).VF <= SS_CHAIN(1506);
SS_SH_SPR_CACHE(10).SPR0 <= SS_CHAIN(1507);
SS_SH_SPR_CACHE(10).TOP <= SS_CHAIN(1508);
SS_SH_SPR_CACHE(10).BOTTOM <= SS_CHAIN(1509);
SS_SH_SPR_CACHE(11).X(9 downto 0) <= SS_CHAIN(1519 downto 1510);
SS_SH_SPR_CACHE(11).Y(9 downto 0) <= SS_CHAIN(1529 downto 1520);
SS_SH_SPR_CACHE(11).PC(5 downto 0) <= SS_CHAIN(1535 downto 1530);
SS_SH_SPR_CACHE(11).PC(10 downto 6) <= SS_CHAIN(1540 downto 1536);
SS_SH_SPR_CACHE(11).CG <= SS_CHAIN(1541);
SS_SH_SPR_CACHE(11).PAL(3 downto 0) <= SS_CHAIN(1545 downto 1542);
SS_SH_SPR_CACHE(11).PRIO <= SS_CHAIN(1546);
SS_SH_SPR_CACHE(11).CGX <= SS_CHAIN(1547);
SS_SH_SPR_CACHE(11).CGY(1 downto 0) <= SS_CHAIN(1549 downto 1548);
SS_SH_SPR_CACHE(11).HF <= SS_CHAIN(1550);
SS_SH_SPR_CACHE(11).VF <= SS_CHAIN(1551);
SS_SH_SPR_CACHE(11).SPR0 <= SS_CHAIN(1552);
SS_SH_SPR_CACHE(11).TOP <= SS_CHAIN(1553);
SS_SH_SPR_CACHE(11).BOTTOM <= SS_CHAIN(1554);
SS_SH_SPR_CACHE(12).X(9 downto 0) <= SS_CHAIN(1564 downto 1555);
SS_SH_SPR_CACHE(12).Y(2 downto 0) <= SS_CHAIN(1567 downto 1565);
SS_SH_SPR_CACHE(12).Y(9 downto 3) <= SS_CHAIN(1574 downto 1568);
SS_SH_SPR_CACHE(12).PC(8 downto 0) <= SS_CHAIN(1583 downto 1575);
SS_SH_SPR_CACHE(12).PC(10 downto 9) <= SS_CHAIN(1585 downto 1584);
SS_SH_SPR_CACHE(12).CG <= SS_CHAIN(1586);
SS_SH_SPR_CACHE(12).PAL(3 downto 0) <= SS_CHAIN(1590 downto 1587);
SS_SH_SPR_CACHE(12).PRIO <= SS_CHAIN(1591);
SS_SH_SPR_CACHE(12).CGX <= SS_CHAIN(1592);
SS_SH_SPR_CACHE(12).CGY(1 downto 0) <= SS_CHAIN(1594 downto 1593);
SS_SH_SPR_CACHE(12).HF <= SS_CHAIN(1595);
SS_SH_SPR_CACHE(12).VF <= SS_CHAIN(1596);
SS_SH_SPR_CACHE(12).SPR0 <= SS_CHAIN(1597);
SS_SH_SPR_CACHE(12).TOP <= SS_CHAIN(1598);
SS_SH_SPR_CACHE(12).BOTTOM <= SS_CHAIN(1599);
SS_SH_SPR_CACHE(13).X(9 downto 0) <= SS_CHAIN(1609 downto 1600);
SS_SH_SPR_CACHE(13).Y(5 downto 0) <= SS_CHAIN(1615 downto 1610);
SS_SH_SPR_CACHE(13).Y(9 downto 6) <= SS_CHAIN(1619 downto 1616);
SS_SH_SPR_CACHE(13).PC(10 downto 0) <= SS_CHAIN(1630 downto 1620);
SS_SH_SPR_CACHE(13).CG <= SS_CHAIN(1631);
SS_SH_SPR_CACHE(13).PAL(3 downto 0) <= SS_CHAIN(1635 downto 1632);
SS_SH_SPR_CACHE(13).PRIO <= SS_CHAIN(1636);
SS_SH_SPR_CACHE(13).CGX <= SS_CHAIN(1637);
SS_SH_SPR_CACHE(13).CGY(1 downto 0) <= SS_CHAIN(1639 downto 1638);
SS_SH_SPR_CACHE(13).HF <= SS_CHAIN(1640);
SS_SH_SPR_CACHE(13).VF <= SS_CHAIN(1641);
SS_SH_SPR_CACHE(13).SPR0 <= SS_CHAIN(1642);
SS_SH_SPR_CACHE(13).TOP <= SS_CHAIN(1643);
SS_SH_SPR_CACHE(13).BOTTOM <= SS_CHAIN(1644);
SS_SH_SPR_CACHE(14).X(2 downto 0) <= SS_CHAIN(1647 downto 1645);
SS_SH_SPR_CACHE(14).X(9 downto 3) <= SS_CHAIN(1654 downto 1648);
SS_SH_SPR_CACHE(14).Y(8 downto 0) <= SS_CHAIN(1663 downto 1655);
SS_SH_SPR_CACHE(14).Y(9 downto 9) <= SS_CHAIN(1664 downto 1664);
SS_SH_SPR_CACHE(14).PC(10 downto 0) <= SS_CHAIN(1675 downto 1665);
SS_SH_SPR_CACHE(14).CG <= SS_CHAIN(1676);
SS_SH_SPR_CACHE(14).PAL(2 downto 0) <= SS_CHAIN(1679 downto 1677);
SS_SH_SPR_CACHE(14).PAL(3 downto 3) <= SS_CHAIN(1680 downto 1680);
SS_SH_SPR_CACHE(14).PRIO <= SS_CHAIN(1681);
SS_SH_SPR_CACHE(14).CGX <= SS_CHAIN(1682);
SS_SH_SPR_CACHE(14).CGY(1 downto 0) <= SS_CHAIN(1684 downto 1683);
SS_SH_SPR_CACHE(14).HF <= SS_CHAIN(1685);
SS_SH_SPR_CACHE(14).VF <= SS_CHAIN(1686);
SS_SH_SPR_CACHE(14).SPR0 <= SS_CHAIN(1687);
SS_SH_SPR_CACHE(14).TOP <= SS_CHAIN(1688);
SS_SH_SPR_CACHE(14).BOTTOM <= SS_CHAIN(1689);
SS_SH_SPR_CACHE(15).X(5 downto 0) <= SS_CHAIN(1695 downto 1690);
SS_SH_SPR_CACHE(15).X(9 downto 6) <= SS_CHAIN(1699 downto 1696);
SS_SH_SPR_CACHE(15).Y(9 downto 0) <= SS_CHAIN(1709 downto 1700);
SS_SH_SPR_CACHE(15).PC(1 downto 0) <= SS_CHAIN(1711 downto 1710);
SS_SH_SPR_CACHE(15).PC(10 downto 2) <= SS_CHAIN(1720 downto 1712);
SS_SH_SPR_CACHE(15).CG <= SS_CHAIN(1721);
SS_SH_SPR_CACHE(15).PAL(3 downto 0) <= SS_CHAIN(1725 downto 1722);
SS_SH_SPR_CACHE(15).PRIO <= SS_CHAIN(1726);
SS_SH_SPR_CACHE(15).CGX <= SS_CHAIN(1727);
SS_SH_SPR_CACHE(15).CGY(1 downto 0) <= SS_CHAIN(1729 downto 1728);
SS_SH_SPR_CACHE(15).HF <= SS_CHAIN(1730);
SS_SH_SPR_CACHE(15).VF <= SS_CHAIN(1731);
SS_SH_SPR_CACHE(15).SPR0 <= SS_CHAIN(1732);
SS_SH_SPR_CACHE(15).TOP <= SS_CHAIN(1733);
SS_SH_SPR_CACHE(15).BOTTOM <= SS_CHAIN(1734);
SS_SH_SPR_CACHE(16).X(8 downto 0) <= SS_CHAIN(1743 downto 1735);
SS_SH_SPR_CACHE(16).X(9 downto 9) <= SS_CHAIN(1744 downto 1744);
SS_SH_SPR_CACHE(16).Y(9 downto 0) <= SS_CHAIN(1754 downto 1745);
SS_SH_SPR_CACHE(16).PC(4 downto 0) <= SS_CHAIN(1759 downto 1755);
SS_SH_SPR_CACHE(16).PC(10 downto 5) <= SS_CHAIN(1765 downto 1760);
SS_SH_SPR_CACHE(16).CG <= SS_CHAIN(1766);
SS_SH_SPR_CACHE(16).PAL(3 downto 0) <= SS_CHAIN(1770 downto 1767);
SS_SH_SPR_CACHE(16).PRIO <= SS_CHAIN(1771);
SS_SH_SPR_CACHE(16).CGX <= SS_CHAIN(1772);
SS_SH_SPR_CACHE(16).CGY(1 downto 0) <= SS_CHAIN(1774 downto 1773);
SS_SH_SPR_CACHE(16).HF <= SS_CHAIN(1775);
SS_SH_SPR_CACHE(16).VF <= SS_CHAIN(1776);
SS_SH_SPR_CACHE(16).SPR0 <= SS_CHAIN(1777);
SS_SH_SPR_CACHE(16).TOP <= SS_CHAIN(1778);
SS_SH_SPR_CACHE(16).BOTTOM <= SS_CHAIN(1779);
SS_SH_SPR_CACHE(17).X(9 downto 0) <= SS_CHAIN(1789 downto 1780);
SS_SH_SPR_CACHE(17).Y(1 downto 0) <= SS_CHAIN(1791 downto 1790);
SS_SH_SPR_CACHE(17).Y(9 downto 2) <= SS_CHAIN(1799 downto 1792);
SS_SH_SPR_CACHE(17).PC(7 downto 0) <= SS_CHAIN(1807 downto 1800);
SS_SH_SPR_CACHE(17).PC(10 downto 8) <= SS_CHAIN(1810 downto 1808);
SS_SH_SPR_CACHE(17).CG <= SS_CHAIN(1811);
SS_SH_SPR_CACHE(17).PAL(3 downto 0) <= SS_CHAIN(1815 downto 1812);
SS_SH_SPR_CACHE(17).PRIO <= SS_CHAIN(1816);
SS_SH_SPR_CACHE(17).CGX <= SS_CHAIN(1817);
SS_SH_SPR_CACHE(17).CGY(1 downto 0) <= SS_CHAIN(1819 downto 1818);
SS_SH_SPR_CACHE(17).HF <= SS_CHAIN(1820);
SS_SH_SPR_CACHE(17).VF <= SS_CHAIN(1821);
SS_SH_SPR_CACHE(17).SPR0 <= SS_CHAIN(1822);
SS_SH_SPR_CACHE(17).TOP <= SS_CHAIN(1823);
SS_SH_SPR_CACHE(17).BOTTOM <= SS_CHAIN(1824);
SS_SH_SPR_CACHE(18).X(9 downto 0) <= SS_CHAIN(1834 downto 1825);
SS_SH_SPR_CACHE(18).Y(4 downto 0) <= SS_CHAIN(1839 downto 1835);
SS_SH_SPR_CACHE(18).Y(9 downto 5) <= SS_CHAIN(1844 downto 1840);
SS_SH_SPR_CACHE(18).PC(10 downto 0) <= SS_CHAIN(1855 downto 1845);
SS_SH_SPR_CACHE(18).CG <= SS_CHAIN(1856);
SS_SH_SPR_CACHE(18).PAL(3 downto 0) <= SS_CHAIN(1860 downto 1857);
SS_SH_SPR_CACHE(18).PRIO <= SS_CHAIN(1861);
SS_SH_SPR_CACHE(18).CGX <= SS_CHAIN(1862);
SS_SH_SPR_CACHE(18).CGY(1 downto 0) <= SS_CHAIN(1864 downto 1863);
SS_SH_SPR_CACHE(18).HF <= SS_CHAIN(1865);
SS_SH_SPR_CACHE(18).VF <= SS_CHAIN(1866);
SS_SH_SPR_CACHE(18).SPR0 <= SS_CHAIN(1867);
SS_SH_SPR_CACHE(18).TOP <= SS_CHAIN(1868);
SS_SH_SPR_CACHE(18).BOTTOM <= SS_CHAIN(1869);
SS_SH_SPR_CACHE(19).X(1 downto 0) <= SS_CHAIN(1871 downto 1870);
SS_SH_SPR_CACHE(19).X(9 downto 2) <= SS_CHAIN(1879 downto 1872);
SS_SH_SPR_CACHE(19).Y(7 downto 0) <= SS_CHAIN(1887 downto 1880);
SS_SH_SPR_CACHE(19).Y(9 downto 8) <= SS_CHAIN(1889 downto 1888);
SS_SH_SPR_CACHE(19).PC(10 downto 0) <= SS_CHAIN(1900 downto 1890);
SS_SH_SPR_CACHE(19).CG <= SS_CHAIN(1901);
SS_SH_SPR_CACHE(19).PAL(1 downto 0) <= SS_CHAIN(1903 downto 1902);
SS_SH_SPR_CACHE(19).PAL(3 downto 2) <= SS_CHAIN(1905 downto 1904);
SS_SH_SPR_CACHE(19).PRIO <= SS_CHAIN(1906);
SS_SH_SPR_CACHE(19).CGX <= SS_CHAIN(1907);
SS_SH_SPR_CACHE(19).CGY(1 downto 0) <= SS_CHAIN(1909 downto 1908);
SS_SH_SPR_CACHE(19).HF <= SS_CHAIN(1910);
SS_SH_SPR_CACHE(19).VF <= SS_CHAIN(1911);
SS_SH_SPR_CACHE(19).SPR0 <= SS_CHAIN(1912);
SS_SH_SPR_CACHE(19).TOP <= SS_CHAIN(1913);
SS_SH_SPR_CACHE(19).BOTTOM <= SS_CHAIN(1914);
SS_SH_SPR_CACHE(20).X(4 downto 0) <= SS_CHAIN(1919 downto 1915);
SS_SH_SPR_CACHE(20).X(9 downto 5) <= SS_CHAIN(1924 downto 1920);
SS_SH_SPR_CACHE(20).Y(9 downto 0) <= SS_CHAIN(1934 downto 1925);
SS_SH_SPR_CACHE(20).PC(0 downto 0) <= SS_CHAIN(1935 downto 1935);
SS_SH_SPR_CACHE(20).PC(10 downto 1) <= SS_CHAIN(1945 downto 1936);
SS_SH_SPR_CACHE(20).CG <= SS_CHAIN(1946);
SS_SH_SPR_CACHE(20).PAL(3 downto 0) <= SS_CHAIN(1950 downto 1947);
SS_SH_SPR_CACHE(20).PRIO <= SS_CHAIN(1951);
SS_SH_SPR_CACHE(20).CGX <= SS_CHAIN(1952);
SS_SH_SPR_CACHE(20).CGY(1 downto 0) <= SS_CHAIN(1954 downto 1953);
SS_SH_SPR_CACHE(20).HF <= SS_CHAIN(1955);
SS_SH_SPR_CACHE(20).VF <= SS_CHAIN(1956);
SS_SH_SPR_CACHE(20).SPR0 <= SS_CHAIN(1957);
SS_SH_SPR_CACHE(20).TOP <= SS_CHAIN(1958);
SS_SH_SPR_CACHE(20).BOTTOM <= SS_CHAIN(1959);
SS_SH_SPR_CACHE(21).X(7 downto 0) <= SS_CHAIN(1967 downto 1960);
SS_SH_SPR_CACHE(21).X(9 downto 8) <= SS_CHAIN(1969 downto 1968);
SS_SH_SPR_CACHE(21).Y(9 downto 0) <= SS_CHAIN(1979 downto 1970);
SS_SH_SPR_CACHE(21).PC(3 downto 0) <= SS_CHAIN(1983 downto 1980);
SS_SH_SPR_CACHE(21).PC(10 downto 4) <= SS_CHAIN(1990 downto 1984);
SS_SH_SPR_CACHE(21).CG <= SS_CHAIN(1991);
SS_SH_SPR_CACHE(21).PAL(3 downto 0) <= SS_CHAIN(1995 downto 1992);
SS_SH_SPR_CACHE(21).PRIO <= SS_CHAIN(1996);
SS_SH_SPR_CACHE(21).CGX <= SS_CHAIN(1997);
SS_SH_SPR_CACHE(21).CGY(1 downto 0) <= SS_CHAIN(1999 downto 1998);
SS_SH_SPR_CACHE(21).HF <= SS_CHAIN(2000);
SS_SH_SPR_CACHE(21).VF <= SS_CHAIN(2001);
SS_SH_SPR_CACHE(21).SPR0 <= SS_CHAIN(2002);
SS_SH_SPR_CACHE(21).TOP <= SS_CHAIN(2003);
SS_SH_SPR_CACHE(21).BOTTOM <= SS_CHAIN(2004);
SS_SH_SPR_CACHE(22).X(9 downto 0) <= SS_CHAIN(2014 downto 2005);
SS_SH_SPR_CACHE(22).Y(0 downto 0) <= SS_CHAIN(2015 downto 2015);
SS_SH_SPR_CACHE(22).Y(9 downto 1) <= SS_CHAIN(2024 downto 2016);
SS_SH_SPR_CACHE(22).PC(6 downto 0) <= SS_CHAIN(2031 downto 2025);
SS_SH_SPR_CACHE(22).PC(10 downto 7) <= SS_CHAIN(2035 downto 2032);
SS_SH_SPR_CACHE(22).CG <= SS_CHAIN(2036);
SS_SH_SPR_CACHE(22).PAL(3 downto 0) <= SS_CHAIN(2040 downto 2037);
SS_SH_SPR_CACHE(22).PRIO <= SS_CHAIN(2041);
SS_SH_SPR_CACHE(22).CGX <= SS_CHAIN(2042);
SS_SH_SPR_CACHE(22).CGY(1 downto 0) <= SS_CHAIN(2044 downto 2043);
SS_SH_SPR_CACHE(22).HF <= SS_CHAIN(2045);
SS_SH_SPR_CACHE(22).VF <= SS_CHAIN(2046);
SS_SH_SPR_CACHE(22).SPR0 <= SS_CHAIN(2047);
SS_SH_SPR_CACHE(22).TOP <= SS_CHAIN(2048);
SS_SH_SPR_CACHE(22).BOTTOM <= SS_CHAIN(2049);
SS_SH_SPR_CACHE(23).X(9 downto 0) <= SS_CHAIN(2059 downto 2050);
SS_SH_SPR_CACHE(23).Y(3 downto 0) <= SS_CHAIN(2063 downto 2060);
SS_SH_SPR_CACHE(23).Y(9 downto 4) <= SS_CHAIN(2069 downto 2064);
SS_SH_SPR_CACHE(23).PC(9 downto 0) <= SS_CHAIN(2079 downto 2070);
SS_SH_SPR_CACHE(23).PC(10 downto 10) <= SS_CHAIN(2080 downto 2080);
SS_SH_SPR_CACHE(23).CG <= SS_CHAIN(2081);
SS_SH_SPR_CACHE(23).PAL(3 downto 0) <= SS_CHAIN(2085 downto 2082);
SS_SH_SPR_CACHE(23).PRIO <= SS_CHAIN(2086);
SS_SH_SPR_CACHE(23).CGX <= SS_CHAIN(2087);
SS_SH_SPR_CACHE(23).CGY(1 downto 0) <= SS_CHAIN(2089 downto 2088);
SS_SH_SPR_CACHE(23).HF <= SS_CHAIN(2090);
SS_SH_SPR_CACHE(23).VF <= SS_CHAIN(2091);
SS_SH_SPR_CACHE(23).SPR0 <= SS_CHAIN(2092);
SS_SH_SPR_CACHE(23).TOP <= SS_CHAIN(2093);
SS_SH_SPR_CACHE(23).BOTTOM <= SS_CHAIN(2094);
SS_SH_SPR_CACHE(24).X(0 downto 0) <= SS_CHAIN(2095 downto 2095);
SS_SH_SPR_CACHE(24).X(9 downto 1) <= SS_CHAIN(2104 downto 2096);
SS_SH_SPR_CACHE(24).Y(6 downto 0) <= SS_CHAIN(2111 downto 2105);
SS_SH_SPR_CACHE(24).Y(9 downto 7) <= SS_CHAIN(2114 downto 2112);
SS_SH_SPR_CACHE(24).PC(10 downto 0) <= SS_CHAIN(2125 downto 2115);
SS_SH_SPR_CACHE(24).CG <= SS_CHAIN(2126);
SS_SH_SPR_CACHE(24).PAL(0 downto 0) <= SS_CHAIN(2127 downto 2127);
SS_SH_SPR_CACHE(24).PAL(3 downto 1) <= SS_CHAIN(2130 downto 2128);
SS_SH_SPR_CACHE(24).PRIO <= SS_CHAIN(2131);
SS_SH_SPR_CACHE(24).CGX <= SS_CHAIN(2132);
SS_SH_SPR_CACHE(24).CGY(1 downto 0) <= SS_CHAIN(2134 downto 2133);
SS_SH_SPR_CACHE(24).HF <= SS_CHAIN(2135);
SS_SH_SPR_CACHE(24).VF <= SS_CHAIN(2136);
SS_SH_SPR_CACHE(24).SPR0 <= SS_CHAIN(2137);
SS_SH_SPR_CACHE(24).TOP <= SS_CHAIN(2138);
SS_SH_SPR_CACHE(24).BOTTOM <= SS_CHAIN(2139);
SS_SH_SPR_CACHE(25).X(3 downto 0) <= SS_CHAIN(2143 downto 2140);
SS_SH_SPR_CACHE(25).X(9 downto 4) <= SS_CHAIN(2149 downto 2144);
SS_SH_SPR_CACHE(25).Y(9 downto 0) <= SS_CHAIN(2159 downto 2150);
SS_SH_SPR_CACHE(25).PC(10 downto 0) <= SS_CHAIN(2170 downto 2160);
SS_SH_SPR_CACHE(25).CG <= SS_CHAIN(2171);
SS_SH_SPR_CACHE(25).PAL(3 downto 0) <= SS_CHAIN(2175 downto 2172);
SS_SH_SPR_CACHE(25).PRIO <= SS_CHAIN(2176);
SS_SH_SPR_CACHE(25).CGX <= SS_CHAIN(2177);
SS_SH_SPR_CACHE(25).CGY(1 downto 0) <= SS_CHAIN(2179 downto 2178);
SS_SH_SPR_CACHE(25).HF <= SS_CHAIN(2180);
SS_SH_SPR_CACHE(25).VF <= SS_CHAIN(2181);
SS_SH_SPR_CACHE(25).SPR0 <= SS_CHAIN(2182);
SS_SH_SPR_CACHE(25).TOP <= SS_CHAIN(2183);
SS_SH_SPR_CACHE(25).BOTTOM <= SS_CHAIN(2184);
SS_SH_SPR_CACHE(26).X(6 downto 0) <= SS_CHAIN(2191 downto 2185);
SS_SH_SPR_CACHE(26).X(9 downto 7) <= SS_CHAIN(2194 downto 2192);
SS_SH_SPR_CACHE(26).Y(9 downto 0) <= SS_CHAIN(2204 downto 2195);
SS_SH_SPR_CACHE(26).PC(2 downto 0) <= SS_CHAIN(2207 downto 2205);
SS_SH_SPR_CACHE(26).PC(10 downto 3) <= SS_CHAIN(2215 downto 2208);
SS_SH_SPR_CACHE(26).CG <= SS_CHAIN(2216);
SS_SH_SPR_CACHE(26).PAL(3 downto 0) <= SS_CHAIN(2220 downto 2217);
SS_SH_SPR_CACHE(26).PRIO <= SS_CHAIN(2221);
SS_SH_SPR_CACHE(26).CGX <= SS_CHAIN(2222);
SS_SH_SPR_CACHE(26).CGY(0 downto 0) <= SS_CHAIN(2223 downto 2223);
SS_SH_SPR_CACHE(26).CGY(1 downto 1) <= SS_CHAIN(2224 downto 2224);
SS_SH_SPR_CACHE(26).HF <= SS_CHAIN(2225);
SS_SH_SPR_CACHE(26).VF <= SS_CHAIN(2226);
SS_SH_SPR_CACHE(26).SPR0 <= SS_CHAIN(2227);
SS_SH_SPR_CACHE(26).TOP <= SS_CHAIN(2228);
SS_SH_SPR_CACHE(26).BOTTOM <= SS_CHAIN(2229);
SS_SH_SPR_CACHE(27).X(9 downto 0) <= SS_CHAIN(2239 downto 2230);
SS_SH_SPR_CACHE(27).Y(9 downto 0) <= SS_CHAIN(2249 downto 2240);
SS_SH_SPR_CACHE(27).PC(5 downto 0) <= SS_CHAIN(2255 downto 2250);
SS_SH_SPR_CACHE(27).PC(10 downto 6) <= SS_CHAIN(2260 downto 2256);
SS_SH_SPR_CACHE(27).CG <= SS_CHAIN(2261);
SS_SH_SPR_CACHE(27).PAL(3 downto 0) <= SS_CHAIN(2265 downto 2262);
SS_SH_SPR_CACHE(27).PRIO <= SS_CHAIN(2266);
SS_SH_SPR_CACHE(27).CGX <= SS_CHAIN(2267);
SS_SH_SPR_CACHE(27).CGY(1 downto 0) <= SS_CHAIN(2269 downto 2268);
SS_SH_SPR_CACHE(27).HF <= SS_CHAIN(2270);
SS_SH_SPR_CACHE(27).VF <= SS_CHAIN(2271);
SS_SH_SPR_CACHE(27).SPR0 <= SS_CHAIN(2272);
SS_SH_SPR_CACHE(27).TOP <= SS_CHAIN(2273);
SS_SH_SPR_CACHE(27).BOTTOM <= SS_CHAIN(2274);
SS_SH_SPR_CACHE(28).X(9 downto 0) <= SS_CHAIN(2284 downto 2275);
SS_SH_SPR_CACHE(28).Y(2 downto 0) <= SS_CHAIN(2287 downto 2285);
SS_SH_SPR_CACHE(28).Y(9 downto 3) <= SS_CHAIN(2294 downto 2288);
SS_SH_SPR_CACHE(28).PC(8 downto 0) <= SS_CHAIN(2303 downto 2295);
SS_SH_SPR_CACHE(28).PC(10 downto 9) <= SS_CHAIN(2305 downto 2304);
SS_SH_SPR_CACHE(28).CG <= SS_CHAIN(2306);
SS_SH_SPR_CACHE(28).PAL(3 downto 0) <= SS_CHAIN(2310 downto 2307);
SS_SH_SPR_CACHE(28).PRIO <= SS_CHAIN(2311);
SS_SH_SPR_CACHE(28).CGX <= SS_CHAIN(2312);
SS_SH_SPR_CACHE(28).CGY(1 downto 0) <= SS_CHAIN(2314 downto 2313);
SS_SH_SPR_CACHE(28).HF <= SS_CHAIN(2315);
SS_SH_SPR_CACHE(28).VF <= SS_CHAIN(2316);
SS_SH_SPR_CACHE(28).SPR0 <= SS_CHAIN(2317);
SS_SH_SPR_CACHE(28).TOP <= SS_CHAIN(2318);
SS_SH_SPR_CACHE(28).BOTTOM <= SS_CHAIN(2319);
SS_SH_SPR_CACHE(29).X(9 downto 0) <= SS_CHAIN(2329 downto 2320);
SS_SH_SPR_CACHE(29).Y(5 downto 0) <= SS_CHAIN(2335 downto 2330);
SS_SH_SPR_CACHE(29).Y(9 downto 6) <= SS_CHAIN(2339 downto 2336);
SS_SH_SPR_CACHE(29).PC(10 downto 0) <= SS_CHAIN(2350 downto 2340);
SS_SH_SPR_CACHE(29).CG <= SS_CHAIN(2351);
SS_SH_SPR_CACHE(29).PAL(3 downto 0) <= SS_CHAIN(2355 downto 2352);
SS_SH_SPR_CACHE(29).PRIO <= SS_CHAIN(2356);
SS_SH_SPR_CACHE(29).CGX <= SS_CHAIN(2357);
SS_SH_SPR_CACHE(29).CGY(1 downto 0) <= SS_CHAIN(2359 downto 2358);
SS_SH_SPR_CACHE(29).HF <= SS_CHAIN(2360);
SS_SH_SPR_CACHE(29).VF <= SS_CHAIN(2361);
SS_SH_SPR_CACHE(29).SPR0 <= SS_CHAIN(2362);
SS_SH_SPR_CACHE(29).TOP <= SS_CHAIN(2363);
SS_SH_SPR_CACHE(29).BOTTOM <= SS_CHAIN(2364);
SS_SH_SPR_CACHE(30).X(2 downto 0) <= SS_CHAIN(2367 downto 2365);
SS_SH_SPR_CACHE(30).X(9 downto 3) <= SS_CHAIN(2374 downto 2368);
SS_SH_SPR_CACHE(30).Y(8 downto 0) <= SS_CHAIN(2383 downto 2375);
SS_SH_SPR_CACHE(30).Y(9 downto 9) <= SS_CHAIN(2384 downto 2384);
SS_SH_SPR_CACHE(30).PC(10 downto 0) <= SS_CHAIN(2395 downto 2385);
SS_SH_SPR_CACHE(30).CG <= SS_CHAIN(2396);
SS_SH_SPR_CACHE(30).PAL(2 downto 0) <= SS_CHAIN(2399 downto 2397);
SS_SH_SPR_CACHE(30).PAL(3 downto 3) <= SS_CHAIN(2400 downto 2400);
SS_SH_SPR_CACHE(30).PRIO <= SS_CHAIN(2401);
SS_SH_SPR_CACHE(30).CGX <= SS_CHAIN(2402);
SS_SH_SPR_CACHE(30).CGY(1 downto 0) <= SS_CHAIN(2404 downto 2403);
SS_SH_SPR_CACHE(30).HF <= SS_CHAIN(2405);
SS_SH_SPR_CACHE(30).VF <= SS_CHAIN(2406);
SS_SH_SPR_CACHE(30).SPR0 <= SS_CHAIN(2407);
SS_SH_SPR_CACHE(30).TOP <= SS_CHAIN(2408);
SS_SH_SPR_CACHE(30).BOTTOM <= SS_CHAIN(2409);
SS_SH_SPR_CACHE(31).X(5 downto 0) <= SS_CHAIN(2415 downto 2410);
SS_SH_SPR_CACHE(31).X(9 downto 6) <= SS_CHAIN(2419 downto 2416);
SS_SH_SPR_CACHE(31).Y(9 downto 0) <= SS_CHAIN(2429 downto 2420);
SS_SH_SPR_CACHE(31).PC(1 downto 0) <= SS_CHAIN(2431 downto 2430);
SS_SH_SPR_CACHE(31).PC(10 downto 2) <= SS_CHAIN(2440 downto 2432);
SS_SH_SPR_CACHE(31).CG <= SS_CHAIN(2441);
SS_SH_SPR_CACHE(31).PAL(3 downto 0) <= SS_CHAIN(2445 downto 2442);
SS_SH_SPR_CACHE(31).PRIO <= SS_CHAIN(2446);
SS_SH_SPR_CACHE(31).CGX <= SS_CHAIN(2447);
SS_SH_SPR_CACHE(31).CGY(1 downto 0) <= SS_CHAIN(2449 downto 2448);
SS_SH_SPR_CACHE(31).HF <= SS_CHAIN(2450);
SS_SH_SPR_CACHE(31).VF <= SS_CHAIN(2451);
SS_SH_SPR_CACHE(31).SPR0 <= SS_CHAIN(2452);
SS_SH_SPR_CACHE(31).TOP <= SS_CHAIN(2453);
SS_SH_SPR_CACHE(31).BOTTOM <= SS_CHAIN(2454);
SS_SH_SPR_CACHE(32).X(8 downto 0) <= SS_CHAIN(2463 downto 2455);
SS_SH_SPR_CACHE(32).X(9 downto 9) <= SS_CHAIN(2464 downto 2464);
SS_SH_SPR_CACHE(32).Y(9 downto 0) <= SS_CHAIN(2474 downto 2465);
SS_SH_SPR_CACHE(32).PC(4 downto 0) <= SS_CHAIN(2479 downto 2475);
SS_SH_SPR_CACHE(32).PC(10 downto 5) <= SS_CHAIN(2485 downto 2480);
SS_SH_SPR_CACHE(32).CG <= SS_CHAIN(2486);
SS_SH_SPR_CACHE(32).PAL(3 downto 0) <= SS_CHAIN(2490 downto 2487);
SS_SH_SPR_CACHE(32).PRIO <= SS_CHAIN(2491);
SS_SH_SPR_CACHE(32).CGX <= SS_CHAIN(2492);
SS_SH_SPR_CACHE(32).CGY(1 downto 0) <= SS_CHAIN(2494 downto 2493);
SS_SH_SPR_CACHE(32).HF <= SS_CHAIN(2495);
SS_SH_SPR_CACHE(32).VF <= SS_CHAIN(2496);
SS_SH_SPR_CACHE(32).SPR0 <= SS_CHAIN(2497);
SS_SH_SPR_CACHE(32).TOP <= SS_CHAIN(2498);
SS_SH_SPR_CACHE(32).BOTTOM <= SS_CHAIN(2499);
SS_SH_SPR_CACHE(33).X(9 downto 0) <= SS_CHAIN(2509 downto 2500);
SS_SH_SPR_CACHE(33).Y(1 downto 0) <= SS_CHAIN(2511 downto 2510);
SS_SH_SPR_CACHE(33).Y(9 downto 2) <= SS_CHAIN(2519 downto 2512);
SS_SH_SPR_CACHE(33).PC(7 downto 0) <= SS_CHAIN(2527 downto 2520);
SS_SH_SPR_CACHE(33).PC(10 downto 8) <= SS_CHAIN(2530 downto 2528);
SS_SH_SPR_CACHE(33).CG <= SS_CHAIN(2531);
SS_SH_SPR_CACHE(33).PAL(3 downto 0) <= SS_CHAIN(2535 downto 2532);
SS_SH_SPR_CACHE(33).PRIO <= SS_CHAIN(2536);
SS_SH_SPR_CACHE(33).CGX <= SS_CHAIN(2537);
SS_SH_SPR_CACHE(33).CGY(1 downto 0) <= SS_CHAIN(2539 downto 2538);
SS_SH_SPR_CACHE(33).HF <= SS_CHAIN(2540);
SS_SH_SPR_CACHE(33).VF <= SS_CHAIN(2541);
SS_SH_SPR_CACHE(33).SPR0 <= SS_CHAIN(2542);
SS_SH_SPR_CACHE(33).TOP <= SS_CHAIN(2543);
SS_SH_SPR_CACHE(33).BOTTOM <= SS_CHAIN(2544);
SS_SH_SPR_CACHE(34).X(9 downto 0) <= SS_CHAIN(2554 downto 2545);
SS_SH_SPR_CACHE(34).Y(4 downto 0) <= SS_CHAIN(2559 downto 2555);
SS_SH_SPR_CACHE(34).Y(9 downto 5) <= SS_CHAIN(2564 downto 2560);
SS_SH_SPR_CACHE(34).PC(10 downto 0) <= SS_CHAIN(2575 downto 2565);
SS_SH_SPR_CACHE(34).CG <= SS_CHAIN(2576);
SS_SH_SPR_CACHE(34).PAL(3 downto 0) <= SS_CHAIN(2580 downto 2577);
SS_SH_SPR_CACHE(34).PRIO <= SS_CHAIN(2581);
SS_SH_SPR_CACHE(34).CGX <= SS_CHAIN(2582);
SS_SH_SPR_CACHE(34).CGY(1 downto 0) <= SS_CHAIN(2584 downto 2583);
SS_SH_SPR_CACHE(34).HF <= SS_CHAIN(2585);
SS_SH_SPR_CACHE(34).VF <= SS_CHAIN(2586);
SS_SH_SPR_CACHE(34).SPR0 <= SS_CHAIN(2587);
SS_SH_SPR_CACHE(34).TOP <= SS_CHAIN(2588);
SS_SH_SPR_CACHE(34).BOTTOM <= SS_CHAIN(2589);
SS_SH_SPR_CACHE(35).X(1 downto 0) <= SS_CHAIN(2591 downto 2590);
SS_SH_SPR_CACHE(35).X(9 downto 2) <= SS_CHAIN(2599 downto 2592);
SS_SH_SPR_CACHE(35).Y(7 downto 0) <= SS_CHAIN(2607 downto 2600);
SS_SH_SPR_CACHE(35).Y(9 downto 8) <= SS_CHAIN(2609 downto 2608);
SS_SH_SPR_CACHE(35).PC(10 downto 0) <= SS_CHAIN(2620 downto 2610);
SS_SH_SPR_CACHE(35).CG <= SS_CHAIN(2621);
SS_SH_SPR_CACHE(35).PAL(1 downto 0) <= SS_CHAIN(2623 downto 2622);
SS_SH_SPR_CACHE(35).PAL(3 downto 2) <= SS_CHAIN(2625 downto 2624);
SS_SH_SPR_CACHE(35).PRIO <= SS_CHAIN(2626);
SS_SH_SPR_CACHE(35).CGX <= SS_CHAIN(2627);
SS_SH_SPR_CACHE(35).CGY(1 downto 0) <= SS_CHAIN(2629 downto 2628);
SS_SH_SPR_CACHE(35).HF <= SS_CHAIN(2630);
SS_SH_SPR_CACHE(35).VF <= SS_CHAIN(2631);
SS_SH_SPR_CACHE(35).SPR0 <= SS_CHAIN(2632);
SS_SH_SPR_CACHE(35).TOP <= SS_CHAIN(2633);
SS_SH_SPR_CACHE(35).BOTTOM <= SS_CHAIN(2634);
SS_SH_SPR_CACHE(36).X(4 downto 0) <= SS_CHAIN(2639 downto 2635);
SS_SH_SPR_CACHE(36).X(9 downto 5) <= SS_CHAIN(2644 downto 2640);
SS_SH_SPR_CACHE(36).Y(9 downto 0) <= SS_CHAIN(2654 downto 2645);
SS_SH_SPR_CACHE(36).PC(0 downto 0) <= SS_CHAIN(2655 downto 2655);
SS_SH_SPR_CACHE(36).PC(10 downto 1) <= SS_CHAIN(2665 downto 2656);
SS_SH_SPR_CACHE(36).CG <= SS_CHAIN(2666);
SS_SH_SPR_CACHE(36).PAL(3 downto 0) <= SS_CHAIN(2670 downto 2667);
SS_SH_SPR_CACHE(36).PRIO <= SS_CHAIN(2671);
SS_SH_SPR_CACHE(36).CGX <= SS_CHAIN(2672);
SS_SH_SPR_CACHE(36).CGY(1 downto 0) <= SS_CHAIN(2674 downto 2673);
SS_SH_SPR_CACHE(36).HF <= SS_CHAIN(2675);
SS_SH_SPR_CACHE(36).VF <= SS_CHAIN(2676);
SS_SH_SPR_CACHE(36).SPR0 <= SS_CHAIN(2677);
SS_SH_SPR_CACHE(36).TOP <= SS_CHAIN(2678);
SS_SH_SPR_CACHE(36).BOTTOM <= SS_CHAIN(2679);
SS_SH_SPR_CACHE(37).X(7 downto 0) <= SS_CHAIN(2687 downto 2680);
SS_SH_SPR_CACHE(37).X(9 downto 8) <= SS_CHAIN(2689 downto 2688);
SS_SH_SPR_CACHE(37).Y(9 downto 0) <= SS_CHAIN(2699 downto 2690);
SS_SH_SPR_CACHE(37).PC(3 downto 0) <= SS_CHAIN(2703 downto 2700);
SS_SH_SPR_CACHE(37).PC(10 downto 4) <= SS_CHAIN(2710 downto 2704);
SS_SH_SPR_CACHE(37).CG <= SS_CHAIN(2711);
SS_SH_SPR_CACHE(37).PAL(3 downto 0) <= SS_CHAIN(2715 downto 2712);
SS_SH_SPR_CACHE(37).PRIO <= SS_CHAIN(2716);
SS_SH_SPR_CACHE(37).CGX <= SS_CHAIN(2717);
SS_SH_SPR_CACHE(37).CGY(1 downto 0) <= SS_CHAIN(2719 downto 2718);
SS_SH_SPR_CACHE(37).HF <= SS_CHAIN(2720);
SS_SH_SPR_CACHE(37).VF <= SS_CHAIN(2721);
SS_SH_SPR_CACHE(37).SPR0 <= SS_CHAIN(2722);
SS_SH_SPR_CACHE(37).TOP <= SS_CHAIN(2723);
SS_SH_SPR_CACHE(37).BOTTOM <= SS_CHAIN(2724);
SS_SH_SPR_CACHE(38).X(9 downto 0) <= SS_CHAIN(2734 downto 2725);
SS_SH_SPR_CACHE(38).Y(0 downto 0) <= SS_CHAIN(2735 downto 2735);
SS_SH_SPR_CACHE(38).Y(9 downto 1) <= SS_CHAIN(2744 downto 2736);
SS_SH_SPR_CACHE(38).PC(6 downto 0) <= SS_CHAIN(2751 downto 2745);
SS_SH_SPR_CACHE(38).PC(10 downto 7) <= SS_CHAIN(2755 downto 2752);
SS_SH_SPR_CACHE(38).CG <= SS_CHAIN(2756);
SS_SH_SPR_CACHE(38).PAL(3 downto 0) <= SS_CHAIN(2760 downto 2757);
SS_SH_SPR_CACHE(38).PRIO <= SS_CHAIN(2761);
SS_SH_SPR_CACHE(38).CGX <= SS_CHAIN(2762);
SS_SH_SPR_CACHE(38).CGY(1 downto 0) <= SS_CHAIN(2764 downto 2763);
SS_SH_SPR_CACHE(38).HF <= SS_CHAIN(2765);
SS_SH_SPR_CACHE(38).VF <= SS_CHAIN(2766);
SS_SH_SPR_CACHE(38).SPR0 <= SS_CHAIN(2767);
SS_SH_SPR_CACHE(38).TOP <= SS_CHAIN(2768);
SS_SH_SPR_CACHE(38).BOTTOM <= SS_CHAIN(2769);
SS_SH_SPR_CACHE(39).X(9 downto 0) <= SS_CHAIN(2779 downto 2770);
SS_SH_SPR_CACHE(39).Y(3 downto 0) <= SS_CHAIN(2783 downto 2780);
SS_SH_SPR_CACHE(39).Y(9 downto 4) <= SS_CHAIN(2789 downto 2784);
SS_SH_SPR_CACHE(39).PC(9 downto 0) <= SS_CHAIN(2799 downto 2790);
SS_SH_SPR_CACHE(39).PC(10 downto 10) <= SS_CHAIN(2800 downto 2800);
SS_SH_SPR_CACHE(39).CG <= SS_CHAIN(2801);
SS_SH_SPR_CACHE(39).PAL(3 downto 0) <= SS_CHAIN(2805 downto 2802);
SS_SH_SPR_CACHE(39).PRIO <= SS_CHAIN(2806);
SS_SH_SPR_CACHE(39).CGX <= SS_CHAIN(2807);
SS_SH_SPR_CACHE(39).CGY(1 downto 0) <= SS_CHAIN(2809 downto 2808);
SS_SH_SPR_CACHE(39).HF <= SS_CHAIN(2810);
SS_SH_SPR_CACHE(39).VF <= SS_CHAIN(2811);
SS_SH_SPR_CACHE(39).SPR0 <= SS_CHAIN(2812);
SS_SH_SPR_CACHE(39).TOP <= SS_CHAIN(2813);
SS_SH_SPR_CACHE(39).BOTTOM <= SS_CHAIN(2814);
SS_SH_SPR_CACHE(40).X(0 downto 0) <= SS_CHAIN(2815 downto 2815);
SS_SH_SPR_CACHE(40).X(9 downto 1) <= SS_CHAIN(2824 downto 2816);
SS_SH_SPR_CACHE(40).Y(6 downto 0) <= SS_CHAIN(2831 downto 2825);
SS_SH_SPR_CACHE(40).Y(9 downto 7) <= SS_CHAIN(2834 downto 2832);
SS_SH_SPR_CACHE(40).PC(10 downto 0) <= SS_CHAIN(2845 downto 2835);
SS_SH_SPR_CACHE(40).CG <= SS_CHAIN(2846);
SS_SH_SPR_CACHE(40).PAL(0 downto 0) <= SS_CHAIN(2847 downto 2847);
SS_SH_SPR_CACHE(40).PAL(3 downto 1) <= SS_CHAIN(2850 downto 2848);
SS_SH_SPR_CACHE(40).PRIO <= SS_CHAIN(2851);
SS_SH_SPR_CACHE(40).CGX <= SS_CHAIN(2852);
SS_SH_SPR_CACHE(40).CGY(1 downto 0) <= SS_CHAIN(2854 downto 2853);
SS_SH_SPR_CACHE(40).HF <= SS_CHAIN(2855);
SS_SH_SPR_CACHE(40).VF <= SS_CHAIN(2856);
SS_SH_SPR_CACHE(40).SPR0 <= SS_CHAIN(2857);
SS_SH_SPR_CACHE(40).TOP <= SS_CHAIN(2858);
SS_SH_SPR_CACHE(40).BOTTOM <= SS_CHAIN(2859);
SS_SH_SPR_CACHE(41).X(3 downto 0) <= SS_CHAIN(2863 downto 2860);
SS_SH_SPR_CACHE(41).X(9 downto 4) <= SS_CHAIN(2869 downto 2864);
SS_SH_SPR_CACHE(41).Y(9 downto 0) <= SS_CHAIN(2879 downto 2870);
SS_SH_SPR_CACHE(41).PC(10 downto 0) <= SS_CHAIN(2890 downto 2880);
SS_SH_SPR_CACHE(41).CG <= SS_CHAIN(2891);
SS_SH_SPR_CACHE(41).PAL(3 downto 0) <= SS_CHAIN(2895 downto 2892);
SS_SH_SPR_CACHE(41).PRIO <= SS_CHAIN(2896);
SS_SH_SPR_CACHE(41).CGX <= SS_CHAIN(2897);
SS_SH_SPR_CACHE(41).CGY(1 downto 0) <= SS_CHAIN(2899 downto 2898);
SS_SH_SPR_CACHE(41).HF <= SS_CHAIN(2900);
SS_SH_SPR_CACHE(41).VF <= SS_CHAIN(2901);
SS_SH_SPR_CACHE(41).SPR0 <= SS_CHAIN(2902);
SS_SH_SPR_CACHE(41).TOP <= SS_CHAIN(2903);
SS_SH_SPR_CACHE(41).BOTTOM <= SS_CHAIN(2904);
SS_SH_SPR_CACHE(42).X(6 downto 0) <= SS_CHAIN(2911 downto 2905);
SS_SH_SPR_CACHE(42).X(9 downto 7) <= SS_CHAIN(2914 downto 2912);
SS_SH_SPR_CACHE(42).Y(9 downto 0) <= SS_CHAIN(2924 downto 2915);
SS_SH_SPR_CACHE(42).PC(2 downto 0) <= SS_CHAIN(2927 downto 2925);
SS_SH_SPR_CACHE(42).PC(10 downto 3) <= SS_CHAIN(2935 downto 2928);
SS_SH_SPR_CACHE(42).CG <= SS_CHAIN(2936);
SS_SH_SPR_CACHE(42).PAL(3 downto 0) <= SS_CHAIN(2940 downto 2937);
SS_SH_SPR_CACHE(42).PRIO <= SS_CHAIN(2941);
SS_SH_SPR_CACHE(42).CGX <= SS_CHAIN(2942);
SS_SH_SPR_CACHE(42).CGY(0 downto 0) <= SS_CHAIN(2943 downto 2943);
SS_SH_SPR_CACHE(42).CGY(1 downto 1) <= SS_CHAIN(2944 downto 2944);
SS_SH_SPR_CACHE(42).HF <= SS_CHAIN(2945);
SS_SH_SPR_CACHE(42).VF <= SS_CHAIN(2946);
SS_SH_SPR_CACHE(42).SPR0 <= SS_CHAIN(2947);
SS_SH_SPR_CACHE(42).TOP <= SS_CHAIN(2948);
SS_SH_SPR_CACHE(42).BOTTOM <= SS_CHAIN(2949);
SS_SH_SPR_CACHE(43).X(9 downto 0) <= SS_CHAIN(2959 downto 2950);
SS_SH_SPR_CACHE(43).Y(9 downto 0) <= SS_CHAIN(2969 downto 2960);
SS_SH_SPR_CACHE(43).PC(5 downto 0) <= SS_CHAIN(2975 downto 2970);
SS_SH_SPR_CACHE(43).PC(10 downto 6) <= SS_CHAIN(2980 downto 2976);
SS_SH_SPR_CACHE(43).CG <= SS_CHAIN(2981);
SS_SH_SPR_CACHE(43).PAL(3 downto 0) <= SS_CHAIN(2985 downto 2982);
SS_SH_SPR_CACHE(43).PRIO <= SS_CHAIN(2986);
SS_SH_SPR_CACHE(43).CGX <= SS_CHAIN(2987);
SS_SH_SPR_CACHE(43).CGY(1 downto 0) <= SS_CHAIN(2989 downto 2988);
SS_SH_SPR_CACHE(43).HF <= SS_CHAIN(2990);
SS_SH_SPR_CACHE(43).VF <= SS_CHAIN(2991);
SS_SH_SPR_CACHE(43).SPR0 <= SS_CHAIN(2992);
SS_SH_SPR_CACHE(43).TOP <= SS_CHAIN(2993);
SS_SH_SPR_CACHE(43).BOTTOM <= SS_CHAIN(2994);
SS_SH_SPR_CACHE(44).X(9 downto 0) <= SS_CHAIN(3004 downto 2995);
SS_SH_SPR_CACHE(44).Y(2 downto 0) <= SS_CHAIN(3007 downto 3005);
SS_SH_SPR_CACHE(44).Y(9 downto 3) <= SS_CHAIN(3014 downto 3008);
SS_SH_SPR_CACHE(44).PC(8 downto 0) <= SS_CHAIN(3023 downto 3015);
SS_SH_SPR_CACHE(44).PC(10 downto 9) <= SS_CHAIN(3025 downto 3024);
SS_SH_SPR_CACHE(44).CG <= SS_CHAIN(3026);
SS_SH_SPR_CACHE(44).PAL(3 downto 0) <= SS_CHAIN(3030 downto 3027);
SS_SH_SPR_CACHE(44).PRIO <= SS_CHAIN(3031);
SS_SH_SPR_CACHE(44).CGX <= SS_CHAIN(3032);
SS_SH_SPR_CACHE(44).CGY(1 downto 0) <= SS_CHAIN(3034 downto 3033);
SS_SH_SPR_CACHE(44).HF <= SS_CHAIN(3035);
SS_SH_SPR_CACHE(44).VF <= SS_CHAIN(3036);
SS_SH_SPR_CACHE(44).SPR0 <= SS_CHAIN(3037);
SS_SH_SPR_CACHE(44).TOP <= SS_CHAIN(3038);
SS_SH_SPR_CACHE(44).BOTTOM <= SS_CHAIN(3039);
SS_SH_SPR_CACHE(45).X(9 downto 0) <= SS_CHAIN(3049 downto 3040);
SS_SH_SPR_CACHE(45).Y(5 downto 0) <= SS_CHAIN(3055 downto 3050);
SS_SH_SPR_CACHE(45).Y(9 downto 6) <= SS_CHAIN(3059 downto 3056);
SS_SH_SPR_CACHE(45).PC(10 downto 0) <= SS_CHAIN(3070 downto 3060);
SS_SH_SPR_CACHE(45).CG <= SS_CHAIN(3071);
SS_SH_SPR_CACHE(45).PAL(3 downto 0) <= SS_CHAIN(3075 downto 3072);
SS_SH_SPR_CACHE(45).PRIO <= SS_CHAIN(3076);
SS_SH_SPR_CACHE(45).CGX <= SS_CHAIN(3077);
SS_SH_SPR_CACHE(45).CGY(1 downto 0) <= SS_CHAIN(3079 downto 3078);
SS_SH_SPR_CACHE(45).HF <= SS_CHAIN(3080);
SS_SH_SPR_CACHE(45).VF <= SS_CHAIN(3081);
SS_SH_SPR_CACHE(45).SPR0 <= SS_CHAIN(3082);
SS_SH_SPR_CACHE(45).TOP <= SS_CHAIN(3083);
SS_SH_SPR_CACHE(45).BOTTOM <= SS_CHAIN(3084);
SS_SH_SPR_CACHE(46).X(2 downto 0) <= SS_CHAIN(3087 downto 3085);
SS_SH_SPR_CACHE(46).X(9 downto 3) <= SS_CHAIN(3094 downto 3088);
SS_SH_SPR_CACHE(46).Y(8 downto 0) <= SS_CHAIN(3103 downto 3095);
SS_SH_SPR_CACHE(46).Y(9 downto 9) <= SS_CHAIN(3104 downto 3104);
SS_SH_SPR_CACHE(46).PC(10 downto 0) <= SS_CHAIN(3115 downto 3105);
SS_SH_SPR_CACHE(46).CG <= SS_CHAIN(3116);
SS_SH_SPR_CACHE(46).PAL(2 downto 0) <= SS_CHAIN(3119 downto 3117);
SS_SH_SPR_CACHE(46).PAL(3 downto 3) <= SS_CHAIN(3120 downto 3120);
SS_SH_SPR_CACHE(46).PRIO <= SS_CHAIN(3121);
SS_SH_SPR_CACHE(46).CGX <= SS_CHAIN(3122);
SS_SH_SPR_CACHE(46).CGY(1 downto 0) <= SS_CHAIN(3124 downto 3123);
SS_SH_SPR_CACHE(46).HF <= SS_CHAIN(3125);
SS_SH_SPR_CACHE(46).VF <= SS_CHAIN(3126);
SS_SH_SPR_CACHE(46).SPR0 <= SS_CHAIN(3127);
SS_SH_SPR_CACHE(46).TOP <= SS_CHAIN(3128);
SS_SH_SPR_CACHE(46).BOTTOM <= SS_CHAIN(3129);
SS_SH_SPR_CACHE(47).X(5 downto 0) <= SS_CHAIN(3135 downto 3130);
SS_SH_SPR_CACHE(47).X(9 downto 6) <= SS_CHAIN(3139 downto 3136);
SS_SH_SPR_CACHE(47).Y(9 downto 0) <= SS_CHAIN(3149 downto 3140);
SS_SH_SPR_CACHE(47).PC(1 downto 0) <= SS_CHAIN(3151 downto 3150);
SS_SH_SPR_CACHE(47).PC(10 downto 2) <= SS_CHAIN(3160 downto 3152);
SS_SH_SPR_CACHE(47).CG <= SS_CHAIN(3161);
SS_SH_SPR_CACHE(47).PAL(3 downto 0) <= SS_CHAIN(3165 downto 3162);
SS_SH_SPR_CACHE(47).PRIO <= SS_CHAIN(3166);
SS_SH_SPR_CACHE(47).CGX <= SS_CHAIN(3167);
SS_SH_SPR_CACHE(47).CGY(1 downto 0) <= SS_CHAIN(3169 downto 3168);
SS_SH_SPR_CACHE(47).HF <= SS_CHAIN(3170);
SS_SH_SPR_CACHE(47).VF <= SS_CHAIN(3171);
SS_SH_SPR_CACHE(47).SPR0 <= SS_CHAIN(3172);
SS_SH_SPR_CACHE(47).TOP <= SS_CHAIN(3173);
SS_SH_SPR_CACHE(47).BOTTOM <= SS_CHAIN(3174);
SS_SH_SPR_CACHE(48).X(8 downto 0) <= SS_CHAIN(3183 downto 3175);
SS_SH_SPR_CACHE(48).X(9 downto 9) <= SS_CHAIN(3184 downto 3184);
SS_SH_SPR_CACHE(48).Y(9 downto 0) <= SS_CHAIN(3194 downto 3185);
SS_SH_SPR_CACHE(48).PC(4 downto 0) <= SS_CHAIN(3199 downto 3195);
SS_SH_SPR_CACHE(48).PC(10 downto 5) <= SS_CHAIN(3205 downto 3200);
SS_SH_SPR_CACHE(48).CG <= SS_CHAIN(3206);
SS_SH_SPR_CACHE(48).PAL(3 downto 0) <= SS_CHAIN(3210 downto 3207);
SS_SH_SPR_CACHE(48).PRIO <= SS_CHAIN(3211);
SS_SH_SPR_CACHE(48).CGX <= SS_CHAIN(3212);
SS_SH_SPR_CACHE(48).CGY(1 downto 0) <= SS_CHAIN(3214 downto 3213);
SS_SH_SPR_CACHE(48).HF <= SS_CHAIN(3215);
SS_SH_SPR_CACHE(48).VF <= SS_CHAIN(3216);
SS_SH_SPR_CACHE(48).SPR0 <= SS_CHAIN(3217);
SS_SH_SPR_CACHE(48).TOP <= SS_CHAIN(3218);
SS_SH_SPR_CACHE(48).BOTTOM <= SS_CHAIN(3219);
SS_SH_SPR_CACHE(49).X(9 downto 0) <= SS_CHAIN(3229 downto 3220);
SS_SH_SPR_CACHE(49).Y(1 downto 0) <= SS_CHAIN(3231 downto 3230);
SS_SH_SPR_CACHE(49).Y(9 downto 2) <= SS_CHAIN(3239 downto 3232);
SS_SH_SPR_CACHE(49).PC(7 downto 0) <= SS_CHAIN(3247 downto 3240);
SS_SH_SPR_CACHE(49).PC(10 downto 8) <= SS_CHAIN(3250 downto 3248);
SS_SH_SPR_CACHE(49).CG <= SS_CHAIN(3251);
SS_SH_SPR_CACHE(49).PAL(3 downto 0) <= SS_CHAIN(3255 downto 3252);
SS_SH_SPR_CACHE(49).PRIO <= SS_CHAIN(3256);
SS_SH_SPR_CACHE(49).CGX <= SS_CHAIN(3257);
SS_SH_SPR_CACHE(49).CGY(1 downto 0) <= SS_CHAIN(3259 downto 3258);
SS_SH_SPR_CACHE(49).HF <= SS_CHAIN(3260);
SS_SH_SPR_CACHE(49).VF <= SS_CHAIN(3261);
SS_SH_SPR_CACHE(49).SPR0 <= SS_CHAIN(3262);
SS_SH_SPR_CACHE(49).TOP <= SS_CHAIN(3263);
SS_SH_SPR_CACHE(49).BOTTOM <= SS_CHAIN(3264);
SS_SH_SPR_CACHE(50).X(9 downto 0) <= SS_CHAIN(3274 downto 3265);
SS_SH_SPR_CACHE(50).Y(4 downto 0) <= SS_CHAIN(3279 downto 3275);
SS_SH_SPR_CACHE(50).Y(9 downto 5) <= SS_CHAIN(3284 downto 3280);
SS_SH_SPR_CACHE(50).PC(10 downto 0) <= SS_CHAIN(3295 downto 3285);
SS_SH_SPR_CACHE(50).CG <= SS_CHAIN(3296);
SS_SH_SPR_CACHE(50).PAL(3 downto 0) <= SS_CHAIN(3300 downto 3297);
SS_SH_SPR_CACHE(50).PRIO <= SS_CHAIN(3301);
SS_SH_SPR_CACHE(50).CGX <= SS_CHAIN(3302);
SS_SH_SPR_CACHE(50).CGY(1 downto 0) <= SS_CHAIN(3304 downto 3303);
SS_SH_SPR_CACHE(50).HF <= SS_CHAIN(3305);
SS_SH_SPR_CACHE(50).VF <= SS_CHAIN(3306);
SS_SH_SPR_CACHE(50).SPR0 <= SS_CHAIN(3307);
SS_SH_SPR_CACHE(50).TOP <= SS_CHAIN(3308);
SS_SH_SPR_CACHE(50).BOTTOM <= SS_CHAIN(3309);
SS_SH_SPR_CACHE(51).X(1 downto 0) <= SS_CHAIN(3311 downto 3310);
SS_SH_SPR_CACHE(51).X(9 downto 2) <= SS_CHAIN(3319 downto 3312);
SS_SH_SPR_CACHE(51).Y(7 downto 0) <= SS_CHAIN(3327 downto 3320);
SS_SH_SPR_CACHE(51).Y(9 downto 8) <= SS_CHAIN(3329 downto 3328);
SS_SH_SPR_CACHE(51).PC(10 downto 0) <= SS_CHAIN(3340 downto 3330);
SS_SH_SPR_CACHE(51).CG <= SS_CHAIN(3341);
SS_SH_SPR_CACHE(51).PAL(1 downto 0) <= SS_CHAIN(3343 downto 3342);
SS_SH_SPR_CACHE(51).PAL(3 downto 2) <= SS_CHAIN(3345 downto 3344);
SS_SH_SPR_CACHE(51).PRIO <= SS_CHAIN(3346);
SS_SH_SPR_CACHE(51).CGX <= SS_CHAIN(3347);
SS_SH_SPR_CACHE(51).CGY(1 downto 0) <= SS_CHAIN(3349 downto 3348);
SS_SH_SPR_CACHE(51).HF <= SS_CHAIN(3350);
SS_SH_SPR_CACHE(51).VF <= SS_CHAIN(3351);
SS_SH_SPR_CACHE(51).SPR0 <= SS_CHAIN(3352);
SS_SH_SPR_CACHE(51).TOP <= SS_CHAIN(3353);
SS_SH_SPR_CACHE(51).BOTTOM <= SS_CHAIN(3354);
SS_SH_SPR_CACHE(52).X(4 downto 0) <= SS_CHAIN(3359 downto 3355);
SS_SH_SPR_CACHE(52).X(9 downto 5) <= SS_CHAIN(3364 downto 3360);
SS_SH_SPR_CACHE(52).Y(9 downto 0) <= SS_CHAIN(3374 downto 3365);
SS_SH_SPR_CACHE(52).PC(0 downto 0) <= SS_CHAIN(3375 downto 3375);
SS_SH_SPR_CACHE(52).PC(10 downto 1) <= SS_CHAIN(3385 downto 3376);
SS_SH_SPR_CACHE(52).CG <= SS_CHAIN(3386);
SS_SH_SPR_CACHE(52).PAL(3 downto 0) <= SS_CHAIN(3390 downto 3387);
SS_SH_SPR_CACHE(52).PRIO <= SS_CHAIN(3391);
SS_SH_SPR_CACHE(52).CGX <= SS_CHAIN(3392);
SS_SH_SPR_CACHE(52).CGY(1 downto 0) <= SS_CHAIN(3394 downto 3393);
SS_SH_SPR_CACHE(52).HF <= SS_CHAIN(3395);
SS_SH_SPR_CACHE(52).VF <= SS_CHAIN(3396);
SS_SH_SPR_CACHE(52).SPR0 <= SS_CHAIN(3397);
SS_SH_SPR_CACHE(52).TOP <= SS_CHAIN(3398);
SS_SH_SPR_CACHE(52).BOTTOM <= SS_CHAIN(3399);
SS_SH_SPR_CACHE(53).X(7 downto 0) <= SS_CHAIN(3407 downto 3400);
SS_SH_SPR_CACHE(53).X(9 downto 8) <= SS_CHAIN(3409 downto 3408);
SS_SH_SPR_CACHE(53).Y(9 downto 0) <= SS_CHAIN(3419 downto 3410);
SS_SH_SPR_CACHE(53).PC(3 downto 0) <= SS_CHAIN(3423 downto 3420);
SS_SH_SPR_CACHE(53).PC(10 downto 4) <= SS_CHAIN(3430 downto 3424);
SS_SH_SPR_CACHE(53).CG <= SS_CHAIN(3431);
SS_SH_SPR_CACHE(53).PAL(3 downto 0) <= SS_CHAIN(3435 downto 3432);
SS_SH_SPR_CACHE(53).PRIO <= SS_CHAIN(3436);
SS_SH_SPR_CACHE(53).CGX <= SS_CHAIN(3437);
SS_SH_SPR_CACHE(53).CGY(1 downto 0) <= SS_CHAIN(3439 downto 3438);
SS_SH_SPR_CACHE(53).HF <= SS_CHAIN(3440);
SS_SH_SPR_CACHE(53).VF <= SS_CHAIN(3441);
SS_SH_SPR_CACHE(53).SPR0 <= SS_CHAIN(3442);
SS_SH_SPR_CACHE(53).TOP <= SS_CHAIN(3443);
SS_SH_SPR_CACHE(53).BOTTOM <= SS_CHAIN(3444);
SS_SH_SPR_CACHE(54).X(9 downto 0) <= SS_CHAIN(3454 downto 3445);
SS_SH_SPR_CACHE(54).Y(0 downto 0) <= SS_CHAIN(3455 downto 3455);
SS_SH_SPR_CACHE(54).Y(9 downto 1) <= SS_CHAIN(3464 downto 3456);
SS_SH_SPR_CACHE(54).PC(6 downto 0) <= SS_CHAIN(3471 downto 3465);
SS_SH_SPR_CACHE(54).PC(10 downto 7) <= SS_CHAIN(3475 downto 3472);
SS_SH_SPR_CACHE(54).CG <= SS_CHAIN(3476);
SS_SH_SPR_CACHE(54).PAL(3 downto 0) <= SS_CHAIN(3480 downto 3477);
SS_SH_SPR_CACHE(54).PRIO <= SS_CHAIN(3481);
SS_SH_SPR_CACHE(54).CGX <= SS_CHAIN(3482);
SS_SH_SPR_CACHE(54).CGY(1 downto 0) <= SS_CHAIN(3484 downto 3483);
SS_SH_SPR_CACHE(54).HF <= SS_CHAIN(3485);
SS_SH_SPR_CACHE(54).VF <= SS_CHAIN(3486);
SS_SH_SPR_CACHE(54).SPR0 <= SS_CHAIN(3487);
SS_SH_SPR_CACHE(54).TOP <= SS_CHAIN(3488);
SS_SH_SPR_CACHE(54).BOTTOM <= SS_CHAIN(3489);
SS_SH_SPR_CACHE(55).X(9 downto 0) <= SS_CHAIN(3499 downto 3490);
SS_SH_SPR_CACHE(55).Y(3 downto 0) <= SS_CHAIN(3503 downto 3500);
SS_SH_SPR_CACHE(55).Y(9 downto 4) <= SS_CHAIN(3509 downto 3504);
SS_SH_SPR_CACHE(55).PC(9 downto 0) <= SS_CHAIN(3519 downto 3510);
SS_SH_SPR_CACHE(55).PC(10 downto 10) <= SS_CHAIN(3520 downto 3520);
SS_SH_SPR_CACHE(55).CG <= SS_CHAIN(3521);
SS_SH_SPR_CACHE(55).PAL(3 downto 0) <= SS_CHAIN(3525 downto 3522);
SS_SH_SPR_CACHE(55).PRIO <= SS_CHAIN(3526);
SS_SH_SPR_CACHE(55).CGX <= SS_CHAIN(3527);
SS_SH_SPR_CACHE(55).CGY(1 downto 0) <= SS_CHAIN(3529 downto 3528);
SS_SH_SPR_CACHE(55).HF <= SS_CHAIN(3530);
SS_SH_SPR_CACHE(55).VF <= SS_CHAIN(3531);
SS_SH_SPR_CACHE(55).SPR0 <= SS_CHAIN(3532);
SS_SH_SPR_CACHE(55).TOP <= SS_CHAIN(3533);
SS_SH_SPR_CACHE(55).BOTTOM <= SS_CHAIN(3534);
SS_SH_SPR_CACHE(56).X(0 downto 0) <= SS_CHAIN(3535 downto 3535);
SS_SH_SPR_CACHE(56).X(9 downto 1) <= SS_CHAIN(3544 downto 3536);
SS_SH_SPR_CACHE(56).Y(6 downto 0) <= SS_CHAIN(3551 downto 3545);
SS_SH_SPR_CACHE(56).Y(9 downto 7) <= SS_CHAIN(3554 downto 3552);
SS_SH_SPR_CACHE(56).PC(10 downto 0) <= SS_CHAIN(3565 downto 3555);
SS_SH_SPR_CACHE(56).CG <= SS_CHAIN(3566);
SS_SH_SPR_CACHE(56).PAL(0 downto 0) <= SS_CHAIN(3567 downto 3567);
SS_SH_SPR_CACHE(56).PAL(3 downto 1) <= SS_CHAIN(3570 downto 3568);
SS_SH_SPR_CACHE(56).PRIO <= SS_CHAIN(3571);
SS_SH_SPR_CACHE(56).CGX <= SS_CHAIN(3572);
SS_SH_SPR_CACHE(56).CGY(1 downto 0) <= SS_CHAIN(3574 downto 3573);
SS_SH_SPR_CACHE(56).HF <= SS_CHAIN(3575);
SS_SH_SPR_CACHE(56).VF <= SS_CHAIN(3576);
SS_SH_SPR_CACHE(56).SPR0 <= SS_CHAIN(3577);
SS_SH_SPR_CACHE(56).TOP <= SS_CHAIN(3578);
SS_SH_SPR_CACHE(56).BOTTOM <= SS_CHAIN(3579);
SS_SH_SPR_CACHE(57).X(3 downto 0) <= SS_CHAIN(3583 downto 3580);
SS_SH_SPR_CACHE(57).X(9 downto 4) <= SS_CHAIN(3589 downto 3584);
SS_SH_SPR_CACHE(57).Y(9 downto 0) <= SS_CHAIN(3599 downto 3590);
SS_SH_SPR_CACHE(57).PC(10 downto 0) <= SS_CHAIN(3610 downto 3600);
SS_SH_SPR_CACHE(57).CG <= SS_CHAIN(3611);
SS_SH_SPR_CACHE(57).PAL(3 downto 0) <= SS_CHAIN(3615 downto 3612);
SS_SH_SPR_CACHE(57).PRIO <= SS_CHAIN(3616);
SS_SH_SPR_CACHE(57).CGX <= SS_CHAIN(3617);
SS_SH_SPR_CACHE(57).CGY(1 downto 0) <= SS_CHAIN(3619 downto 3618);
SS_SH_SPR_CACHE(57).HF <= SS_CHAIN(3620);
SS_SH_SPR_CACHE(57).VF <= SS_CHAIN(3621);
SS_SH_SPR_CACHE(57).SPR0 <= SS_CHAIN(3622);
SS_SH_SPR_CACHE(57).TOP <= SS_CHAIN(3623);
SS_SH_SPR_CACHE(57).BOTTOM <= SS_CHAIN(3624);
SS_SH_SPR_CACHE(58).X(6 downto 0) <= SS_CHAIN(3631 downto 3625);
SS_SH_SPR_CACHE(58).X(9 downto 7) <= SS_CHAIN(3634 downto 3632);
SS_SH_SPR_CACHE(58).Y(9 downto 0) <= SS_CHAIN(3644 downto 3635);
SS_SH_SPR_CACHE(58).PC(2 downto 0) <= SS_CHAIN(3647 downto 3645);
SS_SH_SPR_CACHE(58).PC(10 downto 3) <= SS_CHAIN(3655 downto 3648);
SS_SH_SPR_CACHE(58).CG <= SS_CHAIN(3656);
SS_SH_SPR_CACHE(58).PAL(3 downto 0) <= SS_CHAIN(3660 downto 3657);
SS_SH_SPR_CACHE(58).PRIO <= SS_CHAIN(3661);
SS_SH_SPR_CACHE(58).CGX <= SS_CHAIN(3662);
SS_SH_SPR_CACHE(58).CGY(0 downto 0) <= SS_CHAIN(3663 downto 3663);
SS_SH_SPR_CACHE(58).CGY(1 downto 1) <= SS_CHAIN(3664 downto 3664);
SS_SH_SPR_CACHE(58).HF <= SS_CHAIN(3665);
SS_SH_SPR_CACHE(58).VF <= SS_CHAIN(3666);
SS_SH_SPR_CACHE(58).SPR0 <= SS_CHAIN(3667);
SS_SH_SPR_CACHE(58).TOP <= SS_CHAIN(3668);
SS_SH_SPR_CACHE(58).BOTTOM <= SS_CHAIN(3669);
SS_SH_SPR_CACHE(59).X(9 downto 0) <= SS_CHAIN(3679 downto 3670);
SS_SH_SPR_CACHE(59).Y(9 downto 0) <= SS_CHAIN(3689 downto 3680);
SS_SH_SPR_CACHE(59).PC(5 downto 0) <= SS_CHAIN(3695 downto 3690);
SS_SH_SPR_CACHE(59).PC(10 downto 6) <= SS_CHAIN(3700 downto 3696);
SS_SH_SPR_CACHE(59).CG <= SS_CHAIN(3701);
SS_SH_SPR_CACHE(59).PAL(3 downto 0) <= SS_CHAIN(3705 downto 3702);
SS_SH_SPR_CACHE(59).PRIO <= SS_CHAIN(3706);
SS_SH_SPR_CACHE(59).CGX <= SS_CHAIN(3707);
SS_SH_SPR_CACHE(59).CGY(1 downto 0) <= SS_CHAIN(3709 downto 3708);
SS_SH_SPR_CACHE(59).HF <= SS_CHAIN(3710);
SS_SH_SPR_CACHE(59).VF <= SS_CHAIN(3711);
SS_SH_SPR_CACHE(59).SPR0 <= SS_CHAIN(3712);
SS_SH_SPR_CACHE(59).TOP <= SS_CHAIN(3713);
SS_SH_SPR_CACHE(59).BOTTOM <= SS_CHAIN(3714);
SS_SH_SPR_CACHE(60).X(9 downto 0) <= SS_CHAIN(3724 downto 3715);
SS_SH_SPR_CACHE(60).Y(2 downto 0) <= SS_CHAIN(3727 downto 3725);
SS_SH_SPR_CACHE(60).Y(9 downto 3) <= SS_CHAIN(3734 downto 3728);
SS_SH_SPR_CACHE(60).PC(8 downto 0) <= SS_CHAIN(3743 downto 3735);
SS_SH_SPR_CACHE(60).PC(10 downto 9) <= SS_CHAIN(3745 downto 3744);
SS_SH_SPR_CACHE(60).CG <= SS_CHAIN(3746);
SS_SH_SPR_CACHE(60).PAL(3 downto 0) <= SS_CHAIN(3750 downto 3747);
SS_SH_SPR_CACHE(60).PRIO <= SS_CHAIN(3751);
SS_SH_SPR_CACHE(60).CGX <= SS_CHAIN(3752);
SS_SH_SPR_CACHE(60).CGY(1 downto 0) <= SS_CHAIN(3754 downto 3753);
SS_SH_SPR_CACHE(60).HF <= SS_CHAIN(3755);
SS_SH_SPR_CACHE(60).VF <= SS_CHAIN(3756);
SS_SH_SPR_CACHE(60).SPR0 <= SS_CHAIN(3757);
SS_SH_SPR_CACHE(60).TOP <= SS_CHAIN(3758);
SS_SH_SPR_CACHE(60).BOTTOM <= SS_CHAIN(3759);
SS_SH_SPR_CACHE(61).X(9 downto 0) <= SS_CHAIN(3769 downto 3760);
SS_SH_SPR_CACHE(61).Y(5 downto 0) <= SS_CHAIN(3775 downto 3770);
SS_SH_SPR_CACHE(61).Y(9 downto 6) <= SS_CHAIN(3779 downto 3776);
SS_SH_SPR_CACHE(61).PC(10 downto 0) <= SS_CHAIN(3790 downto 3780);
SS_SH_SPR_CACHE(61).CG <= SS_CHAIN(3791);
SS_SH_SPR_CACHE(61).PAL(3 downto 0) <= SS_CHAIN(3795 downto 3792);
SS_SH_SPR_CACHE(61).PRIO <= SS_CHAIN(3796);
SS_SH_SPR_CACHE(61).CGX <= SS_CHAIN(3797);
SS_SH_SPR_CACHE(61).CGY(1 downto 0) <= SS_CHAIN(3799 downto 3798);
SS_SH_SPR_CACHE(61).HF <= SS_CHAIN(3800);
SS_SH_SPR_CACHE(61).VF <= SS_CHAIN(3801);
SS_SH_SPR_CACHE(61).SPR0 <= SS_CHAIN(3802);
SS_SH_SPR_CACHE(61).TOP <= SS_CHAIN(3803);
SS_SH_SPR_CACHE(61).BOTTOM <= SS_CHAIN(3804);
SS_SH_SPR_CACHE(62).X(2 downto 0) <= SS_CHAIN(3807 downto 3805);
SS_SH_SPR_CACHE(62).X(9 downto 3) <= SS_CHAIN(3814 downto 3808);
SS_SH_SPR_CACHE(62).Y(8 downto 0) <= SS_CHAIN(3823 downto 3815);
SS_SH_SPR_CACHE(62).Y(9 downto 9) <= SS_CHAIN(3824 downto 3824);
SS_SH_SPR_CACHE(62).PC(10 downto 0) <= SS_CHAIN(3835 downto 3825);
SS_SH_SPR_CACHE(62).CG <= SS_CHAIN(3836);
SS_SH_SPR_CACHE(62).PAL(2 downto 0) <= SS_CHAIN(3839 downto 3837);
SS_SH_SPR_CACHE(62).PAL(3 downto 3) <= SS_CHAIN(3840 downto 3840);
SS_SH_SPR_CACHE(62).PRIO <= SS_CHAIN(3841);
SS_SH_SPR_CACHE(62).CGX <= SS_CHAIN(3842);
SS_SH_SPR_CACHE(62).CGY(1 downto 0) <= SS_CHAIN(3844 downto 3843);
SS_SH_SPR_CACHE(62).HF <= SS_CHAIN(3845);
SS_SH_SPR_CACHE(62).VF <= SS_CHAIN(3846);
SS_SH_SPR_CACHE(62).SPR0 <= SS_CHAIN(3847);
SS_SH_SPR_CACHE(62).TOP <= SS_CHAIN(3848);
SS_SH_SPR_CACHE(62).BOTTOM <= SS_CHAIN(3849);
SS_SH_SPR_CACHE(63).X(5 downto 0) <= SS_CHAIN(3855 downto 3850);
SS_SH_SPR_CACHE(63).X(9 downto 6) <= SS_CHAIN(3859 downto 3856);
SS_SH_SPR_CACHE(63).Y(9 downto 0) <= SS_CHAIN(3869 downto 3860);
SS_SH_SPR_CACHE(63).PC(1 downto 0) <= SS_CHAIN(3871 downto 3870);
SS_SH_SPR_CACHE(63).PC(10 downto 2) <= SS_CHAIN(3880 downto 3872);
SS_SH_SPR_CACHE(63).CG <= SS_CHAIN(3881);
SS_SH_SPR_CACHE(63).PAL(3 downto 0) <= SS_CHAIN(3885 downto 3882);
SS_SH_SPR_CACHE(63).PRIO <= SS_CHAIN(3886);
SS_SH_SPR_CACHE(63).CGX <= SS_CHAIN(3887);
SS_SH_SPR_CACHE(63).CGY(1 downto 0) <= SS_CHAIN(3889 downto 3888);
SS_SH_SPR_CACHE(63).HF <= SS_CHAIN(3890);
SS_SH_SPR_CACHE(63).VF <= SS_CHAIN(3891);
SS_SH_SPR_CACHE(63).SPR0 <= SS_CHAIN(3892);
SS_SH_SPR_CACHE(63).TOP <= SS_CHAIN(3893);
SS_SH_SPR_CACHE(63).BOTTOM <= SS_CHAIN(3894);
SS_SH_SPR_CG <= SS_CHAIN(3895);
SS_SH_SPR_CH0(7 downto 0) <= SS_CHAIN(3903 downto 3896);
SS_SH_SPR_CH0(15 downto 8) <= SS_CHAIN(3911 downto 3904);
SS_SH_SPR_CH1(7 downto 0) <= SS_CHAIN(3919 downto 3912);
SS_SH_SPR_CH1(15 downto 8) <= SS_CHAIN(3927 downto 3920);
SS_SH_SPR_CH2(7 downto 0) <= SS_CHAIN(3935 downto 3928);
SS_SH_SPR_CH2(15 downto 8) <= SS_CHAIN(3943 downto 3936);
SS_SH_SPR_COLOR(0)(7 downto 0) <= SS_CHAIN(3951 downto 3944);
SS_SH_SPR_COLOR(0)(8 downto 8) <= SS_CHAIN(3952 downto 3952);
SS_SH_SPR_COLOR(1)(8 downto 0) <= SS_CHAIN(3961 downto 3953);
SS_SH_SPR_COLOR(2)(5 downto 0) <= SS_CHAIN(3967 downto 3962);
SS_SH_SPR_COLOR(2)(8 downto 6) <= SS_CHAIN(3970 downto 3968);
SS_SH_SPR_COLOR(3)(8 downto 0) <= SS_CHAIN(3979 downto 3971);
SS_SH_SPR_COLOR(4)(3 downto 0) <= SS_CHAIN(3983 downto 3980);
SS_SH_SPR_COLOR(4)(8 downto 4) <= SS_CHAIN(3988 downto 3984);
SS_SH_SPR_COLOR(5)(8 downto 0) <= SS_CHAIN(3997 downto 3989);
SS_SH_SPR_COLOR(6)(1 downto 0) <= SS_CHAIN(3999 downto 3998);
SS_SH_SPR_COLOR(6)(8 downto 2) <= SS_CHAIN(4006 downto 4000);
SS_SH_SPR_COLOR(7)(8 downto 0) <= SS_CHAIN(4015 downto 4007);
SS_SH_SPR_EVAL <= SS_CHAIN(4016);
SS_SH_SPR_EVAL_CNT(6 downto 0) <= unsigned(SS_CHAIN(4023 downto 4017));
SS_SH_SPR_EVAL_DONE <= SS_CHAIN(4024);
SS_SH_SPR_EVAL_FULL <= SS_CHAIN(4025);
SS_SH_SPR_EVAL_X(5 downto 0) <= unsigned(SS_CHAIN(4031 downto 4026));
SS_SH_SPR_EVAL_X(7 downto 6) <= unsigned(SS_CHAIN(4033 downto 4032));
SS_SH_SPR_FETCH <= SS_CHAIN(4034);
SS_SH_SPR_FETCH_CNT(6 downto 0) <= unsigned(SS_CHAIN(4041 downto 4035));
SS_SH_SPR_FETCH_DONE <= SS_CHAIN(4042);
SS_SH_SPR_FETCH_EN <= SS_CHAIN(4043);
SS_SH_SPR_FETCH_W <= SS_CHAIN(4044);
SS_SH_SPR_FIND <= SS_CHAIN(4045);
SS_SH_SPR_LINE_ADDR(0)(1 downto 0) <= SS_CHAIN(4047 downto 4046);
SS_SH_SPR_LINE_ADDR(0)(8 downto 2) <= SS_CHAIN(4054 downto 4048);
SS_SH_SPR_LINE_ADDR(1)(8 downto 0) <= SS_CHAIN(4063 downto 4055);
SS_SH_SPR_LINE_CLR <= SS_CHAIN(4064);
SS_SH_SPR_LINE_D(0)(8 downto 0) <= SS_CHAIN(4073 downto 4065);
SS_SH_SPR_LINE_D(1)(5 downto 0) <= SS_CHAIN(4079 downto 4074);
SS_SH_SPR_LINE_D(1)(8 downto 6) <= SS_CHAIN(4082 downto 4080);
SS_SH_SPR_LINE_WE(1 downto 0) <= SS_CHAIN(4084 downto 4083);
SS_SH_SPR_OUT_X(9 downto 0) <= unsigned(SS_CHAIN(4094 downto 4085));
SS_SH_SPR_PC(0 downto 0) <= SS_CHAIN(4095 downto 4095);
SS_SH_SPR_PC(10 downto 1) <= SS_CHAIN(4105 downto 4096);
SS_SH_SPR_TILE_BOTTOM <= SS_CHAIN(4106);
SS_SH_SPR_TILE_FRAME(4 downto 0) <= SS_CHAIN(4111 downto 4107);
SS_SH_SPR_TILE_FRAME(20 downto 5) <= SS_CHAIN(4127 downto 4112);
SS_SH_SPR_TILE_FRAME(36 downto 21) <= SS_CHAIN(4143 downto 4128);
SS_SH_SPR_TILE_FRAME(52 downto 37) <= SS_CHAIN(4159 downto 4144);
SS_SH_SPR_TILE_FRAME(68 downto 53) <= SS_CHAIN(4175 downto 4160);
SS_SH_SPR_TILE_FRAME(84 downto 69) <= SS_CHAIN(4191 downto 4176);
SS_SH_SPR_TILE_FRAME(100 downto 85) <= SS_CHAIN(4207 downto 4192);
SS_SH_SPR_TILE_FRAME(116 downto 101) <= SS_CHAIN(4223 downto 4208);
SS_SH_SPR_TILE_FRAME(132 downto 117) <= SS_CHAIN(4239 downto 4224);
SS_SH_SPR_TILE_FRAME(148 downto 133) <= SS_CHAIN(4255 downto 4240);
SS_SH_SPR_TILE_FRAME(164 downto 149) <= SS_CHAIN(4271 downto 4256);
SS_SH_SPR_TILE_FRAME(180 downto 165) <= SS_CHAIN(4287 downto 4272);
SS_SH_SPR_TILE_FRAME(196 downto 181) <= SS_CHAIN(4303 downto 4288);
SS_SH_SPR_TILE_FRAME(212 downto 197) <= SS_CHAIN(4319 downto 4304);
SS_SH_SPR_TILE_FRAME(228 downto 213) <= SS_CHAIN(4335 downto 4320);
SS_SH_SPR_TILE_FRAME(244 downto 229) <= SS_CHAIN(4351 downto 4336);
SS_SH_SPR_TILE_FRAME(260 downto 245) <= SS_CHAIN(4367 downto 4352);
SS_SH_SPR_TILE_FRAME(276 downto 261) <= SS_CHAIN(4383 downto 4368);
SS_SH_SPR_TILE_FRAME(292 downto 277) <= SS_CHAIN(4399 downto 4384);
SS_SH_SPR_TILE_FRAME(308 downto 293) <= SS_CHAIN(4415 downto 4400);
SS_SH_SPR_TILE_FRAME(324 downto 309) <= SS_CHAIN(4431 downto 4416);
SS_SH_SPR_TILE_FRAME(340 downto 325) <= SS_CHAIN(4447 downto 4432);
SS_SH_SPR_TILE_FRAME(356 downto 341) <= SS_CHAIN(4463 downto 4448);
SS_SH_SPR_TILE_FRAME(372 downto 357) <= SS_CHAIN(4479 downto 4464);
SS_SH_SPR_TILE_FRAME(388 downto 373) <= SS_CHAIN(4495 downto 4480);
SS_SH_SPR_TILE_FRAME(404 downto 389) <= SS_CHAIN(4511 downto 4496);
SS_SH_SPR_TILE_FRAME(420 downto 405) <= SS_CHAIN(4527 downto 4512);
SS_SH_SPR_TILE_FRAME(436 downto 421) <= SS_CHAIN(4543 downto 4528);
SS_SH_SPR_TILE_FRAME(452 downto 437) <= SS_CHAIN(4559 downto 4544);
SS_SH_SPR_TILE_FRAME(468 downto 453) <= SS_CHAIN(4575 downto 4560);
SS_SH_SPR_TILE_FRAME(484 downto 469) <= SS_CHAIN(4591 downto 4576);
SS_SH_SPR_TILE_FRAME(500 downto 485) <= SS_CHAIN(4607 downto 4592);
SS_SH_SPR_TILE_FRAME(516 downto 501) <= SS_CHAIN(4623 downto 4608);
SS_SH_SPR_TILE_FRAME(532 downto 517) <= SS_CHAIN(4639 downto 4624);
SS_SH_SPR_TILE_FRAME(548 downto 533) <= SS_CHAIN(4655 downto 4640);
SS_SH_SPR_TILE_FRAME(559 downto 549) <= SS_CHAIN(4666 downto 4656);
SS_SH_SPR_TILE_HF <= SS_CHAIN(4667);
SS_SH_SPR_TILE_LEFT <= SS_CHAIN(4668);
SS_SH_SPR_TILE_P0(2 downto 0) <= SS_CHAIN(4671 downto 4669);
SS_SH_SPR_TILE_P0(15 downto 3) <= SS_CHAIN(4684 downto 4672);
SS_SH_SPR_TILE_P1(2 downto 0) <= SS_CHAIN(4687 downto 4685);
SS_SH_SPR_TILE_P1(15 downto 3) <= SS_CHAIN(4700 downto 4688);
SS_SH_SPR_TILE_P2(2 downto 0) <= SS_CHAIN(4703 downto 4701);
SS_SH_SPR_TILE_P2(15 downto 3) <= SS_CHAIN(4716 downto 4704);
SS_SH_SPR_TILE_P3(2 downto 0) <= SS_CHAIN(4719 downto 4717);
SS_SH_SPR_TILE_P3(15 downto 3) <= SS_CHAIN(4732 downto 4720);
SS_SH_SPR_TILE_PAL(2 downto 0) <= SS_CHAIN(4735 downto 4733);
SS_SH_SPR_TILE_PAL(3 downto 3) <= SS_CHAIN(4736 downto 4736);
SS_SH_SPR_TILE_PIX_SET(14 downto 0) <= SS_CHAIN(4751 downto 4737);
SS_SH_SPR_TILE_PIX_SET(30 downto 15) <= SS_CHAIN(4767 downto 4752);
SS_SH_SPR_TILE_PIX_SET(46 downto 31) <= SS_CHAIN(4783 downto 4768);
SS_SH_SPR_TILE_PIX_SET(62 downto 47) <= SS_CHAIN(4799 downto 4784);
SS_SH_SPR_TILE_PIX_SET(78 downto 63) <= SS_CHAIN(4815 downto 4800);
SS_SH_SPR_TILE_PIX_SET(94 downto 79) <= SS_CHAIN(4831 downto 4816);
SS_SH_SPR_TILE_PIX_SET(110 downto 95) <= SS_CHAIN(4847 downto 4832);
SS_SH_SPR_TILE_PIX_SET(126 downto 111) <= SS_CHAIN(4863 downto 4848);
SS_SH_SPR_TILE_PIX_SET(142 downto 127) <= SS_CHAIN(4879 downto 4864);
SS_SH_SPR_TILE_PIX_SET(158 downto 143) <= SS_CHAIN(4895 downto 4880);
SS_SH_SPR_TILE_PIX_SET(174 downto 159) <= SS_CHAIN(4911 downto 4896);
SS_SH_SPR_TILE_PIX_SET(190 downto 175) <= SS_CHAIN(4927 downto 4912);
SS_SH_SPR_TILE_PIX_SET(206 downto 191) <= SS_CHAIN(4943 downto 4928);
SS_SH_SPR_TILE_PIX_SET(222 downto 207) <= SS_CHAIN(4959 downto 4944);
SS_SH_SPR_TILE_PIX_SET(238 downto 223) <= SS_CHAIN(4975 downto 4960);
SS_SH_SPR_TILE_PIX_SET(254 downto 239) <= SS_CHAIN(4991 downto 4976);
SS_SH_SPR_TILE_PIX_SET(270 downto 255) <= SS_CHAIN(5007 downto 4992);
SS_SH_SPR_TILE_PIX_SET(286 downto 271) <= SS_CHAIN(5023 downto 5008);
SS_SH_SPR_TILE_PIX_SET(302 downto 287) <= SS_CHAIN(5039 downto 5024);
SS_SH_SPR_TILE_PIX_SET(318 downto 303) <= SS_CHAIN(5055 downto 5040);
SS_SH_SPR_TILE_PIX_SET(334 downto 319) <= SS_CHAIN(5071 downto 5056);
SS_SH_SPR_TILE_PIX_SET(350 downto 335) <= SS_CHAIN(5087 downto 5072);
SS_SH_SPR_TILE_PIX_SET(366 downto 351) <= SS_CHAIN(5103 downto 5088);
SS_SH_SPR_TILE_PIX_SET(382 downto 367) <= SS_CHAIN(5119 downto 5104);
SS_SH_SPR_TILE_PIX_SET(398 downto 383) <= SS_CHAIN(5135 downto 5120);
SS_SH_SPR_TILE_PIX_SET(414 downto 399) <= SS_CHAIN(5151 downto 5136);
SS_SH_SPR_TILE_PIX_SET(430 downto 415) <= SS_CHAIN(5167 downto 5152);
SS_SH_SPR_TILE_PIX_SET(446 downto 431) <= SS_CHAIN(5183 downto 5168);
SS_SH_SPR_TILE_PIX_SET(462 downto 447) <= SS_CHAIN(5199 downto 5184);
SS_SH_SPR_TILE_PIX_SET(478 downto 463) <= SS_CHAIN(5215 downto 5200);
SS_SH_SPR_TILE_PIX_SET(494 downto 479) <= SS_CHAIN(5231 downto 5216);
SS_SH_SPR_TILE_PIX_SET(510 downto 495) <= SS_CHAIN(5247 downto 5232);
SS_SH_SPR_TILE_PIX_SET(526 downto 511) <= SS_CHAIN(5263 downto 5248);
SS_SH_SPR_TILE_PIX_SET(542 downto 527) <= SS_CHAIN(5279 downto 5264);
SS_SH_SPR_TILE_PIX_SET(558 downto 543) <= SS_CHAIN(5295 downto 5280);
SS_SH_SPR_TILE_PIX_SET(559 downto 559) <= SS_CHAIN(5296 downto 5296);
SS_SH_SPR_TILE_PRIO <= SS_CHAIN(5297);
SS_SH_SPR_TILE_RIGTH <= SS_CHAIN(5298);
SS_SH_SPR_TILE_SAVE <= SS_CHAIN(5299);
SS_SH_SPR_TILE_SPR0 <= SS_CHAIN(5300);
SS_SH_SPR_TILE_SPR0_SET(10 downto 0) <= SS_CHAIN(5311 downto 5301);
SS_SH_SPR_TILE_SPR0_SET(26 downto 11) <= SS_CHAIN(5327 downto 5312);
SS_SH_SPR_TILE_SPR0_SET(42 downto 27) <= SS_CHAIN(5343 downto 5328);
SS_SH_SPR_TILE_SPR0_SET(58 downto 43) <= SS_CHAIN(5359 downto 5344);
SS_SH_SPR_TILE_SPR0_SET(74 downto 59) <= SS_CHAIN(5375 downto 5360);
SS_SH_SPR_TILE_SPR0_SET(90 downto 75) <= SS_CHAIN(5391 downto 5376);
SS_SH_SPR_TILE_SPR0_SET(106 downto 91) <= SS_CHAIN(5407 downto 5392);
SS_SH_SPR_TILE_SPR0_SET(122 downto 107) <= SS_CHAIN(5423 downto 5408);
SS_SH_SPR_TILE_SPR0_SET(138 downto 123) <= SS_CHAIN(5439 downto 5424);
SS_SH_SPR_TILE_SPR0_SET(154 downto 139) <= SS_CHAIN(5455 downto 5440);
SS_SH_SPR_TILE_SPR0_SET(170 downto 155) <= SS_CHAIN(5471 downto 5456);
SS_SH_SPR_TILE_SPR0_SET(186 downto 171) <= SS_CHAIN(5487 downto 5472);
SS_SH_SPR_TILE_SPR0_SET(202 downto 187) <= SS_CHAIN(5503 downto 5488);
SS_SH_SPR_TILE_SPR0_SET(218 downto 203) <= SS_CHAIN(5519 downto 5504);
SS_SH_SPR_TILE_SPR0_SET(234 downto 219) <= SS_CHAIN(5535 downto 5520);
SS_SH_SPR_TILE_SPR0_SET(250 downto 235) <= SS_CHAIN(5551 downto 5536);
SS_SH_SPR_TILE_SPR0_SET(266 downto 251) <= SS_CHAIN(5567 downto 5552);
SS_SH_SPR_TILE_SPR0_SET(282 downto 267) <= SS_CHAIN(5583 downto 5568);
SS_SH_SPR_TILE_SPR0_SET(298 downto 283) <= SS_CHAIN(5599 downto 5584);
SS_SH_SPR_TILE_SPR0_SET(314 downto 299) <= SS_CHAIN(5615 downto 5600);
SS_SH_SPR_TILE_SPR0_SET(330 downto 315) <= SS_CHAIN(5631 downto 5616);
SS_SH_SPR_TILE_SPR0_SET(346 downto 331) <= SS_CHAIN(5647 downto 5632);
SS_SH_SPR_TILE_SPR0_SET(362 downto 347) <= SS_CHAIN(5663 downto 5648);
SS_SH_SPR_TILE_SPR0_SET(378 downto 363) <= SS_CHAIN(5679 downto 5664);
SS_SH_SPR_TILE_SPR0_SET(394 downto 379) <= SS_CHAIN(5695 downto 5680);
SS_SH_SPR_TILE_SPR0_SET(410 downto 395) <= SS_CHAIN(5711 downto 5696);
SS_SH_SPR_TILE_SPR0_SET(426 downto 411) <= SS_CHAIN(5727 downto 5712);
SS_SH_SPR_TILE_SPR0_SET(442 downto 427) <= SS_CHAIN(5743 downto 5728);
SS_SH_SPR_TILE_SPR0_SET(458 downto 443) <= SS_CHAIN(5759 downto 5744);
SS_SH_SPR_TILE_SPR0_SET(474 downto 459) <= SS_CHAIN(5775 downto 5760);
SS_SH_SPR_TILE_SPR0_SET(490 downto 475) <= SS_CHAIN(5791 downto 5776);
SS_SH_SPR_TILE_SPR0_SET(506 downto 491) <= SS_CHAIN(5807 downto 5792);
SS_SH_SPR_TILE_SPR0_SET(522 downto 507) <= SS_CHAIN(5823 downto 5808);
SS_SH_SPR_TILE_SPR0_SET(538 downto 523) <= SS_CHAIN(5839 downto 5824);
SS_SH_SPR_TILE_SPR0_SET(554 downto 539) <= SS_CHAIN(5855 downto 5840);
SS_SH_SPR_TILE_SPR0_SET(559 downto 555) <= SS_CHAIN(5860 downto 5856);
SS_SH_SPR_TILE_TOP <= SS_CHAIN(5861);
SS_SH_SPR_TILE_X(9 downto 0) <= unsigned(SS_CHAIN(5871 downto 5862));
SS_SH_SPR_X(9 downto 0) <= SS_CHAIN(5881 downto 5872);
SS_SH_SPR_Y(5 downto 0) <= SS_CHAIN(5887 downto 5882);
SS_SH_SPR_Y(9 downto 6) <= SS_CHAIN(5891 downto 5888);
SS_SH_SR_LATCH(6 downto 0) <= SS_CHAIN(5898 downto 5892);
SS_SH_TILE_CNT(4 downto 0) <= unsigned(SS_CHAIN(5903 downto 5899));
SS_SH_TILE_CNT(6 downto 5) <= unsigned(SS_CHAIN(5905 downto 5904));
SS_SH_TILE_ZERO <= SS_CHAIN(5906);
SS_SH_VDE(7 downto 0) <= SS_CHAIN(5914 downto 5907);
SS_SH_VDISP <= SS_CHAIN(5915);
SS_SH_VDISP_OLD <= SS_CHAIN(5916);
SS_SH_VDS(2 downto 0) <= SS_CHAIN(5919 downto 5917);
SS_SH_VDS(7 downto 3) <= SS_CHAIN(5924 downto 5920);
SS_SH_VDW(8 downto 0) <= SS_CHAIN(5933 downto 5925);
SS_SH_VM(1 downto 0) <= SS_CHAIN(5935 downto 5934);
SS_SH_VRR(15 downto 0) <= SS_CHAIN(5951 downto 5936);
SS_SH_VSW(4 downto 0) <= SS_CHAIN(5956 downto 5952);


SS_RDO <= SS_R_SAT or SS_R_SPR_LINE_BUF0 or SS_R_SPR_LINE_BUF1 or SS_LOCAL_RDO;
end rtl;
