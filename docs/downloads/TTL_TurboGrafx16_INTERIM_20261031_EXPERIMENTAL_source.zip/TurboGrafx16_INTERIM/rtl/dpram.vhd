LIBRARY ieee;
USE ieee.std_logic_1164.all;
use ieee.numeric_std.all;

LIBRARY altera_mf;
USE altera_mf.altera_mf_components.all;

entity dpram is
	generic (
		addr_width    : integer := 8;
		data_width    : integer := 8;
		mem_init_file : string := " ";
		disable_value : std_logic := '1';
        SS_REG_BASE : integer := -1
	);
	PORT
	(
		
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_WE : in std_logic := '0';
        SS_ADDR : in std_logic_vector(addr_width-1 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(data_width-1 downto 0) := (others => '0');
        SS_DO : out std_logic_vector(data_width-1 downto 0);
        clock : in STD_LOGIC;
		address_a	: in  STD_LOGIC_VECTOR (addr_width-1 DOWNTO 0);
		data_a		: in  STD_LOGIC_VECTOR (data_width-1 DOWNTO 0) := (others => '0');
		enable_a		: in  STD_LOGIC := '1';
		wren_a		: in  STD_LOGIC := '0';
		q_a			: out STD_LOGIC_VECTOR (data_width-1 DOWNTO 0);
		cs_a        : in  std_logic := '1';

		address_b	: in  STD_LOGIC_VECTOR (addr_width-1 DOWNTO 0) := (others => '0');
		data_b		: in  STD_LOGIC_VECTOR (data_width-1 DOWNTO 0) := (others => '0');
		enable_b		: in  STD_LOGIC := '1';
		wren_b		: in  STD_LOGIC := '0';
		q_b			: out STD_LOGIC_VECTOR (data_width-1 DOWNTO 0);
		cs_b        : in  std_logic := '1'
	);
end entity;


ARCHITECTURE SYN OF dpram IS

	signal q0 : std_logic_vector((data_width - 1) downto 0);
	signal q1 : std_logic_vector((data_width - 1) downto 0);

signal sh_q0, sh_q1 : std_logic_vector(data_width-1 downto 0);
    signal replay : std_logic := '0';
    signal ma : std_logic_vector(addr_width-1 downto 0);
    signal md : std_logic_vector(data_width-1 downto 0);
    signal mw, ea, eb : std_logic;
BEGIN

    process(all) variable word:natural; begin
      SS_RDO <= (others => '0');
      word := to_integer(unsigned(SS_RADDR));
      if SS_REG_BASE >= 0 then
        for bitno in 0 to data_width-1 loop
          if word = SS_REG_BASE + bitno/16 then SS_RDO(bitno mod 16) <= sh_q0(bitno); end if;
          if word = SS_REG_BASE + (data_width+15)/16 + bitno/16 then SS_RDO(bitno mod 16) <= sh_q1(bitno); end if;
        end loop;
      end if;
    end process;
    ma <= SS_ADDR when SS_FREEZE = '1' else address_a;
    md <= SS_DI when SS_FREEZE = '1' else data_a;
    mw <= SS_WE when SS_FREEZE = '1' else wren_a and cs_a;
    ea <= '1' when SS_FREEZE = '1' else enable_a;
    eb <= enable_b and not SS_FREEZE;
    SS_DO <= q0;
    process(clock) begin
      if rising_edge(clock) then
        replay <= SS_FREEZE;
        if SS_RWE = '1' and SS_REG_BASE >= 0 then
          for bitno in 0 to data_width-1 loop
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + bitno/16 then sh_q0(bitno) <= SS_RDI(bitno mod 16); end if;
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + (data_width+15)/16 + bitno/16 then sh_q1(bitno) <= SS_RDI(bitno mod 16); end if;
          end loop;
        end if;
        if SS_SAVE = '1' then
          if cs_a = '1' then sh_q0 <= q0; else sh_q0 <= (others => disable_value); end if;
          if cs_b = '1' then sh_q1 <= q1; else sh_q1 <= (others => disable_value); end if;
        end if;
      end if;
    end process;
    q_a<= sh_q0 when replay = '1' else q0 when cs_a = '1' else (others => disable_value);
	q_b<= sh_q1 when replay = '1' else q1 when cs_b = '1' else (others => disable_value);

	altsyncram_component : altsyncram
	GENERIC MAP (
		address_reg_b => "CLOCK1",
		clock_enable_input_a => "NORMAL",
		clock_enable_input_b => "NORMAL",
		clock_enable_output_a => "BYPASS",
		clock_enable_output_b => "BYPASS",
		indata_reg_b => "CLOCK1",
		intended_device_family => "Cyclone V",
		lpm_type => "altsyncram",
		numwords_a => 2**addr_width,
		numwords_b => 2**addr_width,
		operation_mode => "BIDIR_DUAL_PORT",
		outdata_aclr_a => "NONE",
		outdata_aclr_b => "NONE",
		outdata_reg_a => "UNREGISTERED",
		outdata_reg_b => "UNREGISTERED",
		power_up_uninitialized => "FALSE",
		read_during_write_mode_port_a => "NEW_DATA_NO_NBE_READ",
		read_during_write_mode_port_b => "NEW_DATA_NO_NBE_READ",
		init_file => mem_init_file, 
		widthad_a => addr_width,
		widthad_b => addr_width,
		width_a => data_width,
		width_b => data_width,
		width_byteena_a => 1,
		width_byteena_b => 1,
		wrcontrol_wraddress_reg_b => "CLOCK1"
	)
	PORT MAP (
		address_a => ma,
		address_b => address_b,
		clock0 => clock,
		clock1 => clock,
		clocken0 => ea,
		clocken1 => eb,
		data_a => md,
		data_b => data_b,
		wren_a => mw,
		wren_b => wren_b and cs_b and not SS_FREEZE,
		q_a => q0,
		q_b => q1
	);

END SYN;

LIBRARY ieee;
USE ieee.std_logic_1164.all;

LIBRARY altera_mf;
USE altera_mf.altera_mf_components.all;

entity dpram_difclk is
	generic (
		addr_width_a  : integer := 8;
		data_width_a  : integer := 8;
		addr_width_b  : integer := 8;
		data_width_b  : integer := 8;
		mem_init_file : string := " "
	);
	PORT
	(
		clock0		: in  STD_LOGIC;
		clock1		: in  STD_LOGIC;
		
		address_a	: in  STD_LOGIC_VECTOR (addr_width_a-1 DOWNTO 0);
		data_a		: in  STD_LOGIC_VECTOR (data_width_a-1 DOWNTO 0) := (others => '0');
		enable_a		: in  STD_LOGIC := '1';
		wren_a		: in  STD_LOGIC := '0';
		q_a			: out STD_LOGIC_VECTOR (data_width_a-1 DOWNTO 0);
		cs_a        : in  std_logic := '1';

		address_b	: in  STD_LOGIC_VECTOR (addr_width_b-1 DOWNTO 0) := (others => '0');
		data_b		: in  STD_LOGIC_VECTOR (data_width_b-1 DOWNTO 0) := (others => '0');
		enable_b		: in  STD_LOGIC := '1';
		wren_b		: in  STD_LOGIC := '0';
		q_b			: out STD_LOGIC_VECTOR (data_width_b-1 DOWNTO 0);
		cs_b        : in  std_logic := '1'
	);
end entity;


ARCHITECTURE SYN OF dpram_difclk IS

	signal q0 : std_logic_vector((data_width_a - 1) downto 0);
	signal q1 : std_logic_vector((data_width_b - 1) downto 0);

BEGIN
	q_a<= q0 when cs_a = '1' else (others => '1');
	q_b<= q1 when cs_b = '1' else (others => '1');

	altsyncram_component : altsyncram
	GENERIC MAP (
		address_reg_b => "CLOCK1",
		clock_enable_input_a => "NORMAL",
		clock_enable_input_b => "NORMAL",
		clock_enable_output_a => "BYPASS",
		clock_enable_output_b => "BYPASS",
		indata_reg_b => "CLOCK1",
		intended_device_family => "Cyclone V",
		lpm_type => "altsyncram",
		numwords_a => 2**addr_width_a,
		numwords_b => 2**addr_width_b,
		operation_mode => "BIDIR_DUAL_PORT",
		outdata_aclr_a => "NONE",
		outdata_aclr_b => "NONE",
		outdata_reg_a => "UNREGISTERED",
		outdata_reg_b => "UNREGISTERED",
		power_up_uninitialized => "FALSE",
		read_during_write_mode_port_a => "NEW_DATA_NO_NBE_READ",
		read_during_write_mode_port_b => "NEW_DATA_NO_NBE_READ",
		init_file => mem_init_file, 
		widthad_a => addr_width_a,
		widthad_b => addr_width_b,
		width_a => data_width_a,
		width_b => data_width_b,
		width_byteena_a => 1,
		width_byteena_b => 1,
		wrcontrol_wraddress_reg_b => "CLOCK1"
	)
	PORT MAP (
		address_a => address_a,
		address_b => address_b,
		clock0 => clock0,
		clock1 => clock1,
		clocken0 => enable_a,
		clocken1 => enable_b,
		data_a => data_a,
		data_b => data_b,
		wren_a => wren_a and cs_a,
		wren_b => wren_b and cs_b,
		q_a => q0,
		q_b => q1
	);

END SYN;

--------------------------------------------------------------
-- Single port Block RAM
--------------------------------------------------------------

LIBRARY ieee;
USE ieee.std_logic_1164.all;

LIBRARY altera_mf;
USE altera_mf.altera_mf_components.all;

ENTITY spram IS
	generic (
		addr_width    : integer := 8;
		data_width    : integer := 8;
		mem_init_file : string := " ";
		mem_name      : string := "MEM" -- for InSystem Memory content editor.
	);
	PORT
	(
		clock   : in  STD_LOGIC;
		address : in  STD_LOGIC_VECTOR (addr_width-1 DOWNTO 0);
		data    : in  STD_LOGIC_VECTOR (data_width-1 DOWNTO 0) := (others => '0');
		enable  : in  STD_LOGIC := '1';
		wren    : in  STD_LOGIC := '0';
		q       : out STD_LOGIC_VECTOR (data_width-1 DOWNTO 0);
		cs      : in  std_logic := '1'
	);
END ENTITY;

ARCHITECTURE SYN OF spram IS
	signal q0 : std_logic_vector((data_width - 1) downto 0);
BEGIN
	q<= q0 when cs = '1' else (others => '1');

	altsyncram_component : altsyncram
	GENERIC MAP (
		clock_enable_input_a => "BYPASS",
		clock_enable_output_a => "BYPASS",
		intended_device_family => "Cyclone V",
		lpm_hint => "ENABLE_RUNTIME_MOD=YES,INSTANCE_NAME="&mem_name,
		lpm_type => "altsyncram",
		numwords_a => 2**addr_width,
		operation_mode => "SINGLE_PORT",
		outdata_aclr_a => "NONE",
		outdata_reg_a => "UNREGISTERED",
		power_up_uninitialized => "FALSE",
		read_during_write_mode_port_a => "NEW_DATA_NO_NBE_READ",
		init_file => mem_init_file, 
		widthad_a => addr_width,
		width_a => data_width,
		width_byteena_a => 1
	)
	PORT MAP (
		address_a => address,
		clock0 => clock,
		data_a => data,
		wren_a => wren and cs,
		q_a => q0
	);

END SYN;
