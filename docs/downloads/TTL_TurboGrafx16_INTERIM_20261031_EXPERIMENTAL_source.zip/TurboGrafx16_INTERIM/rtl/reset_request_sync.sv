// Experimental reset-domain crossing.  RESET is an asynchronous system-level
// request, not a timing-clean clk_sys signal. Capture a short request, then
// release it through two clocked synchronizer stages. The output changes only
// on clk_sys edges; therefore all synchronous reset and commit consumers see
// the same request ordering. The async-set capture has a technology-dependent
// minimum pulse width and needs targeted implementation/CDC review.
module reset_request_sync(input wire clk_sys, input wire async_request, output wire sync_request);
 (* altera_attribute = "-name PRESERVE_REGISTER ON" *) reg request_latch = 1'b1;
 (* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED; -name PRESERVE_REGISTER ON" *) reg request_meta = 1'b1;
 (* altera_attribute = "-name PRESERVE_REGISTER ON" *) reg request_sync = 1'b1;
 always @(posedge clk_sys or posedge async_request)
   if (async_request) request_latch <= 1'b1;
   else request_latch <= 1'b0;
 always @(posedge clk_sys) begin
   request_meta <= request_latch;
   request_sync <= request_meta;
 end
 assign sync_request = request_sync;
endmodule
