library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.STD_LOGIC_TEXTIO.all;
library STD;
use STD.TEXTIO.ALL;

entity huc6260 is
	port (
        
        SS_ADDR : in std_logic_vector(17 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_WE : in std_logic := '0';
        SS_DO : out std_logic_vector(15 downto 0);
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LOAD : in std_logic := '0';

		CLK 		: in std_logic;
		RESET_N	: in std_logic;

		-- CPU Interface
		A			: in std_logic_vector(2 downto 0);
		CE_N		: in std_logic;
		WR_N		: in std_logic;
		RD_N		: in std_logic;
		DI			: in std_logic_vector(7 downto 0);
		DO 		: buffer std_logic_vector(7 downto 0);

		-- VDC Interface
		COLNO		: in std_logic_vector(8 downto 0);
		CLKEN		: buffer std_logic;
		CLKEN_F	: buffer std_logic;
		HSYNC_F	: buffer std_logic;
		HSYNC_R	: buffer std_logic;
		VSYNC_F	: buffer std_logic;
		VSYNC_R	: buffer std_logic;
		CLKEN_FS	: buffer std_logic;
		RVBL		: in std_logic;
		
		GRID_EN	: in std_logic_vector(1 downto 0);
		BORDER_EN: in std_logic;
		BORDER	: in std_logic;
		GRID		: in std_logic_vector(1 downto 0);

		-- NTSC/RGB Video Output
		R			: buffer std_logic_vector(2 downto 0);
		G			: buffer std_logic_vector(2 downto 0);
		B			: buffer std_logic_vector(2 downto 0);
		BW			: buffer std_logic;

		VS_N		: buffer std_logic;
		HS_N		: buffer std_logic;
		HBL		: buffer std_logic;
		VBL		: buffer std_logic
	);
end huc6260;

architecture rtl of huc6260 is

-- CPU Interface
signal PREV_A	: std_logic_vector(2 downto 0);

type ctrl_t is ( CTRL_IDLE, CTRL_WAIT, CTRL_INCR );
signal CTRL		: ctrl_t;
signal CR		: std_logic_vector(7 downto 0);

-- VCE Registers
signal DOTCLOCK	: std_logic_vector(1 downto 0);

-- CPU Color RAM Interface
signal RAM_A	: std_logic_vector(8 downto 0);
signal RAM_DI	: std_logic_vector(8 downto 0);
signal RAM_WE	: std_logic := '0';
signal RAM_DO	: std_logic_vector(8 downto 0);

-- CPU conflict color latching
signal R_FF	: std_logic_vector(2 downto 0);
signal G_FF	: std_logic_vector(2 downto 0);
signal B_FF	: std_logic_vector(2 downto 0);
signal CE_N_FF : std_logic := '1';

-- Color RAM Output
signal COLOR	: std_logic_vector(8 downto 0);

constant LEFT_BL_CLOCKS	: integer := 456;
constant DISP_CLOCKS	   : integer := 2160;
constant LINE_CLOCKS	   : integer := 2730;
constant HS_CLOCKS		: integer := 192;
constant HS_OFF			: integer := 46;

constant TOTAL_LINES		: integer := 263;  -- 525
constant VS_LINES			: integer := 3; 	 -- pcetech.txt
constant TOP_BL_LINES_E	: integer := 19;   -- pcetech.txt (must include VS_LINES in current implementation)
constant DISP_LINES_E	: integer := 242;	 -- same as in mednafen
signal TOP_BL_LINES		: integer;
signal DISP_LINES			: integer;
signal END_LINE			: integer := TOTAL_LINES;
signal HSYNC_START_POS	: integer;
signal HSYNC_END_POS 	: integer;

signal H_CNT	: std_logic_vector(11 downto 0);
signal V_CNT	: std_logic_vector(9 downto 0);

signal HBL_FF, HBL_FF2	: std_logic;
signal VBL_FF, VBL_FF2	: std_logic;

-- Clock generation
signal CLKEN_CNT	: std_logic_vector(2 downto 0);
signal CLKEN_FS_CNT: std_logic_vector(2 downto 0);
signal CLKEN_FF	: std_logic;
signal CLKEN_FF_F	: std_logic;
signal MULTIRES_FF : std_logic;
signal MULTIRES   : std_logic;

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_B : std_logic_vector(2 downto 0);
signal SS_SH_BW : std_logic;
signal SS_SH_B_FF : std_logic_vector(2 downto 0);
signal SS_SH_CE_N_FF : std_logic;
signal SS_SH_CLKEN_CNT : std_logic_vector(2 downto 0);
signal SS_SH_CLKEN_FF : std_logic;
signal SS_SH_CLKEN_FF_F : std_logic;
signal SS_SH_CLKEN_FS : std_logic;
signal SS_SH_CLKEN_FS_CNT : std_logic_vector(2 downto 0);
signal SS_SH_CR : std_logic_vector(7 downto 0);
signal SS_SH_CTRL : ctrl_t;
signal SS_SH_DO : std_logic_vector(7 downto 0);
signal SS_SH_DOTCLOCK : std_logic_vector(1 downto 0);
signal SS_SH_END_LINE : integer;
signal SS_SH_G : std_logic_vector(2 downto 0);
signal SS_SH_G_FF : std_logic_vector(2 downto 0);
signal SS_SH_HBL : std_logic;
signal SS_SH_HBL_FF : std_logic;
signal SS_SH_HBL_FF2 : std_logic;
signal SS_SH_HSYNC_F : std_logic;
signal SS_SH_HSYNC_R : std_logic;
signal SS_SH_HS_N : std_logic;
signal SS_SH_H_CNT : std_logic_vector(11 downto 0);
signal SS_SH_MULTIRES : std_logic;
signal SS_SH_MULTIRES_FF : std_logic;
signal SS_SH_PREV_A : std_logic_vector(2 downto 0);
signal SS_SH_R : std_logic_vector(2 downto 0);
signal SS_SH_RAM_A : std_logic_vector(8 downto 0);
signal SS_SH_RAM_DI : std_logic_vector(8 downto 0);
signal SS_SH_RAM_WE : std_logic;
signal SS_SH_R_FF : std_logic_vector(2 downto 0);
signal SS_SH_VBL : std_logic;
signal SS_SH_VBL_FF : std_logic;
signal SS_SH_VBL_FF2 : std_logic;
signal SS_SH_VSYNC_F : std_logic;
signal SS_SH_VSYNC_R : std_logic;
signal SS_SH_VS_N : std_logic;
signal SS_SH_V_CNT : std_logic_vector(9 downto 0);
signal SS_M_RAM : std_logic_vector(8 downto 0);
signal SS_M_RAM_SEL : std_logic;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_R_RAM : std_logic_vector(15 downto 0);
signal SS_CHAIN : std_logic_vector(159 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(159 downto 0);
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin



TOP_BL_LINES <= TOP_BL_LINES_E when RVBL = '1' else TOP_BL_LINES_E+4;
DISP_LINES   <= DISP_LINES_E   when RVBL = '1' else DISP_LINES_E-11;
	 
-- Color RAM
ram : entity work.dpram generic map (addr_width => 9, data_width => 9, mem_init_file =>"huc6260_palette_init.mif", SS_REG_BASE => 555)
port map(
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_R_RAM,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_WE => SS_M_RAM_SEL,
SS_ADDR => SS_ADDR(8 downto 0), SS_DI => SS_DI(8 downto 0), SS_DO => SS_M_RAM,

	clock			=> CLK,

	address_a	=> RAM_A,
	data_a		=> RAM_DI,
	wren_a		=> RAM_WE,
	q_a			=> RAM_DO,
	
	address_b	=> COLNO,
	q_b			=> COLOR
);

process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
CR <= SS_SH_CR;
CTRL <= SS_SH_CTRL;
DO <= SS_SH_DO;
PREV_A <= SS_SH_PREV_A;
RAM_A <= SS_SH_RAM_A;
RAM_DI <= SS_SH_RAM_DI;
RAM_WE <= SS_SH_RAM_WE;
elsif SS_FREEZE = '0' then

		if RESET_N = '0' then
			RAM_A <= (others => '0');
			RAM_DI <= (others => '0');
			RAM_WE <= '0';
			CR <= x"00";
			
			PREV_A <= (others => '0');
			CTRL <= CTRL_IDLE;
		else
			case CTRL is
			
			when CTRL_IDLE =>
				RAM_WE <= '0';
				if CE_N = '0' and WR_N = '0' then
					-- CPU Write
					PREV_A <= A;
					CTRL <= CTRL_WAIT;
					case A is
					when "000" =>
						CR <= DI;
					when "010" =>
						RAM_A(7 downto 0) <= DI;
					when "011" =>
						RAM_A(8) <= DI(0);
					when "100" =>
						RAM_WE <= '1';
						RAM_DI <= RAM_DO(8) & DI;
					when "101" =>
						RAM_WE <= '1';
						RAM_DI <= DI(0) & RAM_DO(7 downto 0);
						CTRL <= CTRL_INCR;
					when others => null;
					end case;
					
				elsif CE_N = '0' and RD_N = '0' then
					-- CPU Read
					PREV_A <= A;
					CTRL <= CTRL_WAIT;
					DO <= x"FF";
					case A is
					when "100" =>
						DO <= RAM_DO(7 downto 0);
					when "101" =>
						DO <= "1111111" & RAM_DO(8);
						CTRL <= CTRL_INCR;
					when others => null;
					end case;
				end if;
			
			when CTRL_INCR =>
				RAM_WE <= '0';
				RAM_A <= RAM_A + 1;
				CTRL <= CTRL_WAIT;
			
			when CTRL_WAIT =>
				RAM_WE <= '0';
				-- Wait for the CPU to "release" the VCE.
				-- I don't know what happens in the case of an address change
				-- however it can be achieved only with addresses read/write cycles,
				-- so it seems unlikely. The case has been handled, though.
				-- HuC6280 Rmw instructions are safe, as there is a "dummy cycle"
				-- between the read cycle and the write cycle.
				CTRL <= CTRL_IDLE;
				if CE_N = '0' and (WR_N = '0' or RD_N = '0') and PREV_A = A then
					CTRL <= CTRL_WAIT;
				end if;
			
			when others => null;
			end case;
		end if;
	
end if;
end if;
end process;

-- Video counting, register loading and clock generation
process(CLK, RESET_N)
begin
	if RESET_N = '0' then
		CLKEN_CNT <= (others=>'0');
		H_CNT <= (others=>'0');
		V_CNT <= (others=>'0');
		CLKEN_FF <= '0';
		MULTIRES_FF <= '0';
		BW <= '0';
	elsif rising_edge(CLK) then
if SS_LOAD = '1' then
BW <= SS_SH_BW;
CLKEN_CNT <= SS_SH_CLKEN_CNT;
CLKEN_FF <= SS_SH_CLKEN_FF;
CLKEN_FF_F <= SS_SH_CLKEN_FF_F;
DOTCLOCK <= SS_SH_DOTCLOCK;
END_LINE <= SS_SH_END_LINE;
H_CNT <= SS_SH_H_CNT;
MULTIRES <= SS_SH_MULTIRES;
MULTIRES_FF <= SS_SH_MULTIRES_FF;
V_CNT <= SS_SH_V_CNT;
elsif SS_FREEZE = '0' then

		H_CNT <= H_CNT + 1;

		CLKEN_FF <= '0';
		CLKEN_CNT <= CLKEN_CNT + 1;
		if DOTCLOCK = "00" and CLKEN_CNT = "111" and H_CNT < LINE_CLOCKS-2-1 then
			CLKEN_CNT <= (others => '0');
			CLKEN_FF <= '1';
		elsif DOTCLOCK = "01" and CLKEN_CNT = "101" then
			CLKEN_CNT <= (others => '0');
			CLKEN_FF <= '1';				
		elsif DOTCLOCK(1) = '1' and CLKEN_CNT = "011" and H_CNT < LINE_CLOCKS-2-1 then
			CLKEN_CNT <= (others => '0');
			CLKEN_FF <= '1';				
		end if;
		
		if DOTCLOCK = "00" and CLKEN_CNT = "011" then
			CLKEN_FF_F <= '1';
		elsif DOTCLOCK = "01" and CLKEN_CNT = "010" then
			CLKEN_FF_F <= '1';				
		elsif DOTCLOCK(1) = '1' and CLKEN_CNT = "001" then
			CLKEN_FF_F <= '1';				
		end if;

		if H_CNT = LINE_CLOCKS-1 then
			CLKEN_CNT <= (others => '0');
			CLKEN_FF <= '1';				
			H_CNT <= (others => '0');
			V_CNT <= V_CNT + 1;
			if V_CNT >= END_LINE-1 then
				V_CNT <= (others => '0');
				if CR(2) = '1' then			-- artifact bit affects number of lines per field; check at start of field
				  END_LINE <= TOTAL_LINES;
				else
				  END_LINE <= TOTAL_LINES - 1;
				end if;
			end if;
			-- Reload registers
			BW <= CR(7);
			DOTCLOCK <= CR(1 downto 0);

			if V_CNT >= TOP_BL_LINES and V_CNT < TOP_BL_LINES + DISP_LINES and DOTCLOCK /= CR(1 downto 0) then 
				MULTIRES_FF <= '1';
			end if;
				
			if V_CNT = TOP_BL_LINES + DISP_LINES then
				MULTIRES <= MULTIRES_FF;
				MULTIRES_FF <= '0';
			end if;
		end if;
	
end if;
end if;
end process;

HSYNC_START_POS <= 8-1 when DOTCLOCK = "00" else 
                   LINE_CLOCKS-6-1 when DOTCLOCK = "01" else 
                   LINE_CLOCKS-26-1;
HSYNC_END_POS   <= 8+464-1 when DOTCLOCK = "00" else 
                   468-6-1 when DOTCLOCK = "01" else 
                   468-26-1;
process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
HSYNC_F <= SS_SH_HSYNC_F;
HSYNC_R <= SS_SH_HSYNC_R;
VSYNC_F <= SS_SH_VSYNC_F;
VSYNC_R <= SS_SH_VSYNC_R;
elsif SS_FREEZE = '0' then

		HSYNC_F <= '0';
		HSYNC_R <= '0';
		VSYNC_F <= '0';
		VSYNC_R <= '0';
		if H_CNT = HSYNC_START_POS then HSYNC_F <= '1'; end if;
		if H_CNT = HSYNC_START_POS + 1 and DOTCLOCK = "01" then HSYNC_F <= '1'; end if;
		if H_CNT = HSYNC_END_POS   then HSYNC_R <= '1'; end if;
		if V_CNT = END_LINE-1    and H_CNT = LINE_CLOCKS-1 then VSYNC_F <= '1'; end if;
		if V_CNT = VS_LINES-1    and H_CNT = LINE_CLOCKS-1 then VSYNC_R <= '1'; end if;
	
end if;
end if;
end process;

process(CLK, RESET_N)
begin
	if RESET_N = '0' then
		CLKEN_FS_CNT <= (others=>'0');
		CLKEN_FS <= '0';
	elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CLKEN_FS <= SS_SH_CLKEN_FS;
CLKEN_FS_CNT <= SS_SH_CLKEN_FS_CNT;
elsif SS_FREEZE = '0' then

		CLKEN_FS <= '0';
		CLKEN_FS_CNT <= CLKEN_FS_CNT + 1;
		if (MULTIRES = '1' or DOTCLOCK(1) = '1') and CLKEN_FS_CNT = "011" and H_CNT < LINE_CLOCKS-2-1 then
			CLKEN_FS_CNT <= (others => '0');
			CLKEN_FS <= '1';				
		elsif DOTCLOCK = "00" and CLKEN_FS_CNT = "111" and H_CNT < LINE_CLOCKS-2-1 then
			CLKEN_FS_CNT <= (others => '0');
			CLKEN_FS <= '1';
		elsif DOTCLOCK = "01" and CLKEN_FS_CNT = "101" then
			CLKEN_FS_CNT <= (others => '0');
			CLKEN_FS <= '1';				
		end if;

		if H_CNT = LINE_CLOCKS-1 then
			 CLKEN_FS_CNT <= (others => '0');
			 CLKEN_FS <= '1';
		end if;
	
end if;
end if;
end process;

-- Sync
process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
HS_N <= SS_SH_HS_N;
VS_N <= SS_SH_VS_N;
elsif SS_FREEZE = '0' then

		if H_CNT = HS_OFF             then HS_N <= '0'; end if;
		if H_CNT = HS_OFF + HS_CLOCKS then HS_N <= '1'; end if;
		if V_CNT = 0                  then VS_N <= '0'; end if;
		if V_CNT = VS_LINES           then VS_N <= '1'; end if;
	
end if;
end if;
end process;

-- Blank
process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
HBL_FF <= SS_SH_HBL_FF;
VBL_FF <= SS_SH_VBL_FF;
elsif SS_FREEZE = '0' then

		if H_CNT = LEFT_BL_CLOCKS               then HBL_FF <= '0'; end if;
		if H_CNT = LEFT_BL_CLOCKS + DISP_CLOCKS then HBL_FF <= '1'; end if;
		if V_CNT = TOP_BL_LINES                 then VBL_FF <= '0'; end if;
		if V_CNT = TOP_BL_LINES + DISP_LINES    then VBL_FF <= '1'; end if;
	
end if;
end if;
end process;

-- Final output
process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
B <= SS_SH_B;
B_FF <= SS_SH_B_FF;
CE_N_FF <= SS_SH_CE_N_FF;
G <= SS_SH_G;
G_FF <= SS_SH_G_FF;
HBL <= SS_SH_HBL;
HBL_FF2 <= SS_SH_HBL_FF2;
R <= SS_SH_R;
R_FF <= SS_SH_R_FF;
VBL <= SS_SH_VBL;
VBL_FF2 <= SS_SH_VBL_FF2;
elsif SS_FREEZE = '0' then

		if CLKEN_FF = '1' then

			-- compensate HUC6202 delay
			VBL_FF2 <= VBL_FF;
			HBL_FF2 <= HBL_FF;

			VBL <= VBL_FF2;
			HBL <= HBL_FF2;

			if BORDER = '1' and BORDER_EN = '0' then
				G <= (others => '0');
				R <= (others => '0');
				B <= (others => '0');
				G_FF <= (others => '0');
				R_FF <= (others => '0');
				B_FF <= (others => '0');
				CE_N_FF  <= '1';

			elsif (CE_N = '0') then
				G <= G_FF;
				R <= R_FF;
				B <= B_FF;
				CE_N_FF <= '0';
			elsif (CE_N_FF = '0') then
				G <= G_FF;
				R <= R_FF;
				B <= B_FF;
				CE_N_FF <= '1';

			elsif (GRID(0) = '1' and GRID_EN(0) = '1') or (GRID(1) = '1' and GRID_EN(1) = '1') then
				G <= (others => '1');
				R <= (others => '1');
				B <= (others => '1');
			else
				G <= COLOR(8 downto 6);
				R <= COLOR(5 downto 3);
				B <= COLOR(2 downto 0);
				G_FF <= COLOR(8 downto 6);
				R_FF <= COLOR(5 downto 3);
				B_FF <= COLOR(2 downto 0);
			end if;
		end if;
	
end if;
end if;
end process;

CLKEN <= CLKEN_FF;
CLKEN_F <= CLKEN_FF_F;

SS_M_RAM_SEL <= SS_WE when SS_ADDR(17 downto 15) = "101" else '0';

SS_DO <= std_logic_vector(resize(unsigned(SS_M_RAM),16)) when SS_ADDR(17 downto 15) = "101" else (others => '0');

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 2 and to_integer(unsigned(SS_RADDR)) <= 11 else (others => '0');
SS_CAPTURE_DATA(2 downto 0) <= std_logic_vector(B(2 downto 0));
SS_CAPTURE_DATA(3) <= BW;
SS_CAPTURE_DATA(6 downto 4) <= std_logic_vector(B_FF(2 downto 0));
SS_CAPTURE_DATA(7) <= CE_N_FF;
SS_CAPTURE_DATA(10 downto 8) <= std_logic_vector(CLKEN_CNT(2 downto 0));
SS_CAPTURE_DATA(11) <= CLKEN_FF;
SS_CAPTURE_DATA(12) <= CLKEN_FF_F;
SS_CAPTURE_DATA(13) <= CLKEN_FS;
SS_CAPTURE_DATA(15 downto 14) <= std_logic_vector(CLKEN_FS_CNT(1 downto 0));
SS_CAPTURE_DATA(16 downto 16) <= std_logic_vector(CLKEN_FS_CNT(2 downto 2));
SS_CAPTURE_DATA(24 downto 17) <= std_logic_vector(CR(7 downto 0));
SS_CAPTURE_DATA(26 downto 25) <= std_logic_vector(to_unsigned(ctrl_t'pos(CTRL),2));
SS_CAPTURE_DATA(31 downto 27) <= std_logic_vector(DO(4 downto 0));
SS_CAPTURE_DATA(34 downto 32) <= std_logic_vector(DO(7 downto 5));
SS_CAPTURE_DATA(36 downto 35) <= std_logic_vector(DOTCLOCK(1 downto 0));
SS_CAPTURE_DATA(63 downto 48) <= ss_integer_read(END_LINE,0);
SS_CAPTURE_DATA(79 downto 64) <= ss_integer_read(END_LINE,16);
SS_CAPTURE_DATA(82 downto 80) <= std_logic_vector(G(2 downto 0));
SS_CAPTURE_DATA(85 downto 83) <= std_logic_vector(G_FF(2 downto 0));
SS_CAPTURE_DATA(86) <= HBL;
SS_CAPTURE_DATA(87) <= HBL_FF;
SS_CAPTURE_DATA(88) <= HBL_FF2;
SS_CAPTURE_DATA(89) <= HSYNC_F;
SS_CAPTURE_DATA(90) <= HSYNC_R;
SS_CAPTURE_DATA(91) <= HS_N;
SS_CAPTURE_DATA(95 downto 92) <= std_logic_vector(H_CNT(3 downto 0));
SS_CAPTURE_DATA(103 downto 96) <= std_logic_vector(H_CNT(11 downto 4));
SS_CAPTURE_DATA(104) <= MULTIRES;
SS_CAPTURE_DATA(105) <= MULTIRES_FF;
SS_CAPTURE_DATA(108 downto 106) <= std_logic_vector(PREV_A(2 downto 0));
SS_CAPTURE_DATA(111 downto 109) <= std_logic_vector(R(2 downto 0));
SS_CAPTURE_DATA(120 downto 112) <= std_logic_vector(RAM_A(8 downto 0));
SS_CAPTURE_DATA(127 downto 121) <= std_logic_vector(RAM_DI(6 downto 0));
SS_CAPTURE_DATA(129 downto 128) <= std_logic_vector(RAM_DI(8 downto 7));
SS_CAPTURE_DATA(130) <= RAM_WE;
SS_CAPTURE_DATA(133 downto 131) <= std_logic_vector(R_FF(2 downto 0));
SS_CAPTURE_DATA(134) <= VBL;
SS_CAPTURE_DATA(135) <= VBL_FF;
SS_CAPTURE_DATA(136) <= VBL_FF2;
SS_CAPTURE_DATA(137) <= VSYNC_F;
SS_CAPTURE_DATA(138) <= VSYNC_R;
SS_CAPTURE_DATA(139) <= VS_N;
SS_CAPTURE_DATA(143 downto 140) <= std_logic_vector(V_CNT(3 downto 0));
SS_CAPTURE_DATA(149 downto 144) <= std_logic_vector(V_CNT(9 downto 4));
SS_CAPTURE_DATA(47 downto 37) <= (others => '0');
SS_CAPTURE_DATA(159 downto 150) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 2 and to_integer(unsigned(SS_RADDR)) <= 11) then
SS_CHAIN <= SS_RDI & SS_CHAIN(159 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 2 and to_integer(unsigned(SS_RADDR)) <= 11) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(159 downto 16);
end if;
end if;
end process;
SS_SH_B(2 downto 0) <= SS_CHAIN(2 downto 0);
SS_SH_BW <= SS_CHAIN(3);
SS_SH_B_FF(2 downto 0) <= SS_CHAIN(6 downto 4);
SS_SH_CE_N_FF <= SS_CHAIN(7);
SS_SH_CLKEN_CNT(2 downto 0) <= SS_CHAIN(10 downto 8);
SS_SH_CLKEN_FF <= SS_CHAIN(11);
SS_SH_CLKEN_FF_F <= SS_CHAIN(12);
SS_SH_CLKEN_FS <= SS_CHAIN(13);
SS_SH_CLKEN_FS_CNT(1 downto 0) <= SS_CHAIN(15 downto 14);
SS_SH_CLKEN_FS_CNT(2 downto 2) <= SS_CHAIN(16 downto 16);
SS_SH_CR(7 downto 0) <= SS_CHAIN(24 downto 17);
SS_SH_CTRL <= ctrl_t'val(to_integer(unsigned(SS_CHAIN(26 downto 25)))) when to_integer(unsigned(SS_CHAIN(26 downto 25))) <= 2 else ctrl_t'val(0);
SS_SH_DO(4 downto 0) <= SS_CHAIN(31 downto 27);
SS_SH_DO(7 downto 5) <= SS_CHAIN(34 downto 32);
SS_SH_DOTCLOCK(1 downto 0) <= SS_CHAIN(36 downto 35);
SS_SH_END_LINE <= to_integer(signed(SS_CHAIN(79 downto 64) & SS_CHAIN(63 downto 48)));
SS_SH_G(2 downto 0) <= SS_CHAIN(82 downto 80);
SS_SH_G_FF(2 downto 0) <= SS_CHAIN(85 downto 83);
SS_SH_HBL <= SS_CHAIN(86);
SS_SH_HBL_FF <= SS_CHAIN(87);
SS_SH_HBL_FF2 <= SS_CHAIN(88);
SS_SH_HSYNC_F <= SS_CHAIN(89);
SS_SH_HSYNC_R <= SS_CHAIN(90);
SS_SH_HS_N <= SS_CHAIN(91);
SS_SH_H_CNT(3 downto 0) <= SS_CHAIN(95 downto 92);
SS_SH_H_CNT(11 downto 4) <= SS_CHAIN(103 downto 96);
SS_SH_MULTIRES <= SS_CHAIN(104);
SS_SH_MULTIRES_FF <= SS_CHAIN(105);
SS_SH_PREV_A(2 downto 0) <= SS_CHAIN(108 downto 106);
SS_SH_R(2 downto 0) <= SS_CHAIN(111 downto 109);
SS_SH_RAM_A(8 downto 0) <= SS_CHAIN(120 downto 112);
SS_SH_RAM_DI(6 downto 0) <= SS_CHAIN(127 downto 121);
SS_SH_RAM_DI(8 downto 7) <= SS_CHAIN(129 downto 128);
SS_SH_RAM_WE <= SS_CHAIN(130);
SS_SH_R_FF(2 downto 0) <= SS_CHAIN(133 downto 131);
SS_SH_VBL <= SS_CHAIN(134);
SS_SH_VBL_FF <= SS_CHAIN(135);
SS_SH_VBL_FF2 <= SS_CHAIN(136);
SS_SH_VSYNC_F <= SS_CHAIN(137);
SS_SH_VSYNC_R <= SS_CHAIN(138);
SS_SH_VS_N <= SS_CHAIN(139);
SS_SH_V_CNT(3 downto 0) <= SS_CHAIN(143 downto 140);
SS_SH_V_CNT(9 downto 4) <= SS_CHAIN(149 downto 144);


SS_RDO <= SS_R_RAM or SS_LOCAL_RDO;
end rtl;
