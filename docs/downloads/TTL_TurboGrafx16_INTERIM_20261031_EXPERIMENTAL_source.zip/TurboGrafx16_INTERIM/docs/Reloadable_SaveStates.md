> **Interim experimental build:** The original completeness claims below are
> not established. No-disc CD-side state and final output pipeline state remain
> outside the snapshot. No physical MiSTer or firmware persistence test has
> been performed. Read `INTERIM_TEST_NOTICE.md` before use.

# Experimental HuCard reloadable snapshot prototype

**Not release-ready:** the staged backup-RAM path passed a focused simulation
with a behavioral RAM model. Full-design fitting, timing, firmware persistence
and hardware validation remain required. Historical logs do not validate this RTL.

This revision extends the Ninja Spirit experimental core. The snapshot image
contains mapped RAM and registers, but not all live peripheral state.
The original volatile implementation is documented separately in
`NinjaSpirit_SaveStates_initial.md`; its build results are historical.

## Controls and storage

- F5: save the selected slot. F8: load it.
- OSD / Save States (HuCard): Save State, Load State, Save State Slot 1–4.
- MiSTer's standard `SS3F000000:80000` interface supplies automatic disk
  persistence. Each slot reserves 512 KiB in DDR3; the actual .ss image is
  354,888 bytes. Wait for transfer and firmware disk activity before powering off.
- Restart the same core, load the same ROM and use the same configuration before
  loading a persisted state. The former volatile slot cannot be imported.

This remains a Ninja Spirit-focused HuCard experiment. SDRAM ROM storage is
required. CD, SuperGrafx, Populous RAM, SNAC, MB128, cheats and special controllers (mouse, pachinko and XE-1AP) remain outside its scope.
Leave MB128 disabled; its external save-device memory is not serialized.
A binary build and simulation are not a substitute for testing firmware disk
persistence, power-cycle recovery and video/audio on physical MiSTer hardware.

## Serialized state map (not complete)

`serialized_layout.json` is the authoritative, deterministic register inventory.
There are 579 register scan words, including CPU architecture and microcode,
MPRs, interrupts/timers/dividers, VDC registers/DMA/sprite cache and pipelines,
VCE timing/color, PSG channels/waveforms/noise/mixer, input protocol state, RAM
read latches, and the completed SDRAM ROM-byte latch. Reserved words belonging
to disabled hardware read zero. Combinational graphics temporaries are
recomputed from restored inputs rather than assigned as clocked registers.

The 43,777 RAM words cover work RAM, VRAM, SAT, two sprite line buffers,
palette RAM, 1,024 packed backup-RAM words, and its CPU read latch. No ROM or BIOS image is stored. Narrow register fields are bit-packed within scan words to share decoders and
balance the read/write wiring. `bit_offset` and `offset` identify each slice.
Local scan-chain registers hold the captured state. Typed shadow names decode
those bits for restoration; small process-variable captures provide staging.
Saving recirculates each local chain once while exporting its words; loading
shifts the complete external image back in before restoring the machine.
The disk layout is unchanged. The register scan interface must be traversed
sequentially with one advance pulse per exported word.

## File format (little endian)

Each entry is a 64-bit word. Header words:

| Word | Contents |
| --- | --- |
| 0 | High 32: number of following 32-bit words; low 32: MiSTer generation/change counter |
| 1 | `54474c5353000001`: magic and format version 1 |
| 2 | `60fef42d3266aca5`: register layout identifier |
| 3 | Bits 31:0 ROM download CRC accumulator; bits 47:32 configuration; remaining bits zero |
| 4 | High 32: payload word count; low 32: CRC-32 of consecutive little-endian 16-bit payload values |
| 5 onward | RAM words, followed by the register map; each value occupies the low 16 bits |

The RAM scan address is sparse, but file payload is contiguous. Four slots start
at `0x3f000000 + slot*0x80000` in byte-addressed DDR3.

Save publishes the generation counter only after the metadata and all payload
writes complete. It first reads the old counter so saving after a reset/load
still changes it. The standard firmware observes this commit and saves to disk.

Load first checks all headers, ROM/configuration identity and the entire payload
checksum without writing machine state. A second pass imports RAM and register
shadows, checks the checksum again, then pulses register restore and resumes.
Live read latches are captured on entry so even a rejected load resumes with
the correct pre-freeze memory outputs. Invalid images leave the live machine unchanged. A failure during partial apply
resets the game. DDR transfers use a clock-domain request/acknowledgement mailbox;
SDRAM refresh continues during the operation.

The configuration identity includes ROM data swap, color/overscan controls,
sprite limit, CPU turbo, Turbo Tap and controller button mode. This is deliberately conservative. The ROM identity
is computed during download and is an integrity identifier, not authentication.
Any incompatible layout/behavior revision must change the format/schema ID.

## Validation

The bundled `savestate/reloadable-*.log` and `savestate/reloadable-build.log`
are historical results for an earlier pre-backup-RAM revision, not results
for the present RTL. The controller test covers four slots, binary .ss export,
erasure of DDR and live state, reset, file reimport, exact RAM/register recovery,
generation changes, rejected identities/headers/checksum, DDR backpressure and
interrupted-apply recovery. Whole-HuCard replay tests use a synthetic program,
reset the actual console and overwrite private shadows before external import,
then compare CPU/video/audio/peripheral output traces at all three CPU speeds.
A longer +50% stress replay also uses repeated VRAM DMA and work-RAM mutation.
The SDRAM test exercises 900 reads and imports the ROM-byte latch after
intentionally overwriting its private shadow.

Inspect a file independently with:

```sh
python3 savestate/snapshot_file.py /path/to/game_1.ss
```

Generated VHDL and the register inventory are reproduced by
`python3 savestate/serialize.py`, using the included `volatile-baseline` inputs.
The controller, top-level integration and SDRAM import ports are checked-in RTL.
Use Quartus Prime Lite 23.1 with Cyclone V support; the unchanged timing
constraints must pass before a binary is released.

Build compatibility: legacy timing exceptions are deferred from synthesis to
fitter/TimeQuest to avoid a Quartus 23.1 internal `get_keepers` crash. Derived
clocks remain active during synthesis. A Tcl harness verifies that final fitter
and TimeQuest constraint calls exactly match the baseline; no final timing
constraints are relaxed. See `reloadable-sdc-validation.log`.

The fitter uses automatic routability optimization for the scan-chain design.
The earlier parallel interfaces failed routing even with aggressive settings. Clock rates and final timing requirements remain
unchanged. `TGFX_FIT_ONLY=1` resumes fitting from a completed synthesis.

The seed-2 aggressive-routability retry also failed routing (52% average,
83% peak interconnect usage). The next fit uses seed 3 and HIGH ALM register
packing effort. Timing constraints and RTL remain unchanged.

The first two random-access register interfaces passed simulation but failed
physical routing. The released implementation uses local recirculating scan
chains, removing the large read multiplexers and distributed data-write buses.

Capture uses statically wired input slices and a single whole-vector update
after two settling clocks, while the machine remains frozen. Compilation uses
one synthesis worker with automatic parallel synthesis disabled to reduce peak
memory use.


Backup RAM is part of a snapshot; restoring it marks backup RAM dirty. If autosave
is enabled this can overwrite later progress in the normal game save file. Back up
the game save before testing. A backup transfer/format must be idle to start.
The backup-RAM extension is a prototype; focused behavioral-RAM simulation passed, but FPGA fit and hardware validation remain required.
A load stages backup RAM in the inactive FPGA bank and switches banks only
after both validation passes. The bank pointer deliberately survives console
reset and cartridge download. Its hardware behavior still needs directed tests.
