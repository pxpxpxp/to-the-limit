# Ninja Spirit save-state experiment

To the Limit — TurboGrafx-16 / PC Engine, based on upstream
`827d45f45799b8ab3a536510847f2108a92e81bd` plus the existing CPU turbo and
Extra-sprites-default changes.

## Use

1. Copy the supplied `TurboGrafx16_NinjaSpirit_SaveStates_20261029.rbf` into
   MiSTer's `_Console` directory, alongside the normal core.
2. Launch it and load your own **Ninja Spirit HuCard ROM** normally.
3. Set CPU Turbo to Off, +20%, or +50% before saving. Extra sprites is the default.
4. During gameplay press **F5** to save; **F8** to restore. Alternatively open
   **Save States (HuCard)** in the OSD and select Save State or Load State.
5. The user LED lights during transfer. The slot is ready when the transfer ends.

There is **one volatile slot**. It is not an SD-card save file and cannot be
exported from this build. Reloading the core, resetting the game, loading another
ROM, changing CPU Turbo or the sprite-limit setting, enabling SNAC, or entering
an unsupported mode invalidates it. A new save replaces the previous slot.

Save/load requires SDRAM for the HuCard ROM and uses otherwise-idle DDR3 for the
snapshot. CD, SuperGrafx and Populous cartridge RAM are outside this experiment.
This build uses the existing LITE generate path, so SuperGrafx and cheats are
excluded. It is intended for Ninja Spirit testing; other HuCard games are not
claimed compatible.

## Implementation

- Wait for the HuC6280's terminal cycle, completed ROM access and inactive ROM
  clock enable. Freeze all instrumented HuCard clocked logic together.
- Capture CPU architectural/microcode state, mapping registers, IRQ/timer state,
  CPU-divider phase, VCE/VDC state, sprite pipeline state and PSG state into
  typed shadow registers. Persistent process variables are included.
- Scan 8,192 work-RAM bytes, 32,768 VRAM words, 256 SAT words, two 512-word
  sprite line buffers and 512 palette words: **42,752 transfer words**.
- Use RAM port A for the scan and inhibit ordinary writes on both ports while
  frozen. Capture both RAM output latches and replay them for the first resumed
  cycle so the CPU/video pipelines see the pre-save read data.
- Stream each scan word into a separate 64-bit DDR3 location starting at
  `0x3F000000`, using a request/acknowledge mailbox between 43/86 MHz domains.
  Commit slot validity only after the final transfer completes.
- Leave physical SDRAM refresh running and restore its last completed ROM byte.
- Restore RAM before the shadow registers; settle before resuming. A transfer
  timeout invalidates the slot and resets the game instead of resuming a partial
  restore.
- Mute audio during the operation. Use MiSTer's existing HDMI/video freeze
  engine and repeat measured pixel enables while emulated video is stopped.
  Scaled HDMI retains its frame; analog freeze output is black with generated
  sync. Physical-display behavior still needs hardware testing.

The inherited sprite-cache reset aggregate also had a two-bit initializer for
the four-bit palette field. It is corrected to four bits.

## Comparison with other MiSTer implementations

These are architectural references, not code ports or compatibility claims.

| Core | Observed approach | Application here |
| --- | --- | --- |
| SNES | Redirect NMI/IRQ vectors through a save/restore routine; register/peripheral mappings; separately pause the sound DSP at state zero; DDR transfer handshakes | A CPU pause alone is insufficient; include peripherals and only access memory at a controlled boundary |
| GBA | Dedicated state-register map; sleep signal; settle wait; internal/register/memory save phases; validity headers | Separate register state from bulk RAM and wait for memory transfers to finish |
| PSX | Pause and idle acknowledgements; subsystem state maps for CPU/GPU/DMA/timers/sound/etc.; DDR transfer phases and validity checks | Explicitly control transfer ownership, restore all relevant subsystems and reject invalid slots |

Sources inspected:

- https://github.com/MiSTer-devel/SNES_MiSTer/blob/master/rtl/savestates.sv
- https://github.com/MiSTer-devel/SNES_MiSTer/blob/master/rtl/SNES.vhd
- https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/gba_savestates.vhd
- https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/reg_savestates.vhd
- https://github.com/MiSTer-devel/PSX_MiSTer/blob/main/rtl/savestates.vhd

## Validation and limits

The source includes synthetic tests, not a commercial game ROM:

- Existing ten CPU regression scenarios pass: stock/reserved lockstep,
  turbo modes, live speed changes, waits, writes, I/O and timer cadence.
- Whole-HuCard replay passes twice at each of Off, +20% and +50%, comparing
  CPU-facing outputs, video, PSG and peripheral outputs after RAM/register
  restoration. Disabled CD/Arcade Card are stubbed in that test. Unknown logic
  levels are normalized to X before comparison; known-to-unknown changes fail.
- Snapshot controller: 42,752-word save and two exact restores with variable
  DDR latency/backpressure, empty-slot rejection, reset invalidation and
  interrupted-load recovery pass.
- Actual SDRAM controller: 900 reads at divisors 6/5/4 and restoring the saved
  ROM-byte latch while refresh continues pass.

- Extended replay at +50% after 900,000 clocks, with live video configuration,
  repeated 128-word VRAM DMA and work-RAM mutation, passes two restores.
- Actual pixel-repeat RTL with MiSTer's video_freezer preserves pixel, HSync and
  VSync cadence while raw game video is stopped, at periods 16/12/8 RAM clocks.
- Deselected RAM read latches preserve zero/one chip-select masks through the
  first resumed cycle, while the scan port remains independently accessible.
- All 14 generated RTL/project files reproduce byte for byte from preserved inputs.

Build and timing results are recorded with the final artifact. No physical MiSTer or Ninja Spirit gameplay test is claimed. In
particular, HDMI/direct-video/analog recovery and audible transitions require
hardware confirmation. This is an experimental first implementation.

## Reproduce

The checked-in/generated RTL is the build input. `savestate/instrument.py`,
`memory_ports.py` and `integrate.py` reproduce it from the preserved source
inputs. The signal inventory is in `savestate/register_manifest.json`.

Use Quartus Prime Lite 23.1 with Cyclone V device support. Run the normal
`quartus_map`, `quartus_fit`, multi-corner `quartus_sta`, and `quartus_asm`
stages. Do not weaken the inherited timing constraints. `savestate/build.py`
records the particular local compatibility setup and refuses assembly when
the reported minimum timing slack is negative.

## Final FPGA build

Quartus synthesis, Standard Fit, assembly and multi-corner timing analysis
completed for `5CSEBA6U23I7`. All **172 reported timing-summary
checks pass**; minimum slack is **0.081 ns**. The inherited constraints
and clock frequencies are unchanged. This only establishes the reported
constrained checks; it does not claim every external interface is constrained.

RBF: `TurboGrafx16_NinjaSpirit_SaveStates_20261029.rbf`, 4,043,120 bytes.

SHA-256: `cec4a1a1dae141eec9c7b3bab7af383b7b35e1ae820067d49572a97ba85ce930`.

Resource summary:

```text
Fitter Status : Successful - Thu Oct 29 17:10:21 2026
Quartus Prime Version : 23.1std.0 Build 991 11/28/2023 SC Lite Edition
Revision Name : TurboGrafx16
Top-level Entity Name : sys_top
Family : Cyclone V
Device : 5CSEBA6U23I7
Timing Models : Final
Logic utilization (in ALMs) : 22,667 / 41,910 ( 54 % )
Total registers : 35012
Total pins : 145 / 314 ( 46 % )
Total virtual pins : 0
Total block memory bits : 3,630,117 / 5,662,720 ( 64 % )
Total RAM Blocks : 465 / 553 ( 84 % )
Total DSP Blocks : 53 / 112 ( 47 % )
Total HSSI RX PCSs : 0
Total HSSI PMA RX Deserializers : 0
Total HSSI TX PCSs : 0
Total HSSI PMA TX Serializers : 0
Total PLLs : 3 / 6 ( 50 % )
Total DLLs : 0 / 4 ( 0 % )
```

Full reports, input hashes and test logs accompany the matching source archive.
Physical MiSTer/Ninja Spirit gameplay testing remains outstanding.
