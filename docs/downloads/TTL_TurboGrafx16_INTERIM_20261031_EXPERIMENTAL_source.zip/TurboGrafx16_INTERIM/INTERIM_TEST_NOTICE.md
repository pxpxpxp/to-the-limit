> **CDC work in progress — not yet built or approved.** This candidate
> synchronizes the external system reset request into the core clock and
> synchronizes snapshot freeze into audio and scaler clock domains. The system
> DDR reset can still arrive before the core sees reset, so **do not reset,
> power-cycle or switch cores while a save or load is in progress**. No visible
> snapshot LED indication is provided. Wait for gameplay to resume and, after
> saving, verify the expected state file and completed disk activity; this is
> not a guarantee against interruption. An in-flight video buffer handoff may
> occur during freeze synchronization. Full framebuffer/pixel integrity,
> actual hardware behavior and fitted synchronizer/MTBF/timing remain unproven.
> Do not publish or call this a complete final release.

# Experimental interim test build — not complete

The four-slot interface and SD-backed snapshot format are experimental. This
build is intended only for Ninja Spirit HuCard testing, not as a reliable
replacement for the existing core. A full production build, complete peripheral
state, firmware persistence validation and physical-hardware testing are still
outstanding. In particular, the real no-disc CD/IRQ and CD-visible RAM state are not yet serialized;
the final audio filter/output and display pipelines are not fully replayed.
A correct synthesis/fit/timing result does not establish game behavior.

Back up the existing `_Console` RBF and the entire `saves/` and `savestates/`
directories before testing. Current MiSTer Main uses `savestates/<core-name>/`
and `_1.ss` through `_4.ss` slot suffixes; firmware versions may differ. Use SDRAM, no CD, standard controller,
MB128/SNAC/special controllers disabled, and a uniquely named copy of the ROM with a disposable game save.
Current firmware uses the ROM basename for state filenames; identical names in
different folders can collide. Some experimental snapshot formats are incompatible with previous versions;
restoring a state can change and later persist battery RAM. Do not use these
states as the only copy of progress. Stop and revert on missing/corrupt saves,
failed reload, unexpected reset/hang, crashes, graphical/audio errors, or other
unexpected behavior. Do not publish this interim build.

A rejected or empty slot can be silent in this prototype; the OSD does not yet
expose the detailed snapshot error code. Treat a no-op as a test failure, not
as proof that a save or load completed.

Do not save the same slot again while its prior disk write is in progress;
firmware can write directly from the shared slot buffer. The MiSTer “Saving the
state” message is not proof of a successful file write.
Check the slot file exists and has the expected 354,888-byte length and changed
modification time after saving; use the included `savestate/snapshot_file.py`
to check its checksum when accessible. Preserve backups and test power-cycle
recovery separately.

Do not reset, power off, switch cores or change configuration while a save,
load, or subsequent SD write is in progress. A system/DDR reset can precede
the core reset and interrupt an operation unsafely. The revised reset and clock-domain handling passed focused simulation tests.
This revision was fitted and independently reviewed for a bounded HuCard test;
it has not been tested on physical hardware. An interrupted save can still
leave the in-memory slot invalid.
Verify the prior disk file is complete before any reset or power-cycle test.

Timing correction in this candidate: the legacy `use_sdr` false-path exception
was removed because a new restore-commit path through that signal failed a
stricter routed setup check in the prior revision. This revision passed fit, multi-corner timing and assembly; its minimum
reported standard slack was +0.077 ns. Independent routed snapshot and
reset/freeze clock-domain checks passed for this bounded test. The physical
asynchronous reset-capture pulse-width requirement, board SDRAM I/O and HPS
DDR clock association remain incompletely verified.

The save-state activity LED indicator was removed to avoid changing a shared
VGA-pin control path. Video freeze synchronization may allow up to two in-flight
writes and one pending frame handoff; complete display/audio replay is unverified.
