#define _GNU_SOURCE
#include <dlfcn.h>
/* Keep allocator interposition consistent when the legacy Quartus runtime
 * loads host libudev. RTLD_DEEPBIND otherwise mixes realloc/malloc providers.
 * This affects host library loading only; no FPGA source or licensing code
 * is changed. */
void *dlopen(const char *filename, int mode)
{
    void *(*next_dlopen)(const char *, int);
    next_dlopen = (void *(*)(const char *, int))dlsym(RTLD_NEXT, "dlopen");
    return next_dlopen(filename, mode & ~RTLD_DEEPBIND);
}

#include <unistd.h>
#include <stdio.h>
#include <string.h>
/* Resolve only this process's executable through proc/self when /proc
 * exposes host PIDs but getpid() returns a namespace PID. */
ssize_t readlink(const char *path, char *buffer, size_t capacity)
{
    char local_executable[80];
    ssize_t (*next_readlink)(const char *, char *, size_t);
    next_readlink = (ssize_t (*)(const char *, char *, size_t))dlsym(RTLD_NEXT, "readlink");
    snprintf(local_executable, sizeof(local_executable), "/proc/%ld/exe", (long)getpid());
    if (strcmp(path, local_executable) == 0)
        path = "/proc/self/exe";
    return next_readlink(path, buffer, capacity);
}

__attribute__((constructor)) static void quartus_live_messages(void)
{
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
