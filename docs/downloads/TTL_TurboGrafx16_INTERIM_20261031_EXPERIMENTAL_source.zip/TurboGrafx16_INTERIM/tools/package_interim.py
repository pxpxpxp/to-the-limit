#!/usr/bin/env python3
"""Package only a completed, timing-clean experimental interim build.

This does not claim complete snapshots, MiSTer firmware persistence, game
compatibility or physical hardware validation. See INTERIM_TEST_NOTICE.md.
"""
from pathlib import Path
import hashlib, json, re, shutil, zipfile
P=Path(__file__).resolve().parents[1]
D=P.parent/'tg16_deliverables'; D.mkdir(exist_ok=True)
inputs=json.loads((P/'savestate/build-inputs.json').read_text())
for n,h in inputs.items():
    assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h, f'Build input changed: {n}'
for tool in ('quartus_map','quartus_fit','quartus_sta','quartus_asm'):
    text=(P/(tool+'.log')).read_text(errors='replace')
    assert re.search(r'was successful',text,re.I), f'{tool} missing success summary'
summary=(P/'output_files/TurboGrafx16.sta.summary').read_text()
slack=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',summary,re.M)]
assert slack and min(slack)>=0, 'Timing summary missing or negative slack'
rbf=P/'output_files/TurboGrafx16.rbf'
assert rbf.is_file() and rbf.stat().st_size>4_000_000, 'Missing or unexpectedly small RBF'
assert rbf.stat().st_mtime >= (P/'savestate/build-inputs.json').stat().st_mtime, 'Stale RBF'
# A standard STA summary can omit snapshot paths under inherited exceptions.
# Require a separately reviewed, identity-bound audit before packaging even an
# experimental test image. This is not a claim of board-I/O/hardware signoff.
audit_path=P/'savestate/interim_validation/routed_snapshot_audit.json'
assert audit_path.is_file(), 'Missing independently reviewed snapshot timing audit'
audit=json.loads(audit_path.read_text())
assert audit.get('status')=='bounded_test_reviewed', 'Snapshot timing audit is not approved for a bounded test'
assert not audit.get('known_snapshot_violations'), 'Snapshot timing violation remains'
for key,path in [('rbf_sha256',rbf),('top_sha256',P/'TurboGrafx16.sv'),('sdc_sha256',P/'TurboGrafx16.sdc')]:
    assert audit.get(key)==hashlib.sha256(path.read_bytes()).hexdigest(), f'Audit identity mismatch: {key}'
name='TurboGrafx16_INTERIM_20261031'
dest=D/(name+'.rbf');shutil.copy2(rbf,dest)
sha=hashlib.sha256(dest.read_bytes()).hexdigest()
metadata={'experimental':True,'hardware_tested':False,'firmware_persistence_tested':False,
 'filename':dest.name,'bytes':dest.stat().st_size,'sha256':sha,'minimum_reported_slack_ns':min(slack),
 'timing_summary_checks':len(slack),'target':'5CSEBA6U23I7','schema':'60fef42d3266aca5',
 'scope':'Ninja Spirit HuCard experimental; no-disc CD-side and output pipeline state not complete'}
(D/(name+'_build.json')).write_text(json.dumps(metadata,indent=2)+'\n')
archive=D/(name+'_source.zip')
skip={'db','incremental_db','output_files','temp','__pycache__','sim','sim_reloadable','.git'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(P.rglob('*')):
  if not f.is_file() or set(f.relative_to(P).parts)&skip or f.suffix in ('.rbf','.sof','.pyc','.ss'): continue
  if len(f.relative_to(P).parts)==1 and f.suffix=='.log': continue
  z.write(f,'TurboGrafx16_INTERIM/'+str(f.relative_to(P)))
 for f in sorted((P/'output_files').glob('*')):
  if f.suffix in ('.rpt','.summary'): z.write(f,'TurboGrafx16_INTERIM/build_reports/'+f.name)
 for tool in ('quartus_map','quartus_fit','quartus_sta','quartus_asm'):
  z.write(P/(tool+'.log'),'TurboGrafx16_INTERIM/build_reports/'+tool+'.log')
 z.writestr('TurboGrafx16_INTERIM/build_reports/build_metadata.json',json.dumps(metadata,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in inputs.items():
  assert hashlib.sha256(z.read('TurboGrafx16_INTERIM/'+n)).hexdigest()==h, n
print(json.dumps({'rbf':str(dest),'source':str(archive),'rbf_sha256':sha,
                  'source_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'minimum_slack_ns':min(slack)},indent=2))
