library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use ieee.std_logic_textio.all;
use std.env.all;

entity tb_cpu_turbo is
    generic (MODE : natural := 0; STALLED : boolean := false);
end entity;

architecture test of tb_cpu_turbo is
    signal clk : std_logic := '0';
    signal rst_n : std_logic := '0';
    signal wait_n, busy_n : std_logic := '1';
    signal turbo : std_logic_vector(1 downto 0);
    signal a, a_ref : std_logic_vector(20 downto 0);
    signal di_ref, di, dout, dout_ref, joy, joy_ref : std_logic_vector(7 downto 0) := x"00";
    signal wr_n, rd_n, ce, cek, ce7, cer, pre_rd, pre_wr, hsm : std_logic;
    signal wr_ref, rd_ref, ce_ref, cek_ref, ce7_ref, cer_ref, pr_ref, pw_ref, hsm_ref : std_logic;
    signal io_ce, io_ref : std_logic;
    signal count, count_ref : unsigned(4 downto 0);
    signal timer, timer_ref : std_logic_vector(6 downto 0);
    signal al, ar, al_ref, ar_ref : std_logic_vector(23 downto 0);
    signal cycles : natural := 0;
    type memory_t is array(0 to 8191) of std_logic_vector(7 downto 0);
    -- Reset vector maps to $E000; all MPRs initially map ROM bank 0.
    -- Map MPR0=$FF (I/O), MPR1=$F8 (RAM); the code remains in MPR7.
    -- Exercise high/low CPU speed, RAM arithmetic, stack operations, VDC and
    -- palette access, PSG writes, controller writes, and timer setup.
    constant code : memory_t := (
        0 => x"78",                    -- SEI
        1 => x"D4",                    -- CSH
        2 => x"A9", 3 => x"FF",         -- LDA #$FF
        4 => x"53", 5 => x"01",         -- TAM #1
        6 => x"A9", 7 => x"F8",
        8 => x"53", 9 => x"02",         -- TAM #2
        10 => x"A2", 11 => x"FF", 12 => x"9A", -- LDX #$FF / TXS
        13 => x"A9", 14 => x"05",
        15 => x"8D", 16 => x"00", 17 => x"0C", -- timer latch=5
        18 => x"A9", 19 => x"01",
        20 => x"8D", 21 => x"01", 22 => x"0C", -- timer on
        23 => x"A2", 24 => x"00",       -- LDX #0
        25 => x"8A",                    -- loop: TXA
        26 => x"9D", 27 => x"00", 28 => x"22", -- STA $2200,X
        29 => x"BD", 30 => x"00", 31 => x"22", -- LDA $2200,X
        32 => x"49", 33 => x"5A",       -- EOR #$5A
        34 => x"48", 35 => x"68",       -- PHA / PLA
        36 => x"9D", 37 => x"00", 38 => x"23", -- STA $2300,X
        39 => x"E8",                    -- INX
        40 => x"D0", 41 => x"EF",       -- BNE loop
        42 => x"A9", 43 => x"03",
        44 => x"8D", 45 => x"00", 46 => x"00", -- VDC register select
        47 => x"8D", 48 => x"02", 49 => x"00", -- VDC data write
        50 => x"AD", 51 => x"00", 52 => x"00", -- VDC status read
        53 => x"A9", 54 => x"12",
        55 => x"8D", 56 => x"04", 57 => x"04", -- palette write
        58 => x"A9", 59 => x"00",
        60 => x"8D", 61 => x"00", 62 => x"08", -- PSG channel 0
        63 => x"A9", 64 => x"FF",
        65 => x"8D", 66 => x"01", 67 => x"08", -- PSG master volume
        68 => x"8D", 69 => x"05", 70 => x"08", -- channel pan
        71 => x"A9", 72 => x"DF",
        73 => x"8D", 74 => x"04", 75 => x"08", -- DDA channel on
        76 => x"A9", 77 => x"15",
        78 => x"8D", 79 => x"06", 80 => x"08", -- DDA value
        81 => x"A9", 82 => x"03",
        83 => x"8D", 84 => x"00", 85 => x"10", -- controller port
        86 => x"54",                    -- CSL
        87 => x"EA", 88 => x"EA", 89 => x"D4", -- NOP / NOP / CSH
        90 => x"A9", 91 => x"A5",
        92 => x"8D", 93 => x"FF", 94 => x"24", -- completion marker
        95 => x"80", 96 => x"FE",       -- BRA forever
        8190 => x"00", 8191 => x"E0", others => x"EA");
    signal ram, ram_ref : memory_t := (others => x"00");
begin
    clk <= not clk after 5 ns;
    turbo <= std_logic_vector(to_unsigned(MODE, 2)) when MODE < 4 else
             std_logic_vector(to_unsigned((cycles / 17) mod 4, 2));
    dut : entity work.HUC6280_TEST port map (
        CLK=>clk, RST_N=>rst_n, WAIT_N=>wait_n, CPU_TURBO=>turbo,
        A=>a, DI=>di, DO=>dout, WR_N=>wr_n, RD_N=>rd_n, RDY=>busy_n,
        NMI_N=>'1', IRQ1_N=>'1', IRQ2_N=>'1', CE=>ce,
        CEK_N=>cek, CE7_N=>ce7, CER_N=>cer, PRE_RD=>pre_rd, PRE_WR=>pre_wr,
        HSM=>hsm, O=>joy, K=>x"FF", VDCNUM=>'0', AUD_LDATA=>al, AUD_RDATA=>ar,
        DBG_IO_CE=>io_ce, DBG_COUNT=>count, DBG_TIMER=>timer);
    reference : entity work.HUC6280_UPSTREAM port map (
        CLK=>clk, RST_N=>rst_n, WAIT_N=>wait_n,
        A=>a_ref, DI=>di_ref, DO=>dout_ref, WR_N=>wr_ref, RD_N=>rd_ref, RDY=>busy_n,
        NMI_N=>'1', IRQ1_N=>'1', IRQ2_N=>'1', CE=>ce_ref,
        CEK_N=>cek_ref, CE7_N=>ce7_ref, CER_N=>cer_ref, PRE_RD=>pr_ref, PRE_WR=>pw_ref,
        HSM=>hsm_ref, O=>joy_ref, K=>x"FF", VDCNUM=>'0', AUD_LDATA=>al_ref, AUD_RDATA=>ar_ref,
        DBG_IO_CE=>io_ref, DBG_COUNT=>count_ref, DBG_TIMER=>timer_ref);

    process begin
        wait for 50 ns;
        wait until falling_edge(clk);
        rst_n <= '1';
        wait;
    end process;

    -- A synchronous memory model plus late/variable memory readiness and VDC busy.
    process(clk)
        variable delay : natural := 0;
    begin
        if rising_edge(clk) then
            if rst_n = '0' then
                cycles <= 0;
            else
                cycles <= cycles + 1;
            end if;
            if a(20 downto 13) = x"F8" then
                di <= ram(to_integer(unsigned(a(12 downto 0))));
            elsif a(20 downto 13) = x"FF" then
                di <= x"00";
            else
                di <= code(to_integer(unsigned(a(12 downto 0))));
            end if;
            if a_ref(20 downto 13) = x"F8" then
                di_ref <= ram_ref(to_integer(unsigned(a_ref(12 downto 0))));
            elsif a_ref(20 downto 13) = x"FF" then
                di_ref <= x"00";
            else
                di_ref <= code(to_integer(unsigned(a_ref(12 downto 0))));
            end if;
            if rst_n = '1' and ce_ref = '1' and wr_ref = '0' and cer_ref = '0' then
                ram_ref(to_integer(unsigned(a_ref(12 downto 0)))) <= dout_ref;
            end if;
            if rst_n = '1' and ce = '1' and wr_n = '0' and cer = '0' then
                ram(to_integer(unsigned(a(12 downto 0)))) <= dout;
            end if;
            if STALLED and rst_n = '1' then
                if ce = '1' then
                    delay := 2 + (cycles mod 13);
                elsif delay > 0 then
                    delay := delay - 1;
                end if;
                if delay > 0 then wait_n <= '0'; else wait_n <= '1'; end if;
                if cycles mod 71 < 19 then busy_n <= '0'; else busy_n <= '1'; end if;
            end if;
        end if;
    end process;

    process
        file trace : text open write_mode is "trace.txt";
        variable row : line;
        variable prev_count, prev_io, timer_edge, done_at : natural := 0;
        variable old_timer : std_logic_vector(6 downto 0) := (others => '0');
        variable divider : natural;
        variable saw_fast, saw_slow, saw_io, complete : boolean := false;
        variable previous_decrement : boolean := false;
    begin
        wait until falling_edge(clk);
        if rst_n = '1' then
            assert io_ce = io_ref report "PSG/timer clock differs from upstream" severity failure;
            if MODE = 0 or MODE = 3 then
                assert std_logic_vector'(a & dout & wr_n & rd_n & ce & cek & ce7 & cer & pre_rd & pre_wr & hsm & joy & al & ar & timer)
                     = std_logic_vector'(a_ref & dout_ref & wr_ref & rd_ref & ce_ref & cek_ref & ce7_ref & cer_ref & pr_ref & pw_ref & hsm_ref & joy_ref & al_ref & ar_ref & timer_ref)
                    report "Off/reserved mode differs from upstream" severity failure;
            end if;
            if count = 0 and cycles > 1 then
                divider := prev_count + 1;
                if hsm = '0' then
                    assert divider >= 24 report "low-speed mode accelerated" severity failure;
                    saw_slow := true;
                elsif a(20 downto 13) = x"FF" then
                    assert divider >= 6 report "I/O cycle accelerated" severity failure;
                    saw_io := true;
                elsif not STALLED and MODE < 4 then
                    if MODE = 1 then assert divider = 5 severity failure;
                    elsif MODE = 2 then assert divider = 4 severity failure;
                    else assert divider = 6 severity failure; end if;
                    saw_fast := true;
                end if;
            end if;
            prev_count := to_integer(count);
            if io_ce = '1' then
                if prev_io /= 0 then assert cycles - prev_io = 6 severity failure; end if;
                prev_io := cycles;
            end if;
            if timer /= old_timer then
                -- Reload and the first decrement have a different phase;
                -- consecutive non-wrapping decrements must be 6144 clocks apart.
                if unsigned(old_timer) > 0 and unsigned(timer) = unsigned(old_timer) - 1 then
                    if previous_decrement then
                        assert cycles - timer_edge = 6144 report "timer cadence changed" severity failure;
                    end if;
                    previous_decrement := true;
                else
                    previous_decrement := false;
                end if;
                timer_edge := cycles;
                old_timer := timer;
            end if;
            if ce = '1' and wr_n = '0' then
                hwrite(row, a); write(row, string'(" ")); hwrite(row, dout);
                writeline(trace, row);
                if a = std_logic_vector(to_unsigned(16#1F04FF#, 21)) then
                    assert dout = x"A5" severity failure;
                    for i in 0 to 255 loop
                        assert ram(16#200# + i) = std_logic_vector(to_unsigned(i, 8)) severity failure;
                        assert ram(16#300# + i) = (std_logic_vector(to_unsigned(i, 8)) xor x"5A") severity failure;
                    end loop;
                    assert joy = x"03" report "controller write lost" severity failure;
                    assert saw_slow and saw_io severity failure;
                    if not STALLED and MODE < 4 then assert saw_fast severity failure; end if;
                    complete := true;
                    done_at := cycles;
                    report "workload complete mode=" & integer'image(MODE) & " stalled=" & boolean'image(STALLED) & " master_clocks=" & integer'image(cycles);
                end if;
            end if;
            if complete and cycles > done_at + 13000 then
                report "PASS: post-workload timer and I/O clock cadence";
                finish;
            end if;
            assert cycles < 300000 report "CPU stalled or failed to complete" severity failure;
        end if;
    end process;
end architecture;
