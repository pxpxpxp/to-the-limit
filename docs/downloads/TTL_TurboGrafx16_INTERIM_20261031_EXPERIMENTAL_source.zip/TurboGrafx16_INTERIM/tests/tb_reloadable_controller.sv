`timescale 1ns/1ps
module tb_reloadable_controller;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;
 reg [31:0] rom_id=32'h1234abcd;
 reg [15:0] config_id=16'h02;
 wire reg_rotate;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we;
 wire [3:0] error;
 wire [17:0] scan_addr;reg [15:0] scan_dout;wire [15:0] scan_din;
 reg normal_idle=1,ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;
 wire [28:0] ram_addr;wire [63:0] ram_din;
 ninja_savestate dut(.*);
 localparam N=43777+579,IMAGE=N+5;
 reg [15:0] memory[0:262143];reg [63:0] ddr[0:262143];
 integer i,j,b,limit,ticks=0,delay_left=0,pending=0;
 integer writes=0,ram_writes=0,loads=0,fd,c,k,offset,r;
 reg expect_fault=0;
 reg [63:0] backup;
 function [15:0] pattern(input integer a,input integer variant);
   pattern=a^(a>>8)^16'h9d35^(variant*16'h571b);
 endfunction
 function integer banklimit(input integer bank);
 case(bank)0:banklimit=8192;1:banklimit=32768;2:banklimit=256;6:banklimit=579;7:banklimit=1025;default:banklimit=512;endcase
 endfunction
 always @(posedge clk) begin
   scan_dout<=scan_addr[17:15]==6 ? memory[6*32768] : memory[scan_addr];
   if(scan_we) begin
     if(!freeze) $fatal(1,"write outside freeze");
     if(scan_addr[17:15]==6) begin
       for(r=0;r<579-1;r=r+1) memory[6*32768+r]<=memory[6*32768+r+1];
       memory[6*32768+579-1]<=scan_din;
     end else memory[scan_addr]<=scan_din;
     ram_writes<=ram_writes+1;
   end
   if(reg_rotate) begin
     if(!freeze || scan_we || scan_addr[17:15]!=6) $fatal(1,"bad scan-chain rotation");
     for(r=0;r<579-1;r=r+1) memory[6*32768+r]<=memory[6*32768+r+1];
     memory[6*32768+579-1]<=memory[6*32768];
   end
   if(load_pulse) loads<=loads+1;
   if(fault_reset && !expect_fault) $fatal(1,"unexpected fault");
 end
 always @(negedge ram_clk) begin ticks=ticks+1;ram_busy=((ticks%13)<4);end
 always @(posedge ram_clk) begin
   ram_ready<=0;
   if(delay_left!=0) begin delay_left<=delay_left-1;
     if(delay_left==1) begin ram_dout<=ddr[pending];ram_ready<=1;end
   end
   if((ram_we||ram_rd)&&!ram_busy) begin
     if(!take_ddr||ram_addr<29'h7e00000||ram_addr>=29'h7e40000) $fatal(1,"DDR ownership/address");
     if(ram_we) begin ddr[ram_addr-29'h7e00000]<=ram_din;writes<=writes+1;end
     if(ram_rd) begin pending<=ram_addr-29'h7e00000;delay_left<=2+(ticks%9);end
   end
 end
 task save;
 begin @(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);wait(!freeze);@(negedge clk);
 if(error) $fatal(1,"save error %0d",error);end
 endtask
 task load;
 begin @(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);wait(!freeze);@(negedge clk);end
 endtask
 task fill(input integer variant);
 begin for(i=0;i<262144;i=i+1)memory[i]=pattern(i,variant);end
 endtask
 task check(input integer variant);
 begin for(b=0;b<8;b=b+1)for(j=0;j<banklimit(b);j=j+1)
 if(memory[b*32768+j]!==pattern(b*32768+j,variant))$fatal(1,"restore mismatch bank=%0d addr=%0d",b,j);end
 endtask
 task rejected(input integer code);
 integer before_writes;
 begin before_writes=ram_writes;load();
 if(error!=code||before_writes!=ram_writes)$fatal(1,"invalid image modified machine, expected=%0d got=%0d",code,error);
 end
 endtask
 initial begin
 for(i=0;i<262144;i=i+1)ddr[i]=0;
 fill(0);repeat(4)@(negedge clk);reset=0;
 rejected(1);check(0);
 // Four independent slots, all containing both RAM and register bank six.
 for(k=0;k<4;k=k+1)begin slot=k;fill(k);save();
 if(ddr[k*65536][63:32]!=(IMAGE-1)*2)$fatal(1,"bad MiSTer size header");end
 // Binary file export, destroy DDR + live state, reset, reimport the file.
 slot=3;fd=$fopen("reloadable_test.ss","wb");if(!fd)$fatal;
 for(i=0;i<IMAGE;i=i+1)for(j=0;j<8;j=j+1)$fwrite(fd,"%c",ddr[3*65536+i][j*8+:8]);
 $fclose(fd);
 for(i=0;i<IMAGE;i=i+1)ddr[3*65536+i]=0;
 fill(9);@(negedge clk);reset=1;repeat(3)@(negedge clk);reset=0;
 fd=$fopen("reloadable_test.ss","rb");if(!fd)$fatal;
 for(i=0;i<IMAGE;i=i+1)for(j=0;j<8;j=j+1)begin c=$fgetc(fd);if(c<0)$fatal;ddr[3*65536+i][j*8+:8]=c;end
 if($fgetc(fd)!=-1)$fatal(1,"file length");$fclose(fd);
 load();if(error)$fatal(1,"file reload error %0d",error);check(3);
 for(k=0;k<3;k=k+1)begin slot=k;fill(9);load();if(error)$fatal;check(k);end
 // Save after reload must publish a different generation even across reset.
 slot=3;backup=ddr[3*65536];save();if(ddr[3*65536][31:0]==backup[31:0])$fatal(1,"unchanged generation");
 // Reject wrong ROM, config, schema, version and payload CRC before any write.
 rom_id=rom_id^1;rejected(4);rom_id=rom_id^1;
 config_id=config_id^1;rejected(4);config_id=config_id^1;
 config_id=config_id^16'h0040;rejected(4);config_id=config_id^16'h0040;
 config_id=config_id^16'h0080;rejected(4);config_id=config_id^16'h0080;
 config_id=config_id^16'h0100;rejected(4);config_id=config_id^16'h0100;
 offset=3*65536;backup=ddr[offset+2];ddr[offset+2]=backup^1;rejected(3);ddr[offset+2]=backup;
 backup=ddr[offset+1];ddr[offset+1]=backup^1;rejected(2);ddr[offset+1]=backup;
 backup=ddr[offset+5+N-1];ddr[offset+5+N-1]=backup^1;rejected(6);ddr[offset+5+N-1]=backup;
 // An interrupted apply must reset; an interrupted validation must not apply.
 @(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(scan_we);
 @(negedge clk);expect_fault=1;reset=1;@(negedge clk);
 if(!fault_reset)$fatal(1,"partial restore did not reset");reset=0;
 repeat(12)@(negedge clk);expect_fault=0;load();if(error)$fatal;
 $display("PASS: full RAM/register image, 4 slots, binary file reload after reset, generation, CRC/ROM/config/schema/version rejection, DDR stalls, register-chain rotation/import, interrupted apply recovery");
 $finish;
 end
 initial begin #1000000000;$fatal(1,"timeout");end
endmodule
