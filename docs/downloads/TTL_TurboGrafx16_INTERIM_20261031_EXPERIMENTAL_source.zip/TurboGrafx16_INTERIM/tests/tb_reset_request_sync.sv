`timescale 1ns/1ps
module tb_reset_request_sync;
 reg clk_sys=0;always #10 clk_sys=~clk_sys;
 reg async_request=0, status_reset=0,buttons_reset=0,bk_loading=0,cart_download=0;
 wire RESET=async_request; wire [63:0] status={63'd0,status_reset};wire [1:0] buttons={buttons_reset,1'b0};
 wire sync_request=reset_sys_request;
 reg ss_load=0,ss_config_changed=0,ss_fault_reset=0,ss_available=1;
 reg ss_freeze=0,ss_cdram_hold=0;
 // INSERT_EXACT_PRODUCTION_RESET_CONTROL
 wire commit=ss_load_commit;
 integer cpu_commit=0,bram_commit=0,cdram_commit=0,sys_cycles=0;reg reset_seen=0;
 always @(posedge clk_sys)begin
  sys_cycles<=sys_cycles+1;
  if(commit)begin cpu_commit<=cpu_commit+1;bram_commit<=bram_commit+1;cdram_commit<=cdram_commit+1;end
  if(reset)reset_seen<=1;
 end
 always @(sync_request) if($time>0 && clk_sys!==1'b1) $fatal(1,"conditioned reset changed away from rising edge");
 task wait_low;integer n;begin n=0;while(sync_request!==0 && n<20)begin @(negedge clk_sys);n=n+1;end if(sync_request!==0)$fatal(1,"reset stuck high");end endtask
 task short_pulse(input integer offset);integer n;begin
  wait_low();reset_seen=0;@(negedge clk_sys); #(offset);async_request=1;#2;async_request=0;
  n=0;while(!reset_seen && n<12)begin @(negedge clk_sys);n=n+1;end
  if(!reset_seen)$fatal(1,"pulse lost offset=%0d",offset);wait_low();
 end endtask
 integer off,before_count;
 initial begin
  // Power-up request is asserted until two clocks sample its release.
  if(sync_request!==1)$fatal(1,"startup reset not asserted");wait_low();
  for(off=1;off<=18;off=off+1)short_pulse(off);
  @(negedge clk_sys);async_request=1;repeat(6)@(negedge clk_sys);if(!sync_request)$fatal(1,"held reset not observed");
  async_request=0;wait_low();
  // A raw short pulse during a pending commit has a defined ordering: any
  // already accepted edge applies to all consumers; synchronized request
  // then blocks every new edge. No raw signal drives the commit expression.
  @(negedge clk_sys);ss_load=1;before_count=cpu_commit;#3;async_request=1;#2;async_request=0;
  wait(sync_request);@(negedge clk_sys);ss_load=0;repeat(2)@(negedge clk_sys);
  if(cpu_commit!=bram_commit||cpu_commit!=cdram_commit||cpu_commit<=before_count)$fatal(1,"mixed or missing atomic commit");wait_low();
  // While machine is frozen for SDRAM drain, retain reset until after release.
  ss_freeze=1;short_pulse(3);repeat(2)@(negedge clk_sys);if(!ss_reset_pending)$fatal(1,"freeze reset was not retained");
  ss_freeze=0;repeat(12)@(negedge clk_sys);if(ss_reset_pending)$fatal(1,"pending reset did not release");
  $display("PASS: synchronous output, startup, 18 subcycle pulses, held request, ordered atomic commit and deferred frozen reset");$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule
