#!/usr/bin/env python3
"""Exhaustively check the production controller's sparse address function.
This parses and evaluates its integer expressions, not an RTL simulator.
"""
import hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'rtl/ninja_savestate.sv').read_text()
count=int(re.search(r'RAM_WORDS\s*=\s*(\d+)',s)[1])
assert count==43777
block=re.search(r'function automatic \[17:0\] scan_location.*?endfunction',s,re.S)[0]
rows=re.findall(r'(?:else\s+)?if\s*\(n\s*<\s*(\w+)\)\s*scan_location\s*=\s*([^;]+);',block)
assert len(rows)==7,rows

def eval_expr(expr,n):
    expr=re.sub(r"(\d+)'h([0-9a-fA-F]+)",lambda m:'0x'+m[2],expr)
    expr=re.sub(r"\d+'\(([^()]*)\)",r'(\1)',expr)
    expr=expr.replace('{3\'d0,n[14:0]}','n')
    assert re.fullmatch(r'[n0-9a-fxA-F()+ \-]+',expr),expr
    return eval(expr,{'__builtins__':{}},{'n':n})

def scan(n):
    for end,expr in rows:
        if n < (count if end=='RAM_WORDS' else int(end)):
            return eval_expr(expr,n)
    raise AssertionError(n)
addresses=list(map(scan,range(count)))
assert len(set(addresses))==count
segments=[(0,8192,0x00000),(8192,40960,0x08000),(40960,41216,0x10000),
          (41216,41728,0x18000),(41728,42240,0x20000),
          (42240,42752,0x28000),(42752,43777,0x38000)]
for start,end,base in segments:
    assert addresses[start:end]==list(range(base,base+end-start)),(start,end,base)
assert addresses[-1]==0x38400  # backup RAM CPU read latch
j=json.loads((p/'savestate/serialized_layout.json').read_text())
salt=b'|hucard-backup-ram-1024-words-latch-config16-v2'
schema=hashlib.sha256(json.dumps(j['fields'],sort_keys=True).encode()+salt).hexdigest()[:16]
assert j['schema']==schema
assert schema in (p/'rtl/snapshot_layout.vh').read_text()
assert schema in (p/'rtl/ninja_savestate.sv').read_text()
assert (count+j['register_words']+5)*8==354888
print('PASS: 43,777 parsed scan addresses unique and complete; schema and image size agree')
