#!/usr/bin/env python3
"""Exercise upstream SDRAM handshakes at all three CPU divisors."""
import argparse
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--iverilog', default='iverilog')
    parser.add_argument('--vvp', default='vvp')
    parser.add_argument('--ivl-dir')
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='tgfx16-sdram-') as directory:
        tmp = Path(directory)
        source = (ROOT / 'rtl/sdram.v').read_text()
        # Icarus requires a separate procedural driver for a bidirectional port;
        # Quartus accepts upstream's inout reg. No state/timing logic is changed.
        source = source.replace('inout  reg [15:0] SDRAM_DQ', 'inout wire [15:0] SDRAM_DQ')
        source = source.replace('assign SDRAM_nCS = 0;',
                                'reg [15:0] dq_driver;\nassign SDRAM_DQ = dq_driver;\nassign SDRAM_nCS = 0;')
        source = source.replace('SDRAM_DQ <=', 'dq_driver <=').replace(', SDRAM_DQ}', ', dq_driver}')
        (tmp / 'sdram.v').write_text(source)
        command = [args.iverilog]
        if args.ivl_dir:
            command += ['-B', args.ivl_dir]
        subprocess.run(command + ['-g2012', '-gstrict-expr-width', '-s', 'tb_sdram_turbo', '-o', str(tmp/'test.vvp'),
                       str(ROOT/'tests/tb_sdram_turbo.sv'), str(tmp/'sdram.v')], check=True)
        subprocess.run([args.vvp, str(tmp/'test.vvp')], check=True)

if __name__ == '__main__':
    main()
