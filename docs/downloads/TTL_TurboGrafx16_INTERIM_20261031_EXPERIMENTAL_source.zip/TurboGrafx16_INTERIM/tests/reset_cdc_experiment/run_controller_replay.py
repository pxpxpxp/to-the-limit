from pathlib import Path
import re,subprocess,tempfile
P=Path(__file__).resolve().parents[2];top=(P/'TurboGrafx16.sv').read_text()
cond=re.search(r'wire reset_sys_request;.*?wire reset = \(reset_sys_request \| status\[0\] \| buttons\[1\] \| bk_loading\);',top,re.S).group(0)
pending=re.search(r'reg ss_reset_pending=0,ss_cold_pending=0;.*?\nend\n',top,re.S).group(0)
commit=re.search(r'assign ss_load_commit\s*=\s*.*?;',top,re.S).group(0)
st='wire clk_sys=clk,ss_freeze=freeze,ss_load=load_pulse,ss_fault_reset=fault_reset;wire ss_config_changed=0,ss_available=enabled;wire ss_load_commit;\nwire RESET=raw_reset;wire [31:0] status=0;wire [1:0] buttons=0;wire bk_loading=0;\n'+cond+'\n'+pending+'\n'+commit
x=(P/'tests/tb_reset_replay.sv').read_text().replace('// INSERT_DEFERRED_RESET',st)
x=x.replace('reg reset=1,cart_download=0','reg raw_reset=1,cart_download=0')
x=re.sub(r'(?<![A-Za-z_])reset=([01]);',r'raw_reset=\1;',x)
old='''if(commit_observations!=c0)$fatal(1,"stale commit occurred on reset edge");raw_reset=0;repeat(12)@(negedge clk);'''
new='''// The external reset is asynchronous and intentionally takes two
   // clocks to reach the coherent core reset. A previously scheduled commit
   // can complete before reset recognition; it must not duplicate.
   if(commit_observations!=c0+1)$fatal(1,"unexpected commit count before conditioned reset");raw_reset=0;repeat(12)@(negedge clk);
   if(commit_observations!=c0+1 || pce_reset_n!==1)$fatal(1,"commit duplicated or conditioned reset stuck");'''
assert old in x;x=x.replace(old,new)
x=x.replace('PASS: reset on load-commit edge suppresses stale commit','PASS: pre-recognition commit completes once; conditioned reset eventually clears')
with tempfile.TemporaryDirectory(prefix='tg16-cdc-controller-') as d:
 t=Path(d)/'tb.sv';t.write_text(x);out=Path(d)/'out';subprocess.run(['iverilog','-g2012','-s','tb_interim_reset','-o',str(out),str(t),str(P/'rtl/ninja_savestate.sv'),str(P/'rtl/reset_request_sync.sv')],check=True);subprocess.run(['vvp',str(out)],cwd=d,check=True)
