from pathlib import Path
import re,subprocess,tempfile
P=Path(__file__).resolve().parents[2]; top=(P/'TurboGrafx16.sv').read_text()
cond=re.search(r'wire reset_sys_request;.*?wire reset = \(reset_sys_request \| status\[0\] \| buttons\[1\] \| bk_loading\);',top,re.S).group(0)
x=(P/'tests/tb_ddr_ownership.sv').read_text().replace('reg reset=1,enabled=1','reg raw_reset=1,enabled=1')
x=re.sub(r'(?<![A-Za-z_])reset=([01]);',r'raw_reset=\1;',x)
x=x.replace('ninja_savestate dut(.*);','wire clk_sys=clk, RESET=raw_reset;wire [31:0] status=0;wire [1:0] buttons=0;wire bk_loading=0;\n'+cond+'\nninja_savestate dut(.*);')
x=x.replace('repeat(4) @(negedge clk);raw_reset=0;start_save();','repeat(4) @(negedge clk);raw_reset=0;repeat(5) @(negedge clk);start_save();')
with tempfile.TemporaryDirectory(prefix='tg16-cdc-ddr-') as td:
 d=Path(td);t=d/'tb.sv';t.write_text(x);exe=d/'test.vvp'
 for phase in range(10):
  subprocess.run(['iverilog','-g2012','-s','tb_ddr_ownership',f'-Ptb_ddr_ownership.PHASE={phase}','-o',str(exe),str(t),str(P/'rtl/ninja_savestate.sv'),str(P/'rtl/reset_request_sync.sv')],check=True)
  print('phase',phase,flush=True);subprocess.run(['vvp',str(exe)],check=True)
