module reset_probe(input clk_sys, RESET, output reset_out);
reg ss_reset_capture = 1'b1;
(* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg ss_reset_meta = 1'b1;
(* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg ss_reset_sys = 1'b1;
always @(posedge clk_sys or posedge RESET) begin
 if (RESET) ss_reset_capture <= 1'b1;
 else ss_reset_capture <= 1'b0;
end
always @(posedge clk_sys) begin
 ss_reset_meta <= ss_reset_capture;
 ss_reset_sys <= ss_reset_meta;
end

assign reset_out = ss_reset_sys;
endmodule
