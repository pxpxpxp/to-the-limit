`timescale 1ns/1ps
module tb;
reg clk_sys=0,RESET=0; always #10 clk_sys=~clk_sys;
reg [31:0] status=0;reg [1:0] buttons=0;reg bk_loading=0;
// INSERT CONDITIONER
integer changes=0;
always @(ss_reset_sys) begin
 if($time!=0) begin
  if(($time % 20)!=10) $fatal(1,"core reset changed away from active clock edge at %0t",$time);
  changes=changes+1;
 end
end
integer k;
task pulse_short(input integer offset);
 integer prior;begin
  wait(!ss_reset_sys); @(posedge clk_sys); #1; #(offset);
  prior=changes; RESET=1; #1; RESET=0;
  repeat(5) @(negedge clk_sys);
  if(ss_reset_sys!==0 || changes!=prior+2) $fatal(1,"short pulse missed offset=%0d changes=%0d",offset,changes-prior);
 end
endtask
initial begin
 repeat(5) @(negedge clk_sys);
 if(ss_reset_sys!==0) $fatal(1,"startup reset did not release");
 for(k=0;k<8;k=k+1) pulse_short(k*2);
 // Held reset must remain asserted while the external signal is high.
 @(negedge clk_sys); RESET=1; repeat(5) @(negedge clk_sys);
 if(!ss_reset_sys)$fatal(1,"long assertion missed");
 RESET=0;repeat(5) @(negedge clk_sys); if(ss_reset_sys)$fatal(1,"long assertion stuck");
 // A short pulse while a previous pulse is propagating is safely coalesced:
 // the result must be asserted eventually and released, not silently lost.
 @(negedge clk_sys);RESET=1;#1 RESET=0;#3 RESET=1;#1 RESET=0;
 repeat(5) @(negedge clk_sys);if(ss_reset_sys)$fatal(1,"overlapping pulse stuck");
 $display("PASS: initialized reset releases, eight 1ns pulse phases are captured, both edges occur only on clk_sys, held reset releases, overlapping pulses coalesce");$finish;
end
initial begin #10000;$fatal(1,"timeout");end
endmodule
