from pathlib import Path
import re, subprocess,tempfile,os
P=Path(__file__).resolve().parents[2];s=(P/'TurboGrafx16.sv').read_text()
m=re.search(r'reg ss_reset_capture = 1\'b1;.*?wire reset = \(ss_reset_sys \| status\[0\] \| buttons\[1\] \| bk_loading\);',s,re.S);assert m
assert len(re.findall(r'\bRESET\b',m.group()))==2
assert s.count('or posedge RESET')==1 and s.count('if (RESET) ss_reset_capture')==1
x=(P/'tests/reset_cdc_experiment/tb_conditioner.sv').read_text().replace('// INSERT CONDITIONER',m.group())
with tempfile.TemporaryDirectory(prefix='tg16-cdc-') as d:
 t=Path(d)/'tb.sv';t.write_text(x);out=Path(d)/'out';subprocess.run(['iverilog','-g2012','-s','tb','-o',str(out),str(t)],check=True);subprocess.run(['vvp',str(out)],check=True)
