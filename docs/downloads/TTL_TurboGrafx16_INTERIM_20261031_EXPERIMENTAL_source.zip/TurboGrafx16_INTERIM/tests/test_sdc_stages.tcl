# Run with Tcl 8.6, e.g. Quartus's bundled tclsh. No timing database needed.
set root [file normalize [file join [file dirname [info script]] ..]]
proc derive_pll_clocks {} {global calls;lappend calls derive_pll_clocks}
proc derive_clock_uncertainty {} {global calls;lappend calls derive_clock_uncertainty}
proc get_clocks {args} {global calls;lappend calls [list get_clocks {*}$args];return CLKCOL}
proc set_multicycle_path {args} {global calls;lappend calls [list set_multicycle_path {*}$args]}
proc set_false_path {args} {global calls;lappend calls [list set_false_path {*}$args]}
foreach stage {quartus_map quartus_fit quartus_sta} {
    set ::quartus(nameofexecutable) $stage
    set before {}
    foreach name {savestate/volatile-baseline/TurboGrafx16.sdc TurboGrafx16.sdc} {
        set calls {}
        source [file join $root $name]
        if {$before eq {}} {set before $calls} else {set after $calls}
    }
    if {$stage ne "quartus_map"} {
        set expected {}
        foreach call $before {
            if {[lindex $call 0] eq "set_false_path" && [lsearch -exact $call "emu|use_sdr"] >= 0} {continue}
            lappend expected $call
        }
        if {$expected ne $after} {error "Unexpected final constraint changes for $stage"}
        puts "PASS: $stage retains baseline constraints except the deliberately removed use_sdr false path"
    } else {
        if {$after ne {derive_pll_clocks derive_clock_uncertainty}} {error "Synthesis clocks or exception staging changed"}
        puts "PASS: quartus_map derived clocks retained; exceptions deferred"
    }
}
