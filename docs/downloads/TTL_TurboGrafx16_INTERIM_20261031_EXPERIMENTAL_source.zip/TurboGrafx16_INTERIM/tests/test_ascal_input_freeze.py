#!/usr/bin/env python3
"""Focused actual ascal input-writer push logic; not a full framebuffer test."""
from pathlib import Path
import re,tempfile,subprocess,os
P=Path(__file__).resolve().parents[1];s=(P/'sys/ascal.vhd').read_text()
fn=re.search(r'FUNCTION to_std_logic \(a : boolean\).*?END FUNCTION to_std_logic;',s,re.S|re.I).group(0)
sync=re.search(r'PROCESS\(i_clk\) BEGIN\s*IF rising_edge\(i_clk\) THEN\s*i_freeze_meta <= freeze; i_freeze <= i_freeze_meta;\s*END IF;\s*END PROCESS;',s,re.S).group(0)
block=re.search(r"IF i_push='1' AND i_freeze='0' THEN.*?\n\s*END IF;\n\s*END IF;",s,re.S).group(0)
vhd='''library ieee; use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb is end;architecture sim of tb is
constant BLEN:integer:=4;constant N_BURST:integer:=4;
signal i_clk:std_logic:='0';signal freeze,i_freeze_meta,i_freeze:std_logic:='0';
signal i_push:std_logic:='1';signal i_wr,i_wreq,i_alt:std_logic:='0';
signal i_wad:integer range 0 to 7:=0;signal i_hbcpt:integer range 0 to 31:=0;signal i_hburst:integer:=30;
signal i_adrs,i_adrsi:unsigned(15 downto 0):=(others=>'0');\n'''+fn+'''\nbegin i_clk<=not i_clk after 7 ns;\n'''+sync+'''\nprocess(i_clk) begin if rising_edge(i_clk) then i_wr<='0';i_wreq<='0';\n'''+block+'''\nend if;end process;
process procedure tick is begin wait until falling_edge(i_clk);wait for 1 ns;end;variable before:natural;begin
for j in 1 to 6 loop tick;end loop;assert i_wr='1' severity failure;
freeze<='1';tick;assert i_wr='1' report "missing in-flight write 1" severity failure;tick;assert i_wr='1' report "missing in-flight write 2" severity failure;tick;assert i_wr='0' report "write after synchronized freeze" severity failure;before:=i_wad;
for j in 1 to 6 loop tick;assert i_wr='0' and i_wreq='0' and i_wad=before report "frozen writer changed" severity failure;end loop;
freeze<='0';tick;assert i_wr='0' severity failure;tick;assert i_wr='0' severity failure;tick;assert i_wr='1' report "resume write missing" severity failure;
report "PASS extracted ascal input writer: two in-flight cycles, frozen hold, release";stop;wait;end process;end;
'''
with tempfile.TemporaryDirectory(prefix='tg16-ascal-writer-') as d:
 d=Path(d);(d/'tb.vhd').write_text(vhd);g=os.environ.get('GHDL','ghdl')
 for args in [[g,'-a','--std=08',str(d/'tb.vhd')],[g,'-e','--std=08','tb'],[g,'-r','--std=08','tb','--assert-level=error']]:subprocess.run(args,cwd=d,check=True)
