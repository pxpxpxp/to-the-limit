#!/usr/bin/env python3
"""Directed DDR owner/late-response regression; requires Icarus Verilog."""
from pathlib import Path
import subprocess, tempfile
P=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='tgfx-ddr-owner-') as d:
    exe=Path(d)/'test.vvp'
    for phase in range(10):
        subprocess.run(['iverilog','-g2012','-s','tb_ddr_ownership',f'-Ptb_ddr_ownership.PHASE={phase}','-o',str(exe),str(P/'tests/tb_ddr_ownership.sv'),str(P/'rtl/ninja_savestate.sv')],check=True)
        print(f'phase={phase}',flush=True)
        subprocess.run(['vvp',str(exe)],check=True)
