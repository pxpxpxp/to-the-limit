#!/usr/bin/env python3
"""Run the production controller against a stalled DDR model and binary files."""
from pathlib import Path
import argparse,subprocess,tempfile,sys
P=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--iverilog',default='iverilog');a.add_argument('--vvp',default='vvp');a.add_argument('--ivl-dir');args=a.parse_args()
with tempfile.TemporaryDirectory(prefix='tgfx-reloadable-') as td:
    target=Path(td)/'test.vvp'
    cmd=[args.iverilog]+(['-B',args.ivl_dir] if args.ivl_dir else [])
    subprocess.run(cmd+['-g2012','-s','tb_reloadable_controller','-o',str(target),str(P/'tests/tb_reloadable_controller.sv'),str(P/'rtl/ninja_savestate.sv')],check=True)
    subprocess.run([args.vvp,str(target)],cwd=td,check=True)
    subprocess.run([sys.executable,str(P/'savestate/snapshot_file.py'),str(Path(td)/'reloadable_test.ss')],check=True)
