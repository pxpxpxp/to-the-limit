library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_ram_replay is end;
architecture test of tb_ram_replay is
signal clk:std_logic:='0';signal frozen,save,we,cs,normal_we:std_logic:='0';
signal a:std_logic_vector(1 downto 0):="00";
signal q_zero,q_one,scan:std_logic_vector(7 downto 0);
begin
clk<=not clk after 5 ns;
zero_mem:entity work.dpram generic map(addr_width=>2,data_width=>8,disable_value=>'0')
port map(clock=>clk,address_a=>"00",data_a=>x"A5",wren_a=>normal_we,cs_a=>cs,q_a=>q_zero,
 SS_FREEZE=>frozen,SS_SAVE=>save,SS_ADDR=>a,SS_DI=>x"5A",SS_WE=>we,SS_DO=>scan);
one_mem:entity work.dpram generic map(addr_width=>2,data_width=>8,disable_value=>'1')
port map(clock=>clk,address_a=>"00",data_a=>x"A5",wren_a=>normal_we,cs_a=>cs,q_a=>q_one,
 SS_FREEZE=>frozen,SS_SAVE=>save,SS_ADDR=>a,SS_DI=>x"5A",SS_WE=>we);
process begin
cs<='1';normal_we<='1';wait until falling_edge(clk);wait until falling_edge(clk);
normal_we<='0';wait until falling_edge(clk);
assert q_zero=x"A5" and q_one=x"A5" severity failure;
cs<='0';wait until falling_edge(clk);
assert q_zero=x"00" and q_one=x"FF" severity failure;
frozen<='1';save<='1';a<="01";
wait until falling_edge(clk);save<='0';we<='1';
wait until falling_edge(clk);we<='0';
wait until falling_edge(clk);
assert scan=x"5A" report "scan port incorrectly masked by normal chip select" severity failure;
frozen<='0';wait until falling_edge(clk);
assert q_zero=x"00" and q_one=x"FF" report "snapshot lost chip-select mask" severity failure;
wait until falling_edge(clk);cs<='1';wait until falling_edge(clk);
assert q_zero=x"A5" and q_one=x"A5" report "scan corrupted normal address" severity failure;
report "PASS: deselected RAM output-latch replay for zero/one disable values and independent scan access";
finish;
end process;
end;
