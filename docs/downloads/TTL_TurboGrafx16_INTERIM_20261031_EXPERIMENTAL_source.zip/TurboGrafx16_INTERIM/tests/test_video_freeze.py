from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
src=(P/'TurboGrafx16.sv').read_text()
block=src[src.index('reg ce_pix;'):src.index('`ifdef DEBUG_PALETTES',src.index('reg ce_pix;'))]
module='module pixel_repeat(input CLK_VIDEO,ce_vid,ss_freeze,output ce);\n'+block+'\nassign ce=ce_pix;endmodule\n'
tb='''`timescale 1ns/1ps
module tb_video;
reg clk=0,freeze=0,ce_vid=0,hs=0,vs=0,hbl=1,vbl=1;
always #5 clk=~clk;
wire ce,ho,vo,hbo,vbo;
pixel_repeat pix(clk,ce_vid,freeze,ce);
video_freezer freezer(.clk(clk),.freeze(freeze),.hs_in(hs),.vs_in(vs),.hbl_in(hbl),.vbl_in(vbl),.sync(),.hs_out(ho),.vs_out(vo),.hbl_out(hbo),.vbl_out(vbo));
integer ticks=0,period=16,i,k,pulses,last_pixel,last_h,last_v,hedges,vedges;
reg oldh,oldv;
always @(negedge clk) begin
 ticks=ticks+1;
 if(!freeze) begin
  ce_vid=(ticks%period)<2;
  hs=(ticks%128)<16;hbl=(ticks%128)<32;
  vs=(ticks%1024)<128;vbl=(ticks%1024)<256;
 end
end
initial begin
for(k=0;k<3;k=k+1) begin
 period=(k==0)?16:(k==1)?12:8;
 repeat(5000) @(posedge clk);
 @(posedge clk);#1;freeze=1;
 repeat(100) @(posedge clk);
 pulses=0;last_pixel=0;last_h=0;last_v=0;hedges=0;vedges=0;oldh=ho;oldv=vo;
 for(i=0;i<4096;i=i+1) begin
  @(posedge clk);#1;
  if(ce) begin
   pulses=pulses+1;
   if(last_pixel && ticks-last_pixel!=period) $fatal(1,"pixel period changed");
   last_pixel=ticks;
  end
  if(ho&&!oldh) begin
   if(last_h && ticks-last_h!=128) $fatal(1,"horizontal sync interrupted");
   last_h=ticks;hedges=hedges+1;
  end
  if(vo&&!oldv) begin
   if(last_v && ticks-last_v!=1024) $fatal(1,"vertical sync interrupted");
   last_v=ticks;vedges=vedges+1;
  end
  oldh=ho;oldv=vo;
 end
 if(pulses<250||hedges<30||vedges<3) $fatal(1,"freeze stopped output timing");
 freeze=0;
end
$display("PASS: actual pixel-repeat RTL and MiSTer video_freezer maintain pixel/H/V cadence at periods 16/12/8");$finish;
end
endmodule
'''
with tempfile.TemporaryDirectory() as d:
    d=Path(d);(d/'pixel.sv').write_text(module);(d/'tb.sv').write_text(tb)
    subprocess.run(['iverilog','-g2012','-s','tb_video','-o',str(d/'test.vvp'),str(d/'pixel.sv'),str(d/'tb.sv'),str(P/'sys/video_freezer.sv')],check=True)
    subprocess.run(['vvp',str(d/'test.vvp')],check=True)
