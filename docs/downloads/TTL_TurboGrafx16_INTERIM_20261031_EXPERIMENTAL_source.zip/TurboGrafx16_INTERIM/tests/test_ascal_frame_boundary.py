#!/usr/bin/env python3
"""Focused test of actual ascal freeze synchronizer and buffer-index logic.
This is not a complete scaler/framebuffer simulation or physical CDC proof.
"""
from pathlib import Path
import re, tempfile,subprocess,os
P=Path(__file__).resolve().parents[1];s=(P/'sys/ascal.vhd').read_text()
fn=re.search(r'FUNCTION buf_next\(a,b.*?END FUNCTION;',s,re.S).group(0)
sync=re.search(r'PROCESS\(o_clk\) BEGIN\s*IF rising_edge\(o_clk\) THEN\s*o_freeze_meta <= freeze; o_freeze <= o_freeze_meta;\s*END IF;\s*END PROCESS;',s,re.S).group(0)
block=re.search(r"o_iendframe0<=i_endframe0; -- <ASYNC>.*?IF o_vsv\(1\)='1' AND o_vsv\(0\)='0' AND o_bufup0='1' THEN\s*o_obuf0<=buf_next\(o_obuf0,o_ibuf0,o_freeze\);\s*o_bufup0<='0';\s*END IF;",s,re.S).group(0)
# The selected lines between the 0-field clauses include the 1-field input;
# trim them for this focused progressive-frame model while retaining exact 0-field code.
a=block.index('o_iendframe1<=');b=block.index('-- Output : Change framebuffer');block=block[:a]+block[b:]
vhd='''library ieee; use ieee.std_logic_1164.all; use std.env.all;
entity tb is end; architecture sim of tb is
signal o_clk:std_logic:='0';signal freeze:std_logic:='0';signal o_freeze_meta,o_freeze:std_logic:='0';
signal i_endframe0,o_iendframe0,o_iendframe02,o_bufup0,o_isync:std_logic:='0';
signal o_vsv:std_logic_vector(1 downto 0):="00"; signal o_ibuf0:natural range 0 to 2:=0; signal o_obuf0:natural range 0 to 2:=1;
'''+fn+'''\nbegin o_clk<=not o_clk after 11 ns;\n'''+sync+'''\nprocess(o_clk) begin if rising_edge(o_clk) then o_isync<='0';\n'''+block+'''\nend if;end process;
process procedure clocks(n:natural) is begin for i in 1 to n loop wait until falling_edge(o_clk);end loop;end;
procedure frame is begin i_endframe0<='1';clocks(3);i_endframe0<='0';clocks(3);end;
procedure vs is begin o_vsv<="10";clocks(1);o_vsv<="00";clocks(1);end;
variable before_i,before_o:natural;begin
clocks(3);frame;vs;assert o_ibuf0=2 and o_obuf0=0 report "baseline swap" severity failure;
-- Prepare a complete pending frame, then assert freeze just before VS.
-- The first destination-clock edge still sees the old synchronized freeze;
-- one final handoff is possible before the synchronized request takes effect.
frame; before_o:=o_obuf0; freeze<='1';o_vsv<="10";clocks(1);o_vsv<="00";
assert o_obuf0/=before_o report "expected in-flight handoff did not occur" severity failure;
clocks(4);assert o_freeze='1' severity failure;before_i:=o_ibuf0;before_o:=o_obuf0;frame;vs;assert o_ibuf0=before_i and o_obuf0=before_o report "frozen frame changed buffers" severity failure;
-- On release, allow synchronization to finish before checking normal swapping.
freeze<='0';clocks(4);assert o_freeze='0' severity failure;frame;vs;assert o_ibuf0/=before_i and o_obuf0/=before_o report "resume did not swap" severity failure;
report "PASS extracted ascal buffer handoff; one in-flight swap allowed during CDC latency";stop;wait;end process;end;
'''
with tempfile.TemporaryDirectory(prefix='tg16-ascal-frame-') as d:
 d=Path(d);(d/'tb.vhd').write_text(vhd);g=os.environ.get('GHDL','ghdl')
 for args in [[g,'-a','--std=08',str(d/'tb.vhd')],[g,'-e','--std=08','tb'],[g,'-r','--std=08','tb','--assert-level=error']]:subprocess.run(args,cwd=d,check=True)
