derive_pll_clocks
derive_clock_uncertainty

# Quartus 23.1 can crash in get_keepers on the synthesis-stage netlist.
# Keep derived clocks during synthesis; defer the original exceptions until
# fitter/TimeQuest, where the named keepers exist. Final constraints are intact.
set ttl_sdc_stage ""
foreach ttl_stage_variable {::TimingAnalyzerInfo(nameofexecutable) ::TimeQuestInfo(nameofexecutable) ::quartus(nameofexecutable)} {
    if {[info exists $ttl_stage_variable]} {set ttl_sdc_stage [set $ttl_stage_variable]}
}
if {$ttl_sdc_stage ne "quartus_map"} {
set_multicycle_path -from {emu|sdram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -setup 2
set_multicycle_path -from {emu|sdram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -hold 1
set_multicycle_path -from {emu|ddram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -setup 2
set_multicycle_path -from {emu|ddram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -hold 1

set_multicycle_path -from {emu|psg_filter|*} -setup 3
set_multicycle_path -from {emu|psg_filter|*} -hold 2
set_multicycle_path -from {emu|adpcm_filter|*} -setup 3
set_multicycle_path -from {emu|adpcm_filter|*} -hold 2

# The use_sdr source now drives snapshot restore/eligibility logic.
# Do not false-path it: both PLL clocks are related, so require timing closure.
}
