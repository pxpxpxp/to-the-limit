# Primed registered warm-hold experiment — not a release

This isolated source candidate addresses a strict timing concern in the guarded
HuCard work. The controller's normal WARM state holds the machine after a
restore, but a watchdog expiration or a reset/eligibility loss can abort WARM.
In the baseline controller a watchdog can expire on the same edge as the
accepted restore, removing its freeze immediately, while restored audio filter
state requires multiple cycles to settle under existing timing exceptions. An
unexpected no-disc CD/HPS guard event can change eligibility without a user
reset or menu action.

The candidate primes one preserved registered hold FF whenever controller
freeze, a CD-RAM drain or restore commit is active, and keeps it high for eight
full `clk_sys` edges after those requests drop. Because it is already high before
any modifying restore step, a watchdog on the commit edge cannot transfer the
machine from controller freeze to a newly rising hold on the same edge. A single
FF output avoids exporting a binary countdown reduction that can glitch at
transitions such as 8→7. The counter and hold are intentionally not cleared by
reset, guard transitions or fault handling. The hold is also primed for saves,
so those operations acquire a small extra tail. The controller's `start_block`
blocks new operations while the hold is active, but continuously samples raw
button edges: a held save/load trigger does not become a second trigger at
release. On-disk schema and serialized fields do not change.

The very first raw-freeze edge followed by immediate cancellation is before any
restore commit or modifying scan write in the tested controller; its physical
cross-domain output transition and any outstanding platform transaction still
require routed and hardware review. The hold does **not** make mid-operation
system/DDR reset, hard power loss, HPS guard events, actual SD persistence, CD
gameplay or downstream display/audio pipelines safe or complete.

## Validation and reproduction

`tests/test_warm_overlay_reproduction.py` rebuilds changed production top and
controller from retained fitted-base sources and exact overlay and verifies all
114 build inputs. Apply the overlay after the earlier source generator; it is
not embedded in that generator. `tests/run_warm_abort_safety.py` tests actual
controller RTL plus extracted exact top commit/fault, registered-hold and
bank-select expressions: 18,692 digital cases span reset/eligibility aborts at
nine post-commit offsets, 1/3/8/16-cycle holds, all 32 divider values/four CE
pairs, watchdog on the commit edge, pre-commit abort, raw buttons held through
completion, press/release within hold and fresh press afterward. Two negative
controls reproduce early WARM release and held-button retrigger under the prior
unsafe approaches. The original small four-slot/CRC/abort simulation was rerun
with the hold wired and a first-freeze guard/reset abort; it asserts no modifying
scan/CD/bank/commit operation occurs before hold priming. These are digital
models, not full PCE/HPS or hardware tests.

`tests/test_registered_hold_glitch_model.py` uses deliberately unequal abstract
Q delays to show how an unregistered binary reduction can glitch while the
single registered hold remains high. This is illustrative, not a device delay
or metastability measurement. The 12 full-capacity exact-controller phases and
synthetic file hashes revalidated against the new `start_block` controller;
those behavioral-model phases do not include the new top-level hold end-to-end.

See `savestate/warm_hold_validation/` for results and earlier test-harness
failures subsequently corrected and rerun. `savestate/build.py` keeps the
fitter override disabling physical register retiming. A new synthesis, fit,
multi-corner timing and expanded physical CDC/filter review of the new hold FF,
its priming sources and fanouts are mandatory. No RBF or hardware test is claimed.
