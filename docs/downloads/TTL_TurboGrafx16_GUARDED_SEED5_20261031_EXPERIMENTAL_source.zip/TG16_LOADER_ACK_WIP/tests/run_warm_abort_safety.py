#!/usr/bin/env python3
"""Test exact production controller and extracted top hold/commit/fault logic."""
from pathlib import Path
import re,subprocess,tempfile,os,sys
P=Path(__file__).resolve().parents[1];s=(P/'TurboGrafx16.sv').read_text()
def get(pattern):
 m=re.search(pattern,s,re.S);assert m,pattern;return m.group(0)
hold=get(r'reg \[3:0\] ss_restore_warm_count = 0;.*?assign ss_machine_freeze\s*=.*?;')
fault=get(r'reg ss_fault_pending=0,ss_cold_pending=0;.*?end\nend')
commit=get(r'assign ss_load_commit\s*=.*?;')
banks=get(r'reg ss_bram_bank = 0;\s*always @\(posedge clk_sys\) if \(ss_load_commit\) ss_bram_bank <= ~ss_bram_bank;')+'\n'+get(r'reg ss_cdram_bank=0;\s*always @\(posedge clk_sys\) if\(ss_load_commit\) ss_cdram_bank<=~ss_cdram_bank;')
assert '.safe(ss_safe && !ss_restore_warm_hold)' in s
assert '.start_block(ss_restore_warm_hold)' in s
assert '.save_button(status[42]|ss_key_save)' in s
assert '.load_button(status[43]|ss_key_load)' in s
ctrl=(P/'rtl/ninja_savestate.sv').read_text()
assert 'old_save<=save_button;old_load<=load_button;' in ctrl
assert 'IDLE: if(req==ack_sync && !cd_ram_hold && !start_block &&' in ctrl
negative='--negative' in sys.argv
negative_held='--negative-held' in sys.argv
assert not (negative and negative_held)
if negative:
 hold="reg [3:0] ss_restore_warm_count = 0; wire ss_restore_warm_hold=0; assign ss_machine_freeze=ss_freeze | ss_cdram_hold;"
tb=(P/'tests/tb_warm_abort_safety.sv').read_text().replace('// INSERT_PRODUCTION_HOLD_AND_FAULT',hold+'\n'+fault).replace('// INSERT_PRODUCTION_COMMIT',commit).replace('// INSERT_PRODUCTION_BANKS',banks)
if negative:
 tb=tb.replace('if(ss_load_commit && (!ss_restore_warm_hold || !ss_freeze))$fatal(1,"hold/raw freeze not primed before accepted commit");', '')
 tb=tb.replace('if(commits!=base+1 || ss_restore_warm_count!=8 || !ss_machine_freeze)', 'if(commits!=base+1)')
if negative_held:
 old='.start_block(ss_restore_warm_hold),.save_button(save_button),.load_button(load_button),';new=".start_block(1'b0),.save_button(save_button && !ss_restore_warm_hold),.load_button(load_button && !ss_restore_warm_hold),";assert tb.count(old)==1;tb=tb.replace(old,new)
with tempfile.TemporaryDirectory(prefix='tg16-warm-abort-') as td:
 v=Path(td)/'tb.sv';v.write_text(tb);out=Path(td)/'sim.vvp'
 path=os.environ.get('PATH','');env={**os.environ,'PATH':str(P.parent/'hdl_toolchain/bin')+':'+path}
 subprocess.run(['iverilog','-g2012','-s','tb_warm_abort_safety','-o',str(out),str(v),*[str(P/'rtl'/f) for f in ('ninja_savestate.sv','adpcm_pack_engine.sv','word_scan_pack_engine.sv','cd_ram_pack_engine.sv')]],env=env,check=True)
 r=subprocess.run(['vvp',str(out)],env=env,text=True,capture_output=True)
 if negative:
  assert r.returncode != 0 and 'resume too early' in r.stdout, r.stdout+r.stderr
  print('PASS: negative control reproduced baseline early resume after commit-edge watchdog')
 elif negative_held:
  assert r.returncode != 0 and 'held/in-hold trigger retriggered' in r.stdout, r.stdout+r.stderr
  print('PASS: negative control reproduced held-button retrigger with raw input masking')
 else:
  print(r.stdout,end='');assert r.returncode==0, r.stderr
