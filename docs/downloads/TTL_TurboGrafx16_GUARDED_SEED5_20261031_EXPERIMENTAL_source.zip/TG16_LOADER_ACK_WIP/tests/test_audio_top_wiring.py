#!/usr/bin/env python3
"""Static check of physical-hold and commit wiring for audio capture."""
from pathlib import Path
import re
s=(Path(__file__).resolve().parents[1]/'TurboGrafx16.sv').read_text()
block=s[s.index('reg [17:0] audio_l'):s.index('assign AUDIO_MIX = 0;')]
assert block.count('.ss_freeze(ss_machine_freeze)')==2
assert block.count('else if (!ss_machine_freeze)')==2
assert block.count('ss_load_commit')==4
assert 'if (ss_save) ss_audio_shadow <= ss_audio_live;' in block
assert 'assign ss_machine_freeze = ss_freeze | ss_cdram_hold' in s
assert re.search(r'ss_load_commit\s*=\s*ss_load.*?ss_available',s,re.S)
assert 'ss_audio_dout)' in s
assert 'wire [12:0] ss_config = {status[22],status[20],status[19:18]' in s
assert ".config_id({3'd0,ss_config})" in s
print('PASS: audio capture, physical freeze and gated commit top-level wiring (static)')
