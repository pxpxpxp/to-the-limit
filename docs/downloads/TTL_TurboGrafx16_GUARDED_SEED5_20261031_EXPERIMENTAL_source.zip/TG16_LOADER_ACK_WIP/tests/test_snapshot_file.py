#!/usr/bin/env python3
"""Fresh, toolchain-independent tests for the snapshot inspector.

These test the file parser, not the FPGA controller or firmware persistence.
"""
import importlib.util, json, struct, tempfile, zlib
from pathlib import Path
P = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('snapshot_file', P / 'savestate/snapshot_file.py')
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
layout = json.loads((P / 'savestate/serialized_layout.json').read_text())
rm,am,cm = 43777,8192,32768
core_words=rm+layout['register_words']; cg=(core_words+3)//4
n = cg+am+cm
values = [((i * 0x123456789abcdef + 17)&0xffffffffffffffff) for i in range(n)]
if core_words%4: values[cg-1] &= (1 << (16*(core_words%4)))-1
payload=struct.pack(f'<{n}Q', *values)
crc = zlib.crc32(payload)
header = ((n + 4)*2 << 32 | 7, 0x54474c5353000002,
          int(layout['schema'], 16), (0x1e2 << 32) | 0x1234abcd,
          (n << 32) | crc)
good = struct.pack('<5Q', *header) + struct.pack(f'<{n}Q', *values)
with tempfile.TemporaryDirectory() as td:
    f = Path(td)/'state.ss'; f.write_bytes(good)
    info = mod.inspect(f)
    assert info['generation'] == 7 and info['configuration'] == 0x1e2
    assert info['rom_id'] == '1234abcd' and info['crc32'] == f'{crc:08x}'
    def rejected(data):
        f.write_bytes(data)
        try: mod.inspect(f)
        except ValueError: return
        raise AssertionError('invalid image accepted')
    rejected(good[:-1]); rejected(good + b'\x00')
    for offset in (4, 8, 16, 39, 36, 40, 40+(cg+2)*8+7, 40+(cg+am+2)*8+7, len(good)-8):
        corrupt = bytearray(good); corrupt[offset] ^= 1; rejected(corrupt)
print('PASS: snapshot inspector valid image plus 11 corruption/length cases')
