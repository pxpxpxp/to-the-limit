#!/usr/bin/env python3
"""Exercise the exact TurboGrafx top-level audio block with savestate controls."""
from pathlib import Path
import argparse, subprocess, tempfile
P=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--iverilog',default='iverilog');a.add_argument('--vvp',default='vvp');args=a.parse_args()
s=(P/'TurboGrafx16.sv').read_text();a=s.index('localparam [3:0] comp_f1');b=s.index('assign AUDIO_MIX = 0;',a)+len('assign AUDIO_MIX = 0;')
wrapper='''module audio_snapshot_dut(input clk_sys,ss_freeze,ss_save,ss_load_commit,ss_we,ss_reg_rotate,
input [17:0] ss_addr,input [15:0] ss_din,input [63:0] status,
input [15:0] cdda_sl,cdda_sr,psg_sl,psg_sr,adpcm_s,
output [15:0] AUDIO_L,AUDIO_R,output AUDIO_S,AUDIO_MIX,output [15:0] scan_data);
wire CDDA_EN=1,PSG_EN=1,ADPCM_EN=1;
wire ss_machine_freeze=ss_freeze;
'''+s[a:b]+'''\nassign scan_data=ss_audio_dout;\nendmodule\n'''
with tempfile.TemporaryDirectory(prefix='tgfx-audio-') as d:
 p=Path(d);(p/'dut.sv').write_text(wrapper)
 subprocess.run([args.iverilog,'-g2012','-s','tb_audio_random_start','-o',str(p/'sim.vvp'),str(P/'tests/tb_audio_random_start.sv'),str(p/'dut.sv'),str(P/'rtl/tgfx_iir_filter.v')],check=True)
 subprocess.run([args.vvp,str(p/'sim.vvp')],check=True)
