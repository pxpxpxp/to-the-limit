#!/usr/bin/env python3
"""Run production dpram control with a behavioral RAM substitute."""
from pathlib import Path
import os,subprocess,tempfile
P=Path(__file__).resolve().parents[1];s=(P/'rtl/dpram.vhd').read_text().split('LIBRARY ieee;',2)[1];s='LIBRARY ieee;'+s
s=s.replace('LIBRARY altera_mf;\nUSE altera_mf.altera_mf_components.all;','use ieee.numeric_std.all;')
pos=s.index('BEGIN\n',s.index('ARCHITECTURE'));s=s[:pos]+'''type mem_t is array(0 to 2**addr_width-1) of std_logic_vector(data_width-1 downto 0);
 signal mem : mem_t := (others => (others => '0'));
'''+s[pos:]
s=s[:s.index('\taltsyncram_component :')]+'''
 process(clock) begin if rising_edge(clock) then
  if ea='1' then if mw='1' then mem(to_integer(unsigned(ma)))<=md;q0<=md;else q0<=mem(to_integer(unsigned(ma)));end if;end if;
  if eb='1' then if wren_b='1' and cs_b='1' then mem(to_integer(unsigned(address_b)))<=data_b;q1<=data_b;else q1<=mem(to_integer(unsigned(address_b)));end if;end if;
 end if;end process;
end SYN;
'''
with tempfile.TemporaryDirectory(prefix='tg16-adpcm-ram-') as td:
 t=Path(td);f=t/'dpram.vhd';f.write_text(s);g=os.environ.get('GHDL','ghdl')
 files=[f,P/'rtl/cd/adpcm_snapshot_ram.vhd',P/'tests/tb_adpcm_snapshot_ram.vhd']
 for a in [('-a','--std=08','-fsynopsys',*map(str,files)),('-e','--std=08','-fsynopsys','tb_adpcm_snapshot_ram'),('-r','--std=08','-fsynopsys','tb_adpcm_snapshot_ram','--assert-level=error','--stop-time=50us')]:subprocess.run([g,*a],cwd=td,check=True)
