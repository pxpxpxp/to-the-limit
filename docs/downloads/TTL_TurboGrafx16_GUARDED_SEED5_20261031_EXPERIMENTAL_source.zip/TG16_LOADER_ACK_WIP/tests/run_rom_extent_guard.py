#!/usr/bin/env python3
"""Simulate production sticky ROM-extent guard including a counter wrap."""
from pathlib import Path
import re, subprocess, tempfile
p=Path(__file__).resolve().parents[1]
s=(p/'TurboGrafx16.sv').read_text()
m=re.search(r'reg ss_cart_old = 0;.*?\nend\n',s,re.S); assert m
assert re.search(r'wire ss_available = !ss_rom_oversize &&',s)
tb='''module tb; reg clk_sys=0; always #5 clk_sys=~clk_sys;
reg cart_download=0, ioctl_wr=0; reg [23:0] romwr_a=0;
'''+m[0]+'''
task tick; begin @(posedge clk_sys); #1; end endtask
initial begin
 tick(); if (ss_rom_oversize!==1) $fatal(1,"unknown image must fail closed");
 cart_download=1; tick(); if(ss_rom_oversize!==0) $fatal(1,"new download reset");
 romwr_a=24'h3ffffe; ioctl_wr=1; tick(); if(ss_rom_oversize!==0) $fatal(1,"last legal word");
 romwr_a=24'h400000; tick(); if(ss_rom_oversize!==1) $fatal(1,"first oversized word");
 romwr_a=0; tick(); if(ss_rom_oversize!==1) $fatal(1,"wrapped counter");
 cart_download=0; ioctl_wr=0; tick(); if(ss_rom_oversize!==1) $fatal(1,"sticky after download");
 cart_download=1; tick(); if(ss_rom_oversize!==0) $fatal(1,"new cart clears guard");
 $display("PASS: production cartridge extent guard, boundary, wrap, and reload"); $finish; end
endmodule
'''
with tempfile.TemporaryDirectory(prefix='tg16-rom-bound-') as d:
 src=Path(d)/'tb.sv';src.write_text(tb);v=Path(d)/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb','-o',str(v),str(src)],check=True)
 subprocess.run(['vvp',str(v)],check=True)
