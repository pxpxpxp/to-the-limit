#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
s=(P/'rtl/sdram.v').read_text().replace('inout  reg [15:0] SDRAM_DQ','inout wire [15:0] SDRAM_DQ')
s=s.replace('assign SDRAM_nCS = 0;','reg [15:0] dq_driver;\nassign SDRAM_DQ = dq_driver;\nassign SDRAM_nCS = 0;')
s=s.replace('SDRAM_DQ <=','dq_driver <=').replace(', SDRAM_DQ}',', dq_driver}')
with tempfile.TemporaryDirectory(prefix='tg16-sdram-scan-') as td:
 t=Path(td);(t/'sdram.v').write_text(s);v=t/'test.vvp'
 subprocess.run(['iverilog','-g2012','-gstrict-expr-width','-s','tb_cd_pack_sdram','-o',str(v),str(P/'tests/tb_cd_pack_sdram.sv'),str(t/'sdram.v'),str(P/'rtl/cd_ram_pack_engine.sv')],check=True)
 subprocess.run(['vvp',str(v)],check=True)
