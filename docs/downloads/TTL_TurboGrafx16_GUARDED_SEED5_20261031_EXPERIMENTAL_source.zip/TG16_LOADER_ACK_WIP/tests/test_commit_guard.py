#!/usr/bin/env python3
"""Static guard truth-table and wiring checks, not an HDL simulation."""
from itertools import product
from pathlib import Path
import re
s=(Path(__file__).resolve().parents[1]/'TurboGrafx16.sv').read_text()
expr=re.search(r'assign ss_load_commit\s*=\s*(.*?);',s,re.S)[1]
expr=' '.join(expr.replace('&&',' and ').replace('||',' or ').replace('!',' not ').split())
names=('ss_load','reset','cart_download','ss_config_changed','ss_fault_reset','ss_fault_pending','ss_available')
assert set(re.findall(r'\b[A-Za-z_][A-Za-z_0-9]*\b',expr)) <= set(names)|{'and','or','not'}
for bits in product((False,True),repeat=len(names)):
 d=dict(zip(names,bits)); got=bool(eval(expr,{'__builtins__':{}},d))
 assert got==(d['ss_load'] and d['ss_available'] and not any(d[n] for n in ('reset','cart_download','ss_config_changed','ss_fault_reset','ss_fault_pending'))),d
raw=re.sub(r'\.ss_load\s*\(', '.sdram_load(',s)
assert len(re.findall(r'\bss_load\b',raw))==3  # declaration, guard, controller pulse output
assert '.SS_LOAD(ss_load_commit)' in s
assert 'if(ss_load_commit) begin' in s
assert 'if (ss_load_commit) ss_bram_bank' in s
assert 'if(ss_load_commit) ss_cdram_bank' in s
assert '.enabled(ss_available && !ss_fault_pending)' in s
assert '.RESET(reset|cart_download|ss_fault_reset|ss_fault_pending)' in s
assert '.COLD_RESET(cart_download|ss_cold_pending)' in s
assert 'if (reset || ss_fault_pending) high_buttons <= 0;' in s
assert '(ss_load_commit || (~OSD_STATUS' in s
assert '.ss_load(ss_sdram_load)' in s
assert re.search(r'always\s*@\(posedge clk_sys\)\s*ss_sdram_load\s*<=\s*ss_load_commit;',s)
print('PASS: 128 commit/abort combinations and consumer wiring, including delayed SDRAM')
