#!/usr/bin/env python3
"""Exercise production DDR/cache arbitration with behavioral RAM wrappers."""
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='tgfx-real-ddr-') as d:
 out=Path(d)/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_ddr_real_integration','-o',str(out),str(P/'tests/tb_ddr_real_integration.sv'),str(P/'rtl/ninja_savestate.sv'),str(P/'rtl/adpcm_pack_engine.sv'),str(P/'rtl/word_scan_pack_engine.sv'),str(P/'rtl/cd_ram_pack_engine.sv'),str(P/'rtl/ddram.sv'),str(P/'rtl/cache_2way.sv')],check=True)
 subprocess.run(['vvp',str(out)],check=True)
