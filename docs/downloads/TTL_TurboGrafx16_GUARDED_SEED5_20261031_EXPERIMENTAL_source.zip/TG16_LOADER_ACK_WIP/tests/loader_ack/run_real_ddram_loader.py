#!/usr/bin/env python3
"""Exact loader + production ddram/cache handshake under phased DDR busy stalls.
SDRAM ack is modeled; startup forces only the legacy uninitialized DDR ack.
"""
from pathlib import Path
import os, subprocess, tempfile
P=Path(__file__).resolve().parents[2];s=(P/'TurboGrafx16.sv').read_text();start=s.index('always @(posedge clk_sys) begin\n\treg old_download, old_reset;');end=s.index('\n\n\n////////////////////////////  CODES',start);loader=s[start:end]
sampler='(* altera_attribute = "-name PRESERVE_REGISTER ON" *) reg dd_wrack_sys = 0;\nalways @(posedge clk_sys) dd_wrack_sys <= dd_wrack;';assert sampler in s and 'rom_wr == dd_wrack_sys' in loader
wrappers=(P/'tests/tb_ddr_real_integration.sv').read_text();wrappers=wrappers[wrappers.index('module dpram #'):]
bench=r'''
`timescale 1ns/1ps
module loader(input clk_sys,reset,cart_download,ioctl_wr,input [15:0] ioctl_dout,input [7:0] ioctl_index,input sd_wrack,dd_wrack,output reg ioctl_wait,output reg [23:0] romwr_a,output reg [1:0] populous,output reg sgx,output reg rom_wr=0);
wire [15:0] romwr_d=ioctl_dout;
SAMPLER
LOADER
endmodule
module tb;
reg clk_sys=0,clk_ram=0,reset=0,cart_download=0,ioctl_wr=0,sd_ack=0,busy=0;
reg [15:0] ioctl_dout=0;reg[7:0] ioctl_index=0;wire ioctl_wait;wire[23:0] romwr_a;wire[1:0] populous;wire sgx,rom_wr,dd_ack;
wire [7:0] burst,be;wire [28:0] addr;wire [63:0] din;wire dd_rd,dd_we,wr_rdy,rd_rdy,idle;wire[7:0] dout;
loader l(clk_sys,reset,cart_download,ioctl_wr,ioctl_dout,ioctl_index,sd_ack,dd_ack,ioctl_wait,romwr_a,populous,sgx,rom_wr);
ddram d(.DDRAM_CLK(clk_ram),.DDRAM_BUSY(busy),.DDRAM_BURSTCNT(burst),.DDRAM_ADDR(addr),.DDRAM_DOUT(64'd0),.DDRAM_DOUT_READY(1'b0),.DDRAM_RD(dd_rd),.DDRAM_DIN(din),.DDRAM_BE(be),.DDRAM_WE(dd_we),.clkref(1'b0),.wraddr({4'd0,romwr_a}),.din(ioctl_dout),.we(1'b0),.we_rdy(wr_rdy),.we_req(rom_wr),.we_ack(dd_ack),.rdaddr(28'd0),.dout(dout),.rd(1'b0),.rd_rdy(rd_rdy),.idle(idle));
always #10 clk_sys=~clk_sys;initial begin #PHASE;forever #5 clk_ram=~clk_ram;end
integer cycle=0,writes=0,expected=0,n,waitcycles; reg [15:0] expected_data;
always @(negedge clk_ram) begin cycle=cycle+1; busy=((cycle%17)<5)||((cycle%89)<4);end
always @(posedge clk_ram) if(dd_we && !busy) begin
 if(d.ram_addr !== (writes*2)) $fatal(1,"wrong DDR write address idx=%0d got=%h",writes,d.ram_addr);
 expected_data=(writes*2)^16'h4a69;
 if(din[15:0] !== expected_data) $fatal(1,"wrong DDR write data idx=%0d got=%h want=%h",writes,din[15:0],expected_data);
 writes=writes+1;
end
initial begin
 force d.we_ack=0;repeat(4) @(negedge clk_ram);release d.we_ack;
 repeat(3) @(negedge clk_sys);reset=1;repeat(3) @(negedge clk_sys);reset=0;
 repeat(2) @(negedge clk_sys);cart_download=1;repeat(3) @(negedge clk_sys);
 for(n=0;n<160;n=n+1) begin
  @(negedge clk_sys); if(ioctl_wait!==0 || romwr_a!==expected) $fatal(1,"not ready");ioctl_dout=expected^16'h4a69;ioctl_wr=1;
  @(negedge clk_sys);ioctl_wr=0;
  fork
   begin repeat((n%11)+1) @(posedge clk_ram);#2 sd_ack=rom_wr;end
   begin waitcycles=0;while(ioctl_wait===1 && waitcycles<150)begin @(negedge clk_sys);waitcycles=waitcycles+1;if(ioctl_wait===0 && (dd_ack!==rom_wr || sd_ack!==rom_wr))$fatal(1,"false completion");end if(ioctl_wait!==0)$fatal(1,"loader timeout");expected=expected+2;if(romwr_a!==expected)$fatal(1,"increment mismatch");end
  join
 end
 waitcycles=0;while(writes<160 && waitcycles<200)begin @(negedge clk_ram);waitcycles=waitcycles+1;end
 if(writes!=160) $fatal(1,"lost/duplicate DDR writes %0d",writes);
 repeat(10)@(negedge clk_ram);if(writes!=160)$fatal(1,"extra DDR writes");
 $display("PASS real ddram/cache + sampled loader: phase=%0d writes=%0d busy-pattern cycles=%0d",PHASE,writes,cycle);$finish;
end
initial begin #4000000;$fatal(1,"timeout");end
endmodule
WRAPPERS
'''.replace('SAMPLER',sampler).replace('LOADER',loader).replace('WRAPPERS',wrappers)
with tempfile.TemporaryDirectory(prefix='tg16-real-loader-') as tmp:
 for phase in (0,1,3,5,7,9):
  src=Path(tmp)/f'tb{phase}.sv';out=Path(tmp)/f'tb{phase}.vvp';src.write_text(bench.replace('PHASE',str(phase)))
  subprocess.run([os.environ.get('IVERILOG','iverilog'),'-g2012','-s','tb','-o',str(out),str(src),str(P/'rtl/ddram.sv'),str(P/'rtl/cache_2way.sv')],check=True)
  run=subprocess.run([os.environ.get('VVP','vvp'),str(out)],capture_output=True,text=True)
  if run.returncode or 'PASS real ddram/cache' not in run.stdout:raise SystemExit(run.stdout+'\n'+run.stderr)
  print(run.stdout.strip(),flush=True)
print('PASS: 960 production ddram write handshakes across six phases, behavioral SDRAM ack; no hardware claim')
