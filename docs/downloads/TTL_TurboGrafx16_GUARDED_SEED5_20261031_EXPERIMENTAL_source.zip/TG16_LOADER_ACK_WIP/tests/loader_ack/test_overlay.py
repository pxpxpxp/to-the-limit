#!/usr/bin/env python3
"""Verify loader-timing patch reconstructs candidate from the known primed baseline."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
P=Path(__file__).resolve().parents[2];baseline=P/'savestate/loader_ack_validation/primed_baseline_top.sv'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='bd9d8b954bf2c05d282aabcf42a7bf49284929fd0e258b0cd518bf6d385a2775'
x=json.loads((P/'savestate/build-inputs.json').read_text())
assert all(hashlib.sha256((P/n).read_bytes()).hexdigest()==h for n,h in x.items())
with tempfile.TemporaryDirectory(prefix='tg16-loader-overlay-') as d:
 q=Path(d);shutil.copy2(baseline,q/'TurboGrafx16.sv')
 subprocess.run(['patch','--batch','-p1','-i',str(P/'savestate/loader_ack_timing.patch')],cwd=q,check=True,stdout=subprocess.DEVNULL)
 assert (q/'TurboGrafx16.sv').read_bytes()==(P/'TurboGrafx16.sv').read_bytes()
print(f'PASS loader-ack overlay: {len(x)} input hashes match manifest; top reconstructed from bundled primed baseline')
