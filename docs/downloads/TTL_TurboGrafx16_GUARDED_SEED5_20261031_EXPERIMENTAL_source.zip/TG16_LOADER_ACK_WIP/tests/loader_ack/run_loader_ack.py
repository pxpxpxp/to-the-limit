#!/usr/bin/env python3
"""Exercise the exact candidate loader and DDR ack sampler with phased delayed acknowledgments."""
from pathlib import Path
import os, subprocess, tempfile
P=Path(__file__).resolve().parents[2]
s=(P/'TurboGrafx16.sv').read_text();start=s.index('always @(posedge clk_sys) begin\n\treg old_download, old_reset;');end=s.index('\n\n\n////////////////////////////  CODES',start);loader=s[start:end]
assert 'rom_wr == dd_wrack_sys' in loader and 'rom_wr == sd_wrack' in loader
sampler='(* altera_attribute = \"-name PRESERVE_REGISTER ON\" *) reg dd_wrack_sys = 0;\nalways @(posedge clk_sys) dd_wrack_sys <= dd_wrack;'
assert sampler in s
bench=r'''
`timescale 1ns/1ps
module loader(input clk_sys,reset,cart_download,ioctl_wr,input [15:0] ioctl_dout,input [7:0] ioctl_index,input sd_wrack,dd_wrack,output reg ioctl_wait,output reg [23:0] romwr_a,output reg [1:0] populous,output reg sgx,output reg rom_wr=0);
wire [15:0] romwr_d=ioctl_dout;
SAMPLER
LOADER
endmodule
module tb;
reg clk_sys=0,clk_ram=0,reset=0,cart_download=0,ioctl_wr=0,sd_wrack=0,dd_wrack=0;
reg [15:0] ioctl_dout=0; reg [7:0] ioctl_index=0;
wire ioctl_wait;wire [23:0] romwr_a;wire [1:0] populous;wire sgx,rom_wr;
loader d(clk_sys,reset,cart_download,ioctl_wr,ioctl_dout,ioctl_index,sd_wrack,dd_wrack,ioctl_wait,romwr_a,populous,sgx,rom_wr);
always #10 clk_sys=~clk_sys;
initial begin #PHASE; forever #5 clk_ram=~clk_ram; end
integer dd,sd,n,expected=0,waitcycles;
task one(input integer a,input integer b);
 reg req;
 begin
  @(negedge clk_sys); if(ioctl_wait!==0) $fatal(1,"busy before new word"); ioctl_dout=expected^16'h4a69; ioctl_wr=1;
  @(negedge clk_sys); ioctl_wr=0; req=rom_wr;
  if(ioctl_wait!==1 || romwr_a!==expected) $fatal(1,"request not latched at %d",expected);
  fork
   begin repeat(a+1) @(posedge clk_ram); #1 dd_wrack=req; end
   begin repeat(b+1) @(posedge clk_ram); #2 sd_wrack=req; end
   begin
    waitcycles=0;
    while(ioctl_wait===1 && waitcycles<100) begin
      @(negedge clk_sys); waitcycles=waitcycles+1;
      if(ioctl_wait===0 && (dd_wrack!==req || sd_wrack!==req)) $fatal(1,"false completion: ddr=%b sdram=%b req=%b",dd_wrack,sd_wrack,req);
      if(ioctl_wait===1 && romwr_a!==expected) $fatal(1,"address changed while awaiting acks");
    end
    if(ioctl_wait!==0) $fatal(1,"timeout waiting for acks");
    expected=expected+2; if(romwr_a!==expected) $fatal(1,"wrong increment %d expected %d",romwr_a,expected);
    repeat(2) begin @(negedge clk_sys); if(romwr_a!==expected || ioctl_wait!==0) $fatal(1,"duplicate increment"); end
   end
  join
 end
endtask
initial begin
 repeat(3) @(negedge clk_sys); reset=1; repeat(3) @(negedge clk_sys); reset=0;
 repeat(2) @(negedge clk_sys); cart_download=1; repeat(3) @(negedge clk_sys);
 if(romwr_a!==0) $fatal(1,"cart start address not zero");
 for(dd=0;dd<7;dd=dd+1) for(sd=0;sd<7;sd=sd+1) one(dd,sd);
 for(n=0;n<60;n=n+1) one((n*3)%11,(n*7)%13);
 // Supported recovery model: a reset cancels host wait, old requests drain,
 // and only then a fresh cartridge download is begun. No in-flight reset or
 // HPS acceptance is claimed safe by this isolated model.
 @(negedge clk_sys); ioctl_wr=1;
 @(negedge clk_sys); ioctl_wr=0; if(ioctl_wait!==1) $fatal(1,"pending setup");
 @(negedge clk_sys); reset=1;
 repeat(3) @(negedge clk_sys); if(ioctl_wait!==0) $fatal(1,"reset did not release host wait");
 reset=0; repeat(3) @(posedge clk_ram); #1 dd_wrack=rom_wr; #1 sd_wrack=rom_wr;
 repeat(4) @(negedge clk_sys); cart_download=0; repeat(3) @(negedge clk_sys); cart_download=1;
 repeat(3) @(negedge clk_sys); expected=0; if(romwr_a!==0) $fatal(1,"redownload address"); one(2,3);
 $display("PASS loader phased toggles and drained-reset restart: PHASE=%0d writes=%0d",PHASE,110);$finish;
end
initial begin #4000000; $fatal(1,"test timeout"); end
endmodule
'''.replace('SAMPLER',sampler).replace('LOADER',loader)
iverilog=os.environ.get('IVERILOG','iverilog'); vvp=os.environ.get('VVP','vvp')
with tempfile.TemporaryDirectory(prefix='tg16-loader-') as tmp:
 for phase in (0,1,3,5,7,9):
  src=Path(tmp)/f'tb{phase}.sv';exe=Path(tmp)/f'tb{phase}.vvp';src.write_text(bench.replace('PHASE',str(phase)))
  subprocess.run([iverilog,'-g2012','-s','tb','-o',str(exe),str(src)],check=True)
  out=subprocess.run([vvp,str(exe)],capture_output=True,text=True,check=True);assert 'PASS loader phased toggles' in out.stdout;print(out.stdout.strip(),flush=True)
print('PASS exact-source loader sampler: 660 writes across six clock phases incl drained-reset restart; behavioral acknowledgments, no HPS/hardware claim')
