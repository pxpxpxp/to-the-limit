`timescale 1ns/1ps
module tb_hps_cd_startup;
 reg clk_sys=0; always #5 clk_sys=~clk_sys;
 tri [35:0] EXT_BUS; reg [15:0] io_din=0; reg io_enable=0,io_strobe=0;
 assign EXT_BUS[31:16]=io_din; assign EXT_BUS[33]=io_strobe; assign EXT_BUS[34]=io_enable;
 reg [112:0] cd_in=0; wire [112:0] cd_out;
 hps_ext dut(.clk_sys(clk_sys),.EXT_BUS(EXT_BUS),.cd_in(cd_in),.cd_out(cd_out));
 reg reset=1,cart_download=0; reg [63:0] status=0;
 reg [15:0] cd_stat; reg cd_stat_rec,cd_dataout_req,cd_region;
 reg [95:0] cd_comm=0; reg cd_comm_send=0,cd_dataout_send=0,cd_reset_req=0;
 reg [79:0] cd_dataout=0;
 integer status_count=0,request_count=0;
 always @(posedge clk_sys) begin
  if(cd_stat_rec) status_count<=status_count+1;
  if(cd_dataout_req) request_count<=request_count+1;
 end
 // INSERT_ACTUAL_TOP_HANDSHAKE
 task set_status(input bit is_request);
 integer i;
 begin
  @(negedge clk_sys); io_enable=1;io_strobe=1;io_din=16'h35;
  @(negedge clk_sys);
  for(i=1;i<=7;i=i+1) begin io_din=(i==2 && is_request)?16'h0001:16'h0000; @(negedge clk_sys);end
  io_enable=0;io_strobe=0; repeat(4) @(negedge clk_sys);
 end
 endtask
 initial begin
  repeat(3) @(negedge clk_sys);reset=0;repeat(8)@(negedge clk_sys);
  // Model clean Main: last_req=0, no CD commands, repeated GET polling.
  for(integer j=0;j<128;j=j+1)begin
   io_enable=1;io_strobe=1;io_din=16'h34;@(negedge clk_sys);#1;
   if(EXT_BUS[15:0]!==16'd0)$fatal(1,"clean GET returned nonzero/unknown request at %0d: %h",j,EXT_BUS[15:0]);
   io_enable=0;io_strobe=0;repeat(2)@(negedge clk_sys);
   if(status_count!==0 || request_count!==0 || cd_out[112]!==1'b1)$fatal(1,"GET polling caused phantom status");
  end
  set_status(0);if(status_count!==1 || request_count!==0)$fatal(1,"positive status not detected");
  $display("PASS: 128 clean CD_GET polls return request zero and generate no CD_SET pulse; positive control detected");$finish;
 end
 initial begin #20000;$fatal(1,"timeout");end
endmodule
