#!/usr/bin/env python3
"""Exhaustively evaluate the actual ss_available RTL expression as booleans."""
from itertools import product
from pathlib import Path
import re
source = (Path(__file__).resolve().parents[1] / 'TurboGrafx16.sv').read_text()
expr = re.search(r'wire\s+ss_available\s*=\s*(.*?);', source, re.S).group(1)
translations = {'populous[romwr_a[9]]':'populous', 'status[13]':'snac', 'status[21]':'mb128', 'status[5]':'cheats_off', 'defbram[3]':'format_idle', 'status[27]':'special_hi', 'status[26]':'special_lo'}
for old,new in translations.items(): expr = expr.replace(old,new)
expr = expr.replace('&&', ' and ').replace('||',' or ').replace('!',' not ')
expr = ' '.join(expr.split())
names=('use_sdr','cd_en','sgx','populous','ioctl_download','snac','mb128','gg_avail','cheats_off','bk_state','format_idle','special_hi','special_lo','ss_cd_unsafe','ss_rom_oversize')
assert set(re.findall(r'[A-Za-z_][A-Za-z_0-9]*',expr)) <= set(names)|{'not','and','or'}
for bits in product((False,True), repeat=len(names)):
 d=dict(zip(names,bits)); got=bool(eval(expr,{'__builtins__':{}},d))
 expected=(d['use_sdr'] and not any(d[n] for n in ('cd_en','sgx','populous','ioctl_download','snac','mb128','bk_state','special_hi','special_lo','ss_cd_unsafe','ss_rom_oversize')) and d['format_idle'] and not (d['gg_avail'] and not d['cheats_off']))
 assert got == expected, d
print('PASS: 32768 actual ss_available Boolean combinations')
