`timescale 1ns/1ps
module tb_audio_random_start;
reg clk_sys=0; always #5 clk_sys=~clk_sys;
reg ss_freeze=1,ss_save=0,ss_load_commit=0,ss_we=0,ss_reg_rotate=0;
reg [17:0] ss_addr=0; reg [15:0] ss_din=0; reg [63:0] status=64'h400000;
reg [15:0] cdda_sl=0,cdda_sr=0,psg_sl=0,psg_sr=0,adpcm_s=0;
wire [15:0] AUDIO_L,AUDIO_R,scan_data; wire AUDIO_S,AUDIO_MIX;
audio_snapshot_dut dut(.*);
localparam BASE=627,WORDS=54,N=130000;
reg [15:0] saved[0:WORDS-1]; reg [79:0] expected[0:N-1];
integer k,i,phase,filter_changes;
task input_for(input integer n); begin
 psg_sl=(n*313+401)^(n>>2); psg_sr=(n*101+401)^(n>>3);
 adpcm_s=(n*159+711)^(n>>4); cdda_sl=n*37; cdda_sr=~(n*17);
end endtask
task commit;begin ss_load_commit=1; @(negedge clk_sys);ss_load_commit=0;end endtask
task reset_audio; begin
 ss_freeze=1;ss_we=1;
 for(k=0;k<WORDS;k=k+1)begin ss_addr=18'h30000+BASE+k; ss_din=(16'h9e37*(k+1)) ^ (16'h7f4a*(phase+1)) ^ (k<<5); @(negedge clk_sys);end
 ss_we=0; commit();
end endtask
task capture; begin
 ss_freeze=1;ss_save=1; @(negedge clk_sys);ss_save=0;
 for(k=0;k<WORDS;k=k+1)begin
   ss_addr=18'h30000+BASE+k; #1; if (^scan_data === 1'bx) $fatal(1,"unknown captured audio word %0d",k); saved[k]=scan_data;
   ss_reg_rotate=1; @(negedge clk_sys); ss_reg_rotate=0;
 end
end endtask
task restore;begin
 ss_freeze=1;ss_we=1;
 for(k=0;k<WORDS;k=k+1)begin ss_addr=18'h30000+BASE+k;ss_din=saved[k];@(negedge clk_sys);end
 ss_we=0;commit();
end endtask
initial begin
 @(negedge clk_sys);
 for(phase=0;phase<4;phase=phase+1)begin
   case(phase)
      0: status=0;
      1: status=(64'd1<<18)|(64'd1<<20);
      2: status=(64'd2<<18)|(64'd1<<22);
      3: status=(64'd3<<18)|(64'd1<<20)|(64'd1<<22);
   endcase
   reset_audio();ss_freeze=0;
   for(i=0;i<300+phase*7;i=i+1)begin input_for(i);@(negedge clk_sys);end
   capture(); ss_freeze=0; filter_changes=0;
   for(i=0;i<N;i=i+1)begin input_for(i); @(negedge clk_sys);
     if (^{AUDIO_L,AUDIO_R,dut.psg_l_filt,dut.psg_r_filt,dut.adpcm_filt} === 1'bx) $fatal(1,"unknown reference audio at %0d",i);
     expected[i]={AUDIO_L,AUDIO_R,dut.psg_l_filt,dut.psg_r_filt,dut.adpcm_filt};
     if(i>0 && expected[i][47:0] != expected[i-1][47:0]) filter_changes=filter_changes+1;end
   if(filter_changes<100) $fatal(1,"filter output did not change sufficiently: %0d",filter_changes);
   // Advance with different input to corrupt all live filter histories.
   for(i=0;i<1500;i=i+1)begin input_for(i+73000);@(negedge clk_sys);end
   restore();ss_freeze=0;
   for(i=0;i<N;i=i+1)begin input_for(i);@(negedge clk_sys);
     if({AUDIO_L,AUDIO_R,dut.psg_l_filt,dut.psg_r_filt,dut.adpcm_filt} !== expected[i])$fatal(1,"phase %0d sample %0d expected %h got %h",phase,i,expected[i],{AUDIO_L,AUDIO_R,dut.psg_l_filt,dut.psg_r_filt,dut.adpcm_filt});
   end
 end
 $display("PASS: four deterministic arbitrary-binary power-on patterns and filter phases, 130000 cycles per replay (~3.0ms at core clock), external image export/import");$finish;
end
initial begin #30000000;$fatal(1,"timeout");end
endmodule
