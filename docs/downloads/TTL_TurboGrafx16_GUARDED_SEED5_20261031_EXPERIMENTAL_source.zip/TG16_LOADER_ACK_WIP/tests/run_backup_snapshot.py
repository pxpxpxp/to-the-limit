#!/usr/bin/env python3
"""Extract production backup RAM logic and exercise it with a behavioral RAM.
Requires iverilog/vvp. This is not an Altera primitive model, fitter, firmware or hardware test.
"""
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
s=(P/'TurboGrafx16.sv').read_text()
# Exact production declarations, latch logic and instantiated backup RAM.
a=s.index('wire  [7:0] bram_q;'); b=s.index('wire        bram_wr;',a)
logic=s[a:b].replace('wire  [7:0] bram_q;','')
a=s.index('// Double-buffer the 2 KiB battery RAM.'); b=s.index('\n);',s.index('dpram_difclk #(11,8,10,16) backram1',a))+3
memory=s[a:b]
commit=s[s.index('assign ss_load_commit ='):s.index(';',s.index('assign ss_load_commit ='))+1]
wrapper='''module backup_snapshot_dut(input clk_sys,ss_freeze,ss_save,ss_load,ss_abort,ss_we,
input [17:0] ss_addr,input [15:0] ss_din,input [10:0] bram_addr,
input [7:0] bram_data,input bram_wr,input [3:0] defbram,input [31:0] sd_lba,
input [7:0] sd_buff_addr,input [15:0] sd_buff_dout,input sd_buff_wr,sd_ack,
input [15:0] defval[4],output [7:0] bram_q,output [15:0] scan_word);
wire bk_int = !sd_lba[31:2];
wire reset=ss_abort, cart_download=0, ss_config_changed=0, ss_fault_reset=0, ss_fault_pending=0, ss_available=1; wire ss_load_commit;
wire ss_machine_freeze=ss_freeze;
'''+commit+'\n'+logic+'\n'+memory+'\nassign scan_word = ss_addr[14:0]==1024 ? {8\'d0,ss_bram_q} : ss_bram_word;\nendmodule\n'
with tempfile.TemporaryDirectory(prefix='tgfx-bram-test-') as d:
    v=Path(d)/'dut.sv'; v.write_text(wrapper); out=Path(d)/'test.vvp'
    subprocess.run(['iverilog','-g2012','-s','tb_backup_snapshot','-o',str(out),str(P/'tests/tb_backup_snapshot.sv'),str(v)],check=True)
    subprocess.run(['vvp',str(out)],check=True)
