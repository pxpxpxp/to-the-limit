#!/usr/bin/env python3
"""Illustrative unequal-Q-delay negative control, not a silicon timing proof."""
from pathlib import Path
import os,re,subprocess,tempfile
P=Path(__file__).resolve().parents[1];s=(P/'TurboGrafx16.sv').read_text();m=re.search(r'reg \[3:0\] ss_restore_warm_count = 0;.*?assign ss_machine_freeze\s*=.*?;',s,re.S);assert m
body=m.group(0)
tb='''`timescale 1ns/1ps
module tb;
 reg clk_sys=0;always #10 clk_sys=~clk_sys;
 reg ss_freeze=0,ss_cdram_hold=0,ss_load_commit=0;wire ss_machine_freeze;
 BODY
 // Deliberately skew idealized counter Q transitions: a reduction of the
 // raw binary countdown can momentarily go low on 8->7. This is a negative
 // example only; it is NOT a claim about actual physical device delays.
 wire [3:0] delayed_count;
 assign #1 delayed_count[3]=ss_restore_warm_count[3];
 assign #4 delayed_count[2:0]=ss_restore_warm_count[2:0];
 wire reduction_only=|delayed_count;
 wire #1 delayed_raw=ss_freeze;
 wire #4 delayed_hold=ss_restore_warm_hold;
 wire physical_or=delayed_raw|delayed_hold;
 reg armed=0;
 always @(negedge physical_or) if(armed)$fatal(1,"post-prime handoff glitched low");
 always @(ss_restore_warm_hold) if($time>0 && clk_sys!==1'b1)$fatal(1,"hold FF changed off clock edge");
 initial begin
  @(negedge clk_sys);ss_freeze=1;repeat(3)@(negedge clk_sys);
  if(!ss_restore_warm_hold || ss_restore_warm_count!=8 || !physical_or)$fatal(1,"prime missing");
  armed=1;ss_freeze=0;
  @(posedge clk_sys);#2;
  if(reduction_only!==0 || ss_restore_warm_hold!==1 || physical_or!==1)$fatal(1,"expected illustrative reduction glitch absent or retained output failed");
  #4;if(reduction_only!==1)$fatal(1,"negative-control pulse did not settle");
  repeat(6)@(posedge clk_sys);#1;if(!ss_restore_warm_hold || !physical_or)$fatal(1,"hold released early");
  armed=0;@(posedge clk_sys);#6;if(ss_restore_warm_hold || physical_or)$fatal(1,"hold did not release");
  $display("PASS: registered hold remains stable in deliberate skew model while reduction-only counter glitches");$finish;
 end
 initial begin #10000;$fatal(1,"timeout");end
endmodule
'''.replace('BODY',body)
with tempfile.TemporaryDirectory(prefix='tg16-hold-skew-') as td:
 t=Path(td);(t/'tb.sv').write_text(tb);env={**os.environ,'PATH':str(P.parent/'hdl_toolchain/bin')+':'+os.environ.get('PATH','')}
 subprocess.run(['iverilog','-g2012','-s','tb','-o',str(t/'sim.vvp'),str(t/'tb.sv')],env=env,check=True)
 subprocess.run(['vvp',str(t/'sim.vvp')],env=env,check=True)
