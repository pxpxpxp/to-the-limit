#!/usr/bin/env python3
"""Run original small full controller/DDR/ADPCM/CD regression through warm hold."""
from pathlib import Path
import os,re,subprocess,tempfile
P=Path(__file__).resolve().parents[1]; top=(P/'TurboGrafx16.sv').read_text(); tb=(P/'tests/tb_adpcm_controller_small.sv').read_text()
m=re.search(r'reg \[3:0\] ss_restore_warm_count = 0;.*?assign ss_machine_freeze\s*=.*?;',top,re.S); assert m
assert tb.count('wire freeze,save_pulse')==1;tb=tb.replace('wire freeze,save_pulse','wire freeze; wire ss_freeze; wire ss_machine_freeze; wire ss_cdram_hold=cd_ram_hold; wire ss_load_commit=load_pulse && !reset && enabled;\n '+m.group(0).replace('clk_sys','clk')+'\n assign freeze=ss_machine_freeze;\n wire save_pulse')
assert tb.count('wire start_block=0;')==1;tb=tb.replace('wire start_block=0;','wire start_block=ss_restore_warm_hold;')
assert tb.count('dut(.*);')==1;tb=tb.replace('dut(.*);','dut(.freeze(ss_freeze),.*);')
assert tb.count('if(load_pulse)bank<=!bank;')==1;tb=tb.replace('if(load_pulse)bank<=!bank;','if(ss_load_commit)bank<=!bank;')
assert tb.count('always @(posedge clk) begin\n  scan_dout')==1
tb=tb.replace('always @(posedge clk) begin\n  scan_dout', "always @(posedge clk) begin\n  if((scan_we || adpcm_we || (cd_ram_write && cd_ram_req!=cd_ram_ack) || ss_load_commit) && !ss_restore_warm_hold)$fatal(1, \"modifying operation before registered hold primed\");\n  scan_dout",1)
old="repeat(4)@(negedge clk);reset=0;\n  for(k=0;k<4;k=k+1)"
new="""repeat(4)@(negedge clk);reset=0;
  // Guard loss on the very first raw-freeze edge, before any restore
  // application: no live scan/bank write or commit may happen.
  slot=0;@(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(ss_freeze);@(negedge clk);enabled=0;@(negedge clk);enabled=1;
  if(writes || adwrites || bank || ss_load_commit)$fatal(1,\"first-freeze abort modified live state\");
  wait(!freeze);repeat(3)@(negedge clk);
  // Likewise cancel on the first raw-freeze edge using reset.
  @(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(ss_freeze);@(negedge clk);reset=1;@(negedge clk);reset=0;
  if(writes || adwrites || bank || ss_load_commit)$fatal(1,\"first-freeze reset modified live state\");
  wait(!freeze);repeat(3)@(negedge clk);
  for(k=0;k<4;k=k+1)"""
assert tb.count(old)==1;tb=tb.replace(old,new)
with tempfile.TemporaryDirectory(prefix='tg16-warm-int-') as td:
 t=Path(td);v=t/'tb.sv';v.write_text(tb);out=t/'sim.vvp';env={**os.environ,'PATH':str(P.parent/'hdl_toolchain/bin')+':'+os.environ.get('PATH','')}
 subprocess.run(['iverilog','-g2012','-s','tb_adpcm_controller_small','-o',str(out),str(v),*[str(P/'rtl'/f) for f in ('ninja_savestate.sv','adpcm_pack_engine.sv','word_scan_pack_engine.sv','cd_ram_pack_engine.sv')]],env=env,check=True)
 subprocess.run(['vvp',str(out)],cwd=t,env=env,check=True)
