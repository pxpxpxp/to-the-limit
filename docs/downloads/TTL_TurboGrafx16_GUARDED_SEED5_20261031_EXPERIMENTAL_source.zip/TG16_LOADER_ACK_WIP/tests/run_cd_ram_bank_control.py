#!/usr/bin/env python3
"""Exercise exact top-level bank and delayed-fault control expressions."""
from pathlib import Path
import re,subprocess,tempfile
P=Path(__file__).resolve().parents[1];s=(P/'TurboGrafx16.sv').read_text()
def get(p):
 m=re.search(p,s,re.S);assert m,p;return m.group(0)
pce=(P/'rtl/pce_top.vhd').read_text()
assert "elsif SS_FREEZE = '0' then" in pce and 'RESET_N <= not RESET;' in pce
parts=[get(r'reg \[3:0\] ss_restore_warm_count = 0;.*?assign ss_machine_freeze\s*=.*?;'),get(r'reg ss_fault_pending=0,ss_cold_pending=0;.*?end\nend'),get(r'reg ss_cdram_bank=0;.*?wire \[24:0\] ss_cdram_normal_addr=.*?;')]
tb=(P/'tests/tb_cd_ram_bank_control.sv').read_text().replace('// INSERT_PRODUCTION_BANK_CONTROL','\n'.join(parts))
with tempfile.TemporaryDirectory(prefix='tg16-bank-control-') as td:
 t=Path(td);v=t/'tb.sv';v.write_text(tb);out=t/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_cd_ram_bank_control','-o',str(out),str(v)],check=True)
 subprocess.run(['vvp',str(out)],check=True)
