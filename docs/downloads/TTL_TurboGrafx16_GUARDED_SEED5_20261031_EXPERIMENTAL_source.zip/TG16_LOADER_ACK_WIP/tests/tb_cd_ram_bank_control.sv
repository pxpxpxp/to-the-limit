`timescale 1ns/1ps
module tb_cd_ram_bank_control;
 reg clk_sys=0;always #5 clk_sys=~clk_sys;
 reg ss_freeze=0,ss_cdram_hold=0,ss_fault_reset=0,ss_load_commit=0,reset=0,cart_download=0;
 reg ss_cdram_write=0;reg [17:0] ss_cdram_addr=0;reg [21:0] cd_ram_a=0;
 // INSERT_PRODUCTION_BANK_CONTROL
 // Equivalent of production pce_top RESET_N update when no SS_LOAD; the Python
 // harness asserts the source still contains that exact freeze qualifier.
 reg pce_reset_n=1,reset_seen=0,cold_seen=0,clear_we=0;
 reg [14:0] clear_addr=0;reg [32767:0] clear_seen=0;
 always @(posedge clk_sys) if(!ss_machine_freeze) begin
  pce_reset_n<=!(reset||cart_download||ss_fault_reset||ss_fault_pending);
  if(reset||cart_download||ss_fault_reset||ss_fault_pending)reset_seen<=1;
  clear_addr<=clear_addr+1'b1;clear_we<=cart_download||ss_cold_pending;
  if(clear_we)clear_seen[clear_addr]<=1;
  if(cart_download||ss_cold_pending)cold_seen<=1;
 end
 initial begin
  repeat(3)@(negedge clk_sys);
  cd_ram_a={4'b1000,18'h12345};ss_cdram_addr=18'h12345;#1;
  if(ss_cdram_normal_addr!==25'h612345||ss_cdram_scan_addr!==25'h612345)$fatal(1,"initial active bank");
  ss_cdram_write=1;#1;if(ss_cdram_scan_addr!==25'h652345)$fatal(1,"initial stage bank");
  ss_load_commit=1;@(negedge clk_sys);ss_load_commit=0;#1;
  if(ss_cdram_normal_addr!==25'h652345||ss_cdram_scan_addr!==25'h612345)$fatal(1,"bank swap");
  ss_cdram_write=0;#1;if(ss_cdram_scan_addr!==25'h652345)$fatal(1,"read swapped bank");
  cd_ram_a={4'b0010,18'h12345};#1;if(ss_cdram_normal_addr!=={3'b001,cd_ram_a})$fatal(1,"arcade address changed");
  ss_cdram_hold=1;ss_fault_reset=1;@(negedge clk_sys);ss_fault_reset=0;repeat(4)@(negedge clk_sys);
  if(!ss_machine_freeze||!ss_fault_pending)$fatal(1,"fault lost during drain");
  ss_cdram_hold=0;@(negedge clk_sys);if(!ss_fault_pending)$fatal(1,"fault released before reset");
  repeat(20)@(negedge clk_sys);if(ss_fault_pending||ss_machine_freeze)$fatal(1,"fault never released");
  // A single-cycle reset while a SDRAM drains must replay after unfreeze.
  reset_seen=0;ss_cdram_hold=1;reset=1;@(negedge clk_sys);reset=0;repeat(4)@(negedge clk_sys);
  if(!ss_machine_freeze||!ss_fault_pending)$fatal(1,"short reset lost during FIFO ownership");
  ss_cdram_hold=0;@(negedge clk_sys);if(!ss_fault_pending)$fatal(1,"reset not replayed after drain");
  repeat(20)@(negedge clk_sys);if(ss_fault_pending||ss_machine_freeze||!reset_seen)$fatal(1,"replayed reset not observed/released");
  cold_seen=0;clear_seen=0;ss_cdram_hold=1;cart_download=1;@(negedge clk_sys);cart_download=0;repeat(4)@(negedge clk_sys);
  if(!ss_fault_pending||!ss_cold_pending)$fatal(1,"cold reset not held");
  ss_cdram_hold=0;wait(!ss_cold_pending);repeat(10)@(negedge clk_sys);if(!cold_seen||!(&clear_seen)||ss_fault_pending)$fatal(1,"cold sweep not completed");
  $display("PASS: CD RAM bank mapping, delayed faults and deferred short reset and 32768-address cold sweep through SDRAM drain");$finish;
 end
 initial begin #500000;$fatal(1,"timeout");end
endmodule
