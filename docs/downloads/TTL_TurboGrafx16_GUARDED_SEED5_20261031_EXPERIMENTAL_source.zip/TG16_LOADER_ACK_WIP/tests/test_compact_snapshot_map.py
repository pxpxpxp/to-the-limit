#!/usr/bin/env python3
"""Bounds, capacity and schema invariants for the compact full-CD prototype."""
from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parents[1];j=json.loads((p/'savestate/serialized_layout.json').read_text());rtl=(p/'rtl/ninja_savestate.sv').read_text()
rm,am,cm,rg=43777,8192,32768,j['register_words'];cg=(rm+rg+3)//4
assert re.search(r'RAM_WORDS=43777,\s*ADPCM_WORDS=8192,\s*CDRAM_WORDS=32768',rtl)
assert re.search(r"MAGIC=64'h54474c5353000002",rtl)
assert cg==11115 and cg+am+cm==52075
size=(cg+am+cm+5)*8
assert size==416640 and size<=0x80000 and cg+am+cm+5<65536
assert cm*8==262144 and am*16==131072
schema=hashlib.sha256(json.dumps(j['fields'],sort_keys=True).encode()+b'|hucard-compact-cd-guard-audio-init-reset-freeze-cdc-v10').hexdigest()[:16]
assert j['schema']==schema and schema in (p/'rtl/snapshot_layout.vh').read_text() and schema in rtl
# CPU RAM sparse banks and compact slot partition must never overlap.
seg=[(0,8192,0x00000),(8192,40960,0x08000),(40960,41216,0x10000),(41216,41728,0x18000),(41728,42240,0x20000),(42240,42752,0x28000),(42752,43777,0x38000)]
a=[]
for start,end,base in seg:a.extend(range(base,base+end-start))
assert len(a)==rm and len(set(a))==rm
assert (0x600000,0x640000,0x680000)==(0x600000,0x600000+262144,0x600000+2*262144)
print(f'PASS: compact core/ADPCM/CD-RAM capacity {size} bytes, schema, bounds and sparse map')
