#!/usr/bin/env python3
"""Exercise production hps_ext plus the real top CD handshake with Icarus.

A negative-control variant forces cd_out's toggle low on powerup to prove the
bench detects the phantom event. Actual MiSTer firmware timing is not modeled.
"""
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
s=(P/'TurboGrafx16.sv').read_text();a=s.index('reg         cd_dat_req;');b=s.index('\nreg [15:0] cd_dat;',a)
tb=(P/'tests/tb_hps_cd_startup.sv').read_text().replace('// INSERT_ACTUAL_TOP_HANDSHAKE',s[a:b])
hps=(P/'rtl/hps_ext.v').read_text(); needle="output reg [112:0] cd_out = {1'b1,112'd0}"; assert needle in hps
with tempfile.TemporaryDirectory(prefix='tg16-hps-startup-') as td:
    t=Path(td);v=t/'tb.sv';v.write_text(tb)
    for negative in [False,True]:
        f=t/'hps.v';f.write_text(hps.replace(needle,"output reg [112:0] cd_out = 113'd0") if negative else hps)
        out=t/'test.vvp';subprocess.run(['iverilog','-g2012','-s','tb_hps_cd_startup','-o',str(out),str(v),str(f)],check=True)
        r=subprocess.run(['vvp',str(out)],text=True,capture_output=True)
        if negative:
            assert r.returncode and 'phantom CD status after FPGA startup' in r.stdout, r.stdout+r.stderr
            print('PASS: low-toggle negative control detects phantom startup event')
        else:
            assert not r.returncode and 'PASS: initialized HPS toggle' in r.stdout, r.stdout+r.stderr
            print(r.stdout,end='')
