`timescale 1ns/1ps
module tb_cd_ram_pack_engine;
 reg clk=0,ramclk=0;always #10 clk=~clk;always #5 ramclk=~ramclk;
 reg reset=1,freeze=0,cancel=0,start_read=0,start_write=0;reg [14:0] group_addr=0;reg [63:0] word_in=0;
 wire [17:0] cell_addr;wire [7:0] cell_din;wire cell_write,cell_req;reg cell_ack=0;reg [7:0] cell_dout=0;
 wire [63:0] word_out;wire hold_req,busy,done,aborted;
 cd_ram_pack_engine dut(.*);
 reg [7:0] active[0:262143],stage[0:262143];integer i,j,ticks=0,delay_left=0;reg pending_req=0,pending_write=0;reg [17:0] pending_addr=0;reg [7:0] pending_data=0;reg blocked=0;
 // Request/ack model with variable latency and a frozen active bank.
 always @(posedge ramclk) begin
  ticks<=ticks+1;
  if(cell_req!=cell_ack && delay_left==0) begin pending_req<=cell_req;pending_write<=cell_write;pending_addr<=cell_addr;pending_data<=cell_din;delay_left<=4+(ticks%11);end
  else if(delay_left!=0 && !blocked)begin
   if(cell_addr!==pending_addr||cell_din!==pending_data||cell_write!==pending_write)$fatal(1,"mailbox payload changed before ack");
   delay_left<=delay_left-1;
   if(delay_left==1)begin if(pending_write)stage[pending_addr]<=pending_data;else cell_dout<=active[pending_addr];cell_ack<=pending_req;end
  end
 end
 task rd(input integer g);
 begin @(negedge clk);group_addr=g;start_read=1;@(negedge clk);start_read=0;wait(done);@(negedge clk);for(j=0;j<8;j=j+1)if(word_out[j*8+:8]!==active[g*8+j])$fatal(1,"read %0d/%0d",g,j);end endtask
 task wr(input integer g,input [63:0] w);
 begin @(negedge clk);group_addr=g;word_in=w;start_write=1;@(negedge clk);start_write=0;wait(done);@(negedge clk);for(j=0;j<8;j=j+1)if(stage[g*8+j]!==w[j*8+:8])$fatal(1,"write %0d/%0d",g,j);end endtask
 initial begin
  for(i=0;i<262144;i=i+1)begin active[i]=(i^(i>>8)^(i>>15))&255;stage[i]=0;end
  repeat(4)@(negedge clk);reset=0;freeze=1;
  for(i=0;i<64;i=i+1)begin rd((i*503)%32768);wr((i*503)%32768,64'hfedcba9876543210^i);end
  rd(32767);wr(32767,64'h0123456789abcdef);
  // Stall a live request, cancel, and prove ownership cannot be released
  // until the eventual response; writes target stage, never active bank.
  @(negedge clk);group_addr=17;word_in=64'hffffffffffffffff;start_write=1;@(negedge clk);start_write=0;
  wait(cell_req!=cell_ack);blocked=1;@(negedge clk);cancel=1;repeat(20)@(negedge clk);
  if(!hold_req||!busy||done||aborted)$fatal(1,"released before stalled response");
  blocked=0;wait(aborted);@(negedge clk);cancel=0;if(hold_req||busy)$fatal(1,"failed to drain abort");
  for(j=0;j<8;j=j+1)if(active[17*8+j]!==((17*8+j)^((17*8+j)>>8)^((17*8+j)>>15))%256)$fatal(1,"abort touched active");
  rd(17);
  $display("PASS: CD RAM byte packing, delayed ack, abort drain, active-bank safety");$finish;
 end
 initial begin #2000000;$fatal(1,"timeout");end
endmodule
