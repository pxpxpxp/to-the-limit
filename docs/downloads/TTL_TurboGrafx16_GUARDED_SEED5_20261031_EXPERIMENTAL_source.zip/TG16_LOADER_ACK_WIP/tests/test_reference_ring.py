#!/usr/bin/env python3
"""Check testbench-only ring reference vs physically shifted scan chain."""
for size in list(range(1,24))+[681]:
    slow=list(range(size)); storage=list(slow); head=0
    for i in range(10000):
        assert slow==[storage[(head+j)%size] for j in range(size)]
        v=slow[0] if i%3==0 else (i*117+19)&65535
        slow=slow[1:]+[v];storage[head]=v;head=(head+1)%size
    assert slow==[storage[(head+j)%size] for j in range(size)]
print('PASS: ring testbench model equals explicit shifting for 10,000 mixed rotates/imports, sizes 1..23 and 681')
