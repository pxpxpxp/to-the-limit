from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1]
s=(P/'TurboGrafx16.sv').read_text();a=s.index('reg         cd_dat_req;');b=s.index('\nreg [15:0] cd_dat;',a)
tb=(P/'tests/tb_hps_cd_clean_get.sv').read_text().replace('// INSERT_ACTUAL_TOP_HANDSHAKE',s[a:b])
with tempfile.TemporaryDirectory(prefix='tg16-hps-overlap-') as td:
 t=Path(td);(t/'tb.sv').write_text(tb);out=t/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_hps_cd_startup','-o',str(out),str(t/'tb.sv'),str(P/'rtl/hps_ext.v')],check=True)
 subprocess.run(['vvp',str(out)],check=True)
