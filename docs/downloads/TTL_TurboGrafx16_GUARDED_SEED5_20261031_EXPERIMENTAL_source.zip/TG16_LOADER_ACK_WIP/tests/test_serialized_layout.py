#!/usr/bin/env python3
"""Check register map word boundaries and absence of overlapping fields.

This checks inventory consistency, not that every live FPGA register is present.
"""
import collections, json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
x=json.loads((P/'savestate/serialized_layout.json').read_text())
used=collections.defaultdict(set)
for row in x['fields']:
    address=row['address']
    if 'kind' in row:
        width=row['width']; bit=row['bit_offset']
        assert 0 < width <= 16 and 0 <= bit and bit+width <= 16, row
        entries=[(address,set(range(bit,bit+width)))]
    else:
        assert row['width'] > 0, row
        entries=[(address+i,set(range(16))) for i in range(row.get('words',1))]
    for addr,bits in entries:
        assert 0 <= addr < x['register_words'], row
        assert not used[addr].intersection(bits), row
        used[addr].update(bits)
assert set(used)==set(range(x['register_words'])), sorted(set(range(x['register_words']))-set(used))
print(f"PASS: {x['register_words']} register words covered with no field overlaps")
