#!/usr/bin/env python3
"""Resumable full-capacity controller tests; individual commits survive interruption."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parents[1];D=P/'savestate/audio_init_validation/segmented';D.mkdir(parents=True,exist_ok=True)
files=['tests/tb_controller_segmented.sv','rtl/ninja_savestate.sv','rtl/adpcm_pack_engine.sv','rtl/word_scan_pack_engine.sv','rtl/cd_ram_pack_engine.sv','savestate/snapshot_file.py','savestate/serialized_layout.json']
h=hashlib.sha256()
for f in files:h.update(f.encode()+b'\0'+(P/f).read_bytes())
identity=h.hexdigest();(D/'source_identity.json').write_text(json.dumps({'sha256':identity,'files':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files}},indent=2)+'\n')
out=D/'segmented.vvp';subprocess.run(['iverilog','-g2012','-s','tb_controller_segmented','-o',str(out),*[str(P/f) for f in files[:5]]],check=True)
for part in range(12):
 marker=D/f'part{part:02d}.json';log=D/f'part{part:02d}.log';dep=None
 if part>=4:
  dep=D/f'slot{part-4 if part<8 else 3}.ss'
  if not dep.exists():raise SystemExit(f'missing prerequisite {dep}')
  dep_hash=hashlib.sha256(dep.read_bytes()).hexdigest()
 else:dep_hash=None
 expected={'source':identity,'part':part,'dependency_sha256':dep_hash}
 if marker.exists():
  try:
   m=json.loads(marker.read_text())
   saved_ok=part>=4 or ((D/f'slot{part}.ss').exists() and hashlib.sha256((D/f'slot{part}.ss').read_bytes()).hexdigest()==m.get('output_sha256'))
   if all(m.get(k)==v for k,v in expected.items()) and saved_ok:
    print(f'SKIP verified completed part {part}',flush=True);continue
  except (ValueError,OSError):pass
  marker.unlink(missing_ok=True)
 print(f'START part {part} {time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}',flush=True)
 with log.open('w') as f:r=subprocess.run(['stdbuf','-oL','-eL','vvp',str(out),f'+PART={part}'],cwd=D,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print(log.read_text(errors='replace')[-5000:]);raise SystemExit(f'part {part} exit {r.returncode}')
 if part<4:
  result=subprocess.run([sys.executable,str(P/'savestate/snapshot_file.py'),str(D/f'slot{part}.ss')],capture_output=True,text=True)
  with log.open('a') as f:f.write(result.stdout+result.stderr)
  if result.returncode:raise SystemExit(f'part {part}: invalid output image')
  expected['output_sha256']=hashlib.sha256((D/f'slot{part}.ss').read_bytes()).hexdigest()
 tmp=marker.with_suffix('.tmp');tmp.write_text(json.dumps(expected,indent=2)+'\n');os.replace(tmp,marker)
 print(f'PASS part {part}',flush=True)
print('PASS: all 12 full-size segmented controller phases; separate files model HPS and DDR, not hardware',flush=True)
