#!/usr/bin/env python3
"""Extract and exercise exact production reset/snapshot control (digital simulation)."""
from pathlib import Path
import re,subprocess,tempfile
P=Path(__file__).resolve().parents[1];s=(P/'TurboGrafx16.sv').read_text()
def get(p):
 m=re.search(p,s,re.S);assert m,p;return m.group(0)
parts=[get(r'wire reset_sys_request;.*?wire reset = .*?;'),get(r'reg \[3:0\] ss_restore_warm_count = 0;.*?assign ss_machine_freeze\s*=.*?;'),get(r'reg ss_fault_pending=0,ss_cold_pending=0;.*?end\nend'),get(r'assign ss_load_commit\s*=.*?;')]
parts.insert(1,'wire ss_load_commit;')
tb=(P/'tests/tb_reset_request_sync.sv').read_text().replace('// INSERT_EXACT_PRODUCTION_RESET_CONTROL','\n'.join(parts))
# The physical raw request enters only the conditioner; no raw consumer exists.
assert len(re.findall(r'\bRESET\b',re.sub(r'//[^\n]*','',s)))==2  # raw conditioner input and PCE formal port
with tempfile.TemporaryDirectory(prefix='tg16-reset-sync-') as d:
 d=Path(d);f=d/'tb.sv';f.write_text(tb);out=d/'sim.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_reset_request_sync','-o',str(out),str(f),str(P/'rtl/reset_request_sync.sv')],check=True)
 subprocess.run(['vvp',str(out)],check=True)
