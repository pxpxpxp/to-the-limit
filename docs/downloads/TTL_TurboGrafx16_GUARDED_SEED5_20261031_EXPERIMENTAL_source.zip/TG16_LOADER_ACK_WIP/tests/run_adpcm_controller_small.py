#!/usr/bin/env python3
"""Small controller model + independent 64-bit ADPCM image/CRC check."""
from pathlib import Path
import struct,subprocess,tempfile,zlib
P=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='tg16-adpcm-ctrl-') as td:
 t=Path(td);vvp=t/'test.vvp'
 subprocess.run(['iverilog','-g2012','-s','tb_adpcm_controller_small','-o',str(vvp),str(P/'tests/tb_adpcm_controller_small.sv'),str(P/'rtl/ninja_savestate.sv'),str(P/'rtl/adpcm_pack_engine.sv'),str(P/'rtl/word_scan_pack_engine.sv'),str(P/'rtl/cd_ram_pack_engine.sv')],check=True)
 subprocess.run(['vvp',str(vvp)],cwd=t,check=True)
 d=(t/'adpcm_small.ss').read_bytes();w=struct.unpack('<20Q',d)
 assert len(d)==20*8 and w[0]>>32==38 and w[1]==0x54474c5353000002 and w[2]==0x1020304050607080
 assert w[3]==((0x42<<32)|0x1234abcd) and w[4]>>32==15
 payload=b''.join(struct.pack('<Q',v) for v in w[5:])
 assert (w[7]>>16)==0  # final core group has three padded 16-bit lanes
 assert zlib.crc32(payload)==(w[4]&0xffffffff)
 for i in range(128):
  actual=(w[8+i//16]>>(4*(i%16)))&15
  assert actual==((i^(i>>3)^(4*7))&15),(i,actual)
 for i in range(32):
  assert ((w[16+i//8]>>(8*(i%8)))&255)==(i^(4*37))&255
 print('PASS: independent compact core/ADPCM/CD RAM file order, padding, length, header, and zlib CRC')
