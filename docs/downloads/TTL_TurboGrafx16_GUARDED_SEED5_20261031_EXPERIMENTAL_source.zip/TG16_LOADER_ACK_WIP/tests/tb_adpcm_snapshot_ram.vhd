library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity tb_adpcm_snapshot_ram is end entity;
architecture test of tb_adpcm_snapshot_ram is
 signal clk:std_logic:='0';signal a,sa:std_logic_vector(16 downto 0):=(others=>'0');
 signal d,sd,q,sq:std_logic_vector(3 downto 0):=(others=>'0');
 signal we,freeze,save,load,rwe,swe:std_logic:='0';signal ra:std_logic_vector(14 downto 0):=(others=>'0');
 signal rdi,rdo:std_logic_vector(15 downto 0):=(others=>'0');
begin
 clk<=not clk after 5 ns;
 dut:entity work.adpcm_snapshot_ram generic map(SS_REG_BASE=>625) port map(
 CLK=>clk,ADDRESS_A=>a,DATA_A=>d,WREN_A=>we,Q_A=>q,
 SS_FREEZE=>freeze,SS_SAVE=>save,SS_LOAD=>load,SS_RADDR=>ra,SS_RDI=>rdi,SS_RWE=>rwe,SS_RDO=>rdo,
 SS_ADDR=>sa,SS_DI=>sd,SS_WE=>swe,SS_DO=>sq);
 process
 procedure tick is begin wait until rising_edge(clk);wait until falling_edge(clk);end;
 begin
  -- Seed 16 cells in active storage.
  for i in 0 to 15 loop a<=std_logic_vector(to_unsigned(i,17));d<=std_logic_vector(to_unsigned(i,4));we<='1';tick;end loop;
  we<='0';a<=std_logic_vector(to_unsigned(7,17));tick;assert q=x"7" severity failure;
  freeze<='1';save<='1';tick;save<='0';tick;ra<=std_logic_vector(to_unsigned(625,15));wait for 1 ns;
  assert rdo(3 downto 0)=x"7" report "failed to capture active output latch" severity failure;
  -- Partial stage, no commit; active image must remain unchanged.
  for i in 0 to 7 loop sa<=std_logic_vector(to_unsigned(i,17));sd<=x"f";swe<='1';tick;end loop;
  swe<='0';freeze<='0';tick;
  for i in 0 to 15 loop a<=std_logic_vector(to_unsigned(i,17));tick;assert q=std_logic_vector(to_unsigned(i,4)) report "abort modified active bank" severity failure;end loop;
  -- Stage a full image; import saved output latch into both bank shadows.
  a<=std_logic_vector(to_unsigned(7,17));tick;freeze<='1';save<='1';tick;save<='0';tick;
  for i in 0 to 15 loop sa<=std_logic_vector(to_unsigned(i,17));sd<=std_logic_vector(to_unsigned(15-i,4));swe<='1';tick;end loop;
  swe<='0';ra<=std_logic_vector(to_unsigned(625,15));rdi<=x"0007";rwe<='1';tick;rwe<='0';
  load<='1';tick;load<='0';tick;assert q=x"7" report "restored read latch lost on bank swap" severity failure;
  freeze<='0';tick;
  for i in 0 to 15 loop a<=std_logic_vector(to_unsigned(i,17));tick;assert q=std_logic_vector(to_unsigned(15-i,4)) report "committed bank mismatch" severity failure;end loop;
  -- An erroneous load while not frozen must not swap banks.
  load<='1';tick;load<='0';a<=std_logic_vector(to_unsigned(0,17));tick;assert q=x"f" report "unfrozen swap" severity failure;
  report "PASS: ADPCM dual-bank staged restore, abort and read latch" severity note;std.env.finish;
 end process;
end architecture;
