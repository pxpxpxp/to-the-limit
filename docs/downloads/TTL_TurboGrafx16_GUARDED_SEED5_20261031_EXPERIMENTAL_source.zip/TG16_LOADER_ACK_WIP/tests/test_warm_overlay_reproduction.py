#!/usr/bin/env python3
"""Regenerate exact top/controller sources from retained baseline and overlay."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
P=Path(__file__).resolve().parents[1];D=P/'savestate/warm_hold_validation'
old=json.loads((D/'base_build_inputs.json').read_text());new=json.loads((P/'savestate/build-inputs.json').read_text())
assert set(old)==set(new) and len(new)==114
changed={n for n in old if old[n]!=new[n]};assert changed=={'TurboGrafx16.sv','rtl/ninja_savestate.sv'},changed
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'base_TurboGrafx16.sv')==old['TurboGrafx16.sv']
assert sha(D/'base_ninja_savestate.sv')==old['rtl/ninja_savestate.sv']
with tempfile.TemporaryDirectory(prefix='tg16-warm-repro-') as td:
 t=Path(td);(t/'rtl').mkdir();shutil.copy2(D/'base_TurboGrafx16.sv',t/'TurboGrafx16.sv');shutil.copy2(D/'base_ninja_savestate.sv',t/'rtl/ninja_savestate.sv')
 subprocess.run(['patch','-s','-p1','-i',str(D/'warm_hold_overlay.patch')],cwd=t,check=True)
 for n in changed:assert (t/n).read_bytes()==(P/n).read_bytes(),n
for n,h in new.items():assert sha(P/n)==h,n
print('PASS: exact warm-hold overlay regenerates top/controller; all 114 build inputs match')
