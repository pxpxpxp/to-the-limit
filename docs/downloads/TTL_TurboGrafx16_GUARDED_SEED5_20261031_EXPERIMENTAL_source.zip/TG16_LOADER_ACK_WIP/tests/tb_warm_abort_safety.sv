`timescale 1ns/1ps
module tb_warm_abort_safety;
 reg clk_sys=0,ram_clk=0; always #10 clk_sys=~clk_sys; always #5 ram_clk=~ram_clk;
 reg reset=0,cart_download=0,ss_config_changed=0,ss_available=1;
 reg save_button=0,load_button=0;
 wire ss_freeze,ss_save,ss_load,ss_fault_reset,ss_cdram_hold,ss_machine_freeze,ss_load_commit;
 wire valid;wire[3:0] error;
 wire[17:0] scan_addr,cd_ram_addr;wire[16:0] adpcm_addr;wire[3:0] adpcm_din;wire adpcm_we;
 wire[7:0] cd_ram_din;wire cd_ram_write,cd_ram_req;wire[15:0] scan_din;wire scan_we,reg_rotate;
 wire take_ddr,ram_rd,ram_we;wire[28:0] ram_addr;wire[63:0] ram_din;
 // INSERT_PRODUCTION_HOLD_AND_FAULT
 // INSERT_PRODUCTION_COMMIT
 // INSERT_PRODUCTION_BANKS
 ninja_savestate #(.RAM_WORDS(5),.ADPCM_WORDS(8),.CDRAM_WORDS(4),.REGISTER_WORDS(4),.SCHEMA(64'h1)) dut(
 .clk(clk_sys),.ram_clk(ram_clk),.reset(reset|cart_download|ss_config_changed),
 .enabled(ss_available&&!ss_fault_pending),.safe(!ss_restore_warm_hold),.start_block(ss_restore_warm_hold),.save_button(save_button),.load_button(load_button),
 .slot(2'b00),.rom_id(32'h1234),.config_id(16'h42),.freeze(ss_freeze),.save_pulse(ss_save),.load_pulse(ss_load),
 .valid(valid),.fault_reset(ss_fault_reset),.error(error),.scan_addr(scan_addr),.scan_dout(16'h0),.scan_din(scan_din),.scan_we(scan_we),.reg_rotate(reg_rotate),
 .adpcm_addr(adpcm_addr),.adpcm_din(adpcm_din),.adpcm_we(adpcm_we),.adpcm_dout(4'h0),.cd_ram_addr(cd_ram_addr),.cd_ram_din(cd_ram_din),.cd_ram_write(cd_ram_write),.cd_ram_req(cd_ram_req),.cd_ram_hold(ss_cdram_hold),.cd_ram_ack(1'b0),.cd_ram_dout(8'h0),
 .normal_idle(1'b1),.ram_busy(1'b0),.ram_ready(1'b0),.ram_dout(64'h0),.take_ddr(take_ddr),.ram_addr(ram_addr),.ram_din(ram_din),.ram_rd(ram_rd),.ram_we(ram_we));
 integer edge_no=0,commit_edge=-1,commits=0,cases=0,starts=0;reg [4:0] div_audio=0;reg psg_ce=0,adpcm_ce=0;reg pce_reset_observed=0,fault_seen=0;integer last_commit;
 always @(ss_restore_warm_hold) if($time>0 && clk_sys!==1'b1)
   $fatal(1,"registered hold changed away from clk_sys rising edge");
 always @(posedge clk_sys) begin
   edge_no=edge_no+1;
   if(ss_load_commit && (!ss_restore_warm_hold || !ss_freeze))$fatal(1,"hold/raw freeze not primed before accepted commit");
   if(ss_load_commit) begin commit_edge=edge_no;commits=commits+1;end
   if(ss_save)starts=starts+1;
   if(commit_edge>=0 && !ss_machine_freeze && edge_no-commit_edge<9)
      $fatal(1,"resume too early: age=%0d",edge_no-commit_edge);
   if(!ss_machine_freeze && (reset || ss_fault_reset || ss_fault_pending))pce_reset_observed=1;
   if(ss_fault_reset)fault_seen=1;
   // Model the original divider hold/restart structure; its values cannot
   // shorten the separate hold. Test all 32 div values and four CE pairs.
   if(!ss_machine_freeze) begin div_audio<=div_audio+1'b1;psg_ce<=&div_audio[3:0];adpcm_ce<=&div_audio[4:0];end
 end
 task one_case(input integer mode,input integer phase,input integer div,input integer ce_pair,input integer watchdog_on_commit,input integer hold_len);
 integer base,guard;reg old_bram,old_cd;begin
  @(negedge clk_sys); reset=0;ss_available=1;commit_edge=-1;pce_reset_observed=0;fault_seen=0;
  wait(!ss_machine_freeze && !ss_fault_pending);repeat(2)@(negedge clk_sys);
  div_audio=div;psg_ce=ce_pair[0];adpcm_ce=ce_pair[1];
  // Inject the production controller immediately before RESTORE; hardware
  // bank/DDR data are not modeled, but RESTORE/WARM/abort RTL is actual.
  dut.state=4'd9;dut.freeze=1;dut.applying=1;dut.loading=1;dut.delay_count=0; base=commits; old_bram=ss_bram_bank;old_cd=ss_cdram_bank;
  @(posedge clk_sys);#1; if(!ss_load_commit)$fatal(1,"missing commit at RESTORE");
  if(watchdog_on_commit) dut.watchdog={28{1'b1}};
  @(posedge clk_sys);#1; if(commits!=base+1 || ss_restore_warm_count!=8 || !ss_machine_freeze)$fatal(1,"commit hold not armed");
  if(ss_bram_bank===old_bram || ss_cdram_bank===old_cd)$fatal(1,"accepted commit did not atomically swap both banks");
  if(watchdog_on_commit && ss_freeze)$fatal(1,"watchdog did not clear controller freeze on commit");
  // phase0 cancels at first edge following commit, phase8 after normal WARM.
  repeat(phase+1)@(negedge clk_sys);
  if(mode==0)ss_available=0;else reset=1;
  // A button pressed during retained hold must not start another operation.
  save_button=1; repeat(hold_len)@(negedge clk_sys);ss_available=1;reset=0;save_button=0;
  if(ss_restore_warm_hold && dut.state!=0 && (watchdog_on_commit || phase<7))$fatal(1,"new request accepted during hold");
  guard=0;while(ss_machine_freeze||ss_fault_pending||ss_fault_reset)begin @(negedge clk_sys);guard=guard+1;if(guard>80)$fatal(1,"deadlock");end
  if(commits!=base+1 || ss_bram_bank===old_bram || ss_cdram_bank===old_cd)$fatal(1,"duplicate or missing commit/bank swap");
  if(phase<7 && (!fault_seen || !pce_reset_observed))$fatal(1,"abort fault reset lost phase=%0d mode=%0d",phase,mode);
  cases=cases+1;
 end endtask
 task precommit_case(input integer mode,input integer div,input integer ce_pair);
 integer base,guard;reg old_bram,old_cd;begin
  @(negedge clk_sys); reset=0;ss_available=1;commit_edge=-1;pce_reset_observed=0;fault_seen=0;
  wait(!ss_machine_freeze && !ss_fault_pending);repeat(2)@(negedge clk_sys);
  div_audio=div;psg_ce=ce_pair[0];adpcm_ce=ce_pair[1];
  dut.state=4'd9;dut.freeze=1;dut.applying=1;dut.loading=1;dut.delay_count=0;
  base=commits;old_bram=ss_bram_bank;old_cd=ss_cdram_bank;
  @(posedge clk_sys);#1;if(!ss_load)$fatal(1,"RESTORE pulse missing");
  @(negedge clk_sys);if(mode==0)ss_available=0;else reset=1;
  @(posedge clk_sys);#1;if(commits!=base || !ss_restore_warm_hold || ss_bram_bank!==old_bram || ss_cdram_bank!==old_cd)$fatal(1,"precommit abort applied state or lost primed hold");
  @(negedge clk_sys);ss_available=1;reset=0;guard=0;
  while(ss_machine_freeze||ss_fault_pending||ss_fault_reset)begin @(negedge clk_sys);guard=guard+1;if(guard>80)$fatal(1,"precommit reset deadlock");end
  if(!fault_seen || !pce_reset_observed)$fatal(1,"precommit fault reset lost");cases=cases+1;
 end endtask
 task held_trigger_case(input integer scenario);
 integer base,base_starts,n;begin
  @(negedge clk_sys);reset=0;ss_available=1;save_button=0;load_button=0;commit_edge=-1;
  wait(!ss_machine_freeze && !ss_fault_pending);repeat(2)@(negedge clk_sys);
  // Existing high raw load/save button represents the original trigger held
  // throughout completion. Preserve controller's actual raw edge history.
  if(scenario==0)load_button=1;
  if(scenario==3)save_button=1;
  dut.old_load=load_button;dut.old_save=save_button;
  dut.state=4'd9;dut.freeze=1;dut.applying=1;dut.loading=1;dut.delay_count=0;
  base=commits;base_starts=starts;
  @(posedge clk_sys);#1;if(!ss_load_commit)$fatal(1,"held-case commit missing");
  @(posedge clk_sys);#1;if(commits!=base+1 || !ss_restore_warm_hold)$fatal(1,"held-case arm failure");
  if(scenario==1||scenario==2)begin
    @(negedge clk_sys);load_button=1;repeat(2)@(negedge clk_sys);
    if(scenario==1)load_button=0; // pressed and released entirely in hold
  end
  repeat(40)@(negedge clk_sys);
  if(commits!=base+1 || starts!=base_starts || ss_machine_freeze || dut.state!=0)
    $fatal(1,"held/in-hold trigger retriggered scenario=%0d state=%0d starts=%0d",scenario,dut.state,starts-base_starts);
  load_button=0;save_button=0;repeat(3)@(negedge clk_sys);
  // A genuinely fresh press after hold must still start normally.
  load_button=1;n=0;while(starts==base_starts && n<8)begin @(negedge clk_sys);n=n+1;end
  if(starts!=base_starts+1)$fatal(1,"fresh load after hold was lost scenario=%0d",scenario);
  load_button=0;reset=1;@(negedge clk_sys);reset=0;repeat(12)@(negedge clk_sys);cases=cases+1;
 end endtask
 integer m,p,d,c,w,h,q;
 initial begin repeat(3)@(negedge clk_sys);for(m=0;m<2;m=m+1)for(p=0;p<9;p=p+1)for(d=0;d<32;d=d+1)for(c=0;c<4;c=c+1)for(w=0;w<2;w=w+1)for(h=0;h<4;h=h+1)one_case(m,p,d,c,w,(h==0)?1:(h==1)?3:(h==2)?8:16);
 for(m=0;m<2;m=m+1)for(d=0;d<32;d=d+1)for(c=0;c<4;c=c+1)precommit_case(m,d,c);
 for(q=0;q<4;q=q+1)held_trigger_case(q);
 $display("PASS: %0d exact-controller reset/guard abort cases incl. commit-edge watchdog, all dividers/CE pairs, eight retained freeze edges, one atomic commit, precommit abort, raw held/pressed triggers and fresh-press recovery",cases);$finish;end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule
