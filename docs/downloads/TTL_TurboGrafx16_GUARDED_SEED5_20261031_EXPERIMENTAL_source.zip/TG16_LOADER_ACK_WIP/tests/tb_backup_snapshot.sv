`timescale 1ns/1ps
// Testbench is paired with run_backup_snapshot.py, which extracts the actual
// backup-RAM instantiation and scan/latch logic from TurboGrafx16.sv.
module tb_backup_snapshot;
reg clk_sys=0; always #5 clk_sys=~clk_sys;
reg ss_freeze=0, ss_save=0, ss_load=0, ss_abort=0, ss_we=0;
reg [17:0] ss_addr=0; reg [15:0] ss_din=0;
reg [10:0] bram_addr=0; reg [7:0] bram_data=0; reg bram_wr=0;
reg [3:0] defbram=15;reg [31:0] sd_lba=0;reg [7:0] sd_buff_addr=0;
reg [15:0] sd_buff_dout=0;reg sd_buff_wr=0,sd_ack=0;
reg [15:0] defval[4];
initial begin defval[0]=16'h5548;defval[1]=16'h4d42;defval[2]=16'h8800;defval[3]=16'h8010;end
wire [7:0] bram_q;wire [15:0] scan_word;
backup_snapshot_dut dut(.*);
reg [15:0] saved[1023:0];reg [7:0] saved_latch; integer i;
initial begin
  // Distinct byte values expose 8/16-bit port order errors.
  for(i=0;i<2048;i=i+1) begin @(negedge clk_sys); bram_addr=i; bram_data=(i*37+9)&255; bram_wr=1; end
  @(negedge clk_sys); bram_wr=0; bram_addr=137;
  repeat(2) @(negedge clk_sys); saved_latch=bram_q;
  ss_freeze=1;ss_save=1; @(negedge clk_sys);ss_save=0;
  for(i=0;i<1024;i=i+1) begin
    ss_addr=18'h38000+i; repeat(2) @(negedge clk_sys);saved[i]=scan_word;
    if(saved[i] !== {8'((2*i+1)*37+9),8'((2*i)*37+9)}) $fatal(1,"scan mismatch %0d",i);
  end
  // Interrupted apply: write only part of the inactive bank, never commit.
  for(i=0;i<32;i=i+1) begin ss_addr=18'h38000+i;ss_din=0;ss_we=1; @(negedge clk_sys);end
  // Reset/config/eligibility abort coincident with the registered commit
  // request must suppress the bank swap.
  ss_we=0;ss_abort=1;ss_load=1; @(negedge clk_sys);
  ss_load=0;ss_abort=0;ss_freeze=0;repeat(2) @(negedge clk_sys);
  for(i=0;i<2048;i=i+1) begin bram_addr=i; @(negedge clk_sys); if(bram_q!==8'((i*37+9)&255)) $fatal(1,"aborted apply changed active bank %0d",i);end
  bram_addr=137;repeat(2) @(negedge clk_sys);ss_freeze=1;ss_save=1;@(negedge clk_sys);ss_save=0;
  // Clobber via scan and attempt a CPU write during freeze.
  bram_addr=137;bram_data=8'hee;bram_wr=1;
  for(i=0;i<1024;i=i+1) begin ss_addr=18'h38000+i;ss_din=0;ss_we=1; @(negedge clk_sys);end
  for(i=0;i<1024;i=i+1) begin ss_addr=18'h38000+i;ss_din=saved[i]; @(negedge clk_sys);end
  ss_addr=18'h38400;ss_din={8'd0,saved_latch}; @(negedge clk_sys);ss_we=0;
  ss_load=1; @(negedge clk_sys); ss_load=0;
  if(bram_q!==saved_latch)$fatal(1,"frozen latch lost");
  bram_wr=0;bram_addr=5; @(negedge clk_sys); ss_freeze=0;
  if(bram_q!==saved_latch)$fatal(1,"saved latch not held through resume");
  @(negedge clk_sys); if(bram_q!==8'((5*37+9)&255))$fatal(1,"normal read did not resume");
  for(i=0;i<2048;i=i+1) begin bram_addr=i; @(negedge clk_sys); if(bram_q!==8'((i*37+9)&255)) $fatal(1,"recovery byte %0d",i);end
  // SD backup writes must target the currently active bank after a swap.
  @(negedge clk_sys);sd_buff_addr=10;sd_buff_dout=16'hb1a2;sd_buff_wr=1;sd_ack=1;
  @(negedge clk_sys);sd_buff_wr=0;sd_ack=0;bram_addr=20;
  @(negedge clk_sys);if(bram_q!==8'ha2)$fatal(1,"SD byte zero missed active bank");
  bram_addr=21; @(negedge clk_sys);if(bram_q!==8'hb1)$fatal(1,"SD byte one missed active bank");
  // Restore once more, proving the bank swap works in the opposite direction.
  ss_freeze=1;ss_save=1; @(negedge clk_sys);ss_save=0;
  for(i=0;i<1024;i=i+1) begin ss_addr=18'h38000+i;ss_din=saved[i];ss_we=1; @(negedge clk_sys);end
  ss_addr=18'h38400;ss_din={8'd0,saved_latch};@(negedge clk_sys);ss_we=0;
  ss_load=1;@(negedge clk_sys);ss_load=0;ss_freeze=0;
  for(i=0;i<2048;i=i+1) begin bram_addr=i; @(negedge clk_sys); if(bram_q!==8'((i*37+9)&255))$fatal(1,"second swap byte %0d",i);end
  $display("PASS: backup-RAM packed scan, interrupted apply, two bank swaps, SD write, freeze and read latch");$finish;
end
endmodule

// Behavioral substitute for Altera's bidirectional asymmetric RAM primitive.
module dpram_difclk #(parameter AA=11,DA=8,AB=10,DB=16)(
 input clock0,clock1,input [AA-1:0] address_a,input [DA-1:0] data_a,input wren_a,input enable_a,
 output reg [DA-1:0] q_a,input [AB-1:0] address_b,input [DB-1:0] data_b,input wren_b,output reg [DB-1:0] q_b);
reg [7:0] mem[0:2047];
always @(posedge clock0) if(enable_a) begin if(wren_a) begin mem[address_a]<=data_a;q_a<=data_a;end else q_a<=mem[address_a];end
always @(posedge clock1) begin if(wren_b) begin mem[2*address_b]<=data_b[7:0];mem[2*address_b+1]<=data_b[15:8];q_b<=data_b;end else q_b<={mem[2*address_b+1],mem[2*address_b]};end
endmodule
