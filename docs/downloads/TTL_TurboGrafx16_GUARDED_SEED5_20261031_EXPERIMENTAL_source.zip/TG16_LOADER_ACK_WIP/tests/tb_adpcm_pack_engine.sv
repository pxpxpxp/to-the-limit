`timescale 1ns/1ps
module tb_adpcm_pack_engine;
 reg clk=0;always #5 clk=~clk;
 reg reset=1,freeze=0,start_read=0,start_write=0;
 reg [12:0] group_addr=0; reg [63:0] word_in=0;
 wire [16:0] cell_addr;wire [3:0] cell_din;wire cell_we;reg [3:0] cell_dout=0;
 wire [63:0] word_out;wire busy,done,aborted;
 adpcm_pack_engine dut(.*);
 reg [3:0] active[0:131071],stage[0:131071]; integer i,k;
 always @(posedge clk) begin
   cell_dout<=active[cell_addr];
   if(cell_we) stage[cell_addr]<=cell_din;
 end
 task read_word(input integer group);
 begin
   @(negedge clk);group_addr=group;start_read=1;@(negedge clk);start_read=0;
   wait(done);@(negedge clk);
   for(k=0;k<16;k=k+1) if(word_out[k*4+:4]!==active[group*16+k]) $fatal(1,"read mismatch group %0d nibble %0d",group,k);
 end endtask
 task write_word(input integer group,input [63:0] data);
 begin
   @(negedge clk);group_addr=group;word_in=data;start_write=1;@(negedge clk);start_write=0;
   wait(done);@(negedge clk);
   for(k=0;k<16;k=k+1) if(stage[group*16+k]!==data[k*4+:4]) $fatal(1,"write mismatch group %0d nibble %0d",group,k);
 end endtask
 initial begin
   for(i=0;i<131072;i=i+1)begin active[i]=(i^(i>>4)^(i>>11))&15;stage[i]=0;end
   repeat(2)@(negedge clk);reset=0;freeze=1;
   for(i=0;i<64;i=i+1) begin read_word((i*127)%8192);write_word((i*127)%8192,64'hfedcba9876543210^i);end
   read_word(8191);write_word(8191,64'h0123456789abcdef);
   // Deliberately abort a staged write. The caller's active bank must remain intact.
   @(negedge clk);group_addr=17;word_in=64'hffffffffffffffff;start_write=1;@(negedge clk);start_write=0;
   repeat(4)@(negedge clk);freeze=0;@(negedge clk);
   if(!aborted || busy || cell_we) $fatal(1,"abort did not stop writes");
   for(k=0;k<16;k=k+1) if(active[17*16+k]!==((17*16+k)^((17*16+k)>>4)^((17*16+k)>>11))%16) $fatal(1,"active bank changed during abort");
   freeze=1;read_word(17);
   // Reject simultaneous starts rather than guessing command priority.
   @(negedge clk);start_read=1;start_write=1;@(negedge clk);start_read=0;start_write=0;
   if(busy || done || cell_we) $fatal(1,"ambiguous start accepted");
   $display("PASS: ADPCM 16-nibble pack/unpack, boundaries, abort and command rejection");$finish;
 end
 initial begin #1000000;$fatal(1,"timeout");end
endmodule
