from pathlib import Path
import subprocess,tempfile,re
p=Path(__file__).resolve().parents[1]; old=p/'savestate/audio_preinit_baseline'
def wrapper(root,suffix):
 s=(root/'TurboGrafx16.sv').read_text();a=s.index('localparam [3:0] comp_f1');b=s.index('assign AUDIO_MIX = 0;',a)+len('assign AUDIO_MIX = 0;')
 prefix=f'''module audio_{suffix}(input clk_sys,ss_freeze,ss_save,ss_load_commit,ss_we,ss_reg_rotate,
input [17:0] ss_addr,input [15:0] ss_din,input [63:0] status,input [15:0] cdda_sl,cdda_sr,psg_sl,psg_sr,adpcm_s,
output [15:0] AUDIO_L,AUDIO_R,output AUDIO_S,AUDIO_MIX,output [15:0] scan_data);
wire CDDA_EN=1,PSG_EN=1,ADPCM_EN=1;wire ss_machine_freeze=ss_freeze;\n'''
 body=s[a:b].replace('tgfx_IIR_filter #(',f'tgfx_IIR_filter_{suffix} #(')
 f=(root/'rtl/tgfx_iir_filter.v').read_text().replace('tgfx_iir_filter_tap',f'tgfx_iir_filter_tap_{suffix}').replace('tgfx_IIR_filter',f'tgfx_IIR_filter_{suffix}')
 return prefix+body+'\nassign scan_data=ss_audio_dout; endmodule\n'+f
with tempfile.TemporaryDirectory(prefix='tgfx-audio-equiv-') as d:
 d=Path(d);(d/'old.sv').write_text(wrapper(old,'old'));(d/'new.sv').write_text(wrapper(p,'new'))
 subprocess.run(['iverilog','-g2012','-s','tb_audio_old_new','-o',str(d/'sim.vvp'),str(p/'tests/inventory/tb_audio_old_new.sv'),str(d/'old.sv'),str(d/'new.sv')],check=True)
 subprocess.run(['vvp',str(d/'sim.vvp')],check=True)
