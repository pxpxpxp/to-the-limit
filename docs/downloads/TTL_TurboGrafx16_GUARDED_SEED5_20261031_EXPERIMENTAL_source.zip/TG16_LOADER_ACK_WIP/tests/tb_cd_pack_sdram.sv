`timescale 1ns/1ps
module tb_cd_pack_sdram;
 reg clk=0,sysclk=0;always #5 clk=~clk;always #10 sysclk=~sysclk;
 reg init=1,clkref=0,rd=0,ss_save=0,ss_load=0,ss_reg_we=0;
 reg [14:0] ss_reg_addr=578;reg [15:0] ss_reg_din=0;wire [15:0] ss_reg_dout;
 reg freeze=0,cancel=0,reset=1,start_read=0,start_write=0; reg [14:0] group_addr=0;reg [63:0] word_in=0;
 wire [17:0] cell_addr;wire [7:0] cell_din;wire cell_write,cell_req,cell_ack;wire [7:0] cell_dout;
 wire [63:0] word_out;wire hold_req,busy,done,aborted;
 wire ss_scan_freeze=freeze|hold_req; wire [24:0] ss_scan_addr={3'b001,3'b100,cell_write,cell_addr};
 cd_ram_pack_engine pack(.clk(sysclk),.reset(reset),.freeze(freeze),.cancel(cancel),.start_read(start_read),.start_write(start_write),.group_addr(group_addr),.word_in(word_in),.cell_addr(cell_addr),.cell_din(cell_din),.cell_write(cell_write),.cell_req(cell_req),.cell_ack(cell_ack),.cell_dout(cell_dout),.word_out(word_out),.hold_req(hold_req),.busy(busy),.done(done),.aborted(aborted));
 reg [24:0] raddr=0;wire ready;wire [7:0] dout;
 tri [15:0] dq;wire [12:0] addr;wire [1:0] ba;wire nras,ncas,nwe;
 sdram dut(.ss_reg_addr(ss_reg_addr),.ss_reg_din(ss_reg_din),.ss_reg_we(ss_reg_we),.ss_reg_dout(ss_reg_dout),.ss_save(ss_save),.ss_load(ss_load),
  .ss_scan_freeze(ss_scan_freeze),.ss_scan_req(cell_req),.ss_scan_wr(cell_write),.ss_scan_addr(ss_scan_addr),.ss_scan_din(cell_din),.ss_scan_ack(cell_ack),.ss_scan_dout(cell_dout),
  .init(init),.clk(clk),.clkref(clkref),.raddr(raddr),.rd(rd),.rd_rdy(ready),.dout(dout),.waddr(25'd0),.din(16'd0),.we(1'b0),.we_req(1'b0),.we_ack(),
  .SDRAM_DQ(dq),.SDRAM_A(addr),.SDRAM_BA(ba),.SDRAM_nCS(),.SDRAM_nWE(nwe),.SDRAM_nRAS(nras),.SDRAM_nCAS(ncas),.SDRAM_DQML(),.SDRAM_DQMH(),.SDRAM_CLK(),.SDRAM_CKE());
 function [15:0] contents(input [23:0] w);contents=w[15:0]^{w[23:16],w[23:16]}^16'ha75c;endfunction
 reg [15:0] mem[0:262143];reg [12:0] row[0:3];reg [15:0] read_data,drive_data;reg [1:0] pending=0;reg drive=0;
 reg [23:0] wa;integer since_refresh=0,refreshes=0,i,t;reg track=0;reg [7:0] original_dout;
 assign dq=drive?drive_data:16'hzzzz;
 always @(negedge clk) begin
  drive<=pending[1];if(pending[1])drive_data<=read_data;pending<={pending[0],1'b0};
  if(track)begin
   since_refresh<=since_refresh+1;
   if({nras,ncas,nwe}==3'b001)begin since_refresh<=0;refreshes<=refreshes+1;end
   if(since_refresh>330)$fatal(1,"SDRAM refresh gap exceeded bound");
  end
  if({nras,ncas,nwe}==3'b011)row[ba]<=addr;
  if({nras,ncas,nwe}==3'b101)begin
   wa={ba,addr[8],row[ba],addr[7:0]};
   read_data<=((wa>=24'h300000)&&(wa<24'h340000))?mem[wa[17:0]]:contents(wa);pending[0]<=1;
  end
  if({nras,ncas,nwe}==3'b100)begin
   wa={ba,addr[8],row[ba],addr[7:0]};
   if(wa>=24'h300000&&wa<24'h340000)begin
    if(!addr[11])mem[wa[17:0]][7:0]<=dq[7:0];
    if(!addr[12])mem[wa[17:0]][15:8]<=dq[15:8];
   end else $fatal(1,"write outside CD banks %h",wa);
  end
 end
 function [7:0] byte_pattern(input integer x);byte_pattern=(x^(x>>8)^(x>>16))&255;endfunction

 integer j;reg [63:0] expected;
 task launch(input bit write_,input [14:0] group_,input [63:0] data_);
 begin @(negedge sysclk);group_addr=group_;word_in=data_;start_read=!write_;start_write=write_;
 @(negedge sysclk);start_read=0;start_write=0;wait(done);@(negedge sysclk);end endtask
 initial begin
  for(i=0;i<262144;i=i+1)mem[i]={byte_pattern(2*i+1),byte_pattern(2*i)};
  repeat(20)@(negedge clk);init=0;
  repeat(100)begin clkref=1;repeat(2)@(negedge clk);clkref=0;repeat(10)@(negedge clk);end
  raddr=25'h001234;rd=1;clkref=1;repeat(2)@(negedge clk);clkref=0;repeat(20)@(negedge clk);rd=0;repeat(10)@(negedge clk);original_dout=dout;
  reset=0;freeze=1;repeat(8)@(negedge clk);track=1;
  for(i=0;i<64;i=i+1) begin
   launch(0,i*503,0); for(j=0;j<8;j=j+1) if(word_out[j*8+:8]!==byte_pattern((i*503)*8+j)) $fatal(1,"pack read %0d/%0d",i,j);
   expected=64'hfedcba9876543210^i;launch(1,i*503,expected);
   for(j=0;j<8;j=j+1) if(mem[131072+(i*503)*4+j/2][8*(j%2)+:8]!==expected[j*8+:8]) $fatal(1,"pack write %0d/%0d",i,j);
  end
  launch(0,32767,0); for(j=0;j<8;j=j+1)if(word_out[j*8+:8]!==byte_pattern(262136+j)) $fatal(1,"last read");
  // Cancel an outstanding request: the physical freeze must remain asserted
  // until the actual SDRAM response traverses the CDC mailbox.
  @(negedge sysclk);group_addr=17;word_in=64'hffffffffffffffff;start_write=1;
  @(negedge sysclk);start_write=0;wait(cell_req!=cell_ack);cancel=1;freeze=0;
  #1;if(!hold_req||!ss_scan_freeze)$fatal(1,"lost freeze before drain");
  wait(aborted);@(negedge sysclk);cancel=0;if(hold_req)$fatal(1,"abort did not drain");
  for(j=0;j<8;j=j+1) if(mem[(17*8+j)/2][8*(j%2)+:8]!==byte_pattern(17*8+j))$fatal(1,"abort modified active bank");
  if(refreshes<2)$fatal(1,"missing refresh");if(dout!==original_dout)$fatal(1,"ROM latch changed");
  $display("PASS: production CD byte packer + SDRAM controller, CDC mailbox, 64 groups, bounded refresh, abort drain and bank safety");$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

module altddio_out #(parameter extend_oe_disable="",intended_device_family="",invert_output="",lpm_hint="",lpm_type="",oe_reg="",power_up_high="",width=1)
 (input [width-1:0] datain_h,datain_l,input outclock,output [width-1:0] dataout,input aclr,aset,oe,outclocken,sclr,sset);
 assign dataout=outclock?datain_h:datain_l;
endmodule
