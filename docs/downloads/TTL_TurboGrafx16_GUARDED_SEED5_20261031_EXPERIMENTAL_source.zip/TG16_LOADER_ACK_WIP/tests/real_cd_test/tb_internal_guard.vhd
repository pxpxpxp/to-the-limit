library ieee; use ieee.std_logic_1164.all;
entity tb_internal_guard is generic (MODE:natural:=0); end entity;
architecture test of tb_internal_guard is
 signal CLK : std_logic:='0';
 signal REG_SEL,RAM_SEL,CPU_CE,CD_STAT_GET,CD_DOUT_REQ,CD_DATA_WR,CD_AUDIO_WR,CD_SUBCD_WR : std_logic:='0';
 signal ADRAM_WE,FIFO_WR_REQ,SUBCD_FIFO_WR_REQ,SS_SCSI_FIFO_WRITE : std_logic:='0';
 signal EXT_WR_N,EXT_RD_N,FIFO_EMPTY,SUBCD_FIFO_EMPTY,SS_SCSI_IDLE : std_logic:='1';
 signal FIFO_RD_REQ,FIFO_SCLR,SUBCD_FIFO_RD_REQ,SUBCD_FIFO_SCLR:std_logic:='0';
 signal SS_CD_EVENT,SS_UNSAFE:std_logic;
 signal SS_UNSAFE_LATCH:std_logic:='0';
begin
 CLK<=not CLK after 5 ns;
 -- INSERT_PRODUCTION_GUARD
 process begin
  wait until falling_edge(CLK); wait for 1 ns;
  assert SS_UNSAFE='0' report "initial idle was unsafe" severity failure;
  case MODE is when 0=>ADRAM_WE<='1';when 1=>FIFO_WR_REQ<='1';when 2=>SUBCD_FIFO_WR_REQ<='1';when others=>SS_SCSI_FIFO_WRITE<='1';end case;
  wait for 1 ns; assert SS_UNSAFE='1' report "write not blocked before consuming edge" severity failure;
  wait until falling_edge(CLK);ADRAM_WE<='0';FIFO_WR_REQ<='0';SUBCD_FIFO_WR_REQ<='0';SS_SCSI_FIFO_WRITE<='0';
  wait for 1 ns;assert SS_UNSAFE='1' report "write history not latched" severity failure;
  report "PASS: internal ADPCM/FIFO write blocks snapshot before edge and latches, mode="&integer'image(MODE) severity note;
  std.env.finish;
 end process;
end architecture;
