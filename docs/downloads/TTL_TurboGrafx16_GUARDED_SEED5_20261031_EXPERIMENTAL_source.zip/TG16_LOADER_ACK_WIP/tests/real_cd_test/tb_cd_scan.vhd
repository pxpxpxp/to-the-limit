library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Actual cd/SCSI/MSM5205/CEGen RTL, with no-media-only primitive models.
-- The second CD instance is reset shortly before the simulated restore.
-- A real snapshot would have to restore its pending state, which it cannot.
entity tb_cd_scan is generic (CAPTURE_DELAY : natural := 2345); end entity;
architecture test of tb_cd_scan is
  signal clk : std_logic := '0';
  signal rst_ref, rst_reloaded : std_logic := '0';
  signal addr : std_logic_vector(20 downto 0) := (others=>'0');
  signal din : std_logic_vector(7 downto 0) := (others=>'0');
  signal dout_ref, dout_reloaded : std_logic_vector(7 downto 0);
  signal wr_n, rd_n : std_logic := '1';
  signal irq_ref, irq_reloaded, unsafe_ref, unsafe_reloaded : std_logic;
  signal freeze, ss_save, ss_load, rotate, rwe : std_logic := '0';
  signal saddr : std_logic_vector(14 downto 0) := (others=>'0');
  signal sdi, sdout : std_logic_vector(15 downto 0) := (others=>'0');
  type words_t is array(579 to 626) of std_logic_vector(15 downto 0);
  signal image : words_t;

begin
  clk <= not clk after 5 ns;
  golden : entity work.cd port map (
    SS_FREEZE=>freeze, SS_SAVE=>'0', SS_LOAD=>'0', SS_RDO=>open, SS_UNSAFE=>unsafe_ref,
    RST_N=>rst_ref, CLK=>clk, EN=>'1', EXT_A=>addr, EXT_DI=>din,
    EXT_DO=>dout_ref, EXT_WR_N=>wr_n, EXT_RD_N=>rd_n, CPU_CE=>'1',
    SEL_N=>open, IRQ_N=>irq_ref, RAM_CS_N=>open, BRAM_EN=>open,
    CD_STAT=>(others=>'0'), CD_MSG=>(others=>'0'), CD_STAT_GET=>'0',
    CD_COMM=>open, CD_COMM_SEND=>open, CD_DOUT_REQ=>'0', CD_DOUT=>open,
    CD_DOUT_SEND=>open, CD_REGION=>'0', CD_RESET=>open, CD_DATA=>(others=>'0'),
    CD_DATA_WR=>'0', CD_AUDIO_WR=>'0', CD_SUBCD_WR=>'0', CD_DATA_END=>open,
    DM=>'0', CD_SL=>open, CD_SR=>open, AD_S=>open
  );
  reloaded : entity work.cd port map (
    SS_FREEZE=>freeze, SS_SAVE=>ss_save, SS_LOAD=>ss_load, SS_RROTATE=>rotate, SS_RADDR=>saddr, SS_RDI=>sdi, SS_RWE=>rwe, SS_RDO=>sdout, SS_UNSAFE=>unsafe_reloaded,
    RST_N=>rst_reloaded, CLK=>clk, EN=>'1', EXT_A=>addr, EXT_DI=>din,
    EXT_DO=>dout_reloaded, EXT_WR_N=>wr_n, EXT_RD_N=>rd_n, CPU_CE=>'1',
    SEL_N=>open, IRQ_N=>irq_reloaded, RAM_CS_N=>open, BRAM_EN=>open,
    CD_STAT=>(others=>'0'), CD_MSG=>(others=>'0'), CD_STAT_GET=>'0',
    CD_COMM=>open, CD_COMM_SEND=>open, CD_DOUT_REQ=>'0', CD_DOUT=>open,
    CD_DOUT_SEND=>open, CD_REGION=>'0', CD_RESET=>open, CD_DATA=>(others=>'0'),
    CD_DATA_WR=>'0', CD_AUDIO_WR=>'0', CD_SUBCD_WR=>'0', CD_DATA_END=>open,
    DM=>'0', CD_SL=>open, CD_SR=>open, AD_S=>open
  );
  watchdog : process begin
    wait for 2 ms;
    assert false report "test timeout" severity failure;
  end process;
  stimulus : process
    procedure tick(n : natural) is begin
      for i in 1 to n loop wait until rising_edge(clk); end loop;
      wait until falling_edge(clk);
    end procedure;
  begin
    tick(4); rst_ref <= '1'; rst_reloaded <= '1'; tick(CAPTURE_DELAY);
    assert unsafe_ref='0' and unsafe_reloaded='0' report "idle no-disc guard did not enable" severity failure;
    freeze <= '1'; ss_save <= '1'; tick(1); ss_save <= '0'; tick(5);
    for i in 579 to 626 loop
      saddr <= std_logic_vector(to_unsigned(i,15)); wait for 1 ns;
      image(i) <= sdout; rotate <= '1'; tick(1); rotate <= '0';
    end loop;
    -- Destroy live state while the golden machine stays frozen.
    rst_reloaded <= '0'; tick(4); rst_reloaded <= '1'; tick(2);
    for i in 579 to 626 loop
      saddr <= std_logic_vector(to_unsigned(i,15)); sdi <= image(i); rwe <= '1'; tick(1);
    end loop;
    rwe <= '0'; ss_load <= '1'; tick(1); ss_load <= '0'; tick(8);
    freeze <= '0'; tick(2);
    addr <= std_logic_vector(to_unsigned(16#1ff803#,21)); rd_n <= '1';
    for i in 0 to 10000 loop
      tick(1);
      assert not is_x(dout_ref(6 downto 2)) and not is_x(dout_reloaded(6 downto 2)) and not is_x(irq_ref) and not is_x(irq_reloaded) report "unknown CD status/IRQ" severity failure;
      assert dout_ref(6 downto 2)=dout_reloaded(6 downto 2) and irq_ref=irq_reloaded
        report "CD status/IRQ diverged after scan restore" severity failure;
    end loop;
    -- Enable autonomous subcode IRQ only after both machines have resumed.
    addr <= std_logic_vector(to_unsigned(16#1ff802#,21)); din <= x"10"; wr_n <= '0';
    tick(1); wr_n <= '1'; tick(2);
    assert irq_ref=irq_reloaded and irq_ref='0' report "IRQ restore mismatch" severity failure;
    assert unsafe_ref='1' and unsafe_reloaded='1' report "CD register access not rejected" severity failure;
    rst_reloaded <= '0'; tick(4); rst_reloaded <= '1'; tick(2);
    assert unsafe_reloaded='1' report "unsafe guard cleared by console reset" severity failure;
    report "PASS: production CD status/IRQ phase replay after external scan restore" severity note;
    std.env.finish;
  end process;
end architecture;
