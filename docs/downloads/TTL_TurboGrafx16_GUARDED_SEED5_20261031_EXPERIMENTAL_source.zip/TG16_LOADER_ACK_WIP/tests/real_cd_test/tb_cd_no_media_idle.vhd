library ieee;use ieee.std_logic_1164.all;use std.env.all;
entity tb_cd_no_media_idle is end;
architecture test of tb_cd_no_media_idle is
 signal clk:std_logic:='0';signal rst_n:std_logic:='0';
 signal unsafe,comm_send,dout_send,data_end,cd_reset:std_logic;
begin
 clk<=not clk after 5 ns;
 dut:entity work.cd port map(
 SS_UNSAFE=>unsafe,SS_RDO=>open,CLK=>clk,RST_N=>rst_n,EN=>'1',
 EXT_A=>(others=>'0'),EXT_DI=>(others=>'0'),EXT_DO=>open,EXT_WR_N=>'1',EXT_RD_N=>'1',CPU_CE=>'1',
 SEL_N=>open,IRQ_N=>open,RAM_CS_N=>open,BRAM_EN=>open,
 CD_STAT=>(others=>'0'),CD_MSG=>(others=>'0'),CD_STAT_GET=>'0',CD_COMM=>open,CD_COMM_SEND=>comm_send,
 CD_DOUT_REQ=>'0',CD_DOUT=>open,CD_DOUT_SEND=>dout_send,CD_REGION=>'0',CD_RESET=>cd_reset,
 CD_DATA=>(others=>'0'),CD_DATA_WR=>'0',CD_AUDIO_WR=>'0',CD_SUBCD_WR=>'0',CD_DATA_END=>data_end,DM=>'0',CD_SL=>open,CD_SR=>open,AD_S=>open);
 process begin
  for i in 1 to 10 loop wait until falling_edge(clk);end loop;rst_n<='1';
  for i in 1 to 30 loop wait until falling_edge(clk);end loop;
  for i in 1 to 80000 loop
   wait until falling_edge(clk);
   assert unsafe='0' report "unexpected guard during clean no-media idle cycle="&integer'image(i) severity failure;
   assert comm_send='0' and dout_send='0' and data_end='0' and cd_reset='0' report "unexpected HPS command/request in clean no-media idle cycle="&integer'image(i)&" signals="&std_logic'image(comm_send)&std_logic'image(dout_send)&std_logic'image(data_end)&std_logic'image(cd_reset) severity failure;
  end loop;
  report "PASS: actual CD/SCSI/vendor FIFOs clean no-media idle, 80000 cycles, no guard or outgoing HPS requests" severity note;finish;
 end process;
end;
