library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Actual cd/SCSI/MSM5205/CEGen RTL, with no-media-only primitive models.
-- The second CD instance is reset shortly before the simulated restore.
-- A real snapshot would have to restore its pending state, which it cannot.
entity tb_real_cd_nodisc is end entity;
architecture test of tb_real_cd_nodisc is
  signal clk : std_logic := '0';
  signal rst_ref, rst_reloaded : std_logic := '0';
  signal addr : std_logic_vector(20 downto 0) := (others=>'0');
  signal din : std_logic_vector(7 downto 0) := (others=>'0');
  signal dout_ref, dout_reloaded : std_logic_vector(7 downto 0);
  signal wr_n, rd_n : std_logic := '1';
  signal irq_ref, irq_reloaded : std_logic;
begin
  clk <= not clk after 5 ns;
  golden : entity work.cd port map (
    RST_N=>rst_ref, CLK=>clk, EN=>'1', EXT_A=>addr, EXT_DI=>din,
    EXT_DO=>dout_ref, EXT_WR_N=>wr_n, EXT_RD_N=>rd_n, CPU_CE=>'1',
    SEL_N=>open, IRQ_N=>irq_ref, RAM_CS_N=>open, BRAM_EN=>open,
    CD_STAT=>(others=>'0'), CD_MSG=>(others=>'0'), CD_STAT_GET=>'0',
    CD_COMM=>open, CD_COMM_SEND=>open, CD_DOUT_REQ=>'0', CD_DOUT=>open,
    CD_DOUT_SEND=>open, CD_REGION=>'0', CD_RESET=>open, CD_DATA=>(others=>'0'),
    CD_DATA_WR=>'0', CD_AUDIO_WR=>'0', CD_SUBCD_WR=>'0', CD_DATA_END=>open,
    DM=>'0', CD_SL=>open, CD_SR=>open, AD_S=>open
  );
  reloaded : entity work.cd port map (
    RST_N=>rst_reloaded, CLK=>clk, EN=>'1', EXT_A=>addr, EXT_DI=>din,
    EXT_DO=>dout_reloaded, EXT_WR_N=>wr_n, EXT_RD_N=>rd_n, CPU_CE=>'1',
    SEL_N=>open, IRQ_N=>irq_reloaded, RAM_CS_N=>open, BRAM_EN=>open,
    CD_STAT=>(others=>'0'), CD_MSG=>(others=>'0'), CD_STAT_GET=>'0',
    CD_COMM=>open, CD_COMM_SEND=>open, CD_DOUT_REQ=>'0', CD_DOUT=>open,
    CD_DOUT_SEND=>open, CD_REGION=>'0', CD_RESET=>open, CD_DATA=>(others=>'0'),
    CD_DATA_WR=>'0', CD_AUDIO_WR=>'0', CD_SUBCD_WR=>'0', CD_DATA_END=>open,
    DM=>'0', CD_SL=>open, CD_SR=>open, AD_S=>open
  );
  watchdog : process begin
    wait for 25 us;
    assert false report "test timeout before expected assertions" severity failure;
  end process;
  stimulus : process
    procedure tick(n : natural) is begin
      for i in 1 to n loop wait until rising_edge(clk); end loop;
      wait until falling_edge(clk);
    end procedure;
  begin
    tick(4); rst_ref <= '1'; rst_reloaded <= '1';
    -- 1,200 clocks exceeds first CDDA_CE; autonomous CD_SUBCD sets.
    tick(1200);
    addr <= std_logic_vector(to_unsigned(16#1FF803#,21)); rd_n <= '0';
    wait for 1 ns;
    assert dout_ref(4)='1' report "reference subcode flag did not set" severity failure;
    assert dout_reloaded(4)='1' report "second subcode flag did not set" severity failure;
    assert irq_ref='1' and irq_reloaded='1' report "reset-disabled IRQ asserted" severity failure;
    rd_n <= '1';
    -- Emulate core reset/reload without CD state restore. Real system writes
    -- HuCard RAM/registers back but leaves the CD state at its reset value.
    rst_reloaded <= '0'; tick(4); rst_reloaded <= '1'; tick(2);
    addr <= std_logic_vector(to_unsigned(16#1FF803#,21)); rd_n <= '0'; wait for 1 ns;
    assert dout_ref(4)='1' and dout_reloaded(4)='0'
      report "expected divergence of real no-disc subcode status across reset" severity failure;
    rd_n <= '1';
    -- Enable subcode interrupt on both without changing the pending flag.
    addr <= std_logic_vector(to_unsigned(16#1FF802#,21)); din <= x"10"; wr_n <= '0';
    tick(1); wr_n <= '1'; wait for 1 ns;
    assert irq_ref='0' and irq_reloaded='1'
      report "expected real CD IRQ divergence absent snapshot restore" severity failure;
    report "PASS: production CD no-disc status and IRQ diverge after reset without CD restore" severity note;
    std.env.finish;
  end process;
end architecture;
