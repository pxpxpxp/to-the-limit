#!/usr/bin/env python3
"""Exercise the exact production internal-write guard, not a behavioral copy."""
from pathlib import Path
import re,subprocess,tempfile,os
P=Path(__file__).resolve().parents[2]
s=(P/'rtl/cd/cd.vhd').read_text()
m=re.search(r'SS_CD_EVENT\s*<=.*?end if; end process;',s,re.S);assert m
s=(P/'tests/real_cd_test/tb_internal_guard.vhd').read_text().replace('-- INSERT_PRODUCTION_GUARD',m.group(0))
with tempfile.TemporaryDirectory(prefix='tg16-internalguard-') as td:
 p=Path(td)/'tb.vhd';p.write_text(s);g=os.environ.get('GHDL','ghdl')
 for a in [('-a','--std=08',str(p)),('-e','--std=08','tb_internal_guard')]:subprocess.run([g,*a],cwd=td,check=True)
 for mode in range(4):subprocess.run([g,'-r','--std=08','tb_internal_guard',f'-gMODE={mode}','--assert-level=error','--stop-time=10us'],cwd=td,check=True)
