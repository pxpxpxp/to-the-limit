library ieee; use ieee.std_logic_1164.all; use ieee.numeric_std.all;
entity tb_cd_guard is generic (MODE : natural := 0); end entity;
architecture test of tb_cd_guard is
 signal clk:std_logic:='0';signal rst_n:std_logic:='0';signal unsafe:std_logic;
 signal get_status,dout_req,data_wr,audio_wr,sub_wr:std_logic:='0';
 signal a:std_logic_vector(20 downto 0):=(others=>'0');signal wr_n,rd_n:std_logic:='1';
begin
 clk<=not clk after 5 ns;
 dut:entity work.cd port map(
 SS_UNSAFE=>unsafe, SS_RDO=>open, CLK=>clk,RST_N=>rst_n,EN=>'1',
 EXT_A=>a,EXT_DI=>(others=>'0'),EXT_DO=>open,EXT_WR_N=>wr_n,EXT_RD_N=>rd_n,CPU_CE=>'1',
 SEL_N=>open,IRQ_N=>open,RAM_CS_N=>open,BRAM_EN=>open,
 CD_STAT=>(others=>'0'),CD_MSG=>(others=>'0'),CD_STAT_GET=>get_status,
 CD_COMM=>open,CD_COMM_SEND=>open,CD_DOUT_REQ=>dout_req,CD_DOUT=>open,CD_DOUT_SEND=>open,
 CD_REGION=>'0',CD_RESET=>open,CD_DATA=>(others=>'0'),CD_DATA_WR=>data_wr,
 CD_AUDIO_WR=>audio_wr,CD_SUBCD_WR=>sub_wr,CD_DATA_END=>open,DM=>'0',CD_SL=>open,CD_SR=>open,AD_S=>open);
 process begin
  for i in 1 to 5 loop wait until falling_edge(clk);end loop;rst_n<='1';
  for i in 1 to 10 loop wait until falling_edge(clk);end loop;
  assert unsafe='0' report "initial no-disc unsafe" severity failure;
  case MODE is
   when 0=>get_status<='1';
   when 1=>dout_req<='1';
   when 2=>data_wr<='1';
   when 3=>audio_wr<='1';
   when 4=>sub_wr<='1';
   when 5=>a<=std_logic_vector(to_unsigned(16#1ff802#,21));wr_n<='0';
   when 6=>a<=std_logic_vector(to_unsigned(16#1ff803#,21));rd_n<='0';
   when 7=>a<=std_logic_vector(to_unsigned(16#d0000#,21));rd_n<='0';
   when 8=>a<=std_logic_vector(to_unsigned(16#10ffff#,21));wr_n<='0';
   when others=>assert false severity failure;
  end case;
  wait for 1 ns;
  assert unsafe='1' report "same-edge event not blocked combinationally" severity failure;
  wait until falling_edge(clk);
  assert unsafe='1' report "unsupported activity not guarded" severity failure;
  report "PASS: unsupported CD activity sets guard, mode="&integer'image(MODE) severity note;
  std.env.finish;
 end process;
end architecture;
