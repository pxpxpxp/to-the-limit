-- Narrow no-media-only models. They deliberately fail if a test writes or
-- drains a FIFO, rather than pretending to validate real queue behavior.
library ieee; use ieee.std_logic_1164.all;
entity CDDA_FIFO is port(clock:in std_logic;data:in std_logic_vector(31 downto 0);rdreq,sclr,wrreq:in std_logic;empty,full:out std_logic;q:out std_logic_vector(31 downto 0));end;
architecture no_media of CDDA_FIFO is begin
  empty<='1';full<='0';q<=(others=>'0');
  process(clock) variable cycles:natural:=0; begin if rising_edge(clock) then
    if cycles < 5 then cycles:=cycles+1; else
    assert wrreq='0' and rdreq='0' report "CDDA FIFO traffic invalidates no-media model" severity failure;
    end if;
  end if; end process;
end;
library ieee; use ieee.std_logic_1164.all;
entity CDSUBC_FIFO is port(clock:in std_logic;data:in std_logic_vector(7 downto 0);rdreq,sclr,wrreq:in std_logic;empty,full:out std_logic;q:out std_logic_vector(7 downto 0));end;
architecture no_media of CDSUBC_FIFO is begin
  empty<='1';full<='0';q<=(others=>'0');
  process(clock) variable cycles:natural:=0; begin if rising_edge(clock) then
    if cycles < 5 then cycles:=cycles+1; else
    assert wrreq='0' and rdreq='0' report "subcode FIFO traffic invalidates no-media model" severity failure;
    end if;
  end if; end process;
end;
library ieee; use ieee.std_logic_1164.all;
entity SCSI_FIFO is port(aclr:in std_logic:='0';data:in std_logic_vector(7 downto 0);rdclk,rdreq,wrclk,wrreq:in std_logic;q:out std_logic_vector(7 downto 0);rdempty,wrfull:out std_logic);end;
architecture no_media of SCSI_FIFO is begin
  rdempty<='1';wrfull<='0';q<=(others=>'0');
  process(wrclk) variable cycles:natural:=0; begin if rising_edge(wrclk) then
    if cycles < 5 then cycles:=cycles+1; else
    assert wrreq='0' report "SCSI FIFO write invalidates no-media model" severity failure;
    end if;
  end if; end process;
  process(rdclk) variable cycles:natural:=0; begin if rising_edge(rdclk) then
    if cycles < 5 then cycles:=cycles+1; else
    assert rdreq='0' report "SCSI FIFO read invalidates no-media model" severity failure;
    end if;
  end if; end process;
end;
