from pathlib import Path
import os,subprocess,tempfile
P=Path(__file__).resolve().parents[2];H=Path(__file__).resolve().parent;G=os.environ.get('GHDL','ghdl');Q=Path(os.environ['QUARTUS_ROOTDIR'])
s=(P/'rtl/dpram.vhd').read_text().split('LIBRARY ieee;',2)[1];s='LIBRARY ieee;'+s;s=s.replace('LIBRARY altera_mf;\nUSE altera_mf.altera_mf_components.all;','use ieee.numeric_std.all;');pos=s.index('BEGIN\n',s.index('ARCHITECTURE'));s=s[:pos]+'''type mem_t is array(0 to 2**addr_width-1) of std_logic_vector(data_width-1 downto 0);
 signal mem:mem_t := (others=>(others=>'0'));
'''+s[pos:];s=s[:s.index('\taltsyncram_component :')]+'''process(clock) begin if rising_edge(clock) then
if ea='1' then if mw='1' then mem(to_integer(unsigned(ma)))<=md;q0<=md;else q0<=mem(to_integer(unsigned(ma)));end if;end if;
if eb='1' then if wren_b='1' and cs_b='1' then mem(to_integer(unsigned(address_b)))<=data_b;q1<=data_b;else q1<=mem(to_integer(unsigned(address_b)));end if;end if;
end if;end process;end SYN;'''
with tempfile.TemporaryDirectory(prefix='tg16-cd-idle-') as d:
 d=Path(d);(d/'lib').mkdir();(d/'dpram.vhd').write_text(s)
 def run(*a):subprocess.run([G,*map(str,a)],cwd=d,check=True)
 sim=Q/'eda/sim_lib';run('-a','--std=08','-fsynopsys','--work=altera_mf','--workdir=lib',sim/'altera_mf_components.vhd',sim/'altera_mf.vhd')
 files=[d/'dpram.vhd',P/'rtl/CEGen.vhd',P/'rtl/cd/CEGen_CD.vhd',P/'rtl/cd/adpcm_snapshot_ram.vhd',P/'rtl/cd/MSM5205.vhd',P/'rtl/cd/SCSI_FIFO.vhd',P/'rtl/cd/CDDA_FIFO.vhd',P/'rtl/cd/CDSUBC_FIFO.vhd',P/'rtl/cd/SCSI.vhd',P/'rtl/cd/cd.vhd',H/'tb_cd_no_media_idle.vhd']
 for f in files:run('-a','--std=08','-fsynopsys','-P./lib',f)
 run('-e','--std=08','-fsynopsys','-P./lib','tb_cd_no_media_idle');run('-r','--std=08','-fsynopsys','-P./lib','tb_cd_no_media_idle','--assert-level=error','--ieee-asserts=disable')
