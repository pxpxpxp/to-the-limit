#!/usr/bin/env python3
"""Test exact CD RAM decode and PCE guard with production expressions."""
from pathlib import Path
import re,subprocess,tempfile,os
P=Path(__file__).resolve().parents[2]
pce=(P/'rtl/pce_top.vhd').read_text();cd=(P/'rtl/cd/cd.vhd').read_text()
def extract(s,pattern):
 m=re.search(pattern,s,re.I|re.S);assert m,pattern;return m.group(0)
parts=[extract(cd,r"RAM_SEL\s*<=\s*'1'\s+when.*?;"),extract(cd,r'RAM_CS_N\s*<=\s*not\s*\(RAM_SEL and EN\);').replace('RAM_CS_N','CD_RAM_CS_N').replace(' and EN',''),
 extract(pce,r'CPU_ROM_SEL_N\s*<=\s*CPU_A\(20\);'),extract(pce,r'ROM_RD\s*<=.*?;'),extract(pce,r'CD_RAM_RD\s*<=.*?;'),extract(pce,r'CD_RAM_WR\s*<=.*?;'),extract(pce,r'SS_CD_UNSAFE\s*<=.*?end process;')]
tb=(P/'tests/real_cd_test/tb_cd_ram_guard.vhd').read_text().replace('-- INSERT_PRODUCTION_DECODE','\n'.join(parts)).replace('EXT_A','CPU_A')
with tempfile.TemporaryDirectory(prefix='tg16-cd-ramguard-') as td:
 v=Path(td)/'tb.vhd';v.write_text(tb);g=os.environ.get('GHDL','ghdl')
 for a in [('-a','--std=08',str(v)),('-e','--std=08','tb_cd_ram_guard')]:subprocess.run([g,*a],cwd=td,check=True)
 for mode in (0,1):subprocess.run([g,'-r','--std=08','tb_cd_ram_guard',f'-gMODE={mode}','--assert-level=error','--stop-time=10us'],cwd=td,check=True)
