library ieee; use ieee.std_logic_1164.all; use ieee.numeric_std.all;
entity tb_cd_ram_guard is generic (MODE:natural:=0); end entity;
architecture test of tb_cd_ram_guard is
 signal CLK : std_logic := '0';
 signal CPU_A : std_logic_vector(20 downto 0) := (others=>'0');
 signal CPU_PRE_RD, CPU_PRE_WR, CD_EN : std_logic := '0';
 signal CPU_ROM_SEL_N, CPU_PRAM_SEL_N, AC_RAM_CS_N, CD_RAM_CS_N : std_logic := '1';
 signal ROM_RD, CD_RAM_RD, CD_RAM_WR, RAM_SEL, SS_CD_UNSAFE : std_logic;
 signal SS_CD_UNSAFE_RAW : std_logic := '0';
 signal SS_CD_RAM_UNSAFE : std_logic := '0';
begin
 CLK <= not CLK after 5 ns;
 -- INSERT_PRODUCTION_DECODE
 process begin
  wait until falling_edge(CLK);
  if MODE=0 then CPU_A<=std_logic_vector(to_unsigned(16#d0000#,21));CPU_PRE_RD<='1';
  else CPU_A<=std_logic_vector(to_unsigned(16#10ffff#,21));CPU_PRE_WR<='1';end if;
  wait for 1 ns;
  if MODE=0 then
    assert CD_RAM_RD='1' and ROM_RD='1' report "expected simultaneous no-disc ROM/CD read" severity failure;
  else assert CD_RAM_WR='1' report "expected no-disc CD RAM write request" severity failure;end if;
  assert SS_CD_UNSAFE='1' report "raw pre-request did not block snapshot" severity failure;
  wait until falling_edge(CLK); CPU_PRE_RD<='0';CPU_PRE_WR<='0';CPU_A<=(others=>'0');
  wait for 1 ns;assert SS_CD_UNSAFE='1' report "CD RAM access was not latched" severity failure;
  report "PASS: production no-disc CD RAM pre-request guard mode="&integer'image(MODE) severity note;
  std.env.finish;
 end process;
end architecture;
