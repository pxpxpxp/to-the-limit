library ieee; use ieee.std_logic_1164.all; use ieee.numeric_std.all;
entity tb_dma_initial is end entity;
architecture test of tb_dma_initial is
 signal clk:std_logic:='0';signal rst_n:std_logic:='0';signal unsafe:std_logic;
 signal get_status,dout_req,data_wr,audio_wr,sub_wr:std_logic:='0';
 signal a:std_logic_vector(20 downto 0):=(others=>'0');signal wr_n,rd_n:std_logic:='1';
begin
 clk<=not clk after 5 ns;
 dut:entity work.cd port map(
 SS_UNSAFE=>unsafe, SS_RDO=>open, CLK=>clk,RST_N=>rst_n,EN=>'1',
 EXT_A=>a,EXT_DI=>(others=>'0'),EXT_DO=>open,EXT_WR_N=>wr_n,EXT_RD_N=>rd_n,CPU_CE=>'1',
 SEL_N=>open,IRQ_N=>open,RAM_CS_N=>open,BRAM_EN=>open,
 CD_STAT=>(others=>'0'),CD_MSG=>(others=>'0'),CD_STAT_GET=>get_status,
 CD_COMM=>open,CD_COMM_SEND=>open,CD_DOUT_REQ=>dout_req,CD_DOUT=>open,CD_DOUT_SEND=>open,
 CD_REGION=>'0',CD_RESET=>open,CD_DATA=>(others=>'0'),CD_DATA_WR=>data_wr,
 CD_AUDIO_WR=>audio_wr,CD_SUBCD_WR=>sub_wr,CD_DATA_END=>open,DM=>'0',CD_SL=>open,CD_SR=>open,AD_S=>open);
 process begin
  for i in 1 to 5 loop wait until falling_edge(clk);end loop;rst_n<='1';
  for i in 1 to 8 loop wait until falling_edge(clk);end loop;
  -- No CPU or HPS CD event is ever driven. DMA_WRITE_PEND is forced to 1
  -- only in this simulation source, representing a permitted power-up value.
  if unsafe='0' then
    for i in 1 to 100 loop wait until falling_edge(clk); exit when unsafe='1';end loop;
  end if;
  assert unsafe='1' report "autonomous ADPCM write escaped guard" severity failure;
  for i in 1 to 30 loop wait until falling_edge(clk);end loop;
  assert unsafe='1' report "autonomous ADPCM write not latched" severity failure;
  report "PASS: forced-high unreset DMA pending causes autonomous write and sticky snapshot guard" severity note;
  std.env.finish;
 end process;
end architecture;
