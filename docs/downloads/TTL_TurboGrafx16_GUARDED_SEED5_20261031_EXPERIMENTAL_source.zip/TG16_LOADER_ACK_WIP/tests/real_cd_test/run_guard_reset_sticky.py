#!/usr/bin/env python3
"""Compile the production CD RTL with narrowly scoped no-media models."""
from pathlib import Path
import argparse, os, subprocess, tempfile
HERE=Path(__file__).resolve().parent
DEFAULT=HERE.parents[1]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=DEFAULT);p.add_argument('--ghdl',default=os.environ.get('GHDL','ghdl'));args=p.parse_args()
P=args.source.resolve()
# Reproduce the existing project's replacement of just the Altera RAM primitive.
# Preserve the original dpram RTL, ports and replay control as test code does.
s=(P/'rtl/dpram.vhd').read_text().split('LIBRARY ieee;',2)[1]
s='LIBRARY ieee;'+s
s=s.replace('LIBRARY altera_mf;\nUSE altera_mf.altera_mf_components.all;','use ieee.numeric_std.all;')
pos=s.index('BEGIN\n',s.index('ARCHITECTURE'))
s=s[:pos]+'''type mem_t is array(0 to 2**addr_width-1) of std_logic_vector(data_width-1 downto 0);
    signal mem : mem_t := (others => (others => '0'));
'''+s[pos:]
s=s[:s.index('\taltsyncram_component :')]+'''
    process(clock) begin
      if rising_edge(clock) then
        if ea = '1' then
          if mw = '1' then mem(to_integer(unsigned(ma))) <= md; q0 <= md;
          else q0 <= mem(to_integer(unsigned(ma))); end if;
        end if;
        if eb = '1' then
          if wren_b = '1' and cs_b = '1' then mem(to_integer(unsigned(address_b))) <= data_b; q1 <= data_b;
          else q1 <= mem(to_integer(unsigned(address_b))); end if;
        end if;
      end if;
    end process;
end SYN;
'''
with tempfile.TemporaryDirectory(prefix='tg16-real-cd-') as td:
    td=Path(td);(td/'dpram.vhd').write_text(s)
    sources=[td/'dpram.vhd',HERE/'empty_fifo_models.vhd',P/'rtl/CEGen.vhd',P/'rtl/cd/CEGen_CD.vhd',P/'rtl/cd/adpcm_snapshot_ram.vhd',P/'rtl/cd/MSM5205.vhd',P/'rtl/cd/SCSI.vhd',P/'rtl/cd/cd.vhd',HERE/'tb_cd_guard_reset_sticky.vhd']
    def run(*a): subprocess.run([args.ghdl,*a],cwd=td,check=True)
    for src in sources: run('-a','--std=08','-fsynopsys',str(src))
    run('-e','--std=08','-fsynopsys','tb_cd_guard')
    for mode in range(9): run('-r','--std=08','-fsynopsys','tb_cd_guard',f'-gMODE={mode}','--assert-level=error','--stop-time=500us')
