`timescale 1ns/1ps
module tb_audio_binary_roundtrip;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg ss_freeze=1,ss_save=0,ss_load_commit=0,ss_we=0,ss_reg_rotate=0;
reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg [63:0] status=0;
reg [15:0] cdda_sl=0,cdda_sr=0,psg_sl=0,psg_sr=0,adpcm_s=0;
wire [15:0] AUDIO_L,AUDIO_R,scan_data;wire AUDIO_S,AUDIO_MIX;
audio_snapshot_dut dut(.*);
reg [15:0] expected[0:53];reg [31:0] rng=32'hc0ffee99;integer v,i;
function [31:0] step(input [31:0] a);reg [31:0] x;begin x=a^(a<<13);x=x^(x>>17);step=x^(x<<5);end endfunction
initial begin
 @(negedge clk_sys);
 for(v=0;v<26;v=v+1)begin
  for(i=0;i<54;i=i+1)begin
   rng=step(rng);expected[i]=(v==0)?0:((v==1)?16'hffff:rng[15:0]);
   if(i==30||i==53)expected[i]=expected[i]&16'h0001;
  end
  ss_we=1;
  for(i=0;i<54;i=i+1)begin ss_addr=18'h30000+627+i;ss_din=expected[i];@(negedge clk_sys);end
  ss_we=0;ss_load_commit=1;@(negedge clk_sys);ss_load_commit=0;ss_save=1;@(negedge clk_sys);ss_save=0;
  for(i=0;i<54;i=i+1)begin
   ss_addr=18'h30000+627+i;#1;
   if(scan_data!==expected[i])$fatal(1,"binary roundtrip vector=%0d word=%0d expected=%h actual=%h",v,i,expected[i],scan_data);
   ss_reg_rotate=1;@(negedge clk_sys);ss_reg_rotate=0;
  end
 end
 $display("PASS: audio 54-word zero, one and 24 pseudorandom images survive commit/capture with reserved bits masked");$finish;
end
initial begin #5000000;$fatal(1,"timeout");end
endmodule
