`timescale 1ns/1ps
module tb_audio_natural_start_inventory;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg ss_freeze=0,ss_save=0,ss_load_commit=0,ss_we=0,ss_reg_rotate=0;
reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg [63:0] status=0;
reg [15:0] cdda_sl=0,cdda_sr=0,psg_sl=0,psg_sr=0,adpcm_s=0;
wire [15:0] AUDIO_L,AUDIO_R,scan_data;wire AUDIO_S,AUDIO_MIX;
audio_snapshot_dut dut(.*);
integer i,n=0;
initial begin
  repeat(80001) @(negedge clk_sys);
  $display("AUDIO_LIVE_BEFORE_CAPTURE left=%b right=%b",AUDIO_L,AUDIO_R);
  ss_freeze=1;ss_save=1;@(negedge clk_sys);ss_save=0;
  for(i=0;i<54;i=i+1)begin
    ss_addr=18'h30000+627+i;#1;
    if (^scan_data === 1'bx)begin $display("AUDIO_SCAN_UNKNOWN address=%0d bits=%b",627+i,scan_data);n=n+1;end
    ss_reg_rotate=1;@(negedge clk_sys);ss_reg_rotate=0;
  end
  $display("AUDIO_SCAN_COMPLETE unknown_words=%0d",n);$finish;
end
initial begin #2000000;$fatal(1,"timeout");end
endmodule
