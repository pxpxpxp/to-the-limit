`timescale 1ns/1ps
module tb_audio_old_new;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg ss_freeze=1,ss_save=0,ss_load_commit=0,ss_we=0,ss_reg_rotate=0;
reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg [63:0] status=0;
reg [15:0] cdda_sl=0,cdda_sr=0,psg_sl=0,psg_sr=0,adpcm_s=0;
wire [15:0] al0,ar0,scan0,al1,ar1,scan1;wire as0,am0,as1,am1;
audio_old orig(.AUDIO_L(al0),.AUDIO_R(ar0),.AUDIO_S(as0),.AUDIO_MIX(am0),.scan_data(scan0),.*);
audio_new fixed(.AUDIO_L(al1),.AUDIO_R(ar1),.AUDIO_S(as1),.AUDIO_MIX(am1),.scan_data(scan1),.*);
reg [31:0] rng=32'h91827364;integer v,i;
function [31:0] step(input [31:0] a);reg [31:0] x;begin x=a^(a<<13);x=x^(x>>17);step=x^(x<<5);end endfunction
initial begin
 @(negedge clk_sys);
 for(v=0;v<4;v=v+1)begin
  ss_freeze=1;ss_we=1;status=(64'(v)<<18);
  for(i=0;i<54;i=i+1)begin rng=step(rng);ss_addr=18'h30000+627+i;ss_din=(v==0)?0:rng[15:0];if(i==30||i==53)ss_din=ss_din&16'h0001;@(negedge clk_sys);end
  ss_we=0;ss_load_commit=1;@(negedge clk_sys);ss_load_commit=0;ss_freeze=0;
  for(i=0;i<20000;i=i+1)begin
   rng=step(rng);psg_sl=rng[15:0];rng=step(rng);psg_sr=rng[15:0];rng=step(rng);adpcm_s=rng[15:0];cdda_sl=~rng[15:0];cdda_sr=rng[31:16];
   @(negedge clk_sys);if({al0,ar0,orig.ss_audio_live} !== {al1,ar1,fixed.ss_audio_live})$fatal(1,"arithmetic/state differs vector=%0d sample=%0d",v,i);
  end
  ss_freeze=1;ss_save=1;@(negedge clk_sys);ss_save=0;
  for(i=0;i<54;i=i+1)begin ss_addr=18'h30000+627+i;#1;if(scan0!==scan1)$fatal(1,"captured scan differs %0d",i);ss_reg_rotate=1;@(negedge clk_sys);ss_reg_rotate=0;end
 end
 $display("PASS: original vs initialized audio, common zero/random states, 4 patterns x 20000 input cycles and complete scan capture");$finish;
end
initial begin #5000000;$fatal(1,"timeout");end
endmodule
