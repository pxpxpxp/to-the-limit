`timescale 1ns/1ps
module tb_word_scan_pack_engine;
 reg clk=0;always #5 clk=~clk;reg reset=1,freeze=0,start_read=0,start_write=0;
 reg [15:0] group_addr=0;reg [63:0] word_in=0;
 wire [15:0] scan_index,scan_din;reg [15:0] scan_dout=0;wire scan_we,scan_rotate,busy,done,aborted,rejected;wire [63:0] word_out;
 word_scan_pack_engine #(.RAM_WORDS(5),.REGISTER_WORDS(4)) dut(.*);
 reg [15:0] ram[0:4],regs[0:3];integer i;
 always @(posedge clk)begin
  scan_dout<=scan_index<5 ? ram[scan_index] : regs[0];
  if(scan_we)begin
   if(scan_index<5)ram[scan_index]<=scan_din;
   else begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=scan_din;end
  end
  if(scan_rotate)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=regs[0];end
 end
 task rd(input integer g,input [63:0] expected);
 begin @(negedge clk);group_addr=g;start_read=1;@(negedge clk);start_read=0;wait(done);@(negedge clk);if(word_out!==expected)$fatal(1,"read group %0d got %h expected %h",g,word_out,expected);end endtask
 task wr(input integer g,input [63:0] value);
 begin @(negedge clk);group_addr=g;word_in=value;start_write=1;@(negedge clk);start_write=0;wait(done);@(negedge clk);end endtask
 initial begin
  for(i=0;i<5;i=i+1)ram[i]=16'h1000+i;for(i=0;i<4;i=i+1)regs[i]=16'h2000+i;
  repeat(3)@(negedge clk);reset=0;freeze=1;
  rd(0,64'h1003100210011000);rd(1,64'h2002200120001004);rd(2,64'h0000000000002003);
  for(i=0;i<4;i=i+1)if(regs[i]!==16'h2000+i)$fatal(1,"read rotation changed chain");
  wr(0,64'h4444333322221111);wr(1,64'haaaa999988887777);wr(2,64'hffffeeeeddddcccc);
  if(ram[0]!==16'h1111||ram[4]!==16'h7777)$fatal(1,"RAM write order");
  if(regs[0]!==16'h8888||regs[1]!==16'h9999||regs[2]!==16'haaaa||regs[3]!==16'hcccc)$fatal(1,"register write order");
  @(negedge clk);group_addr=3;start_read=1;@(negedge clk);start_read=0;
  if(!rejected||busy)$fatal(1,"out-of-range group not rejected");
  @(negedge clk);group_addr=0;start_read=1;@(negedge clk);start_read=0;@(negedge clk);freeze=0;@(negedge clk);
  if(!aborted||busy||scan_we||scan_rotate)$fatal(1,"abort failed");
  $display("PASS: packed RAM/register boundary, chain rotation, tail pad, rejection and abort");$finish;
 end
 initial begin #100000;$fatal(1,"timeout");end
endmodule
