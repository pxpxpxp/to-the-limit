from pathlib import Path
import re,tempfile,subprocess,os
p=Path(__file__).resolve().parents[1]; audio=(p/'sys/audio_out.sv').read_text(); top=(p/'sys/sys_top.v').read_text(); asc=(p/'sys/ascal.vhd').read_text(); emu=(p/'TurboGrafx16.sv').read_text()
assert not re.search(r'ss_(?:machine_)?freeze\s*\?', re.search(r'assign AUDIO_L.*?assign AUDIO_S',emu,re.S).group(0))
a=re.search(r'\(\* altera_attribute.*?reg freeze_meta = 0;.*?reg freeze_audio = 0;\s*always @\(posedge clk\) begin.*?end\s*\n.*?reg \[15:0\] cl,cr;\s*always @\(posedge clk\) begin.*?\nend',audio,re.S).group(0)
assert re.search(r'assign LED_USER\s*=\s*cart_download\s*\|\s*bk_state\s*\|\s*bk_pending\s*;',emu), 'snapshot freeze must not enter shared LED/VGA OE'
assert 'wire led_u = ~led_user;' in top
i=re.search(r'PROCESS\(i_clk\) BEGIN\s*IF rising_edge\(i_clk\) THEN\s*i_freeze_meta <= freeze; i_freeze <= i_freeze_meta;\s*END IF;\s*END PROCESS;',asc,re.S).group(0)
o=re.search(r'PROCESS\(o_clk\) BEGIN\s*IF rising_edge\(o_clk\) THEN\s*o_freeze_meta <= freeze; o_freeze <= o_freeze_meta;\s*END IF;\s*END PROCESS;',asc,re.S).group(0)
with tempfile.TemporaryDirectory(prefix='tg16-freeze-cdc-') as d:
 d=Path(d)
 sv='''`timescale 1ns/1ps
module dut(input clk,freeze_async,is_signed,input [15:0] core_l,core_r,output [15:0] out_l,out_r);\n'''+a+'''\nassign out_l=cl;assign out_r=cr; endmodule
module tb;
reg a=0,f=0,signed_fmt=1; reg [15:0] l=16'h1357,r=16'h2468; wire [15:0] ol,orr; dut d(a,f,signed_fmt,l,r,ol,orr);
always #7 a=~a;
task settle; input integer n; integer k; begin for(k=0;k<n;k=k+1) @(negedge a); #1;end endtask
initial begin
 settle(8); if(ol!==l || orr!==r) $fatal(1,"initial outputs");
 #3 f=1; #1; if(d.freeze_audio!==0) $fatal(1,"async leakage");
 settle(8); if(d.freeze_audio!==1 || ol!==0 || orr!==0) $fatal(1,"freeze propagation");
 #2 l=16'hbeef; r=16'h9876; settle(6); if(ol!==0 || orr!==0) $fatal(1,"muting");
 #3 f=0; #1; if(d.freeze_audio!==1) $fatal(1,"async release");
 settle(9); if(d.freeze_audio!==0 || ol!==l || orr!==r) $fatal(1,"resume propagation");
 signed_fmt=0; #3 f=1; settle(8); if(ol!==16'h8000 || orr!==16'h8000) $fatal(1,"unsigned mute not midscale");
 #3 f=0; settle(9); if(ol!==l || orr!==r) $fatal(1,"unsigned resume");
 $display("PASS audio CDC stable transitions");$finish;end
initial begin #3000; $fatal(1,"timeout"); end
endmodule
'''
 (d/'tb.sv').write_text(sv); cmds=[[os.environ.get('IVERILOG','iverilog'),'-g2012','-s','tb','-o',str(d/'svtest'),str(d/'tb.sv')],[os.environ.get('VVP','vvp'),str(d/'svtest')]]
 vhd='''library ieee;use ieee.std_logic_1164.all;use std.env.all;
entity tb is end; architecture sim of tb is
signal i_clk,o_clk: std_logic:='0';signal freeze:std_logic:='0';signal i_freeze_meta,i_freeze,o_freeze_meta,o_freeze:std_logic:='0';begin
 i_clk<=not i_clk after 7 ns;o_clk<=not o_clk after 11 ns;\n'''+i+'\n'+o+'''
 process begin
 wait for 52 ns; assert i_freeze='0' and o_freeze='0' severity failure;
 wait for 1 ns; freeze<='1'; wait for 1 ns; assert i_freeze='0' and o_freeze='0' report "async leak" severity failure;
 wait for 100 ns; assert i_freeze='1' and o_freeze='1' report "assert failed" severity failure;
 wait for 2 ns; freeze<='0'; wait for 1 ns; assert i_freeze='1' and o_freeze='1' report "async release" severity failure;
 wait for 100 ns; assert i_freeze='0' and o_freeze='0' report "release failed" severity failure;
 report "PASS independent input and HDMI freeze CDC stable transitions";stop;wait;end process;end;
'''
 (d/'tb.vhd').write_text(vhd);gh=os.environ.get('GHDL','ghdl');cmds += [[gh,'-a','--std=08',str(d/'tb.vhd')],[gh,'-e','--std=08','tb'],[gh,'-r','--std=08','tb','--assert-level=error']]
 for cmd in cmds: print('+',' '.join(cmd),flush=True);subprocess.run(cmd,cwd=d,check=True)
print('PASS extracted production CDC processes; independent clocks and nonedge transitions; digital simulation only')
