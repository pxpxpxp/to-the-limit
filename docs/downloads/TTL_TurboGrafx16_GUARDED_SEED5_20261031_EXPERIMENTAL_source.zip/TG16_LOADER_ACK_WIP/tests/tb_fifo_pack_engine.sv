`timescale 1ns/1ps
module tb_fifo_pack_engine;
 reg clk=0;always #5 clk=~clk;
 reg reset=1,freeze=0,start_read=0,start_write=0;reg [11:0] group_addr=0;reg [63:0] word_in=0;
 reg [12:0] cdda_count=4096,scsi_count=4096;reg [8:0] sub_count=490;
 wire [12:0] cdda_count_in,scsi_count_in;wire [8:0] sub_count_in;wire set_count;
 wire [1:0] scan_sel;wire [11:0] scan_addr;wire [31:0] scan_din;wire scan_we;reg [31:0] scan_dout;
 wire [63:0] word_out;wire busy,done,rejected,aborted;
 fifo_pack_engine dut(.*);
 reg [31:0] a[0:4095],b[0:489],c[0:4095];integer i,j;reg [63:0] expected;
 always @(posedge clk)begin
  case(scan_sel)
   0:begin scan_dout<=a[scan_addr];if(scan_we)a[scan_addr]<=scan_din;end
   1:if(scan_addr<490)begin scan_dout<=b[scan_addr];if(scan_we)b[scan_addr]<=scan_din;end else scan_dout<=32'hbad;
   2:begin scan_dout<=c[scan_addr];if(scan_we)c[scan_addr]<=scan_din;end
  endcase
 end
 task read_group(input integer g,input [63:0] expect_);begin
 @(negedge clk);group_addr=g;start_read=1;@(negedge clk);start_read=0;wait(done);@(negedge clk);
 if(word_out!==expect_)$fatal(1,"group %0d got %h expected %h",g,word_out,expect_);end endtask
 task write_group(input integer g,input [63:0] val);begin
 @(negedge clk);group_addr=g;word_in=val;start_write=1;@(negedge clk);start_write=0;wait(done);@(negedge clk);end endtask
 task reject_group(input integer g,input [63:0] val);begin
 @(negedge clk);group_addr=g;word_in=val;start_write=1;@(negedge clk);start_write=0;
 if(!rejected||done||scan_we||set_count)$fatal(1,"expected rejection %0d",g);@(negedge clk);end endtask
 initial begin
 for(i=0;i<4096;i=i+1)begin a[i]=32'ha0000000+i;c[i]=i%256;end
 for(i=0;i<490;i=i+1)b[i]=i%256;
 repeat(4)@(negedge clk);reset=0;freeze=1;
 read_group(0,{29'd0,13'd4096,9'd490,13'd4096});
 read_group(1,{a[1],a[0]});read_group(2048,{a[4095],a[4094]});
 expected=0;for(j=0;j<8;j=j+1)expected[j*8+:8]=b[j];read_group(2049,expected);
 read_group(2110,{48'd0,b[489][7:0],b[488][7:0]});
 expected=0;for(j=0;j<8;j=j+1)expected[j*8+:8]=c[4088+j];read_group(2622,expected);
 write_group(1,64'h0123456789abcdef);if(a[0]!==32'h89abcdef||a[1]!==32'h01234567)$fatal(1,"CDDA write");
 write_group(2110,64'h0000000000004433);if(b[488]!==32'h33||b[489]!==32'h44)$fatal(1,"subcode write");
 write_group(2622,64'h0102030405060708);for(j=0;j<8;j=j+1)if(c[4088+j]!==((64'h0102030405060708 >> (j*8))&255))$fatal(1,"SCSI write");
 reject_group(0,{29'd0,13'd4097,9'd490,13'd4096});reject_group(2110,64'h10000);reject_group(2623,0);
 @(negedge clk);group_addr=1;start_read=1;@(negedge clk);start_read=0;freeze=0;@(negedge clk);if(!aborted||busy)$fatal(1,"abort");
 $display("PASS: FIFO counts, fixed-layout boundary read/write, padding rejection and abort");$finish;
 end
 initial begin #100000;$fatal(1,"timeout");end
endmodule
