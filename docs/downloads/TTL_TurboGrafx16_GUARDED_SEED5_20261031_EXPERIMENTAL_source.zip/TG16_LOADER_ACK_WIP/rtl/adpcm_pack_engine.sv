// Isolated experimental ADPCM scan-word packer; not integrated into core.
// The caller must hold the machine frozen and keep src/stage banks stable.
// One 64-bit DDR word stores 16 consecutive low-to-high 4-bit ADPCM cells.
module adpcm_pack_engine (
 input wire clk, reset, freeze, start_read, start_write,
 input wire [12:0] group_addr,
 input wire [63:0] word_in,
 output reg [16:0] cell_addr=0,
 output wire [3:0] cell_din,
 output wire cell_we,
 input wire [3:0] cell_dout,
 output reg [63:0] word_out=0,
 output wire busy,
 output reg done=0, aborted=0
);
 localparam IDLE=0,READ_WAIT=1,READ_CAPTURE=2,WRITE=3;
 reg [1:0] state=IDLE;
 reg [3:0] nibble=0;
 reg [12:0] group_hold=0;
 reg [63:0] data_hold=0;
 assign busy=(state!=IDLE);
 assign cell_we=(state==WRITE) && freeze && !reset;
 assign cell_din=data_hold[nibble*4 +: 4];
 always @(posedge clk) begin
  done<=0;aborted<=0;
  if (reset) begin state<=IDLE;end
  else if (state!=IDLE && !freeze) begin state<=IDLE;aborted<=1;end
  else case(state)
   IDLE: if(freeze && (start_read ^ start_write)) begin
      group_hold<=group_addr;cell_addr<={group_addr,4'd0};nibble<=0;data_hold<=word_in;
      if(start_read) begin word_out<=0;state<=READ_WAIT;end
      else state<=WRITE;
   end
   READ_WAIT: state<=READ_CAPTURE;
   READ_CAPTURE: begin
      word_out[nibble*4+:4]<=cell_dout;
      if(nibble==15) begin state<=IDLE;done<=1;end
      else begin nibble<=nibble+1'd1;cell_addr<={group_hold,nibble+4'd1};state<=READ_WAIT;end
   end
   WRITE: begin
      if(nibble==15) begin state<=IDLE;done<=1;end
      else begin nibble<=nibble+1'd1;cell_addr<={group_hold,nibble+4'd1};end
   end
   default: state<=IDLE;
  endcase
 end
endmodule
