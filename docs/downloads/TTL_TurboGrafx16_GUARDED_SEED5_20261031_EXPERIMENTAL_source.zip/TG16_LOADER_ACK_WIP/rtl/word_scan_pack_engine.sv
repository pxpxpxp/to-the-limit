// Experimental generic 4 x 16-bit scan-to-DDR packing engine.
// A full scan must visit groups in increasing order so register chains rotate
// exactly once. Caller keeps the machine frozen until complete or aborts safely.
module word_scan_pack_engine #(
 parameter integer RAM_WORDS=43777,
 parameter integer REGISTER_WORDS=627,
 parameter integer TOTAL_WORDS=RAM_WORDS+REGISTER_WORDS,
 parameter integer GROUP_WORDS=(TOTAL_WORDS+3)/4
)(
 input wire clk,reset,freeze,start_read,start_write,
 input wire [15:0] group_addr,
 input wire [63:0] word_in,
 output reg [15:0] scan_index=0,
 input wire [15:0] scan_dout,
 output wire [15:0] scan_din,
 output wire scan_we,scan_rotate,
 output reg [63:0] word_out=0,
 output wire busy,
 output reg done=0,aborted=0,rejected=0
);
 localparam IDLE=0,READ_WAIT=1,READ_CAPTURE=2,WRITE=3;
 reg [1:0] state=IDLE,lane=0;
 reg [15:0] base_index=0;
 reg [63:0] data_hold=0;
 wire lane_valid=(scan_index<TOTAL_WORDS);
 assign busy=(state!=IDLE);
 assign scan_we=(state==WRITE)&&freeze&&!reset&&lane_valid;
 assign scan_rotate=(state==READ_CAPTURE)&&freeze&&!reset&&lane_valid&&(scan_index>=RAM_WORDS);
 assign scan_din=data_hold[lane*16+:16];
 always @(posedge clk) begin
  done<=0;aborted<=0;rejected<=0;
  if(reset) state<=IDLE;
  else if(state!=IDLE&&!freeze) begin state<=IDLE;aborted<=1;end
  else case(state)
   IDLE: if(freeze && (start_read ^ start_write)) begin
      if(group_addr>=GROUP_WORDS) rejected<=1;
      else begin
       base_index<=group_addr*4;scan_index<=group_addr*4;lane<=0;data_hold<=word_in;
       if(start_read) begin word_out<=0;state<=READ_WAIT;end else state<=WRITE;
      end
   end
   READ_WAIT: state<=READ_CAPTURE;
   READ_CAPTURE: begin
      if(lane_valid)word_out[lane*16+:16]<=scan_dout;
      if(lane==3 || scan_index==TOTAL_WORDS-1)begin state<=IDLE;done<=1;end
      else begin lane<=lane+1'd1;scan_index<=base_index+lane+1'd1;state<=READ_WAIT;end
   end
   WRITE: begin
      if(lane==3 || scan_index==TOTAL_WORDS-1)begin state<=IDLE;done<=1;end
      else begin lane<=lane+1'd1;scan_index<=base_index+lane+1'd1;end
   end
   default:state<=IDLE;
  endcase
 end
endmodule
