// Experimental 8 x 8-bit SDRAM snapshot packer with a toggle/ack mailbox.
// Caller must OR hold_req into the *physical* machine freeze/ownership signal.
// cancel/reset while a request is outstanding waits for its response before
// releasing hold_req. A response that never arrives is fail-stop, not timeout.
module cd_ram_pack_engine (
 input wire clk, reset, freeze, cancel, start_read, start_write,
 input wire [14:0] group_addr,
 input wire [63:0] word_in,
 output reg [17:0] cell_addr=0,
 output reg [7:0] cell_din=0,
 output reg cell_write=0,cell_req=0,
 input wire cell_ack,
 input wire [7:0] cell_dout,
 output reg [63:0] word_out=0,
 output wire hold_req,busy,
 output reg done=0,aborted=0
);
 localparam IDLE=0,ISSUE=1,WAIT_ACK=2;
 reg [1:0] state=IDLE;
 reg [2:0] byte_index=0;
 reg [14:0] group_hold=0;
 reg [63:0] data_hold=0;
 reg abort_pending=0;
 (* async_reg="true" *) reg ack_meta=0,ack_sync=0;
 assign hold_req=(state!=IDLE);
 assign busy=hold_req;
 always @(posedge clk) begin
  ack_meta<=cell_ack;ack_sync<=ack_meta;done<=0;aborted<=0;
  case(state)
   IDLE: begin
     abort_pending<=0;
     if(!reset&&!cancel&&freeze&&(cell_req==ack_sync)&&(start_read ^ start_write)) begin
       group_hold<=group_addr;byte_index<=0;cell_addr<={group_addr,3'd0};
       cell_din<=word_in[7:0];cell_write<=start_write;data_hold<=word_in;
       word_out<=0;state<=ISSUE;
     end
   end
   ISSUE: begin
     if(reset||cancel||!freeze)begin state<=IDLE;aborted<=1;end
     else begin cell_req<=!cell_req;state<=WAIT_ACK;end
   end
   WAIT_ACK: begin
     if(reset||cancel||!freeze)abort_pending<=1;
     if(ack_sync==cell_req) begin
       if(abort_pending||reset||cancel||!freeze)begin state<=IDLE;aborted<=1;end
       else begin
         if(!cell_write)word_out[byte_index*8+:8]<=cell_dout;
         if(byte_index==7)begin state<=IDLE;done<=1;end
         else begin
           byte_index<=byte_index+1'd1;cell_addr<={group_hold,byte_index+3'd1};
           cell_din<=data_hold[(byte_index+3'd1)*8+:8];state<=ISSUE;
         end
       end
     end
   end
   default:state<=IDLE;
  endcase
 end
endmodule
