localparam integer SS_REGISTER_WORDS = 681;
localparam [63:0] SS_SCHEMA = 64'ha58e5a8c9764267f;
