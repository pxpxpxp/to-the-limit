// Experimental fixed-layout CD FIFO shadow packing. Same clk as FIFO wrappers.
// Group 0 = {29'b0, SCSI count[12:0], subcode count[8:0], CDDA count[12:0]};
// groups 1..2048 = CDDA pairs, 2049..2110 = subcode octets, 2111..2622 = SCSI octets.
// Start only while frozen after capture completes; load writes shadow RAM, not
// the active FIFOs. Commit/prepare and global HPS quiescence are parent duties.
module fifo_pack_engine(
 input wire clk,reset,freeze,start_read,start_write,
 input wire [11:0] group_addr,input wire [63:0] word_in,
 input wire [12:0] cdda_count,scsi_count,input wire [8:0] sub_count,
 output reg [12:0] cdda_count_in=0,scsi_count_in=0,output reg [8:0] sub_count_in=0,output reg set_count=0,
 output reg [1:0] scan_sel=0,output reg [11:0] scan_addr=0,
 output reg [31:0] scan_din=0,output reg scan_we=0,input wire [31:0] scan_dout,
 output reg [63:0] word_out=0,output wire busy,output reg done=0,rejected=0,aborted=0
);
 localparam IDLE=0,READ_WAIT=1,READ_CAPTURE=2,WRITE_ONE=3,WRITE_DONE=4;
 reg [2:0] state=IDLE;reg [2:0] lane=0;reg [11:0] base=0;reg [63:0] hold=0;reg [1:0] sel=0;
 assign busy=(state!=IDLE);
 always @(posedge clk) begin
  done<=0;rejected<=0;aborted<=0;set_count<=0;scan_we<=0;
  if(state!=IDLE && (reset||!freeze))begin state<=IDLE;aborted<=1;end
  else case(state)
   IDLE: if(!reset && freeze && (start_read ^ start_write))begin
    if(group_addr==0)begin
     if(start_read)begin word_out<={29'd0,scsi_count,sub_count,cdda_count};done<=1;end
     else if(word_in[63:35]!=0 || word_in[12:0]>4096 || word_in[21:13]>490 || word_in[34:22]>4096)rejected<=1;
     else begin cdda_count_in<=word_in[12:0];sub_count_in<=word_in[21:13];scsi_count_in<=word_in[34:22];set_count<=1;done<=1;end
    end else if(group_addr>2622 || (start_write && group_addr==2110 && word_in[63:16]!=0)) rejected<=1;
    else begin
     lane<=0;hold<=word_in;word_out<=0;
     if(group_addr<=2048)begin sel<=0;scan_sel<=0;base<=(group_addr-1)*2;scan_addr<=(group_addr-1)*2;end
     else if(group_addr<=2110)begin sel<=1;scan_sel<=1;base<=(group_addr-2049)*8;scan_addr<=(group_addr-2049)*8;end
     else begin sel<=2;scan_sel<=2;base<=(group_addr-2111)*8;scan_addr<=(group_addr-2111)*8;end
     if(start_read)state<=READ_WAIT;else state<=WRITE_ONE;
    end
   end
   READ_WAIT:state<=READ_CAPTURE; // external shadow RAM read is synchronous
   READ_CAPTURE:begin
    if(sel==0)word_out[lane*32+:32]<=scan_dout;
    else if(sel!=1 || base+lane<490)word_out[lane*8+:8]<=scan_dout[7:0];
    if((sel==0 && lane==1)||(sel!=0 && lane==7))begin state<=IDLE;done<=1;end
    else begin lane<=lane+1'b1;scan_addr<=base+lane+1'b1;state<=READ_WAIT;end
   end
   WRITE_ONE:begin
    scan_addr<=base+lane;
    scan_din<=sel==0 ? hold[lane*32+:32] : {24'd0,hold[lane*8+:8]};
    scan_we<=sel!=1 || base+lane<490;
    if((sel==0 && lane==1)||(sel!=0 && lane==7))state<=WRITE_DONE;
    else lane<=lane+1'b1;
   end
   WRITE_DONE: begin state<=IDLE;done<=1;end // last registered write lands here
   default:state<=IDLE;
  endcase
 end
endmodule
