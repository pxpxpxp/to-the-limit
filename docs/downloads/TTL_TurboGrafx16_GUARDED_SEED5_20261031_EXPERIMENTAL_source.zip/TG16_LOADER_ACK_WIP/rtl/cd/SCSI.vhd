library STD;
use STD.TEXTIO.ALL;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_TEXTIO.all;
use IEEE.NUMERIC_STD.ALL;

entity SCSI is
	port(
 SS_RROTATE : in std_logic := '0';
 SS_RADDR : in std_logic_vector(14 downto 0) := (others=>'0');
 SS_RDI : in std_logic_vector(15 downto 0) := (others=>'0');
 SS_RWE : in std_logic := '0';
 SS_RDO : out std_logic_vector(15 downto 0);
 SS_FIFO_IDLE : out std_logic;
 SS_FIFO_WRITE : out std_logic;
 SS_FREEZE : in std_logic := '0';
 SS_SAVE : in std_logic := '0';
 SS_LOAD : in std_logic := '0';

		RESET_N		: in std_logic;
		CLK 			: in std_logic;
		
		DBI			: in std_logic_vector(7 downto 0);
		DBO			: buffer std_logic_vector(7 downto 0);
		SEL_N			: in std_logic;
		ACK_N			: in std_logic;
		RST_N			: in std_logic;
		BSY_N			: buffer std_logic;
		REQ_N			: buffer std_logic;
		MSG_N			: buffer std_logic;
		CD_N			: buffer std_logic;
		IO_N			: buffer std_logic;
		
		STATUS		: in std_logic_vector(7 downto 0);
		MESSAGE		: in std_logic_vector(7 downto 0);
		STAT_GET		: in std_logic;
		
		COMMAND		: buffer std_logic_vector(95 downto 0);
		COMM_SEND	: buffer std_logic;
		
		DOUT_REQ		: in std_logic;
		DOUT			: buffer std_logic_vector(79 downto 0);
		DOUT_SEND	: buffer std_logic;
		
		CD_DATA		: in std_logic_vector(7 downto 0);
		CD_WR			: in std_logic;
		CD_DATA_END	: buffer std_logic;
		STOP_CD_SND	: buffer std_logic;
		
		DBG_DATAIN_CNT: buffer unsigned(15 downto 0)
	);
end SCSI;

architecture rtl of SCSI is
	
	type SCSIPhase_t is (
		SP_FREE,
		SP_COMM_BEFOREREQ,
		SP_COMM_START,
		SP_COMM_END,
		SP_STAT_START,
		SP_STAT_END,
		SP_STAT_HOLD,
		SP_MSGIN_START,
		SP_MSGIN_END,
		SP_MSGIN_HOLD,
		SP_DATAIN_START,
		SP_DATAIN_END,
		SP_DATAOUT_START,
		SP_DATAOUT_END
	);
	signal SP 			: SCSIPhase_t; 
	
	signal BSY_Nr 		: std_logic;
	signal MSG_Nr 		: std_logic;
	signal CD_Nr 		: std_logic;
	signal IO_Nr 		: std_logic;
	signal REQ_Nr 		: std_logic;
--	signal TR_DONE		: std_logic;
--	signal TR_RDY		: std_logic;
	
	type CommBuf_t is array (0 to 11) of std_logic_vector(7 downto 0);
	signal COMM 		: CommBuf_t;
	signal COMM_POS 	: unsigned(3 downto 0);
	signal COMM_OUT 	: std_logic;
	type CommLen_t is array (0 to 15) of unsigned(3 downto 0);
	constant COMM_LEN : CommLen_t :=
	("0110", "0110", "1010", "1010", "1010", "1010", "1010", "1010", "1010", "1010", "1100", "1100", "1010", "1010", "1010", "1010"); 

	type DataBuf_t is array (0 to 9) of std_logic_vector(7 downto 0);
	signal DATA_BUF 	: DataBuf_t;
	signal DATA_POS	: unsigned(3 downto 0);
	signal DATA_OUT	: std_logic;
	
	signal FULL 		: std_logic;
	signal EMPTY		: std_logic;
	signal FIFO_RD_REQ: std_logic;
	signal FIFO_WR_REQ: std_logic;
	signal FIFO_D 		: std_logic_vector(7 downto 0);
	signal FIFO_Q 		: std_logic_vector(7 downto 0);
	signal CD_WR_OLD 	: std_logic;
	signal STAT_PEND 	: std_logic;
	signal DOUT_PEND  : std_logic;
	
	signal DATAIN_CNT 	: unsigned(15 downto 0);

	signal STAT_COUNT    : unsigned(15 downto 0);
	signal DELAY_COUNT   : unsigned(16 downto 0);

signal SS_SH_BSY_NR : std_logic;
signal SS_SH_CD_DATA_END : std_logic;
signal SS_SH_CD_NR : std_logic;
signal SS_SH_CD_WR_OLD : std_logic;
signal SS_SH_COMM : CommBuf_t;
signal SS_SH_COMM_OUT : std_logic;
signal SS_SH_COMM_POS : unsigned(3 downto 0);
signal SS_SH_DATAIN_CNT : unsigned(15 downto 0);
signal SS_SH_DATA_BUF : DataBuf_t;
signal SS_SH_DATA_OUT : std_logic;
signal SS_SH_DATA_POS : unsigned(3 downto 0);
signal SS_SH_DBO : std_logic_vector(7 downto 0);
signal SS_SH_DELAY_COUNT : unsigned(16 downto 0);
signal SS_SH_DOUT_PEND : std_logic;
signal SS_SH_FIFO_D : std_logic_vector(7 downto 0);
signal SS_SH_FIFO_RD_REQ : std_logic;
signal SS_SH_FIFO_WR_REQ : std_logic;
signal SS_SH_IO_NR : std_logic;
signal SS_SH_MSG_NR : std_logic;
signal SS_SH_REQ_NR : std_logic;
signal SS_SH_SP : SCSIPhase_t;
signal SS_SH_STAT_COUNT : unsigned(15 downto 0);
signal SS_SH_STAT_PEND : std_logic;
signal SS_SH_STOP_CD_SND : std_logic;
signal SS_CHAIN, SS_CAPTURE_DATA : std_logic_vector(271 downto 0);
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin

	process( RESET_N, CLK )
	begin
		if RESET_N = '0' then
			FIFO_D <= (others => '0');
			FIFO_WR_REQ <= '0';
			
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CD_WR_OLD <= SS_SH_CD_WR_OLD;
FIFO_D <= SS_SH_FIFO_D;
FIFO_WR_REQ <= SS_SH_FIFO_WR_REQ;
elsif SS_FREEZE = '0' then

			FIFO_WR_REQ <= '0';

				CD_WR_OLD <= CD_WR;
				if CD_WR = '1' and CD_WR_OLD = '0' then
					FIFO_D <= CD_DATA;
					if FULL = '0' then
						FIFO_WR_REQ <= '1';
					end if;
				end if;

		
end if;
end if;
	end process;

	
	FIFO : entity work.SCSI_FIFO 
	port map(
		aclr     => not RESET_N,

		wrclk		=> CLK,
		data		=> FIFO_D,
		wrreq		=> FIFO_WR_REQ,
		wrfull	=> FULL,
		
		rdclk		=> CLK,
		rdreq		=> FIFO_RD_REQ,
		rdempty	=> EMPTY,
		q			=> FIFO_Q
	);

	process( CLK, RESET_N ) begin
		if RESET_N = '0' then
			DBO <= (others => '0');
			BSY_Nr <= '1';
			MSG_Nr <= '1';
			CD_Nr <= '1';
			IO_Nr <= '1';
			REQ_Nr <= '1';
			COMM <= (others => (others => '0'));
			COMM_POS <= (others => '0');
			DATA_BUF <= (others => (others => '0'));
			DATA_POS <= (others => '0');
			SP <= SP_FREE;
			STOP_CD_SND <= '0';
			
			COMM_OUT <= '0';
			DATA_OUT <= '0';
			CD_DATA_END <= '0';
			STAT_PEND <= '0';
			DOUT_PEND <= '0';
			FIFO_RD_REQ <= '0';
			
			STAT_COUNT  <= (others => '0');
			DELAY_COUNT <= (others => '0');
			
			DATAIN_CNT  <= (others => '0');

		elsif rising_edge( CLK ) then
if SS_LOAD = '1' then
BSY_NR <= SS_SH_BSY_NR;
CD_DATA_END <= SS_SH_CD_DATA_END;
CD_NR <= SS_SH_CD_NR;
COMM <= SS_SH_COMM;
COMM_OUT <= SS_SH_COMM_OUT;
COMM_POS <= SS_SH_COMM_POS;
DATAIN_CNT <= SS_SH_DATAIN_CNT;
DATA_BUF <= SS_SH_DATA_BUF;
DATA_OUT <= SS_SH_DATA_OUT;
DATA_POS <= SS_SH_DATA_POS;
DBO <= SS_SH_DBO;
DELAY_COUNT <= SS_SH_DELAY_COUNT;
DOUT_PEND <= SS_SH_DOUT_PEND;
FIFO_RD_REQ <= SS_SH_FIFO_RD_REQ;
IO_NR <= SS_SH_IO_NR;
MSG_NR <= SS_SH_MSG_NR;
REQ_NR <= SS_SH_REQ_NR;
SP <= SS_SH_SP;
STAT_COUNT <= SS_SH_STAT_COUNT;
STAT_PEND <= SS_SH_STAT_PEND;
STOP_CD_SND <= SS_SH_STOP_CD_SND;
elsif SS_FREEZE = '0' then

			if STAT_GET = '1' then
				STAT_PEND <= '1';
			end if;
			
			if DOUT_REQ = '1' then
				DOUT_PEND <= '1';
			end if;
			

			COMM_OUT <= '0';
			DATA_OUT <= '0';
			CD_DATA_END <= '0';
			FIFO_RD_REQ <= '0';
			
			if RST_N = '0' then
				BSY_Nr <= '1';
				MSG_Nr <= '1';
				CD_Nr <= '1';
				IO_Nr <= '1';
				REQ_Nr <= '1';
			else
				case SP is
					when SP_FREE =>
						if SEL_N = '0' then
							BSY_Nr <= '0';
							MSG_Nr <= '1';
							CD_Nr <= '0';
							IO_Nr <= '1';
							SP <= SP_COMM_BEFOREREQ;
							DELAY_COUNT <= to_unsigned(1700, DELAY_COUNT'LENGTH);		
							DATAIN_CNT <= (others => '0');
						elsif STAT_PEND = '1' then
							STAT_COUNT <= STAT_COUNT + 1;

							if (STAT_COUNT = 45000) then		
																		
																		
								STAT_COUNT <= (others => '0');
								STAT_PEND <= '0';
								DBO <= STATUS;
								BSY_Nr <= '0';
								MSG_Nr <= '1';
								CD_Nr <= '0';
								IO_Nr <= '0';
								REQ_Nr <= '0';
								SP <= SP_STAT_START;
							end if;
						elsif EMPTY = '0' then
							DBO <= FIFO_Q;
							BSY_Nr <= '0';
							MSG_Nr <= '1';
							CD_Nr <= '1';
							IO_Nr <= '0';
							REQ_Nr <= '0';
							FIFO_RD_REQ <= '1';
							SP <= SP_DATAIN_START;
						elsif DOUT_PEND = '1' then
							DOUT_PEND <= '0';
							BSY_Nr <= '0';
							MSG_Nr <= '1';
							CD_Nr <= '1';
							IO_Nr <= '1';
							REQ_Nr <= '0';
							SP <= SP_DATAOUT_START;
						end if;
						
					when SP_COMM_BEFOREREQ =>
						if (DELAY_COUNT = 0) then
							REQ_Nr <= '0';
							SP <= SP_COMM_START;
						else
							DELAY_COUNT <= DELAY_COUNT - 1;
						end if;

					when SP_COMM_START =>
						if REQ_Nr = '0' and ACK_N = '0' then
							REQ_Nr <= '1';
							COMM(to_integer(COMM_POS)) <= DBI;
							COMM_POS <= COMM_POS + 1;
							SP <= SP_COMM_END;
						end if;
					
					when SP_COMM_END =>
						if REQ_Nr = '1' and ACK_N = '1' then
							if COMM_POS = COMM_LEN(to_integer(unsigned(COMM(0)(7 downto 4)))) then
								COMM_POS <= (others => '0');
								COMM_OUT <= '1';
								CD_Nr <= '1';
								SP <= SP_FREE;
								if ((COMM(0) = x"08") or (COMM(0) = x"DA")) then	
									STOP_CD_SND <= '1';
								end if;
								if ((COMM(0) = x"D8") or (COMM(0) = x"D9")) then	
									STOP_CD_SND <= '0';
								end if;
							else
								SP <= SP_COMM_BEFOREREQ;
								DELAY_COUNT <= to_unsigned(5370, DELAY_COUNT'LENGTH);	
							end if;
						end if;

					when SP_STAT_START =>
						if REQ_Nr = '0' and ACK_N = '0' then
							REQ_Nr <= '1';
							SP <= SP_STAT_END;
						end if;
					
					when SP_STAT_END =>
						if REQ_Nr = '1' and ACK_N = '1' then
							SP <= SP_STAT_HOLD;
							DELAY_COUNT <= to_unsigned(49400, DELAY_COUNT'LENGTH);	
						end if;

					when SP_STAT_HOLD =>
						if (DELAY_COUNT = 0) then
							DBO <= MESSAGE;
							BSY_Nr <= '0';
							MSG_Nr <= '0';
							CD_Nr <= '0';
							IO_Nr <= '0';
							REQ_Nr <= '0';
							SP <= SP_MSGIN_START;
						else
							DELAY_COUNT <= DELAY_COUNT - 1;
						end if;
					
					when SP_MSGIN_START =>
						if REQ_Nr = '0' and ACK_N = '0' then
							REQ_Nr <= '1';
							SP <= SP_MSGIN_END;
						end if;
					
					when SP_MSGIN_END =>
						if REQ_Nr = '1' and ACK_N = '1' then
							SP <= SP_MSGIN_HOLD;
							DELAY_COUNT <= to_unsigned(6600, DELAY_COUNT'LENGTH);		
						end if;

					when SP_MSGIN_HOLD =>
						if (DELAY_COUNT = 0) then
							BSY_Nr <= '1';
							MSG_Nr <= '1';
							CD_Nr <= '1';
							IO_Nr <= '1';
							REQ_Nr <= '1';
							SP <= SP_FREE;
						else
							DELAY_COUNT <= DELAY_COUNT - 1;
						end if;

					when SP_DATAIN_START =>
						if REQ_Nr = '0' and ACK_N = '0' then
							REQ_Nr <= '1';
							SP <= SP_DATAIN_END;
							STOP_CD_SND <= '0';		
						end if;
					
					when SP_DATAIN_END =>
						if REQ_Nr = '1' and ACK_N = '1' then
							if EMPTY = '0' then
								DBO <= FIFO_Q;
								REQ_Nr <= '0';
								FIFO_RD_REQ <= '1';
								SP <= SP_DATAIN_START;
							else
								CD_DATA_END <= '1';
								SP <= SP_FREE;
							end if;
							DATAIN_CNT <= DATAIN_CNT + 1;
						end if;
						
					when SP_DATAOUT_START =>
						if REQ_Nr = '0' and ACK_N = '0' then
							REQ_Nr <= '1';
							DATA_BUF(to_integer(DATA_POS)) <= DBI;
							DATA_POS <= DATA_POS + 1;
							SP <= SP_DATAOUT_END;
						end if;
					
					when SP_DATAOUT_END =>
						if REQ_Nr = '1' and ACK_N = '1' then
							if DATA_POS = 10 then
								DATA_POS <= (others => '0');
								DATA_OUT <= '1';
								SP <= SP_FREE;
							else
								REQ_Nr <= '0';
								SP <= SP_DATAOUT_START;
							end if;
						end if;
						
					when others => null;
				end case;
			end if;
		
end if;
end if;
	end process;
	
	SS_FIFO_IDLE <= EMPTY and not FIFO_RD_REQ and not FIFO_WR_REQ;
 SS_FIFO_WRITE <= FIFO_WR_REQ;
 BSY_N <= BSY_Nr;
	MSG_N <= MSG_Nr;
	CD_N <= CD_Nr;
	IO_N <= IO_Nr;
	REQ_N <= REQ_Nr;
	
	COMMAND <= COMM(11) & COMM(10) & COMM(9) & COMM(8) & COMM(7) & COMM(6) & COMM(5) & COMM(4) & COMM(3) & COMM(2) & COMM(1) & COMM(0);
	COMM_SEND <= COMM_OUT;
	
	DOUT <= DATA_BUF(9) & DATA_BUF(8) & DATA_BUF(7) & DATA_BUF(6) & DATA_BUF(5) & DATA_BUF(4) & DATA_BUF(3) & DATA_BUF(2) & DATA_BUF(1) & DATA_BUF(0);
	DOUT_SEND <= DATA_OUT;
	
	DBG_DATAIN_CNT <= DATAIN_CNT;


SS_CAPTURE_DATA(0) <= BSY_NR;
SS_CAPTURE_DATA(1) <= CD_DATA_END;
SS_CAPTURE_DATA(2) <= CD_NR;
SS_CAPTURE_DATA(3) <= CD_WR_OLD;
SS_CAPTURE_DATA(11 downto 4) <= std_logic_vector(COMM(0)(7 downto 0));
SS_CAPTURE_DATA(15 downto 12) <= std_logic_vector(COMM(1)(3 downto 0));
SS_CAPTURE_DATA(19 downto 16) <= std_logic_vector(COMM(1)(7 downto 4));
SS_CAPTURE_DATA(27 downto 20) <= std_logic_vector(COMM(2)(7 downto 0));
SS_CAPTURE_DATA(31 downto 28) <= std_logic_vector(COMM(3)(3 downto 0));
SS_CAPTURE_DATA(35 downto 32) <= std_logic_vector(COMM(3)(7 downto 4));
SS_CAPTURE_DATA(43 downto 36) <= std_logic_vector(COMM(4)(7 downto 0));
SS_CAPTURE_DATA(47 downto 44) <= std_logic_vector(COMM(5)(3 downto 0));
SS_CAPTURE_DATA(51 downto 48) <= std_logic_vector(COMM(5)(7 downto 4));
SS_CAPTURE_DATA(59 downto 52) <= std_logic_vector(COMM(6)(7 downto 0));
SS_CAPTURE_DATA(63 downto 60) <= std_logic_vector(COMM(7)(3 downto 0));
SS_CAPTURE_DATA(67 downto 64) <= std_logic_vector(COMM(7)(7 downto 4));
SS_CAPTURE_DATA(75 downto 68) <= std_logic_vector(COMM(8)(7 downto 0));
SS_CAPTURE_DATA(79 downto 76) <= std_logic_vector(COMM(9)(3 downto 0));
SS_CAPTURE_DATA(83 downto 80) <= std_logic_vector(COMM(9)(7 downto 4));
SS_CAPTURE_DATA(91 downto 84) <= std_logic_vector(COMM(10)(7 downto 0));
SS_CAPTURE_DATA(95 downto 92) <= std_logic_vector(COMM(11)(3 downto 0));
SS_CAPTURE_DATA(99 downto 96) <= std_logic_vector(COMM(11)(7 downto 4));
SS_CAPTURE_DATA(100) <= COMM_OUT;
SS_CAPTURE_DATA(104 downto 101) <= std_logic_vector(COMM_POS(3 downto 0));
SS_CAPTURE_DATA(111 downto 105) <= std_logic_vector(DATAIN_CNT(6 downto 0));
SS_CAPTURE_DATA(120 downto 112) <= std_logic_vector(DATAIN_CNT(15 downto 7));
SS_CAPTURE_DATA(127 downto 121) <= std_logic_vector(DATA_BUF(0)(6 downto 0));
SS_CAPTURE_DATA(128 downto 128) <= std_logic_vector(DATA_BUF(0)(7 downto 7));
SS_CAPTURE_DATA(136 downto 129) <= std_logic_vector(DATA_BUF(1)(7 downto 0));
SS_CAPTURE_DATA(143 downto 137) <= std_logic_vector(DATA_BUF(2)(6 downto 0));
SS_CAPTURE_DATA(144 downto 144) <= std_logic_vector(DATA_BUF(2)(7 downto 7));
SS_CAPTURE_DATA(152 downto 145) <= std_logic_vector(DATA_BUF(3)(7 downto 0));
SS_CAPTURE_DATA(159 downto 153) <= std_logic_vector(DATA_BUF(4)(6 downto 0));
SS_CAPTURE_DATA(160 downto 160) <= std_logic_vector(DATA_BUF(4)(7 downto 7));
SS_CAPTURE_DATA(168 downto 161) <= std_logic_vector(DATA_BUF(5)(7 downto 0));
SS_CAPTURE_DATA(175 downto 169) <= std_logic_vector(DATA_BUF(6)(6 downto 0));
SS_CAPTURE_DATA(176 downto 176) <= std_logic_vector(DATA_BUF(6)(7 downto 7));
SS_CAPTURE_DATA(184 downto 177) <= std_logic_vector(DATA_BUF(7)(7 downto 0));
SS_CAPTURE_DATA(191 downto 185) <= std_logic_vector(DATA_BUF(8)(6 downto 0));
SS_CAPTURE_DATA(192 downto 192) <= std_logic_vector(DATA_BUF(8)(7 downto 7));
SS_CAPTURE_DATA(200 downto 193) <= std_logic_vector(DATA_BUF(9)(7 downto 0));
SS_CAPTURE_DATA(201) <= DATA_OUT;
SS_CAPTURE_DATA(205 downto 202) <= std_logic_vector(DATA_POS(3 downto 0));
SS_CAPTURE_DATA(207 downto 206) <= std_logic_vector(DBO(1 downto 0));
SS_CAPTURE_DATA(213 downto 208) <= std_logic_vector(DBO(7 downto 2));
SS_CAPTURE_DATA(223 downto 214) <= std_logic_vector(DELAY_COUNT(9 downto 0));
SS_CAPTURE_DATA(230 downto 224) <= std_logic_vector(DELAY_COUNT(16 downto 10));
SS_CAPTURE_DATA(231) <= DOUT_PEND;
SS_CAPTURE_DATA(239 downto 232) <= std_logic_vector(FIFO_D(7 downto 0));
SS_CAPTURE_DATA(240) <= FIFO_RD_REQ;
SS_CAPTURE_DATA(241) <= FIFO_WR_REQ;
SS_CAPTURE_DATA(242) <= IO_NR;
SS_CAPTURE_DATA(243) <= MSG_NR;
SS_CAPTURE_DATA(244) <= REQ_NR;
SS_CAPTURE_DATA(248 downto 245) <= std_logic_vector(to_unsigned(SCSIPhase_t'pos(SP),4));
SS_CAPTURE_DATA(255 downto 249) <= std_logic_vector(STAT_COUNT(6 downto 0));
SS_CAPTURE_DATA(264 downto 256) <= std_logic_vector(STAT_COUNT(15 downto 7));
SS_CAPTURE_DATA(265) <= STAT_PEND;
SS_CAPTURE_DATA(266) <= STOP_CD_SND;
SS_CAPTURE_DATA(267) <= '0';
SS_CAPTURE_DATA(268) <= '0';
SS_CAPTURE_DATA(269) <= '0';
SS_CAPTURE_DATA(270) <= '0';
SS_CAPTURE_DATA(271) <= '0';
SS_SH_BSY_NR <= SS_CHAIN(0);
SS_SH_CD_DATA_END <= SS_CHAIN(1);
SS_SH_CD_NR <= SS_CHAIN(2);
SS_SH_CD_WR_OLD <= SS_CHAIN(3);
SS_SH_COMM(0)(7 downto 0) <= SS_CHAIN(11 downto 4);
SS_SH_COMM(1)(3 downto 0) <= SS_CHAIN(15 downto 12);
SS_SH_COMM(1)(7 downto 4) <= SS_CHAIN(19 downto 16);
SS_SH_COMM(2)(7 downto 0) <= SS_CHAIN(27 downto 20);
SS_SH_COMM(3)(3 downto 0) <= SS_CHAIN(31 downto 28);
SS_SH_COMM(3)(7 downto 4) <= SS_CHAIN(35 downto 32);
SS_SH_COMM(4)(7 downto 0) <= SS_CHAIN(43 downto 36);
SS_SH_COMM(5)(3 downto 0) <= SS_CHAIN(47 downto 44);
SS_SH_COMM(5)(7 downto 4) <= SS_CHAIN(51 downto 48);
SS_SH_COMM(6)(7 downto 0) <= SS_CHAIN(59 downto 52);
SS_SH_COMM(7)(3 downto 0) <= SS_CHAIN(63 downto 60);
SS_SH_COMM(7)(7 downto 4) <= SS_CHAIN(67 downto 64);
SS_SH_COMM(8)(7 downto 0) <= SS_CHAIN(75 downto 68);
SS_SH_COMM(9)(3 downto 0) <= SS_CHAIN(79 downto 76);
SS_SH_COMM(9)(7 downto 4) <= SS_CHAIN(83 downto 80);
SS_SH_COMM(10)(7 downto 0) <= SS_CHAIN(91 downto 84);
SS_SH_COMM(11)(3 downto 0) <= SS_CHAIN(95 downto 92);
SS_SH_COMM(11)(7 downto 4) <= SS_CHAIN(99 downto 96);
SS_SH_COMM_OUT <= SS_CHAIN(100);
SS_SH_COMM_POS(3 downto 0) <= unsigned(SS_CHAIN(104 downto 101));
SS_SH_DATAIN_CNT(6 downto 0) <= unsigned(SS_CHAIN(111 downto 105));
SS_SH_DATAIN_CNT(15 downto 7) <= unsigned(SS_CHAIN(120 downto 112));
SS_SH_DATA_BUF(0)(6 downto 0) <= SS_CHAIN(127 downto 121);
SS_SH_DATA_BUF(0)(7 downto 7) <= SS_CHAIN(128 downto 128);
SS_SH_DATA_BUF(1)(7 downto 0) <= SS_CHAIN(136 downto 129);
SS_SH_DATA_BUF(2)(6 downto 0) <= SS_CHAIN(143 downto 137);
SS_SH_DATA_BUF(2)(7 downto 7) <= SS_CHAIN(144 downto 144);
SS_SH_DATA_BUF(3)(7 downto 0) <= SS_CHAIN(152 downto 145);
SS_SH_DATA_BUF(4)(6 downto 0) <= SS_CHAIN(159 downto 153);
SS_SH_DATA_BUF(4)(7 downto 7) <= SS_CHAIN(160 downto 160);
SS_SH_DATA_BUF(5)(7 downto 0) <= SS_CHAIN(168 downto 161);
SS_SH_DATA_BUF(6)(6 downto 0) <= SS_CHAIN(175 downto 169);
SS_SH_DATA_BUF(6)(7 downto 7) <= SS_CHAIN(176 downto 176);
SS_SH_DATA_BUF(7)(7 downto 0) <= SS_CHAIN(184 downto 177);
SS_SH_DATA_BUF(8)(6 downto 0) <= SS_CHAIN(191 downto 185);
SS_SH_DATA_BUF(8)(7 downto 7) <= SS_CHAIN(192 downto 192);
SS_SH_DATA_BUF(9)(7 downto 0) <= SS_CHAIN(200 downto 193);
SS_SH_DATA_OUT <= SS_CHAIN(201);
SS_SH_DATA_POS(3 downto 0) <= unsigned(SS_CHAIN(205 downto 202));
SS_SH_DBO(1 downto 0) <= SS_CHAIN(207 downto 206);
SS_SH_DBO(7 downto 2) <= SS_CHAIN(213 downto 208);
SS_SH_DELAY_COUNT(9 downto 0) <= unsigned(SS_CHAIN(223 downto 214));
SS_SH_DELAY_COUNT(16 downto 10) <= unsigned(SS_CHAIN(230 downto 224));
SS_SH_DOUT_PEND <= SS_CHAIN(231);
SS_SH_FIFO_D(7 downto 0) <= SS_CHAIN(239 downto 232);
SS_SH_FIFO_RD_REQ <= SS_CHAIN(240);
SS_SH_FIFO_WR_REQ <= SS_CHAIN(241);
SS_SH_IO_NR <= SS_CHAIN(242);
SS_SH_MSG_NR <= SS_CHAIN(243);
SS_SH_REQ_NR <= SS_CHAIN(244);
SS_SH_SP <= SCSIPhase_t'val(to_integer(unsigned(SS_CHAIN(248 downto 245)))) when to_integer(unsigned(SS_CHAIN(248 downto 245))) <= 13 else SCSIPhase_t'val(0);
SS_SH_STAT_COUNT(6 downto 0) <= unsigned(SS_CHAIN(255 downto 249));
SS_SH_STAT_COUNT(15 downto 7) <= unsigned(SS_CHAIN(264 downto 256));
SS_SH_STAT_PEND <= SS_CHAIN(265);
SS_SH_STOP_CD_SND <= SS_CHAIN(266);
SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 599 and to_integer(unsigned(SS_RADDR)) < 616 else (others=>'0');
process(CLK) begin if rising_edge(CLK) then
 SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
 if SS_CHAIN_CAPTURE(1)='1' then SS_CHAIN <= SS_CAPTURE_DATA;
 elsif SS_RWE='1' and (to_integer(unsigned(SS_RADDR)) >= 599 and to_integer(unsigned(SS_RADDR)) < 616) then SS_CHAIN <= SS_RDI & SS_CHAIN(271 downto 16);
 elsif SS_RROTATE='1' and (to_integer(unsigned(SS_RADDR)) >= 599 and to_integer(unsigned(SS_RADDR)) < 616) then SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(271 downto 16);
 end if;
end if; end process;
SS_RDO <= SS_LOCAL_RDO;
end rtl;
