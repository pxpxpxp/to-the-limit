-- Experimental atomic ADPCM snapshot RAM; do not release without full-system
-- simulation, Quartus fitting/timing and firmware/hardware validation.
library ieee; use ieee.std_logic_1164.all;
entity adpcm_snapshot_ram is
 generic(SS_REG_BASE:integer := -1);
 port(
  CLK:in std_logic;
  ADDRESS_A:in std_logic_vector(16 downto 0);
  DATA_A:in std_logic_vector(3 downto 0);
  WREN_A:in std_logic;
  Q_A:out std_logic_vector(3 downto 0);
  SS_FREEZE,SS_SAVE,SS_LOAD:in std_logic;
  SS_RADDR:in std_logic_vector(14 downto 0);
  SS_RDI:in std_logic_vector(15 downto 0);
  SS_RWE:in std_logic;
  SS_RDO:out std_logic_vector(15 downto 0);
  SS_ADDR:in std_logic_vector(16 downto 0);
  SS_DI:in std_logic_vector(3 downto 0);
  SS_WE:in std_logic;
  SS_DO:out std_logic_vector(3 downto 0)
 );
end entity;
architecture rtl of adpcm_snapshot_ram is
 signal active_bank:std_logic:='0';
 signal q0,q1,scan0,scan1:std_logic_vector(3 downto 0);
 signal rdo0,rdo1:std_logic_vector(15 downto 0);
begin
 -- No reset: soft console reset must not select a partially written stage.
 -- The caller only commits a complete, twice-validated image while frozen.
 process(CLK) begin if rising_edge(CLK) then
  if SS_FREEZE='1' and SS_LOAD='1' then active_bank<=not active_bank;end if;
 end if;end process;
 Q_A <= q0 when active_bank='0' else q1;
 SS_DO <= scan0 when active_bank='0' else scan1;
 SS_RDO <= rdo0 when active_bank='0' else rdo1;
 bank0:entity work.dpram generic map(17,4,SS_REG_BASE=>SS_REG_BASE)
 port map(clock=>CLK,address_a=>ADDRESS_A,data_a=>DATA_A,
  enable_a=>not SS_FREEZE and not active_bank,wren_a=>WREN_A and not active_bank,q_a=>q0,
  SS_FREEZE=>SS_FREEZE,SS_SAVE=>SS_SAVE,SS_ADDR=>SS_ADDR,SS_DI=>SS_DI,
  SS_WE=>SS_WE and active_bank,SS_DO=>scan0,
  SS_RADDR=>SS_RADDR,SS_RDI=>SS_RDI,SS_RWE=>SS_RWE,SS_RDO=>rdo0);
 bank1:entity work.dpram generic map(17,4,SS_REG_BASE=>SS_REG_BASE)
 port map(clock=>CLK,address_a=>ADDRESS_A,data_a=>DATA_A,
  enable_a=>not SS_FREEZE and active_bank,wren_a=>WREN_A and active_bank,q_a=>q1,
  SS_FREEZE=>SS_FREEZE,SS_SAVE=>SS_SAVE,SS_ADDR=>SS_ADDR,SS_DI=>SS_DI,
  SS_WE=>SS_WE and not active_bank,SS_DO=>scan1,
  SS_RADDR=>SS_RADDR,SS_RDI=>SS_RDI,SS_RWE=>SS_RWE,SS_RDO=>rdo1);
end architecture;
