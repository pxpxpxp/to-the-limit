# Core audio snapshot candidate

The core PSG and ADPCM output filters, filter history and phase, audio divider,
enables and mixer pipeline are held and restored. The separate system IIR and
downstream display chain are unchanged. Audio identity settings are included
in the configuration ID. The recirculating audio chain uses register words
627–680. Physical freeze includes deferred CD-RAM/FIFO rollback holds.

The exact top-level audio block has a 130,000-cycle replay test across four
filter/divider phases and mixer settings with no-unknown output checks. This is
a simulation using synthetic input, not the real game, FPGA timing or audible
hardware validation. Controller and whole-core test logs describe their own
limits. Inherited filter multicycle exceptions can mask paths into the new
audio shadow; those paths require explicit stricter routed timing analysis.

Core audio divider, CEs, mixer and filter state have explicit FPGA-configuration initial values. This fixes natural-start 4-state unknowns in the test model; it is not a soft-reset change. The audio-only candidate used schema `dee35671fc44fdd3`; the current CDC-integrated WIP uses `a58e5a8c9764267f`. Standalone pre-fit probes and sampled-state comparisons are not a full fitted-hardware proof.
