# Guarded HuCard loader-ack timing experiment — source-only WIP

This source adds a preserved clk_sys sample of the DDR write-acknowledgment before the cartridge loader's address-enable comparator. It addresses a routed related-clock path that failed the stricter one-cycle check; no timing exception was relaxed. The source is not yet fitted, audited or hardware-tested and contains no approved RBF.

Behavioral tests cover delayed two-ack toggle sequences, six clock phases, production ddram/cache writes and a drained-reset restart. They do not prove real HPS timing or reset during an in-flight transfer. Populous PRAM and other guarded configurations remain unsupported; this is not an all-HuCard release. CD save states are a later stage. See the preserved source notices and ATTRIBUTION.md; inventory files identify the earlier audited interim and fuller baseline and must not be mistaken for hashes of this changed top-level file.
