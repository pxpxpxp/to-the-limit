# Preserved notice index — loader-ack WIP

Scan of included text files before inventory additions; original file headers remain authoritative.

## ATTRIBUTION.md

```text
3: Audit: 2026-10-31. This is an independent **To the Limit** experimental derivative, not an official MiSTer release or an endorsement by the contributors below. Existing source copyright and license notices are retained. No game ROM or BIOS is supplied.
35: | `sys/spdif.v` | Ultra-Embedded.com, Copyright 2012; GPL-2.0-or-later |
36: | `sys/f2sdram_safe_terminator.sv` | bellwood420, Copyright 2021; no explicit license statement located in this file |
37: | `sys/yc_out.sv` | Mike Simone, Copyright 2022; GPL-2.0-or-later |
38: | Generated PLL, reconfiguration and CD FIFO HDL | Intel / Altera; vendor-specific notices and restrictions retained in each file. **Not relicensed by this document or COPYING.** |
40: Files without individual attribution/license headers (including several original CPU/VDC/PSG modules and support utilities) remain identified by path and hash. Absence of a header is **not** a public-domain determination, permission grant, or evidence of authorship by this project. Historical authorship beyond the verified README and file headers is unresolved; do not invent individual ownership assignments.
44: `docs/NinjaSpirit_SaveStates_initial.md` explicitly identifies SNES, GBA and PSX implementations as **architectural references, not code ports**. Preserve its links to [SNES savestates](https://github.com/MiSTer-devel/SNES_MiSTer/blob/master/rtl/savestates.sv), [SNES top level](https://github.com/MiSTer-devel/SNES_MiSTer/blob/master/rtl/SNES.vhd), [GBA save states](https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/gba_savestates.vhd), [GBA state registers](https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/reg_savestates.vhd), and [PSX save states](https://github.com/MiSTer-devel/PSX_MiSTer/blob/main/rtl/savestates.vhd). “SNES-style menu” describes interface inspiration, not SNES code authorship or compatibility.
46: The interim's `savestate/firmware_persistence_audit/` contains extracted functions from official [Main_MiSTer commit 08271656799ede50358de1248f6ee878dd7ce5c4](https://github.com/MiSTer-devel/Main_MiSTer/tree/08271656799ede50358de1248f6ee878dd7ce5c4), not a newly authored firmware implementation. Its README preserves exact source lines and blob IDs for `process_ss.inc` / `user_io.cpp` and `file_path.inc` / `file_io.cpp`; its full upstream GPL-3.0 LICENSE is retained.
52: `LICENSES/GPL-2.txt`, `LICENSES/GPL-3.txt`, and `LICENSES/LGPL-3.txt` reproduce the complete GNU license texts from this environment's `/usr/share/common-licenses`. Root `COPYING` indexes both GPL versions and LGPL without choosing a version for ambiguous files; it does not remove any file's stated version choice, change authorship, override custom/vendor terms, or assign a license to files with unresolved terms. LGPL v3 is read together with GPL v3. Preserve all source notices and these texts when redistributing the corresponding source. Distribute an RBF with access to its matching source, not a later unrelated WIP snapshot.
62: The first 80 lines of all 75 `rtl/` and `sys/` HDL/header paths in the delivered interim were requested at the recorded upstream commit. 72 existed upstream; 3 were local additions. Every copyright, explicit GPL-label and TEMLIB permission line found in those upstream prefixes was retained in the corresponding complete interim file (zero missing/changed matching notice lines). This bounded cross-check complements the full-text local inventory; it is not a complete authorship-history reconstruction.
```

## ATTRIBUTION_NOTICES_fuller_wip.md

```text
8: 81: If you can read copyright string at the end of US BIOS file, then it's not correct dump! It's already pre-swapped for emulators.
9: 82: While it will work on MiSTer, some CD games will refuse to start. **Correct US BIOS file is when copyright string is not readable.**
10: 146: The 'Original' palette is based on reverse engineering work of the VDP by [furrtek](https://github.com/furrtek). An RGB to YUV lookup table was discovered that translates the colors to their intended values with the composite output of the console. Further work was done by [ArtemioUrbina](https://github.com/ArtemioUrbina) to verify the color output. [Kitrinx](https://github.com/Kitrinx) created a tool to generate the resulting [palette](https://github.com/Kitrinx/TG16_Palette).
16: 5: //  Copyright (C) 2017-2019 Sorgelig
22: 3: To the Limit — TurboGrafx-16 / PC Engine, based on upstream
23: 57: These are architectural references, not code ports or compatibility claims.
29: 3: // Copyright (c) 2020 Alexey Melnikov
35: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
36: 33: --authorized distributors.  Please refer to the applicable 
42: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
43: 33: --authorized distributors.  Please refer to the applicable 
49: 21: --Copyright (C) 1991-2014 Altera Corporation
50: 32: --Altera or its authorized distributors.  Please refer to the 
56: 3: // Copyright (c) 2018 Sorgelig
57: 5: // This program is GPL v2+ Licensed.
63: 3: // Copyright (c) 2020 Sorgelig
69: 4: // Copyright (c) 2020 Alexey Melnikov
75: 3: --  Copyright (C) 2018 Sorgelig
81: 102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
87: 13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
88: 20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
94: 31: //	Copyright (C) 1991-2020 Altera Corporation
95: 41: //	any other silicon devices, unless such use is explicitly licensed under
96: 43: //	the intellectual property, including patents, copyrights, trademarks,
102: 5: // Copyright (c) 2018 Sorgelig
103: 7: // Based on sdram module by Till Harbaum
109: 3: //  Copyright (C) 2020 Sorgelig
115: 5: //  Copyright (C) 2017-2019 Sorgelig
121: 3: //  Copyright (C) 2020 Sorgelig
127: 2: Copyright 2005, 2006, 2007 Dennis van Weeren
128: 3: Copyright 2008, 2009 Jakub Bednarski
134: 3: // Copyright (c) 2020 Alexey Melnikov
140: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
141: 33: --authorized distributors.  Please refer to the applicable 
147: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
148: 33: --authorized distributors.  Please refer to the applicable 
154: 21: --Copyright (C) 1991-2014 Altera Corporation
155: 32: --Altera or its authorized distributors.  Please refer to the 
161: 3: // Copyright (c) 2018 Sorgelig
162: 5: // This program is GPL v2+ Licensed.
168: 3: // Copyright (c) 2020 Sorgelig
174: 4: // Copyright (c) 2020 Alexey Melnikov
180: 3: --  Copyright (C) 2018 Sorgelig
186: 102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
192: 13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
193: 20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
199: 31: //	Copyright (C) 1991-2020 Altera Corporation
200: 41: //	any other silicon devices, unless such use is explicitly licensed under
201: 43: //	the intellectual property, including patents, copyrights, trademarks,
207: 5: // Copyright (c) 2018 Sorgelig
208: 7: // Based on sdram module by Till Harbaum
214: 5: //  Copyright (C) 2017-2019 Sorgelig
220: 5: //  Copyright (C) 2017-2019 Sorgelig
226: 5: // Copyright (c) 2018 Sorgelig
227: 7: // Based on sdram module by Till Harbaum
233: 5: //  Copyright (C) 2017-2019 Sorgelig
239: 3: //  Copyright (C) 2017-2020 Sorgelig
240: 150: //  Copyright (C) 2020 Sorgelig
246: 6: -- This code can be freely distributed and used for any purpose, but, if you
252: 2: // Copyright (c) 2020 Alexey Melnikov
258: 15: //Must be based on CLK_VIDEO
264: 6: // Copyright (c) 2021 bellwood420
270: 4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
271: 5: // Copyright (c) 2017-2026 Alexey Melnikov
277: 3: // Copyright (c) 2012-2013 Ludvig Strigeus
278: 4: // Copyright (c) 2017,2018 Sorgelig
279: 6: // This program is GPL Licensed. See COPYING for the full license.
285: 3: //  Copyright (C) 2020 Sorgelig
291: 4: //  Copyright (C) 2019 Sorgelig
297: 13: set_global_assignment -entity "pll_audio" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
298: 20: set_global_assignment -entity "pll_audio_0002" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
304: 28: //	Copyright (C) 1991-2020 Altera Corporation
305: 38: //	any other silicon devices, unless such use is explicitly licensed under
306: 40: //	the intellectual property, including patents, copyrights, trademarks,
312: 10: // Intel or its authorized distributors.  Please refer to the applicable 
318: 10: // Intel or its authorized distributors.  Please refer to the applicable 
324: 59: //	Copyright (C) 1991-2018 Altera Corporation
325: 69: //	any other silicon devices, unless such use is explicitly licensed under
326: 71: //	the intellectual property, including patents, copyrights, trademarks,
332: 10: // Intel or its authorized distributors.  Please refer to the applicable 
338: 13: set_global_assignment -entity "pll_hdmi" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
339: 20: set_global_assignment -entity "pll_hdmi_0002" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
345: 32: //	Copyright (C) 1991-2018 Altera Corporation
346: 42: //	any other silicon devices, unless such use is explicitly licensed under
347: 44: //	the intellectual property, including patents, copyrights, trademarks,
353: 4: // Copyright (c) 2015 Till Harbaum <till@harbaum.org> 
354: 5: // Copyright (c) 2017-2021 Alexey Melnikov
360: 4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
361: 5: // Copyright (c) 2015-2018 Sorgelig
367: 5: //                          Copyright 2012
368: 9: //                         License: GPL
374: 3: // Copyright (c) 2018 Sorgelig
375: 5: // This program is GPL Licensed. See COPYING for the full license.
381: 4: // Copyright (c) 2020 Grabulosaure, (c) 2021 Alexey Melnikov
382: 7: // Copyright (c) 2021 Alexey Melnikov
383: 9: // This program is GPL Licensed. See COPYING for the full license.
389: 3: // Copyright (c) 2017,2021 Alexey Melnikov
390: 5: // This program is GPL Licensed. See COPYING for the full license.
396: 3: //  Copyright (C) 2022 Mike Simone
```

## ATTRIBUTION_NOTICES_interim.md

```text
8: 81: If you can read copyright string at the end of US BIOS file, then it's not correct dump! It's already pre-swapped for emulators.
9: 82: While it will work on MiSTer, some CD games will refuse to start. **Correct US BIOS file is when copyright string is not readable.**
10: 146: The 'Original' palette is based on reverse engineering work of the VDP by [furrtek](https://github.com/furrtek). An RGB to YUV lookup table was discovered that translates the colors to their intended values with the composite output of the console. Further work was done by [ArtemioUrbina](https://github.com/ArtemioUrbina) to verify the color output. [Kitrinx](https://github.com/Kitrinx) created a tool to generate the resulting [palette](https://github.com/Kitrinx/TG16_Palette).
16: 5: //  Copyright (C) 2017-2019 Sorgelig
22: 3: To the Limit — TurboGrafx-16 / PC Engine, based on upstream
23: 57: These are architectural references, not code ports or compatibility claims.
29: 35: `serialized_layout.json` is the authoritative, deterministic register inventory.
35: 3: // Copyright (c) 2020 Alexey Melnikov
41: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
42: 33: --authorized distributors.  Please refer to the applicable 
48: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
49: 33: --authorized distributors.  Please refer to the applicable 
55: 21: --Copyright (C) 1991-2014 Altera Corporation
56: 32: --Altera or its authorized distributors.  Please refer to the 
62: 3: // Copyright (c) 2018 Sorgelig
63: 5: // This program is GPL v2+ Licensed.
69: 3: // Copyright (c) 2020 Sorgelig
75: 4: // Copyright (c) 2020 Alexey Melnikov
81: 3: --  Copyright (C) 2018 Sorgelig
87: 102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
93: 13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
94: 20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
100: 31: //	Copyright (C) 1991-2020 Altera Corporation
101: 41: //	any other silicon devices, unless such use is explicitly licensed under
102: 43: //	the intellectual property, including patents, copyrights, trademarks,
108: 5: // Copyright (c) 2018 Sorgelig
109: 7: // Based on sdram module by Till Harbaum
115: 3: // Copyright (c) 2020 Alexey Melnikov
121: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
122: 33: --authorized distributors.  Please refer to the applicable 
128: 21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
129: 33: --authorized distributors.  Please refer to the applicable 
135: 21: --Copyright (C) 1991-2014 Altera Corporation
136: 32: --Altera or its authorized distributors.  Please refer to the 
142: 3: // Copyright (c) 2018 Sorgelig
143: 5: // This program is GPL v2+ Licensed.
149: 3: // Copyright (c) 2020 Sorgelig
155: 4: // Copyright (c) 2020 Alexey Melnikov
161: 3: --  Copyright (C) 2018 Sorgelig
167: 102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
173: 13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
174: 20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
180: 31: //	Copyright (C) 1991-2020 Altera Corporation
181: 41: //	any other silicon devices, unless such use is explicitly licensed under
182: 43: //	the intellectual property, including patents, copyrights, trademarks,
188: 5: // Copyright (c) 2018 Sorgelig
189: 7: // Based on sdram module by Till Harbaum
195: 5: //  Copyright (C) 2017-2019 Sorgelig
201: 5: //  Copyright (C) 2017-2019 Sorgelig
207: 5: // Copyright (c) 2018 Sorgelig
208: 7: // Based on sdram module by Till Harbaum
214: 3: //  Copyright (C) 2017-2020 Sorgelig
215: 150: //  Copyright (C) 2020 Sorgelig
221: 6: -- This code can be freely distributed and used for any purpose, but, if you
227: 2: // Copyright (c) 2020 Alexey Melnikov
233: 15: //Must be based on CLK_VIDEO
239: 6: // Copyright (c) 2021 bellwood420
245: 4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
246: 5: // Copyright (c) 2017-2026 Alexey Melnikov
252: 3: // Copyright (c) 2012-2013 Ludvig Strigeus
253: 4: // Copyright (c) 2017,2018 Sorgelig
254: 6: // This program is GPL Licensed. See COPYING for the full license.
260: 3: //  Copyright (C) 2020 Sorgelig
266: 4: //  Copyright (C) 2019 Sorgelig
272: 13: set_global_assignment -entity "pll_audio" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
273: 20: set_global_assignment -entity "pll_audio_0002" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
279: 28: //	Copyright (C) 1991-2020 Altera Corporation
280: 38: //	any other silicon devices, unless such use is explicitly licensed under
281: 40: //	the intellectual property, including patents, copyrights, trademarks,
287: 10: // Intel or its authorized distributors.  Please refer to the applicable 
293: 10: // Intel or its authorized distributors.  Please refer to the applicable 
299: 59: //	Copyright (C) 1991-2018 Altera Corporation
300: 69: //	any other silicon devices, unless such use is explicitly licensed under
301: 71: //	the intellectual property, including patents, copyrights, trademarks,
307: 10: // Intel or its authorized distributors.  Please refer to the applicable 
313: 13: set_global_assignment -entity "pll_hdmi" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
314: 20: set_global_assignment -entity "pll_hdmi_0002" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
320: 32: //	Copyright (C) 1991-2018 Altera Corporation
321: 42: //	any other silicon devices, unless such use is explicitly licensed under
322: 44: //	the intellectual property, including patents, copyrights, trademarks,
328: 4: // Copyright (c) 2015 Till Harbaum <till@harbaum.org> 
329: 5: // Copyright (c) 2017-2021 Alexey Melnikov
335: 4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
336: 5: // Copyright (c) 2015-2018 Sorgelig
342: 5: //                          Copyright 2012
343: 9: //                         License: GPL
349: 3: // Copyright (c) 2018 Sorgelig
350: 5: // This program is GPL Licensed. See COPYING for the full license.
356: 4: // Copyright (c) 2020 Grabulosaure, (c) 2021 Alexey Melnikov
357: 7: // Copyright (c) 2021 Alexey Melnikov
358: 9: // This program is GPL Licensed. See COPYING for the full license.
364: 3: // Copyright (c) 2017,2021 Alexey Melnikov
365: 5: // This program is GPL Licensed. See COPYING for the full license.
371: 3: //  Copyright (C) 2022 Mike Simone
```

## ReadMe.md

```text
81: If you can read copyright string at the end of US BIOS file, then it's not correct dump! It's already pre-swapped for emulators.
82: While it will work on MiSTer, some CD games will refuse to start. **Correct US BIOS file is when copyright string is not readable.**
146: The 'Original' palette is based on reverse engineering work of the VDP by [furrtek](https://github.com/furrtek). An RGB to YUV lookup table was discovered that translates the colors to their intended values with the composite output of the console. Further work was done by [ArtemioUrbina](https://github.com/ArtemioUrbina) to verify the color output. [Kitrinx](https://github.com/Kitrinx) created a tool to generate the resulting [palette](https://github.com/Kitrinx/TG16_Palette).
```

## TurboGrafx16.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## docs/NinjaSpirit_SaveStates_initial.md

```text
3: To the Limit — TurboGrafx-16 / PC Engine, based on upstream
57: These are architectural references, not code ports or compatibility claims.
```

## rtl/arcade.sv

```text
3: // Copyright (c) 2020 Alexey Melnikov
```

## rtl/cd/CDDA_FIFO.vhd

```text
21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
33: --authorized distributors.  Please refer to the applicable 
```

## rtl/cd/CDSUBC_FIFO.vhd

```text
21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
33: --authorized distributors.  Please refer to the applicable 
```

## rtl/cd/SCSI_FIFO.vhd

```text
21: --Copyright (C) 1991-2014 Altera Corporation
32: --Altera or its authorized distributors.  Please refer to the 
```

## rtl/color_mix.sv

```text
3: // Copyright (c) 2018 Sorgelig
5: // This program is GPL v2+ Licensed.
```

## rtl/ddram.sv

```text
3: // Copyright (c) 2020 Sorgelig
```

## rtl/hps_ext.v

```text
4: // Copyright (c) 2020 Alexey Melnikov
```

## rtl/huc6202.vhd

```text
3: --  Copyright (C) 2018 Sorgelig
```

## rtl/mb128.sv

```text
102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
```

## rtl/pll.qip

```text
13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
```

## rtl/pll.v

```text
31: //	Copyright (C) 1991-2020 Altera Corporation
41: //	any other silicon devices, unless such use is explicitly licensed under
43: //	the intellectual property, including patents, copyrights, trademarks,
```

## rtl/sdram.v

```text
5: // Copyright (c) 2018 Sorgelig
7: // Based on sdram module by Till Harbaum
```

## rtl/tgfx_iir_filter.v

```text
3: //  Copyright (C) 2020 Sorgelig
```

## savestate/audio_preinit_baseline/TurboGrafx16.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## savestate/audio_preinit_baseline/rtl/tgfx_iir_filter.v

```text
3: //  Copyright (C) 2020 Sorgelig
```

## savestate/guarded_cdc_validation/hps_guard/firmware_source/osd.cpp

```text
2: Copyright 2005, 2006, 2007 Dennis van Weeren
3: Copyright 2008, 2009 Jakub Bednarski
```

## savestate/loader_ack_validation/primed_baseline_top.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## savestate/original-rtl/arcade.sv

```text
3: // Copyright (c) 2020 Alexey Melnikov
```

## savestate/original-rtl/cd/CDDA_FIFO.vhd

```text
21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
33: --authorized distributors.  Please refer to the applicable 
```

## savestate/original-rtl/cd/CDSUBC_FIFO.vhd

```text
21: --Copyright (C) 2017  Intel Corporation. All rights reserved.
33: --authorized distributors.  Please refer to the applicable 
```

## savestate/original-rtl/cd/SCSI_FIFO.vhd

```text
21: --Copyright (C) 1991-2014 Altera Corporation
32: --Altera or its authorized distributors.  Please refer to the 
```

## savestate/original-rtl/color_mix.sv

```text
3: // Copyright (c) 2018 Sorgelig
5: // This program is GPL v2+ Licensed.
```

## savestate/original-rtl/ddram.sv

```text
3: // Copyright (c) 2020 Sorgelig
```

## savestate/original-rtl/hps_ext.v

```text
4: // Copyright (c) 2020 Alexey Melnikov
```

## savestate/original-rtl/huc6202.vhd

```text
3: --  Copyright (C) 2018 Sorgelig
```

## savestate/original-rtl/mb128.sv

```text
102: 	else if (~clk_prev & i_Clk) begin		// drive the SPI-like protocol based on this signal's positive edge
```

## savestate/original-rtl/pll.qip

```text
13: set_global_assignment -entity "pll" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
20: set_global_assignment -entity "pll_0002" -library "pll" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
```

## savestate/original-rtl/pll.v

```text
31: //	Copyright (C) 1991-2020 Altera Corporation
41: //	any other silicon devices, unless such use is explicitly licensed under
43: //	the intellectual property, including patents, copyrights, trademarks,
```

## savestate/original-rtl/sdram.v

```text
5: // Copyright (c) 2018 Sorgelig
7: // Based on sdram module by Till Harbaum
```

## savestate/original-top.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## savestate/volatile-baseline/TurboGrafx16.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## savestate/volatile-baseline/rtl/sdram.v

```text
5: // Copyright (c) 2018 Sorgelig
7: // Based on sdram module by Till Harbaum
```

## savestate/warm_hold_validation/base_TurboGrafx16.sv

```text
5: //  Copyright (C) 2017-2019 Sorgelig
```

## sys/arcade_video.v

```text
3: //  Copyright (C) 2017-2020 Sorgelig
150: //  Copyright (C) 2020 Sorgelig
```

## sys/ascal.vhd

```text
6: -- This code can be freely distributed and used for any purpose, but, if you
```

## sys/ddr_svc.sv

```text
2: // Copyright (c) 2020 Alexey Melnikov
```

## sys/emu_ports.vh

```text
15: //Must be based on CLK_VIDEO
```

## sys/f2sdram_safe_terminator.sv

```text
6: // Copyright (c) 2021 bellwood420
```

## sys/hps_io.sv

```text
4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
5: // Copyright (c) 2017-2026 Alexey Melnikov
```

## sys/hq2x.sv

```text
3: // Copyright (c) 2012-2013 Ludvig Strigeus
4: // Copyright (c) 2017,2018 Sorgelig
6: // This program is GPL Licensed. See COPYING for the full license.
```

## sys/iir_filter.v

```text
3: //  Copyright (C) 2020 Sorgelig
```

## sys/ltc2308.sv

```text
4: //  Copyright (C) 2019 Sorgelig
```

## sys/pll_audio.qip

```text
13: set_global_assignment -entity "pll_audio" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
20: set_global_assignment -entity "pll_audio_0002" -library "pll_audio" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
```

## sys/pll_audio.v

```text
28: //	Copyright (C) 1991-2020 Altera Corporation
38: //	any other silicon devices, unless such use is explicitly licensed under
40: //	the intellectual property, including patents, copyrights, trademarks,
```

## sys/pll_cfg/altera_pll_reconfig_core.v

```text
10: // Intel or its authorized distributors.  Please refer to the applicable 
```

## sys/pll_cfg/altera_pll_reconfig_top.v

```text
10: // Intel or its authorized distributors.  Please refer to the applicable 
```

## sys/pll_cfg/pll_cfg.v

```text
59: //	Copyright (C) 1991-2018 Altera Corporation
69: //	any other silicon devices, unless such use is explicitly licensed under
71: //	the intellectual property, including patents, copyrights, trademarks,
```

## sys/pll_cfg/pll_cfg_hdmi.v

```text
10: // Intel or its authorized distributors.  Please refer to the applicable 
```

## sys/pll_hdmi.qip

```text
13: set_global_assignment -entity "pll_hdmi" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
20: set_global_assignment -entity "pll_hdmi_0002" -library "pll_hdmi" -name IP_COMPONENT_AUTHOR "QWx0ZXJhIENvcnBvcmF0aW9u"
```

## sys/pll_hdmi.v

```text
32: //	Copyright (C) 1991-2018 Altera Corporation
42: //	any other silicon devices, unless such use is explicitly licensed under
44: //	the intellectual property, including patents, copyrights, trademarks,
```

## sys/scandoubler.v

```text
4: // Copyright (c) 2015 Till Harbaum <till@harbaum.org> 
5: // Copyright (c) 2017-2021 Alexey Melnikov
```

## sys/sd_card.sv

```text
4: // Copyright (c) 2014 Till Harbaum <till@harbaum.org>
5: // Copyright (c) 2015-2018 Sorgelig
```

## sys/spdif.v

```text
5: //                          Copyright 2012
9: //                         License: GPL
```

## sys/video_cleaner.sv

```text
3: // Copyright (c) 2018 Sorgelig
5: // This program is GPL Licensed. See COPYING for the full license.
```

## sys/video_freak.sv

```text
4: // Copyright (c) 2020 Grabulosaure, (c) 2021 Alexey Melnikov
7: // Copyright (c) 2021 Alexey Melnikov
9: // This program is GPL Licensed. See COPYING for the full license.
```

## sys/video_mixer.sv

```text
3: // Copyright (c) 2017,2021 Alexey Melnikov
5: // This program is GPL Licensed. See COPYING for the full license.
```

## sys/yc_out.sv

```text
3: //  Copyright (C) 2022 Mike Simone
```
