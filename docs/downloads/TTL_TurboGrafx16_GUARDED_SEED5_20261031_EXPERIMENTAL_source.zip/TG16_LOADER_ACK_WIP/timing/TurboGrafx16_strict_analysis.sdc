# Analysis-only: removes legacy broad SDR/DDR/filter exceptions for strict path checking.
derive_pll_clocks
derive_clock_uncertainty

# Quartus 23.1 can crash in get_keepers on the synthesis-stage netlist.
# Keep derived clocks during synthesis; defer the original exceptions until
# fitter/TimeQuest, where the named keepers exist. Final constraints are intact.
set ttl_sdc_stage ""
foreach ttl_stage_variable {::TimingAnalyzerInfo(nameofexecutable) ::TimeQuestInfo(nameofexecutable) ::quartus(nameofexecutable)} {
    if {[info exists $ttl_stage_variable]} {set ttl_sdc_stage [set $ttl_stage_variable]}
}
if {$ttl_sdc_stage ne "quartus_map"} {


}
