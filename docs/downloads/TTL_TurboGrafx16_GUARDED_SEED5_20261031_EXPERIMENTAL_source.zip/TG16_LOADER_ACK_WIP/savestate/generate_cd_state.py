#!/usr/bin/env python3
"""Experimental CD register-chain instrumentation; not a release.

The map appends to the 579 original entries. This does not serialize CD RAM or
FIFO content; safe eligibility must separately reject any CD register access or
external CD events since FPGA initialization. Generated HDL must be simulated.
"""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parents[1]
ns={'__file__':str(P/'savestate/serialize.py')}
exec((P/'savestate/serialize.py').read_text().split('pkg=')[0],ns)
ns['cursor']=579
rows_manifest=[]; bases={}
ports='''\n SS_RROTATE : in std_logic := '0';\n SS_RADDR : in std_logic_vector(14 downto 0) := (others=>'0');\n SS_RDI : in std_logic_vector(15 downto 0) := (others=>'0');\n SS_RWE : in std_logic := '0';\n SS_RDO : out std_logic_vector(15 downto 0);\n SS_FREEZE : in std_logic := '0';\n SS_SAVE : in std_logic := '0';\n SS_LOAD : in std_logic := '0';\n'''
files=['cd.vhd','SCSI.vhd','MSM5205.vhd']
for fn in files:
 s=(P/'savestate/cd_baseline'/fn).read_text(); clean=re.sub(r'--[^\n]*','',s)
 ent_end=re.search(r'\bend\s+(?:entity\s+)?\w+\s*;',s,re.I).end()
 s=re.sub(r'\bout\b','buffer',s[:ent_end],flags=re.I)+s[ent_end:]
 s=re.sub(r'(\bport\s*\()',lambda m:m[1]+ports,s,count=1,flags=re.I)
 clean=re.sub(r'--[^\n]*','',s); types=ns['types'](clean); decl={}
 for m in re.finditer(r'\bsignal\s+([\w,\s]+?)\s*:\s*([^;]+);',clean,re.I):
  ty=m[2].split(':=')[0].strip()
  for name in re.split(r'\s*,\s*',m[1].strip()): decl[name.upper()]=ty
 for m in re.finditer(r'\b(\w+)\s*:\s*buffer\s+([^;\n]+)',clean,re.I): decl[m[1].upper()]=m[2].strip()
 used=set(); seen=[]
 def inst(m):
  z=m[0]; c=re.sub(r'--[^\n]*','',z); edge=re.search(r'rising_edge\s*\(\s*CLK\s*\)\s*then',c,re.I)
  if not edge:return z
  # Comments are stripped in this transformed process to maintain matching offsets.
  z=c; edge=re.search(r'rising_edge\s*\(\s*CLK\s*\)\s*then',z,re.I); tail=z[edge.end():]
  end=list(re.finditer(r'\bend\s+if\s*;',tail,re.I))[-1];body=tail[:end.start()]
  lhs=re.findall(r'(?m)(?:^|;|\bthen\b|\belse\b|=>)\s*(\w+(?:\([^\n;]*?\))?(?:\.\w+(?:\([^\n;]*?\))?)?)\s*<=',body,re.I)
  roots=sorted(set(re.match(r'\w+',x)[0].upper() for x in lhs))
  assert all(x in decl for x in roots),(fn,[x for x in roots if x not in decl])
  assert not used.intersection(roots),(fn,used.intersection(roots))
  used.update(roots);seen.append(roots)
  return z[:edge.end()]+"\nif SS_LOAD = '1' then\n"+''.join(f'{x} <= SS_SH_{x};\n' for x in roots)+"elsif SS_FREEZE = '0' then\n"+body+'\nend if;\n'+tail[end.start():]
 s=re.sub(r'\bprocess\s*\(.*?end\s+process\s*;',inst,s,flags=re.I|re.S)
 # Process variables NEW_ADPCM_LEN, DELTA, NEXT_STEP and NEXT_SAMPLE are
 # temporary expressions assigned before use in each active path.
 leaves=[]
 for name in sorted(used):leaves += ns['flatten']('SS_SH_'+name,decl[name],types)
 start=ns['cursor']; ns['words'](fn,leaves); end=ns['cursor']; bases[fn]=(start,end)
 rows=ns['layout']; rows=[r for r in rows if r['owner']==fn];rows_manifest.extend(rows)
 n=(end-start)*16;bits=set(); capture=[]; decode=[]
 leaves_by_name={x[0]:x for x in leaves}
 for r in rows:
  name,ty,total,kind,extra=leaves_by_name[r['field']];off=r['offset'];width=r['width'];lo=(r['address']-start)*16+r['bit_offset'];hi=lo+width-1
  assert not bits.intersection(range(lo,hi+1));bits.update(range(lo,hi+1));live=name.replace('SS_SH_','',1);chain=f'SS_CHAIN({hi} downto {lo})'
  if kind=='bit':capture.append(f'SS_CAPTURE_DATA({lo}) <= {live};');decode.append(f'{name} <= SS_CHAIN({lo});')
  elif kind=='vector':
   capture.append(f'SS_CAPTURE_DATA({hi} downto {lo}) <= std_logic_vector({live}({extra+off+width-1} downto {extra+off}));')
   value=chain if ty=='std_logic_vector' else f'{ty}({chain})'
   decode.append(f'{name}({extra+off+width-1} downto {extra+off}) <= {value};')
  elif kind in ('enum','integer'):
   assert off==0 and width==total
   capture.append(f"SS_CAPTURE_DATA({hi} downto {lo}) <= std_logic_vector(to_unsigned("+(f"{ty}'pos({live})" if kind=='enum' else live)+f',{width}));')
   value=f'to_integer(unsigned({chain}))';value=(f"{ty}'val({value})" if kind=='enum' else value)
   decode.append(f"{name} <= {value} when to_integer(unsigned({chain})) <= {extra} else "+(f"{ty}'val(0);" if kind=='enum' else '0;'))
  else:raise ValueError((fn,name,kind))
 for bit in set(range(n))-bits:capture.append(f"SS_CAPTURE_DATA({bit}) <= '0';")
 arch=re.search(r'architecture\s+\w+\s+of\s+\w+\s+is',s,re.I).end(); b=re.search(r'(?m)^\s*begin\s*$',s[arch:],re.I).start()+arch
 declarations='\n'+''.join(f'signal SS_SH_{x} : {decl[x]};\n' for x in sorted(used))+f'signal SS_CHAIN, SS_CAPTURE_DATA : std_logic_vector({n-1} downto 0);\nsignal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";\nsignal SS_LOCAL_RDO : std_logic_vector(15 downto 0);\n'
 s=s[:b]+declarations+s[b:]
 e=re.search(r'end\s+(?:rtl|syn)\s*;',s,re.I)
 selected=f'to_integer(unsigned(SS_RADDR)) >= {start} and to_integer(unsigned(SS_RADDR)) < {end}'
 body='\n'+'\n'.join(capture+decode)+f'''\nSS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when {selected} else (others=>'0');
process(CLK) begin if rising_edge(CLK) then
 SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
 if SS_CHAIN_CAPTURE(1)='1' then SS_CHAIN <= SS_CAPTURE_DATA;
 elsif SS_RWE='1' and ({selected}) then SS_CHAIN <= SS_RDI & SS_CHAIN({n-1} downto 16);
 elsif SS_RROTATE='1' and ({selected}) then SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN({n-1} downto 16);
 end if;
end if; end process;
SS_RDO <= SS_LOCAL_RDO;
'''
 s=s[:e.start()]+body+s[e.start():]
 (P/'rtl/cd'/fn).write_text(s)
 print(fn,'roots',len(used),'word range',start,end-1,'processes',len(seen))
# Record deterministic map separately until the surrounding integration and
# generator are wired; do not claim compatibility or completeness yet.
(P/'savestate/cd_layout.json').write_text(json.dumps({'fields':rows_manifest,'bases':bases,'register_words':ns['cursor']},indent=2)+'\n')
# Distinct timer instances must have distinct scan addresses. Reuse the existing
# tested CEGen scan implementation with a parameterized base.
base=ns['cursor']; ce_a=base;ce_b=base+3;ram_base=base+6;end=base+8
s=(P/'savestate/cd_baseline/CEGen.vhd').read_text().replace('ENTITY CEGen IS','ENTITY CEGen_CD IS\n    generic (SS_REG_BASE : integer := 0);',1).replace('END CEGen;','END CEGen_CD;',1).replace('ARCHITECTURE SYN OF CEGen IS','ARCHITECTURE SYN OF CEGen_CD IS',1)
s=s.replace('>= 398','>= SS_REG_BASE').replace('<= 400','<= SS_REG_BASE+2')
(P/'rtl/cd/CEGen_CD.vhd').write_text(s)
cd=P/'rtl/cd/cd.vhd';s=cd.read_text()
s=s.replace('signal SS_LOCAL_RDO :', 'signal SS_CHILD_SCSI, SS_CHILD_MSM, SS_CHILD_CE_A, SS_CHILD_CE_B, SS_CHILD_RAM : std_logic_vector(15 downto 0);\nsignal SS_LOCAL_RDO :',1)
for entity,q in [('SCSI','SS_CHILD_SCSI'),('MSM5205','SS_CHILD_MSM')]:
 pat=rf'(entity\s+work\.{entity}\b.*?port\s+map\s*\()'
 s,n=re.subn(pat,lambda m:m[1]+f'\nSS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>{q}, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LOAD=>SS_LOAD,\n',s,count=1,flags=re.I|re.S);assert n,entity
for label,b,q in [('CDDA_CLK_GEN',ce_a,'SS_CHILD_CE_A'),('ADPCM_CLK_GEN',ce_b,'SS_CHILD_CE_B')]:
 pat=rf'({label}\s*:\s*entity\s+work\.)CEGen(\s*port\s+map\s*\()'
 s,n=re.subn(pat,lambda m:m[1]+f'CEGen_CD generic map(SS_REG_BASE => {b}) '+m[2]+f'\nSS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>{q}, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LOAD=>SS_LOAD,\n',s,count=1,flags=re.I|re.S);assert n,label
s=s.replace('entity work.dpram generic map (17,4)','entity work.dpram generic map (17,4, SS_REG_BASE => '+str(ram_base)+')',1)
pat=r'(ADPCM_DRAM\s*:\s*entity\s+work\.dpram.*?port\s+map\s*\()'
s,n=re.subn(pat,lambda m:m[1]+'''\nSS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CHILD_RAM, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE,\n''',s,count=1,flags=re.I|re.S);assert n
s=s.replace('SS_RDO <= SS_LOCAL_RDO;','SS_RDO <= SS_LOCAL_RDO or SS_CHILD_SCSI or SS_CHILD_MSM or SS_CHILD_CE_A or SS_CHILD_CE_B or SS_CHILD_RAM;',1)
cd.write_text(s)
qip=P/'rtl/cd/cd.qip';q=qip.read_text()
if 'CEGen_CD.vhd' not in q:q+='\nset_global_assignment -name VHDL_FILE [file join $::quartus(qip_path) CEGen_CD.vhd ]\n'
qip.write_text(q)
print('CD timer and RAM latch word ranges',ce_a,ce_b,ram_base,'total',end)
layout=json.loads((P/'savestate/serialized_layout.json').read_text())
# Idempotently replace our appended rows on subsequent runs.
layout['fields']=[r for r in layout['fields'] if r['address']<579]+rows_manifest+[
 {'owner':'cd.vhd','field':'CDDA_CLK_GEN','address':ce_a,'words':3,'width':33},
 {'owner':'cd.vhd','field':'ADPCM_CLK_GEN','address':ce_b,'words':3,'width':33},
 {'owner':'cd.vhd','field':'ADPCM_DRAM.read_latches','address':ram_base,'words':2,'width':4}]
assert end == 627
layout['fields'] += [dict(owner='audio_snapshot',field=f'audio_word_{n}',address=end+n,width=16) for n in range(54)]
end += 54
layout['register_words']=end
layout['schema']=hashlib.sha256(json.dumps(layout['fields'],sort_keys=True).encode()+b'|hucard-compact-cd-guard-audio-init-reset-freeze-cdc-v10').hexdigest()[:16]
(P/'savestate/serialized_layout.json').write_text(json.dumps(layout,indent=2)+'\n')
(P/'rtl/snapshot_layout.vh').write_text(f"localparam integer SS_REGISTER_WORDS = {end};\nlocalparam [63:0] SS_SCHEMA = 64'h{layout['schema']};\n")
print('schema',layout['schema'])
# Fail closed for the unsupported FIFO and ADPCM RAM state. The guard observes
# all CPU CD-register accesses and inbound HPS events for the lifetime of this
# FPGA configuration. It intentionally does not reset on console reset or ROM
# download; otherwise old ADPCM/FIFO contents could be falsely assumed empty.
cd=P/'rtl/cd/cd.vhd';s=cd.read_text();s=s.replace("SS_RDO : out std_logic_vector(15 downto 0);", "SS_RDO : out std_logic_vector(15 downto 0);\n SS_UNSAFE : out std_logic;",1)
s=s.replace('signal SS_LOCAL_RDO :',"signal SS_UNSAFE_LATCH : std_logic := '0';\nsignal SS_SCSI_IDLE, SS_SCSI_FIFO_WRITE, SS_CD_EVENT : std_logic;\nsignal SS_LOCAL_RDO :",1)
insert='''
SS_CD_EVENT <= ((REG_SEL or RAM_SEL) and CPU_CE and (not EXT_WR_N or not EXT_RD_N)) or CD_STAT_GET or CD_DOUT_REQ or CD_DATA_WR or CD_AUDIO_WR or CD_SUBCD_WR or ADRAM_WE or FIFO_WR_REQ or SUBCD_FIFO_WR_REQ or SS_SCSI_FIFO_WRITE;
SS_UNSAFE <= SS_UNSAFE_LATCH or SS_CD_EVENT or not (FIFO_EMPTY and SUBCD_FIFO_EMPTY and SS_SCSI_IDLE) or FIFO_WR_REQ or FIFO_RD_REQ or FIFO_SCLR or SUBCD_FIFO_WR_REQ or SUBCD_FIFO_RD_REQ or SUBCD_FIFO_SCLR;
process(CLK) begin if rising_edge(CLK) then
 if SS_CD_EVENT='1' then
   SS_UNSAFE_LATCH <= '1';
 end if;
end if; end process;
'''
s=s.replace("REG_SEL <= '1' when",insert+"\nREG_SEL <= '1' when",1)
s=s.replace('SS_RDO=>SS_CHILD_SCSI, SS_FREEZE', 'SS_RDO=>SS_CHILD_SCSI, SS_FIFO_IDLE=>SS_SCSI_IDLE, SS_FIFO_WRITE=>SS_SCSI_FIFO_WRITE, SS_FREEZE',1)
cd.write_text(s)
p=P/'rtl/cd/SCSI.vhd';s=p.read_text().replace('SS_RDO : out std_logic_vector(15 downto 0);', 'SS_RDO : out std_logic_vector(15 downto 0);\n SS_FIFO_IDLE : out std_logic;\n SS_FIFO_WRITE : out std_logic;',1)
s=s.replace('BSY_N <= BSY_Nr;', "SS_FIFO_IDLE <= EMPTY and not FIFO_RD_REQ and not FIFO_WR_REQ;\n SS_FIFO_WRITE <= FIFO_WR_REQ;\n BSY_N <= BSY_Nr;",1);p.write_text(s)
p=P/'rtl/pce_top.vhd';s=p.read_text();s=s.replace('SS_SAFE : out std_logic;', 'SS_SAFE : out std_logic;\n        SS_CD_UNSAFE : out std_logic;',1) if 'SS_CD_UNSAFE : out' not in s else s
s=s.replace('signal SS_LOCAL_RDO :', 'signal SS_CD_RDO : std_logic_vector(15 downto 0);\nsignal SS_CD_UNSAFE_RAW : std_logic;\nsignal SS_CD_RAM_UNSAFE : std_logic := \'0\';\nsignal SS_LOCAL_RDO :',1) if 'signal SS_CD_RDO :' not in s else s
s=s.replace('CD : entity work.cd\nport map(','''CD : entity work.cd
port map(
 SS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CD_RDO, SS_UNSAFE=>SS_CD_UNSAFE_RAW,
 SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LOAD=>SS_LOAD,''',1) if 'SS_RDO=>SS_CD_RDO' not in s else s
s=s.replace('SS_RDO <= SS_R_RAM or', 'SS_RDO <= SS_CD_RDO or SS_R_RAM or',1)
s=s.replace('SS_UNSAFE=>SS_CD_UNSAFE,', 'SS_UNSAFE=>SS_CD_UNSAFE_RAW,',1)
if 'signal SS_CD_UNSAFE_RAW :' not in s:
 s=s.replace('signal SS_CD_RDO : std_logic_vector(15 downto 0);', "signal SS_CD_RDO : std_logic_vector(15 downto 0);\nsignal SS_CD_UNSAFE_RAW : std_logic;\nsignal SS_CD_RAM_UNSAFE : std_logic := '0';",1)
# RAM prefetch/read/write can be issued before CPU_CE. Watch the actual memory
# request signals, not just the CD register block's CPU interface.
marker="CD_RAM_WR <= CPU_PRE_WR and not (CD_RAM_CS_N and AC_RAM_CS_N);"
ram_guard="""
SS_CD_UNSAFE <= SS_CD_UNSAFE_RAW or SS_CD_RAM_UNSAFE or CD_RAM_RD or CD_RAM_WR;
process(CLK) begin if rising_edge(CLK) then
 if CD_RAM_RD='1' or CD_RAM_WR='1' then SS_CD_RAM_UNSAFE <= '1'; end if;
end if; end process;
"""
if 'SS_CD_RAM_UNSAFE <=' not in s:
 assert marker in s; s=s.replace(marker,marker+ram_guard,1)
p.write_text(s)
# The SV wrapper gets the eligibility signal and preserves its visible behavior;
# a separate UI explanation should be added before release.
p=P/'TurboGrafx16.sv';s=p.read_text().replace('.SS_SAFE(ss_safe), .SS_ADDR(ss_addr)', '.SS_SAFE(ss_safe), .SS_CD_UNSAFE(ss_cd_unsafe), .SS_ADDR(ss_addr)',1)
s=s.replace('wire ss_freeze, ss_save, ss_load, ss_load_commit, ss_safe, ss_valid, ss_fault_reset;', 'wire ss_freeze, ss_save, ss_load, ss_load_commit, ss_safe, ss_valid, ss_fault_reset, ss_cd_unsafe;',1)
s=s.replace('!ioctl_download && !status[13] && !status[21]', '!ioctl_download && !ss_cd_unsafe && !status[13] && !status[21]',1);p.write_text(s)
# Default parameters are important for independent controller benches.
p=P/'rtl/ninja_savestate.sv';s=p.read_text();s=re.sub(r'parameter integer REGISTER_WORDS=\d+',f'parameter integer REGISTER_WORDS={end}',s,count=1);s=re.sub(r"parameter \[63:0\] SCHEMA=64'h[0-9a-f]+",f"parameter [63:0] SCHEMA=64'h{layout['schema']}",s,count=1);p.write_text(s)
print('Integrated experimental CD guard and register bus; unsupported CD activity disables save states')
# Full-CD experimental branch: atomic dual-bank ADPCM memory with a separate
# nibble scan bus. FIFO capture is NOT yet integrated; keep all CD guards.
cd=P/'rtl/cd/cd.vhd';s=cd.read_text().replace('SS_UNSAFE : out std_logic;', '''SS_UNSAFE : out std_logic;
 SS_ADPCM_ADDR : in std_logic_vector(16 downto 0) := (others=>'0');
 SS_ADPCM_DI : in std_logic_vector(3 downto 0) := (others=>'0');
 SS_ADPCM_WE : in std_logic := '0';
 SS_ADPCM_DO : out std_logic_vector(3 downto 0);''',1)
a=s.index('ADPCM_DRAM : entity work.dpram');b=s.index('\n\t);',a)+len('\n\t);')
s=s[:a]+'''ADPCM_DRAM : entity work.adpcm_snapshot_ram generic map (SS_REG_BASE => 625)
 port map(CLK=>CLK,ADDRESS_A=>ADRAM_A,DATA_A=>ADRAM_DI,WREN_A=>ADRAM_WE,Q_A=>ADRAM_DO,
  SS_FREEZE=>SS_FREEZE,SS_SAVE=>SS_SAVE,SS_LOAD=>SS_LOAD,
  SS_RADDR=>SS_RADDR,SS_RDI=>SS_RDI,SS_RWE=>SS_RWE,SS_RDO=>SS_CHILD_RAM,
  SS_ADDR=>SS_ADPCM_ADDR,SS_DI=>SS_ADPCM_DI,SS_WE=>SS_ADPCM_WE,SS_DO=>SS_ADPCM_DO);''' + s[b:]
cd.write_text(s)
qip=P/'rtl/cd/cd.qip';q=qip.read_text();entry='set_global_assignment -name VHDL_FILE [file join $::quartus(qip_path) adpcm_snapshot_ram.vhd ]'
if entry not in q:q+='\n'+entry+'\n'
qip.write_text(q)
p=P/'rtl/pce_top.vhd';s=p.read_text()
if 'SS_ADPCM_ADDR : in' not in s:
 s=s.replace('SS_CD_UNSAFE : out std_logic;', '''SS_CD_UNSAFE : out std_logic;
        SS_ADPCM_ADDR : in std_logic_vector(16 downto 0) := (others=>'0');
        SS_ADPCM_DI : in std_logic_vector(3 downto 0) := (others=>'0');
        SS_ADPCM_WE : in std_logic := '0';
        SS_ADPCM_DO : out std_logic_vector(3 downto 0);''',1)
 s=s.replace('SS_RDO=>SS_CD_RDO, SS_UNSAFE=>SS_CD_UNSAFE_RAW,', '''SS_RDO=>SS_CD_RDO, SS_UNSAFE=>SS_CD_UNSAFE_RAW,
 SS_ADPCM_ADDR=>SS_ADPCM_ADDR, SS_ADPCM_DI=>SS_ADPCM_DI, SS_ADPCM_WE=>SS_ADPCM_WE, SS_ADPCM_DO=>SS_ADPCM_DO,''',1)
p.write_text(s)
p=P/'TurboGrafx16.sv';s=p.read_text()
if '.SS_ADPCM_ADDR(' not in s:
 s=s.replace('.SS_SAFE(ss_safe), .SS_CD_UNSAFE(ss_cd_unsafe),', '''.SS_SAFE(ss_safe), .SS_CD_UNSAFE(ss_cd_unsafe),
    .SS_ADPCM_ADDR(ss_adpcm_addr), .SS_ADPCM_DI(ss_adpcm_din), .SS_ADPCM_WE(ss_adpcm_we), .SS_ADPCM_DO(ss_adpcm_dout),''',1)
 s=s.replace('wire [17:0] ss_addr;', '''wire [17:0] ss_addr;
wire [16:0] ss_adpcm_addr;
wire [3:0] ss_adpcm_din, ss_adpcm_dout;
wire ss_adpcm_we;''',1)
 s=s.replace('.reg_rotate(ss_reg_rotate), .scan_addr(ss_addr),', '''.adpcm_addr(ss_adpcm_addr), .adpcm_din(ss_adpcm_din), .adpcm_we(ss_adpcm_we), .adpcm_dout(ss_adpcm_dout),
 .reg_rotate(ss_reg_rotate), .scan_addr(ss_addr),''',1)
p.write_text(s)
f=P/'files.qip';s=f.read_text();entry='set_global_assignment -name SYSTEMVERILOG_FILE rtl/adpcm_pack_engine.sv'
if entry not in s:s+='\n'+entry+'\n'
f.write_text(s)
