`timescale 1ns/1ps
module trace_tb;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg ss_machine_freeze=1,cart_download=0,reset=0,ss_fault_reset=0;
// INSERT_ACTUAL_TOP_DEFERRED_RESET
integer fd,i;
initial begin
 fd=$fopen("cold_trace.txt","w");if(!fd)$fatal;
 for(i=0;i<32790;i=i+1)begin
  @(negedge clk_sys);
  cart_download=(i==2);
  ss_machine_freeze=(i<8);
  $fdisplay(fd,"%0d %0d %0d %0d",ss_machine_freeze,cart_download,ss_cold_pending,(i==0));
 end
 $fclose(fd);
 if(ss_cold_pending||ss_cold_count!=0)$fatal(1,"deferred cold state did not drain");
 $display("PASS: production deferred-reset block emitted 32790-cycle frozen-pulse trace");$finish;
end
endmodule
