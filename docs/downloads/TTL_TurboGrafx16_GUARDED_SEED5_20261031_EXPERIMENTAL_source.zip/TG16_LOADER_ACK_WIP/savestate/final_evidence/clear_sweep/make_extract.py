from pathlib import Path
import re,hashlib
P=Path('/workspace/scratch/3a9e05704b35'); C=P/'tg16_guarded_build_candidate'; O=P/'tg16_clr_a_audit'
top=(C/'TurboGrafx16.sv').read_text(); pce=(C/'rtl/pce_top.vhd').read_text(); vdc=(C/'rtl/huc6270.vhd').read_text(); dpr=(C/'rtl/dpram.vhd').read_text()
m=re.search(r'reg ss_fault_pending=0,ss_cold_pending=0;.*?\nend\n',top,re.S);assert m and 'ss_cold_count==32771' in m.group()
(O/'top_deferred_extract.sv').write_text(m.group())
def get(src,term):
 pattern=r'process\(CLK\) begin if rising_edge\(CLK\) then\s*if SS_LOAD = \'1\' then\s*CLR_A <= SS_SH_CLR_A;.*?end if; end process;\s*process\(CLK\) begin if rising_edge\(CLK\) then\s*if SS_LOAD = \'1\' then\s*CLR_WE <= SS_SH_CLR_WE;.*?end if; end process;'
 matches=re.findall(pattern,src,re.S|re.I);assert len(matches)==1,(term,len(matches));return matches[0]
def unit(name,width,cold,body):return f'''library ieee;use ieee.std_logic_1164.all;use ieee.std_logic_unsigned.all;
entity {name} is port(CLK,SS_LOAD,SS_FREEZE,{cold}:in std_logic;SS_SH_CLR_A:in std_logic_vector({width-1} downto 0);SS_SH_CLR_WE:in std_logic;CLEAR_ADDR:out std_logic_vector({width-1} downto 0);CLEAR_WE:out std_logic);end;
architecture rtl of {name} is signal CLR_A:std_logic_vector({width-1} downto 0);signal CLR_WE:std_logic;begin
{body}
CLEAR_ADDR<=CLR_A;CLEAR_WE<=CLR_WE;
end;\n'''
(O/'pce_clear_extract.vhd').write_text(unit('pce_clear_extract',15,'COLD_RESET',get(pce,'pce')))
# Actual VDC CLR_A is an unsigned subtype; retain original arithmetic via unsigned_std logic; source type checked.
assert re.search(r'signal\s+CLR_A\s*:\s*unsigned\s*\(\s*7\s+downto\s+0\s*\)',vdc,re.I)
v=unit('vdc_clear_extract',8,'CLR_MEM',get(vdc,'vdc')).replace('signal CLR_A:std_logic_vector(7 downto 0)','signal CLR_A:unsigned(7 downto 0)').replace('SS_SH_CLR_A:in std_logic_vector(7 downto 0)','SS_SH_CLR_A:in unsigned(7 downto 0)').replace('CLEAR_ADDR<=CLR_A','CLEAR_ADDR<=std_logic_vector(CLR_A)').replace('use ieee.std_logic_unsigned.all;','use ieee.numeric_std.all;')
(O/'vdc_clear_extract.vhd').write_text(v)
assert 'eb <= enable_b and not SS_FREEZE;' in dpr and 'wren_b => wren_b and cs_b and not SS_FREEZE' in dpr
assert "SAT_ADDR <= std_logic_vector(SPR_EVAL_X) when CLR_WE = '0' else std_logic_vector(CLR_A);" in vdc
(O/'source_hashes.sha256').write_text(''.join(f"{hashlib.sha256((C/f).read_bytes()).hexdigest()}  {f}\n" for f in ['TurboGrafx16.sv','rtl/pce_top.vhd','rtl/huc6270.vhd','rtl/dpram.vhd']))
print('PASS exact production clear and deferred-reset extraction, DPRAM freeze gate and SAT address mux')
