library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.textio.all;use std.env.all;
entity tb_clear_sweep is generic(PCE_START:natural:=0;VDC_START:natural:=0);end;
architecture sim of tb_clear_sweep is
 signal clk:std_logic:='0';signal frozen:std_logic:='1';signal cart,pending,load,cold:std_logic:='0';
 signal paddr:std_logic_vector(14 downto 0);signal pwe:std_logic;
 signal vaddr:std_logic_vector(7 downto 0);signal vwe:std_logic;
 type pseen_t is array(0 to 32767) of boolean;type vseen_t is array(0 to 255) of boolean;
begin
 clk<=not clk after 5 ns;cold<=cart or pending;
 pce:entity work.pce_clear_extract port map(CLK=>clk,SS_LOAD=>load,SS_FREEZE=>frozen,COLD_RESET=>cold,SS_SH_CLR_A=>std_logic_vector(to_unsigned(PCE_START,15)),SS_SH_CLR_WE=>'0',CLEAR_ADDR=>paddr,CLEAR_WE=>pwe);
 vdc:entity work.vdc_clear_extract port map(CLK=>clk,SS_LOAD=>load,SS_FREEZE=>frozen,CLR_MEM=>cold,SS_SH_CLR_A=>to_unsigned(VDC_START,8),SS_SH_CLR_WE=>'0',CLEAR_ADDR=>vaddr,CLEAR_WE=>vwe);
 process
 file trace:text open read_mode is "cold_trace.txt";variable l:line;variable fi,ci,pi,li:integer;variable pseen:pseen_t:=(others=>false);variable vseen:vseen_t:=(others=>false);variable pn,vn,pwrites,vwrites,cycle:integer:=0;
 begin
 while not endfile(trace) loop
  readline(trace,l);read(l,fi);read(l,ci);read(l,pi);read(l,li);
  wait until falling_edge(clk);
  if fi=1 then frozen<='1';else frozen<='0';end if;
  if ci=1 then cart<='1';else cart<='0';end if;
  if pi=1 then pending<='1';else pending<='0';end if;
  if li=1 then load<='1';else load<='0';end if;
  wait until rising_edge(clk);
  if fi=0 and pwe='1' then assert not is_x(paddr) report "unknown PCE clear address" severity failure;pwrites:=pwrites+1;if not pseen(to_integer(unsigned(paddr))) then pseen(to_integer(unsigned(paddr))):=true;pn:=pn+1;end if;end if;
  if fi=0 and vwe='1' then assert not is_x(vaddr) report "unknown VDC SAT clear address" severity failure;vwrites:=vwrites+1;if not vseen(to_integer(unsigned(vaddr))) then vseen(to_integer(unsigned(vaddr))):=true;vn:=vn+1;end if;end if;
  cycle:=cycle+1;
 end loop;
 assert pn=32768 report "PCE clear sweep misses addresses: "&integer'image(pn) severity failure;
 assert vn=256 report "VDC SAT clear sweep misses addresses: "&integer'image(vn) severity failure;
 report "PASS: actual extracted clear logic, production deferred-reset trace, PCE start="&integer'image(PCE_START)&" VDC start="&integer'image(VDC_START)&" unique="&integer'image(pn)&"/"&integer'image(vn)&" writes="&integer'image(pwrites)&"/"&integer'image(vwrites) severity note;finish;
 end process;
end;
