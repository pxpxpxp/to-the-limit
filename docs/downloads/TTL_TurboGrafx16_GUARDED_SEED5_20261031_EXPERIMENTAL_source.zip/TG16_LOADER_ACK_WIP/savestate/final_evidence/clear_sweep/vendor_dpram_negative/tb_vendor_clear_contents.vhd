library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.textio.all;use std.env.all;
entity tb_vendor_clear_contents is end;
architecture sim of tb_vendor_clear_contents is
 signal clk:std_logic:='0';signal frozen:std_logic:='1';signal ram_frozen,cart,pending,load,cold:std_logic:='0';
 signal paddr:std_logic_vector(14 downto 0);signal pwe:std_logic;
 signal vaddr:std_logic_vector(7 downto 0);signal vwe:std_logic;
 signal host_addr:std_logic_vector(14 downto 0):=(others=>'0');signal host_we,sat_host_we:std_logic:='0';
 signal qram,qsat:std_logic_vector(15 downto 0);
begin
 clk<=not clk after 5 ns;cold<=cart or pending;
 pce:entity work.pce_clear_extract port map(CLK=>clk,SS_LOAD=>load,SS_FREEZE=>frozen,COLD_RESET=>cold,SS_SH_CLR_A=>std_logic_vector(to_unsigned(11693,15)),SS_SH_CLR_WE=>'0',CLEAR_ADDR=>paddr,CLEAR_WE=>pwe);
 vdc:entity work.vdc_clear_extract port map(CLK=>clk,SS_LOAD=>load,SS_FREEZE=>frozen,CLR_MEM=>cold,SS_SH_CLR_A=>to_unsigned(183,8),SS_SH_CLR_WE=>'0',CLEAR_ADDR=>vaddr,CLEAR_WE=>vwe);
 -- Exact production dpram RTL and Intel Quartus altsyncram simulation model.
 -- Host writes below are test setup only, before the deferred pulse.
 vram:entity work.dpram generic map(addr_width=>15,data_width=>16,mem_init_file=>"UNUSED")
  port map(clock=>clk,SS_FREEZE=>ram_frozen,SS_RDO=>open,SS_DO=>open,address_a=>host_addr,data_a=>x"ffff",wren_a=>host_we,q_a=>qram,address_b=>paddr,data_b=>x"0000",wren_b=>pwe,q_b=>open);
 sat:entity work.dpram generic map(addr_width=>8,data_width=>16,mem_init_file=>"UNUSED")
  port map(clock=>clk,SS_FREEZE=>ram_frozen,SS_RDO=>open,SS_DO=>open,address_a=>host_addr(7 downto 0),data_a=>x"ffff",wren_a=>sat_host_we,q_a=>qsat,address_b=>vaddr,data_b=>x"0000",wren_b=>vwe,q_b=>open);
 process
 file trace:text open read_mode is "../negative_control/cold_trace.txt";variable l:line;variable fi,ci,pi,li:integer;
 begin
 -- Fill every tested word with ones; no behavioral RAM initialization shortcut.
 for i in 0 to 32767 loop
  wait until falling_edge(clk);host_addr<=std_logic_vector(to_unsigned(i,15));host_we<='1';
  if i<256 then sat_host_we<='1';else sat_host_we<='0';end if;
 end loop;
 wait until falling_edge(clk);host_we<='0';sat_host_we<='0';
 -- Prove the initialization actually wrote ones before testing clearing.
 for i in 0 to 32767 loop
  wait until falling_edge(clk);host_addr<=std_logic_vector(to_unsigned(i,15));
  wait until rising_edge(clk);wait for 1 ns;
  assert qram=x"ffff" report "VRAM preload failed address="&integer'image(i)&" value="&to_hstring(qram) severity failure;
  if i<256 then assert qsat=x"ffff" report "SAT preload failed address="&integer'image(i)&" value="&to_hstring(qsat) severity failure;end if;
 end loop;
 -- Apply the production-top generated deferred-cold trace.
 while not endfile(trace) loop
  readline(trace,l);read(l,fi);read(l,ci);read(l,pi);read(l,li);wait until falling_edge(clk);
  if fi=1 then frozen<='1';ram_frozen<='1';else frozen<='0';ram_frozen<='0';end if;
  if ci=1 then cart<='1';else cart<='0';end if;
  if pi=1 then pending<='1';else pending<='0';end if;
  if li=1 then load<='1';else load<='0';end if;
 end loop;
 -- Read through actual synchronous altsyncram port A, checking every word.
 for i in 0 to 32767 loop
  wait until falling_edge(clk);host_addr<=std_logic_vector(to_unsigned(i,15));
  wait until rising_edge(clk);wait for 1 ns;
  assert qram=x"0000" report "VRAM clear failed address="&integer'image(i)&" value="&to_hstring(qram) severity failure;
  if i<256 then assert qsat=x"0000" report "SAT clear failed address="&integer'image(i)&" value="&to_hstring(qsat) severity failure;end if;
 end loop;
 report "PASS: actual dpram/Intel altsyncram contents, every VRAM and SAT word initialized ffff then cleared by deferred-reset trace" severity note;finish;
 end process;
end;
