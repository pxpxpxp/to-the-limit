library ieee;use ieee.std_logic_1164.all;use ieee.std_logic_unsigned.all;
entity pce_clear_extract is port(CLK,SS_LOAD,SS_FREEZE,COLD_RESET:in std_logic;SS_SH_CLR_A:in std_logic_vector(14 downto 0);SS_SH_CLR_WE:in std_logic;CLEAR_ADDR:out std_logic_vector(14 downto 0);CLEAR_WE:out std_logic);end;
architecture rtl of pce_clear_extract is signal CLR_A:std_logic_vector(14 downto 0);signal CLR_WE:std_logic;begin
process(CLK) begin if rising_edge(CLK) then
if SS_LOAD = '1' then
CLR_A <= SS_SH_CLR_A;
elsif SS_FREEZE = '0' then

CLR_A <= CLR_A + 1;

end if;
end if; end process;
process(CLK) begin if rising_edge(CLK) then
if SS_LOAD = '1' then
CLR_WE <= SS_SH_CLR_WE;
elsif SS_FREEZE = '0' then

CLR_WE <= COLD_RESET;

end if;
end if; end process;
CLEAR_ADDR<=CLR_A;CLEAR_WE<=CLR_WE;
end;
