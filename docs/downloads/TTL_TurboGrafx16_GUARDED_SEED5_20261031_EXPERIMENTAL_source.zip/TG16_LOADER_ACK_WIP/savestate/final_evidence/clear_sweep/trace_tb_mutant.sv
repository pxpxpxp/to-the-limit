`timescale 1ns/1ps
module trace_tb;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg ss_machine_freeze=1,cart_download=0,reset=0,ss_fault_reset=0;
reg ss_fault_pending=0,ss_cold_pending=0;
reg [3:0] ss_fault_count=0;
reg [15:0] ss_cold_count=0;
always @(posedge clk_sys) begin
 if(cart_download && ss_machine_freeze) begin ss_cold_pending<=1;ss_cold_count<=0;end
 else if(ss_cold_pending && !ss_machine_freeze) begin
  if(ss_cold_count==32765) begin ss_cold_pending<=0;ss_cold_count<=0;end
  else ss_cold_count<=ss_cold_count+1'd1;
 end
 // pce_top samples RESET only while unfrozen. Retain an external reset
 // seen during snapshot ownership until the machine can observe it.
 if(ss_fault_reset || ((reset || cart_download) && ss_machine_freeze)) begin ss_fault_pending<=1;ss_fault_count<=0;end
 else if(ss_fault_pending && !ss_machine_freeze && !ss_cold_pending) begin
   if(ss_fault_count==7)ss_fault_pending<=0;else ss_fault_count<=ss_fault_count+1'd1;
 end
end

integer fd,i;
initial begin
 fd=$fopen("cold_trace.txt","w");if(!fd)$fatal;
 for(i=0;i<32790;i=i+1)begin
  @(negedge clk_sys);
  cart_download=(i==2);
  ss_machine_freeze=(i<8);
  $fdisplay(fd,"%0d %0d %0d %0d",ss_machine_freeze,cart_download,ss_cold_pending,(i==0));
 end
 $fclose(fd);
 if(ss_cold_pending||ss_cold_count!=0)$fatal(1,"deferred cold state did not drain");
 $display("PASS: production deferred-reset block emitted 32790-cycle frozen-pulse trace");$finish;
end
endmodule
