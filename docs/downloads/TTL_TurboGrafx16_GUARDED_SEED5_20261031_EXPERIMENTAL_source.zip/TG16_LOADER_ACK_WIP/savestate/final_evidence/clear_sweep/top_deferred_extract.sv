reg ss_fault_pending=0,ss_cold_pending=0;
reg [3:0] ss_fault_count=0;
reg [15:0] ss_cold_count=0;
always @(posedge clk_sys) begin
 if(cart_download && ss_machine_freeze) begin ss_cold_pending<=1;ss_cold_count<=0;end
 else if(ss_cold_pending && !ss_machine_freeze) begin
  if(ss_cold_count==32771) begin ss_cold_pending<=0;ss_cold_count<=0;end
  else ss_cold_count<=ss_cold_count+1'd1;
 end
 // pce_top samples RESET only while unfrozen. Retain an external reset
 // seen during snapshot ownership until the machine can observe it.
 if(ss_fault_reset || ((reset || cart_download) && ss_machine_freeze)) begin ss_fault_pending<=1;ss_fault_count<=0;end
 else if(ss_fault_pending && !ss_machine_freeze && !ss_cold_pending) begin
   if(ss_fault_count==7)ss_fault_pending<=0;else ss_fault_count<=ss_fault_count+1'd1;
 end
end
