from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parents[1];s=(P/'TurboGrafx16.sv').read_text();block=s[s.index('reg [3:0] joy_latch;'):s.index('wire snac =')];a=s.index('assign ss_input_dout =');b=s.index(';',a)+1;readmux=s[a:b]
head='''`timescale 1ns/1ps
module dut(input clk_sys,reset,ss_fault_pending,ss_machine_freeze,ss_load_commit,ss_save,ss_we,input [17:0] ss_addr,input [15:0] ss_din,input [1:0] joy_out,input [31:0] status,input [15:0] joy_data,joy_0,joy_1,joy_2,joy_3,joy_4,input [24:0] ps2_mouse,output wire [15:0] ss_input_dout);
'''
tb='''endmodule
module tb;
parameter POLLING=0;
reg clk_sys=0;always #5 clk_sys=~clk_sys;
reg reset=1,ss_fault_pending=0,ss_machine_freeze=0,ss_load_commit=0,ss_save=0,ss_we=0;
reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg [1:0] joy_out=0;reg [31:0] status=0;
reg [15:0] joy_data=0,joy_0=0,joy_1=0,joy_2=0,joy_3=0,joy_4=0;reg [24:0] ps2_mouse=0;wire [15:0] ss_input_dout;integer i,n=0;
dut u(.*);
initial begin
 repeat(4)@(negedge clk_sys);reset=0;
 for(i=0;i<80001;i=i+1)begin if(POLLING!=0)joy_out=((i%32)<16)?2'b10:2'b00;@(negedge clk_sys);end
 ss_machine_freeze=1;ss_save=1;@(negedge clk_sys);ss_save=0;
 for(i=561;i<=577;i=i+1)begin ss_addr=18'h30000+i;#1;
  if(^ss_input_dout === 1'bx)begin $display("INPUT_SCAN_UNKNOWN polling=%0d address=%0d bits=%b",POLLING,i,ss_input_dout);n=n+1;end
 end
 $display("INPUT_SCAN_COMPLETE polling=%0d unknown_words=%0d",POLLING,n);$finish;
end
initial begin #2000000;$fatal(1,"timeout");end
endmodule
'''
with tempfile.TemporaryDirectory(prefix='tg16-input-inventory-') as d:
 d=Path(d);(d/'tb.sv').write_text(head+block+readmux+tb)
 for mode in [0,1]:
  target=d/f'sim{mode}';subprocess.run(['iverilog','-g2012','-s','tb',f'-Ptb.POLLING={mode}','-o',str(target),str(d/'tb.sv')],check=True)
  subprocess.run(['vvp',str(target)],check=True)
