`timescale 1ns/1ps
module tb_sdram_word578_no_x;
 reg clk=0;always #5 clk=~clk;
 reg init=1,clkref=0,rd=0,ss_save=0,ss_load=0,ss_reg_we=0;
 reg [14:0] ss_reg_addr=578;reg [15:0] ss_reg_din=0;wire [15:0] ss_reg_dout;
 reg ss_scan_freeze=0,ss_scan_req=0,ss_scan_wr=0;reg [24:0] ss_scan_addr=0;reg [7:0] ss_scan_din=0;
 wire ss_scan_ack;wire [7:0] ss_scan_dout;
 reg [24:0] raddr=0;wire ready;wire [7:0] dout;
 tri [15:0] dq;wire [12:0] addr;wire [1:0] ba;wire nras,ncas,nwe;
 sdram dut(.ss_reg_addr(ss_reg_addr),.ss_reg_din(ss_reg_din),.ss_reg_we(ss_reg_we),.ss_reg_dout(ss_reg_dout),.ss_save(ss_save),.ss_load(ss_load),
  .ss_scan_freeze(ss_scan_freeze),.ss_scan_req(ss_scan_req),.ss_scan_wr(ss_scan_wr),.ss_scan_addr(ss_scan_addr),.ss_scan_din(ss_scan_din),.ss_scan_ack(ss_scan_ack),.ss_scan_dout(ss_scan_dout),
  .init(init),.clk(clk),.clkref(clkref),.raddr(raddr),.rd(rd),.rd_rdy(ready),.dout(dout),.waddr(25'd0),.din(16'd0),.we(1'b0),.we_req(1'b0),.we_ack(),
  .SDRAM_DQ(dq),.SDRAM_A(addr),.SDRAM_BA(ba),.SDRAM_nCS(),.SDRAM_nWE(nwe),.SDRAM_nRAS(nras),.SDRAM_nCAS(ncas),.SDRAM_DQML(),.SDRAM_DQMH(),.SDRAM_CLK(),.SDRAM_CKE());
 function [15:0] contents(input [23:0] w);contents=w[15:0]^{w[23:16],w[23:16]}^16'ha75c;endfunction
 reg [15:0] mem[0:262143];reg [12:0] row[0:3];reg [15:0] read_data,drive_data;reg [1:0] pending=0;reg drive=0;
 reg [23:0] wa;integer since_refresh=0,refreshes=0,i,t;reg track=0;reg [7:0] original_dout;
 assign dq=drive?drive_data:16'hzzzz;
 always @(negedge clk) begin
  drive<=pending[1];if(pending[1])drive_data<=read_data;pending<={pending[0],1'b0};
  if(track)begin
   since_refresh<=since_refresh+1;
   if({nras,ncas,nwe}==3'b001)begin since_refresh<=0;refreshes<=refreshes+1;end
   if(since_refresh>330)$fatal(1,"SDRAM refresh gap exceeded bound");
  end
  if({nras,ncas,nwe}==3'b011)row[ba]<=addr;
  if({nras,ncas,nwe}==3'b101)begin
   wa={ba,addr[8],row[ba],addr[7:0]};
   read_data<=((wa>=24'h300000)&&(wa<24'h340000))?mem[wa[17:0]]:contents(wa);pending[0]<=1;
  end
  if({nras,ncas,nwe}==3'b100)begin
   wa={ba,addr[8],row[ba],addr[7:0]};
   if(wa>=24'h300000&&wa<24'h340000)begin
    if(!addr[11])mem[wa[17:0]][7:0]<=dq[7:0];
    if(!addr[12])mem[wa[17:0]][15:8]<=dq[15:8];
   end else $fatal(1,"write outside CD banks %h",wa);
  end
 end
 function [7:0] byte_pattern(input integer x);byte_pattern=(x^(x>>8)^(x>>16))&255;endfunction
 task scan(input bit w,input [24:0] address,input [7:0] din,output [7:0] result);
 begin
  @(negedge clk);ss_scan_addr=address;ss_scan_din=din;ss_scan_wr=w;ss_scan_req=!ss_scan_req;t=0;
  while(ss_scan_ack!==ss_scan_req)begin @(negedge clk);t=t+1;if(t>1000)$fatal(1,"scan timeout");end
  result=ss_scan_dout;
 end endtask
 reg [7:0] got;
 initial begin
  for(i=0;i<262144;i=i+1)mem[i]={byte_pattern(2*i+1),byte_pattern(2*i)};
  repeat(20)@(negedge clk);init=0;
  repeat(100)begin clkref=1;repeat(2)@(negedge clk);clkref=0;repeat(10)@(negedge clk);end
  raddr=25'h001234;rd=1;clkref=1;repeat(2)@(negedge clk);clkref=0;repeat(20)@(negedge clk);rd=0;repeat(10)@(negedge clk);original_dout=dout;
  if (^original_dout === 1'bx) $fatal(1,"completed ROM read has unknown dout");
  ss_save=1;repeat(2)@(negedge clk);ss_save=0;#1;
  if(ss_reg_dout !== {8'd0,original_dout})$fatal(1,"word 578 is unknown or mismatched after completed ROM read: %h",ss_reg_dout);
  $display("PASS: word 578 after completed synthetic ROM read is defined and matches latch %h",original_dout);
  ss_scan_freeze=1;repeat(8)@(negedge clk);track=1;
  for(i=0;i<300;i=i+1)begin
   scan(0,25'h600000+i,0,got);if(got!==byte_pattern(i))$fatal(1,"active read mismatch %0d",i);
   scan(1,25'h640000+i,byte_pattern(i)^8'h5a,got);
   scan(0,25'h640000+i,0,got);if(got!==(byte_pattern(i)^8'h5a))$fatal(1,"stage read mismatch %0d",i);
  end
  if(refreshes<2)$fatal(1,"scan did not refresh");
  if(dout!==original_dout)$fatal(1,"scan modified live ROM latch");
  track=0;ss_scan_freeze=0;repeat(10)@(negedge clk);
  $display("PASS: SDRAM byte scan, separate active/stage banks, ROM latch preservation, bounded refresh %0d",refreshes);$finish;
 end
 initial begin #3000000;$fatal(1,"timeout");end
endmodule

module altddio_out #(parameter extend_oe_disable="",intended_device_family="",invert_output="",lpm_hint="",lpm_type="",oe_reg="",power_up_high="",width=1)
 (input [width-1:0] datain_h,datain_l,input outclock,output [width-1:0] dataout,input aclr,aset,oe,outclocken,sclr,sset);
 assign dataout=outclock?datain_h:datain_l;
endmodule
