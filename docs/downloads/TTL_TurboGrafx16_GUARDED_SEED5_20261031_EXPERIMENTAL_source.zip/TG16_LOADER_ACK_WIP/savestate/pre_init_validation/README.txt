Logs in this directory predate the audio power-up initializer and schema dee35671fc44fdd3; do not treat them as exact-final source proof.
