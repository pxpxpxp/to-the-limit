#!/usr/bin/env python3
"""Deterministically integrate core audio scan after CD/FIFO generation."""
from pathlib import Path
P=Path(__file__).resolve().parents[1]
p=P/'TurboGrafx16.sv'; s=p.read_text()
a=s.index('reg [17:0] audio_l'); b=s.index('assign AUDIO_MIX = 0;',a)+len('assign AUDIO_MIX = 0;')
s=s[:a]+(P/'savestate/audio_top_block.sv').read_text().rstrip()+s[b:]
old='(ss_reg_dout | ss_input_dout | ss_sdram_dout)';new='(ss_reg_dout | ss_input_dout | ss_sdram_dout | ss_audio_dout)'
if old in s:s=s.replace(old,new,1)
assert new in s
old="wire [8:0] ss_config = {status[2],status[30:29],status[3],status[28],status[17],status[41],status[40:39]};\nreg [8:0] ss_old_config=0;"
new="wire [12:0] ss_config = {status[22],status[20],status[19:18],status[2],status[30:29],status[3],status[28],status[17],status[41],status[40:39]};\nreg [12:0] ss_old_config=0;"
if old in s:s=s.replace(old,new,1)
assert new in s
s=s.replace(".config_id({7'd0,ss_config})",".config_id({3'd0,ss_config})",1)
assert ".config_id({3'd0,ss_config})" in s
p.write_text(s)
p=P/'files.qip';s=p.read_text();entry='set_global_assignment -name VERILOG_FILE rtl/tgfx_iir_filter.v'
if entry not in s:s+='\n'+entry+'\n'
p.write_text(s)
