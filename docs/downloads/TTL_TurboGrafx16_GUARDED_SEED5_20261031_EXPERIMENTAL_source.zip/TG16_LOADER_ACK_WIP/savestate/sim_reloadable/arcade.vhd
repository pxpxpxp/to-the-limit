library ieee; use ieee.std_logic_1164.all;
entity ARCADE_CARD is
	port(
		CLK     : in  std_logic;
		RST_N   : in  std_logic;

		EN      : in  std_logic;
		WR_N    : in  std_logic;
		RD_N    : in  std_logic;
		A       : in  std_logic_vector(20 downto 0);
		DI      : in  std_logic_vector(7 downto 0);
		DO      : out std_logic_vector(7 downto 0);

		SEL_N   : out std_logic;

		RAM_CS_N: out std_logic;
		RAM_A   : out std_logic_vector(20 downto 0)
	);
end ARCADE_CARD;
architecture sim of ARCADE_CARD is begin
DO <= (others => '0');
SEL_N <= '1';
RAM_CS_N <= '1';
RAM_A <= (others => '0');
end;
