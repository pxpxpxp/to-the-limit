library STD;
use STD.TEXTIO.ALL;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_TEXTIO.all;
use IEEE.NUMERIC_STD.ALL;

entity cd is
	port(
 SS_RROTATE : in std_logic := '0';
 SS_RADDR : in std_logic_vector(14 downto 0) := (others=>'0');
 SS_RDI : in std_logic_vector(15 downto 0) := (others=>'0');
 SS_RWE : in std_logic := '0';
 SS_RDO : out std_logic_vector(15 downto 0);
 SS_UNSAFE : out std_logic;
 SS_FREEZE : in std_logic := '0';
 SS_SAVE : in std_logic := '0';
 SS_LOAD : in std_logic := '0';

		RST_N			: in  std_logic;
		CLK 			: in  std_logic;
		EN 			: in  std_logic;

		EXT_A 		: in  std_logic_vector(20 downto 0);
		EXT_DI 		: in  std_logic_vector(7 downto 0);
		EXT_DO 		: buffer std_logic_vector(7 downto 0);
		EXT_WR_N		: in  std_logic;
		EXT_RD_N		: in  std_logic;
		CPU_CE		: in  std_logic;
		
		SEL_N			: buffer std_logic;
		IRQ_N			: buffer std_logic;
		
		RAM_CS_N		: buffer std_logic;
		BRAM_EN		: buffer std_logic;
		
		CD_STAT		: in std_logic_vector(7 downto 0);
		CD_MSG		: in std_logic_vector(7 downto 0);
		CD_STAT_GET	: in std_logic;
		
		CD_COMM		: buffer std_logic_vector(95 downto 0);
		CD_COMM_SEND: buffer std_logic;
		
		CD_DOUT_REQ	: in std_logic;
		CD_DOUT		: buffer std_logic_vector(79 downto 0);
		CD_DOUT_SEND: buffer std_logic;
		
		CD_REGION   : in  std_logic;
		CD_RESET		: buffer std_logic;
		
		CD_DATA		: in std_logic_vector(7 downto 0);
		CD_DATA_WR	: in std_logic;
		CD_AUDIO_WR	: in std_logic;
		CD_SUBCD_WR	: in std_logic;
		CD_DATA_END	: buffer std_logic;
		
		DM				: in std_logic;
		
		CD_SL			: buffer signed(15 downto 0);
		CD_SR			: buffer signed(15 downto 0);
		AD_S			: buffer signed(15 downto 0)
	);
end cd;
architecture sim of cd is begin
SS_RDO <= (others => '0');
SS_UNSAFE <= '0';
end;
