LIBRARY ieee;
USE ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use ieee.numeric_std.all;

entity dpram is
	generic (
		addr_width    : integer := 8;
		data_width    : integer := 8;
		mem_init_file : string := " ";
		disable_value : std_logic := '1';
        SS_REG_BASE : integer := -1
	);
	PORT
	(
		
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_WE : in std_logic := '0';
        SS_ADDR : in std_logic_vector(addr_width-1 downto 0) := (others => '0');
        SS_DI : in std_logic_vector(data_width-1 downto 0) := (others => '0');
        SS_DO : out std_logic_vector(data_width-1 downto 0);
        clock : in STD_LOGIC;
		address_a	: in  STD_LOGIC_VECTOR (addr_width-1 DOWNTO 0);
		data_a		: in  STD_LOGIC_VECTOR (data_width-1 DOWNTO 0) := (others => '0');
		enable_a		: in  STD_LOGIC := '1';
		wren_a		: in  STD_LOGIC := '0';
		q_a			: out STD_LOGIC_VECTOR (data_width-1 DOWNTO 0);
		cs_a        : in  std_logic := '1';

		address_b	: in  STD_LOGIC_VECTOR (addr_width-1 DOWNTO 0) := (others => '0');
		data_b		: in  STD_LOGIC_VECTOR (data_width-1 DOWNTO 0) := (others => '0');
		enable_b		: in  STD_LOGIC := '1';
		wren_b		: in  STD_LOGIC := '0';
		q_b			: out STD_LOGIC_VECTOR (data_width-1 DOWNTO 0);
		cs_b        : in  std_logic := '1'
	);
end entity;


ARCHITECTURE SYN OF dpram IS

	signal q0 : std_logic_vector((data_width - 1) downto 0);
	signal q1 : std_logic_vector((data_width - 1) downto 0);

signal sh_q0, sh_q1 : std_logic_vector(data_width-1 downto 0);
    signal replay : std_logic := '0';
    signal ma : std_logic_vector(addr_width-1 downto 0);
    signal md : std_logic_vector(data_width-1 downto 0);
    signal mw, ea, eb : std_logic;
type mem_t is array(0 to 2**addr_width-1) of std_logic_vector(data_width-1 downto 0);
    signal mem : mem_t := (others => (others => '0'));
BEGIN

    process(all) variable word:natural; begin
      SS_RDO <= (others => '0');
      word := to_integer(unsigned(SS_RADDR));
      if SS_REG_BASE >= 0 then
        for bitno in 0 to data_width-1 loop
          if word = SS_REG_BASE + bitno/16 then SS_RDO(bitno mod 16) <= sh_q0(bitno); end if;
          if word = SS_REG_BASE + (data_width+15)/16 + bitno/16 then SS_RDO(bitno mod 16) <= sh_q1(bitno); end if;
        end loop;
      end if;
    end process;
    ma <= SS_ADDR when SS_FREEZE = '1' else address_a;
    md <= SS_DI when SS_FREEZE = '1' else data_a;
    mw <= SS_WE when SS_FREEZE = '1' else wren_a and cs_a;
    ea <= '1' when SS_FREEZE = '1' else enable_a;
    eb <= enable_b and not SS_FREEZE;
    SS_DO <= q0;
    process(clock) begin
      if rising_edge(clock) then
        replay <= SS_FREEZE;
        if SS_RWE = '1' and SS_REG_BASE >= 0 then
          for bitno in 0 to data_width-1 loop
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + bitno/16 then sh_q0(bitno) <= SS_RDI(bitno mod 16); end if;
            if to_integer(unsigned(SS_RADDR)) = SS_REG_BASE + (data_width+15)/16 + bitno/16 then sh_q1(bitno) <= SS_RDI(bitno mod 16); end if;
          end loop;
        end if;
        if SS_SAVE = '1' then
          if cs_a = '1' then sh_q0 <= q0; else sh_q0 <= (others => disable_value); end if;
          if cs_b = '1' then sh_q1 <= q1; else sh_q1 <= (others => disable_value); end if;
        end if;
      end if;
    end process;
    q_a<= sh_q0 when replay = '1' else q0 when cs_a = '1' else (others => disable_value);
	q_b<= sh_q1 when replay = '1' else q1 when cs_b = '1' else (others => disable_value);


    process(clock) begin
      if rising_edge(clock) then
        if ea = '1' then
          if mw = '1' then mem(to_integer(unsigned(ma))) <= md; q0 <= md;
          else q0 <= mem(to_integer(unsigned(ma))); end if;
        end if;
        if eb = '1' then
          if wren_b = '1' and cs_b = '1' then mem(to_integer(unsigned(address_b))) <= data_b; q1 <= data_b;
          else q1 <= mem(to_integer(unsigned(address_b))); end if;
        end if;
      end if;
    end process;
end SYN;
