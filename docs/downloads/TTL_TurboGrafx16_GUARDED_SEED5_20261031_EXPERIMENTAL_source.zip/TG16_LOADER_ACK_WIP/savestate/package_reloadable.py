"""Release only current, timing-clean RTL with its matching tests and binary."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
raise SystemExit('Experimental CD-empty-guard candidate is not a release; do not run release packaging until full validation')
P=Path(__file__).resolve().parents[1]
O=P.parent/'deliverables';O.mkdir(exist_ok=True)
name='TurboGrafx16_Reloadable_SaveStates_20261029'
rbf=P/'output_files/TurboGrafx16.rbf'
assert rbf.is_file() and rbf.stat().st_size>4_000_000,'No complete RBF'
inputs=json.loads((P/'savestate/build-inputs.json').read_text())
assert all(hashlib.sha256((P/n).read_bytes()).hexdigest()==h for n,h in inputs.items()),'RTL changed after build input capture'
assert rbf.stat().st_mtime>(P/'savestate/build-inputs.json').stat().st_mtime,'Stale RBF'
slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',(P/'output_files/TurboGrafx16.sta.summary').read_text(),re.M)]
assert slacks and min(slacks)>=0,'Timing failed'
for n in ['quartus_map','quartus_fit','quartus_sta','quartus_asm']:
    assert 'was successful' in (P/(n+'.log')).read_text(),f'{n} did not succeed'
replay=(P/'savestate/reloadable-replay.log').read_text()
for n in range(3):assert f'console reset + overwritten shadow bank, replay twice, mode={n}' in replay
assert 'PASS: full RAM/register image, 4 slots, binary file reload after reset' in (P/'savestate/reloadable-controller.log').read_text()
assert 'PASS: exported ROM byte reimported after shadow overwrite' in (P/'savestate/reloadable-sdram.log').read_text()
assert 'PASS:' in (P/'savestate/reloadable-reproduction.log').read_text()
assert 'quartus_sta final constraint calls identical to baseline' in (P/'savestate/reloadable-sdc-validation.log').read_text()
assert 'console reset + overwritten shadow bank, replay twice, mode=2' in (P/'savestate/reloadable-stress.log').read_text()
reports=P/'savestate/reloadable_build_reports';reports.mkdir(exist_ok=True)
for f in (P/'output_files').iterdir():
    if f.suffix in ('.rpt','.summary'):shutil.copy2(f,reports/f.name)
for f in ('quartus_map.log','quartus_fit.log','quartus_sta.log','quartus_asm.log','TurboGrafx16.qsf','TurboGrafx16.sdc'):
    shutil.copy2(P/f,reports/f)
dest=O/(name+'.rbf');shutil.copy2(rbf,dest)
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
meta=dict(filename=dest.name,bytes=dest.stat().st_size,sha256=digest,target='5CSEBA6U23I7',
          timing_checks=len(slacks),minimum_slack_ns=min(slacks),
          fit_summary=(P/'output_files/TurboGrafx16.fit.summary').read_text(),
          hardware_tested=False,format_version=1,register_words=627,image_bytes=355272)
(P/'savestate/final-build.json').write_text(json.dumps(meta,indent=2)+'\n')
(O/(name+'.sha256')).write_text(f'{digest}  {dest.name}\n')
doc=P/'docs/Reloadable_SaveStates.md';s=doc.read_text();marker='\n## FPGA build result\n'
if marker in s:s=s[:s.index(marker)]
s+=marker+f'''\nAll {len(slacks)} reported timing-summary checks pass; minimum slack is
{min(slacks):.3f} ns. Standard Fit, assembly and multi-corner timing analysis
completed for {meta['target']} without weakening the timing constraints.

RBF: `{dest.name}`, {dest.stat().st_size:,} bytes.

SHA-256: `{digest}`.

Physical MiSTer testing, including firmware disk persistence and power-cycle
recovery, remains outstanding. The included results are synthetic simulation
and FPGA build checks.

```text
{meta['fit_summary'].strip()}
```
'''
doc.write_text(s)
archive=O/(name+'_source.zip')
skip={'db','incremental_db','output_files','temp','__pycache__','.git','sim','sim_reloadable'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(P.rglob('*')):
        if not f.is_file():continue
        rel=f.relative_to(P)
        if set(rel.parts)&skip:continue
        if f.suffix in ('.pyc','.rbf','.sof','.qws','.bak','.ss'):continue
        if f.name in ('package.py','packed-debug.log') or f.name.startswith('first-layout-'):continue # historical release recipe
        if len(rel.parts)==1 and f.suffix=='.log':continue
        z.write(f,'TurboGrafx16_Reloadable/'+str(rel))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,h in inputs.items():assert hashlib.sha256(z.read('TurboGrafx16_Reloadable/'+n)).hexdigest()==h,n
print(json.dumps(dict(rbf=str(dest),source=str(archive),sha256=digest,minimum_slack_ns=min(slacks)),indent=2))
