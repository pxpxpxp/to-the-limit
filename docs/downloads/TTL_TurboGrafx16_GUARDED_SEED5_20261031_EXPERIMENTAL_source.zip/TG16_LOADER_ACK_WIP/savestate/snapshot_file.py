#!/usr/bin/env python3
"""Inspect the actual MiSTer .ss image; reject incomplete/incompatible payloads."""
from pathlib import Path
import argparse,struct,json,zlib
P=Path(__file__).resolve().parent

def inspect(path):
    layout=json.loads((P/'serialized_layout.json').read_text())
    data=Path(path).read_bytes()
    ram_words=43777; adpcm_words=8192; cdram_words=32768
    core_words=ram_words+layout['register_words']; core_groups=(core_words+3)//4
    count=core_groups+adpcm_words+cdram_words
    if len(data)!=(count+5)*8:raise ValueError(f'wrong file size: {len(data)}')
    control,magic,schema,identity,check=struct.unpack_from('<5Q',data)
    if control>>32!=(count+4)*2:raise ValueError('invalid MiSTer length header')
    if magic!=0x54474c5353000002:raise ValueError('unsupported snapshot version')
    if schema!=int(layout['schema'],16):raise ValueError('incompatible register layout')
    if identity>>48:raise ValueError('invalid identity padding')
    if check>>32!=count:raise ValueError('wrong payload word count')
    words=struct.unpack_from(f'<{count}Q',data,40)
    if core_words%4 and words[core_groups-1] >> (16*(core_words%4)):
        raise ValueError('nonzero core padding')
    payload=data[40:]
    if zlib.crc32(payload)!=(check&0xffffffff):raise ValueError('payload CRC mismatch')
    return dict(bytes=len(data),ram_words=ram_words,adpcm_groups=adpcm_words,cdram_groups=cdram_words,core_groups=core_groups,register_words=layout['register_words'],
                schema=f'{schema:016x}',rom_id=f'{identity&0xffffffff:08x}',
                configuration=(identity>>32)&65535,generation=control&0xffffffff,
                crc32=f'{check&0xffffffff:08x}')
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('file');args=parser.parse_args()
    try:print(json.dumps(inspect(args.file),indent=2))
    except (ValueError,OSError) as e:parser.exit(1,str(e)+'\n')
