"""Deterministic whole-HuCard replay test; synthetic program, no game ROM.

Real CD and Intel FIFO simulation models are used; Arcade is stubbed. All HuCard CPU, video,
PSG and RAM RTL is production code; only Altera RAM primitives are modeled.
"""
from pathlib import Path
import re,subprocess
import json,os
P=Path(__file__).resolve().parents[2];T=P/'savestate/sim_fifo_real_no_x_warmed';T.mkdir(exist_ok=True)
G=os.environ.get('GHDL','ghdl')
Q=Path(os.environ['QUARTUS_ROOTDIR']) if os.environ.get('QUARTUS_ROOTDIR') else None
if Q is None: raise SystemExit('Set QUARTUS_ROOTDIR to the installed Quartus root for its Intel simulation models')
(T/'lib').mkdir(exist_ok=True)
sim=Q/'eda/sim_lib'
subprocess.run([G,'-a','--std=08','-fsynopsys','--work=altera_mf',f'--workdir={T / "lib"}',str(sim/'altera_mf_components.vhd'),str(sim/'altera_mf.vhd')],cwd=T,check=True)
DEBUG=os.environ.get('SNAP_DEBUG')=='1'
STRESS=os.environ.get('SNAP_STRESS')=='1'
def run(*args):
    r=subprocess.run([G,args[0],f'-P{T / "lib"}',*args[1:]],cwd=T,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(r.stdout)
    if r.stdout:print(r.stdout,flush=True)
# Reuse the actual dpram scan, shadow-latch and replay control; replace primitive.
s=(P/'rtl/dpram.vhd').read_text().split('LIBRARY ieee;',2)[1]
s='LIBRARY ieee;'+s
s=s.replace('LIBRARY altera_mf;\nUSE altera_mf.altera_mf_components.all;','use ieee.numeric_std.all;')
pos=s.index('BEGIN\n',s.index('ARCHITECTURE'))
s=s[:pos]+'''type mem_t is array(0 to 2**addr_width-1) of std_logic_vector(data_width-1 downto 0);
    signal mem : mem_t := (others => (others => '0'));
'''+s[pos:]
s=s[:s.index('\taltsyncram_component :')]+'''
    process(clock) begin
      if rising_edge(clock) then
        if ea = '1' then
          if mw = '1' then mem(to_integer(unsigned(ma))) <= md; q0 <= md;
          else q0 <= mem(to_integer(unsigned(ma))); end if;
        end if;
        if eb = '1' then
          if wren_b = '1' and cs_b = '1' then mem(to_integer(unsigned(address_b))) <= data_b; q1 <= data_b;
          else q1 <= mem(to_integer(unsigned(address_b))); end if;
        end if;
      end if;
    end process;
end SYN;
'''
(T/'dpram.vhd').write_text(s)
# Disabled peripheral entities: verify stubs cannot accidentally be enabled.
def stub(source,name):
    end=re.search(r'end\s+'+name+r'\s*;',source,re.I).end()
    ent=source[:end];body=''
    for m in re.finditer(r'(\w+)\s*:\s*out\s+([^;\n]+)',ent,re.I):
        port,ty=m.groups();one=port.upper() in ['SEL_N','IRQ_N','RAM_CS_N']
        val="'1'" if one else "'0'"
        body+=f'{port} <= '+(val if ty.strip().lower()=='std_logic' else "(others => '0')")+';\n'
    return ent+f'\narchitecture sim of {name} is begin\n'+body+'end;\n'
(T/'cd.vhd').write_text(stub((P/'rtl/cd/cd.vhd').read_text(),'cd'))
top=(P/'rtl/pce_top.vhd').read_text()
comp=re.search(r'component ARCADE_CARD is.*?end component;',top,re.S|re.I)[0]
ent='library ieee; use ieee.std_logic_1164.all;\n'+comp.replace('component ARCADE_CARD is','entity ARCADE_CARD is').replace('end component;','end ARCADE_CARD;')
(T/'arcade.vhd').write_text(stub(ent,'ARCADE_CARD'))
# Production entity port map, with explicitly disabled peripherals.
ent=top[:top.index('end pce_top;')]
ports=re.findall(r'(?m)^\s*(\w+)\s*:\s*(in|buffer|out)\s+([^;\n]+)',ent,re.I)
decl='';mapping=[];out=[]
for name,direction,ty in ports:
    ty=ty.strip().split(':=')[0].strip()
    if name=='LITE':continue
    sig=name.lower()+'_s'
    if direction.lower()=='in':
        v={ 'CLK':'clk','RESET':'rst','COLD_RESET':'cold','CPU_TURBO':'std_logic_vector(to_unsigned(MODE,2))',
         'SS_RROTATE':'rotate','SS_RADDR':'addr(14 downto 0)','SS_RDI':'din','SS_RWE':'rwe','SS_FREEZE':'frozen','SS_SAVE':'save','SS_LOAD':'load','SS_ADDR':'addr','SS_DI':'din','SS_WE':'we',
         'ROM_RDY':"'1'",'ROM_DO':'rom_byte','ROM_SZ':'x"020"','JOY_IN':'"1111"',
         'BG_EN':"'1'",'SPR_EN':"'1'",'SP64':"'1'"}.get(name,"'0'" if ty.lower()=='std_logic' else "(others => '0')")
        mapping.append(f'{name} => {v}')
    else:
        decl+=f'signal {sig} : {ty};\n';mapping.append(f'{name} => {sig}')
        if name not in ['SS_DO','SS_SAFE','SS_RDO']:
            out.append(('std_logic_vector('+sig+')') if ty.startswith('signed') else sig)
code=(P/'tests/tb_cpu_turbo.vhd').read_text();code=code[code.index('constant code :'):code.index('    signal ram, ram_ref')]
code=code.replace('95 => x"80", 96 => x"FE",','95 => x"EE", 96 => x"00", 97 => x"22", 98 => x"4C", 99 => x"5F", 100 => x"E0",')
if STRESS:
    values={int(a):int(v,16) for a,v in re.findall(r'(\d+)\s*=>\s*x"([0-9A-F]{2})"',code)}
    program=[]
    def lda(n):program.extend([0xa9,n])
    def sta(a):program.extend([0x8d,a&255,a>>8])
    def vdc(r,n):
        lda(r);sta(0);lda(n&255);sta(2);lda(n>>8);sta(3)
    # Configure a live display and seed VRAM using real CPU bus writes.
    for r,v in [(5,0xc0),(9,0),(10,0x0202),(11,0x031f),(12,0x0e02),(13,223),(14,3),(0,0)]:vdc(r,v)
    for n in range(32):vdc(2,(n*0x1235)&65535)
    loop=0xe000+95+len(program)
    program.extend([0xee,0x00,0x22]) # continuously mutate work RAM
    for r,v in [(16,0),(17,64),(18,127)]:vdc(r,v) # continuous 128-word VRAM DMA
    program.extend([0x4c,loop&255,loop>>8])
    values={k:v for k,v in values.items() if k<95 or k>=8190}
    values.update({95+i:v for i,v in enumerate(program)})
    code='constant code : memory_t := (\n'+',\n'.join(f'{a} => x"{v:02X}"' for a,v in sorted(values.items()))+',others => x"EA");\n'
tb='''library ieee; use ieee.std_logic_1164.all; use ieee.numeric_std.all;
use std.env.all;
entity tb_full_snapshot is generic(MODE:natural:=0);end;
architecture test of tb_full_snapshot is
signal clk:std_logic:='0';signal rst,cold:std_logic:='1';
signal frozen,save,load,we,rwe,rotate:std_logic:='0';
signal addr:std_logic_vector(17 downto 0):=(others=>'0');
signal din:std_logic_vector(15 downto 0):=(others=>'0');
signal rom_byte:std_logic_vector(7 downto 0);
type memory_t is array(0 to 8191) of std_logic_vector(7 downto 0);
'''+code+decl+'''
type snapshot_t is array(0 to 196607) of std_logic_vector(15 downto 0);
type trace_t is array(0 to 2047) of std_logic_vector(511 downto 0);
function lastword(bank:integer) return integer is begin
 case bank is when 0=>return 8191;when 1=>return 32767;when 2=>return 255;when others=>return 511;end case;end;
begin
clk<=not clk after 5 ns;
rom_byte<=code(to_integer(unsigned(rom_a_s(12 downto 0))));
dut:entity work.pce_top generic map(LITE=>1) port map(
'''+',\n'.join(mapping)+''');
process
variable snap:snapshot_t;variable regs:snapshot_t;variable trace:trace_t;variable v:std_logic_vector(511 downto 0);
procedure halt(capture:boolean) is begin
 loop wait until rising_edge(clk);exit when ss_safe_s='1';end loop;
 frozen<='1';if capture then save<='1';end if;
 wait until rising_edge(clk);save<='0';wait until falling_edge(clk);
end;
begin
wait for 100 ns;wait until falling_edge(clk);rst<='0';cold<='0';
for i in 0 to 80000 loop wait until falling_edge(clk);end loop;
halt(true);
assert ss_cd_unsafe_s='0' report "test program unexpectedly used CD subsystem" severity failure;
for b in 0 to 5 loop for a in 0 to lastword(b) loop
 addr<=std_logic_vector(to_unsigned(b*32768+a,18));
 wait until falling_edge(clk);wait until falling_edge(clk);
 snap(b*32768+a):=ss_do_s;
end loop;end loop;
for a in 0 to REGISTER_LAST loop
 addr<=std_logic_vector(to_unsigned(a,18));
 wait until falling_edge(clk);wait until falling_edge(clk);
 regs(a):=ss_rdo_s;rotate<='1';wait until falling_edge(clk);rotate<='0';
end loop;
frozen<='0'; -- BASELINE_START
for i in 0 to 2047 loop
 wait until falling_edge(clk);
 assert not is_x(rom_a_s & rom_rd_s) report "unknown CPU ROM bus" severity failure;
 assert not is_x(video_r_s & video_g_s & video_b_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s & video_ce_s) report "unknown video signals" severity failure;
 assert not is_x(std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s)) report "unknown PSG samples" severity failure;
 v:=std_logic_vector(resize(unsigned('''+' & '.join(out)+'''),512));
 trace(i):=to_x01(v);
end loop;
-- BASELINE_END
for repetition in 0 to 1 loop
 for i in 0 to 5000 loop wait until falling_edge(clk);end loop;
 -- Reset the actual console before importing. The snapshot must survive
 -- destruction of the live CPU/video/audio machine as well as shadow overwrite.
 rst<='1';for i in 0 to 7 loop wait until falling_edge(clk);end loop;
 rst<='0';for i in 0 to 80000 loop wait until falling_edge(clk);end loop;
 halt(false);
 -- Destroy the old private snapshot with a different capture. A load must
 -- now recover the externally held register words, not those shadow values.
 save<='1';wait until falling_edge(clk);save<='0';
 for i in 0 to 3 loop wait until falling_edge(clk);end loop;
 for a in 0 to REGISTER_LAST loop
   addr<=std_logic_vector(to_unsigned(a,18));din<=regs(a);rwe<='1';
   wait until falling_edge(clk);
 end loop;
 rwe<='0';
 for a in 0 to REGISTER_LAST loop
   addr<=std_logic_vector(to_unsigned(a,18));
   wait until falling_edge(clk);wait until falling_edge(clk);
   assert to_x01(ss_rdo_s)=to_x01(regs(a)) report "register scan readback address="&integer'image(a)&" expected="&to_hstring(regs(a))&" actual="&to_hstring(ss_rdo_s) severity failure;
   rotate<='1';wait until falling_edge(clk);rotate<='0';
 end loop;
 for b in 0 to 5 loop for a in 0 to lastword(b) loop
   addr<=std_logic_vector(to_unsigned(b*32768+a,18));din<=snap(b*32768+a);we<='1';
   wait until falling_edge(clk);
 end loop;end loop;
 we<='0';load<='1';wait until falling_edge(clk);load<='0';
 for i in 0 to 7 loop wait until falling_edge(clk);end loop;
 frozen<='0'; -- REPLAY_START
 for i in 0 to 2047 loop
  wait until falling_edge(clk);
  assert not is_x(rom_a_s & rom_rd_s) report "unknown CPU ROM bus" severity failure;
  assert not is_x(video_r_s & video_g_s & video_b_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s & video_ce_s) report "unknown video signals" severity failure;
  assert not is_x(std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s)) report "unknown PSG samples" severity failure;
  v:=std_logic_vector(resize(unsigned('''+' & '.join(out)+'''),512));
  v:=to_x01(v);
  for bitnum in 0 to 511 loop
    if v(bitnum)/=trace(i)(bitnum) then report "bit="&integer'image(bitnum)&" expected="&std_logic'image(trace(i)(bitnum))&" actual="&std_logic'image(v(bitnum));end if;
  end loop;
  assert v=trace(i) report "expected="&to_hstring(trace(i))&" actual="&to_hstring(v)&" full-core replay mismatch cycle="&integer'image(i)&" pass="&integer'image(repetition) severity failure;
 end loop;
 -- REPLAY_END
end loop;
report "PASS: vendor-FIFO real-CD HuCard registers + RAM, console reset + overwritten shadow bank, replay twice, mode="&integer'image(MODE);finish;
end process;
end;
'''
tb=tb.replace('REGISTER_LAST',str(json.loads((P/'savestate/serialized_layout.json').read_text())['register_words']-1))
(T/'tb.vhd').write_text(tb)
if STRESS:
    tb=tb.replace('0 to 80000','0 to 900000')
    (T/'tb.vhd').write_text(tb)
units=['HUC6280_PKG','AddSubBCD','HUC6280_ALU','HUC6280_AG','HUC6280_MC','HUC6280_CPU','psg','HUC6280']
files=[T/'dpram.vhd',P/'rtl/CEGen.vhd',P/'rtl/cd/CEGen_CD.vhd',P/'rtl/cd/adpcm_snapshot_ram.vhd',P/'rtl/cd/MSM5205.vhd',P/'rtl/cd/SCSI_FIFO.vhd',P/'rtl/cd/CDDA_FIFO.vhd',P/'rtl/cd/CDSUBC_FIFO.vhd',P/'rtl/cd/SCSI.vhd',P/'rtl/cd/cd.vhd',T/'arcade.vhd']+[P/'rtl/HUC6280'/f'{u}.vhd' for u in units]+[P/'rtl/huc6202.vhd',P/'rtl/huc6260.vhd',P/'rtl/huc6270.vhd',P/'rtl/pce_top.vhd',T/'tb.vhd']
if DEBUG:
    (T/'debug.vhd').write_text('package snapshot_debug is signal phase : integer := 0; end;')
    tb=tb.replace('-- BASELINE_START','work.snapshot_debug.phase<=1;').replace('-- BASELINE_END','work.snapshot_debug.phase<=0;').replace('-- REPLAY_START','work.snapshot_debug.phase<=2;').replace('-- REPLAY_END','work.snapshot_debug.phase<=0;')
    (T/'tb.vhd').write_text(tb)
    manifest=json.loads((P/'savestate/register_manifest.json').read_text())
    for i,f in enumerate(files):
        rel=str(f.relative_to(P/'rtl')) if f.is_relative_to(P/'rtl') else ''
        if rel not in manifest:continue
        src=f.read_text();dec='';body=''
        for n in manifest[rel]['signals']:
            ty=re.search(r'signal SS_SH_'+n+r'\s*:\s*([^;]+);',src,re.I)[1]
            dec+=f'type DBG_T_{n} is array(0 to 2047) of {ty};\nvariable DBG_{n}:DBG_T_{n};\n'
            extra=(f'&" expected="&to_hstring(std_logic_vector(DBG_{n}(idx)))&" actual="&to_hstring(std_logic_vector({n}))' if n=='CLR_A' else '')
            body+=f'if work.snapshot_debug.phase=1 then DBG_{n}(idx):= {n};else assert DBG_{n}(idx)={n} report "register replay {rel}:{n} cycle="&integer\'image(idx){extra} severity warning;end if;\n'
        # Debug arrays are local to the monitor process to avoid overloading & in RTL.
        arch=re.search(r'architecture\s+\w+\s+of\s+\w+\s+is',src,re.I).end();b=re.search(r'(?m)^\s*begin\s*$',src[arch:],re.I).end()+arch
        proc='\nprocess(CLK) '+dec+' variable idx:integer:=0;begin if rising_edge(CLK) then if work.snapshot_debug.phase=0 then idx:=0;elsif idx<2048 then\n'+body+'idx:=idx+1;end if;end if;end process;\n'
        src=src[:b]+proc+src[b:];nf=T/('debug_'+f.name);nf.write_text(src);files[i]=nf
    files.insert(0,T/'debug.vhd')
run('-a','--std=08','-fsynopsys',*map(str,files));run('-e','--std=08','-fsynopsys','tb_full_snapshot')
for mode in ([1] if DEBUG else [2] if STRESS else [0,1,2]):
    run('-r','--std=08','-fsynopsys','tb_full_snapshot',f'-gMODE={mode}','--assert-level=error','--ieee-asserts=disable')
