library ieee; use ieee.std_logic_1164.all; use ieee.numeric_std.all;
use std.env.all;
entity tb_full_snapshot is generic(MODE:natural:=0);end;
architecture test of tb_full_snapshot is
signal clk:std_logic:='0';signal rst,cold:std_logic:='1';
signal frozen,save,load,we,rwe,rotate:std_logic:='0';
signal addr:std_logic_vector(17 downto 0):=(others=>'0');
signal din:std_logic_vector(15 downto 0):=(others=>'0');
signal rom_byte:std_logic_vector(7 downto 0);
type memory_t is array(0 to 8191) of std_logic_vector(7 downto 0);
constant code : memory_t := (
        0 => x"78",                    -- SEI
        1 => x"D4",                    -- CSH
        2 => x"A9", 3 => x"FF",         -- LDA #$FF
        4 => x"53", 5 => x"01",         -- TAM #1
        6 => x"A9", 7 => x"F8",
        8 => x"53", 9 => x"02",         -- TAM #2
        10 => x"A2", 11 => x"FF", 12 => x"9A", -- LDX #$FF / TXS
        13 => x"A9", 14 => x"05",
        15 => x"8D", 16 => x"00", 17 => x"0C", -- timer latch=5
        18 => x"A9", 19 => x"01",
        20 => x"8D", 21 => x"01", 22 => x"0C", -- timer on
        23 => x"A2", 24 => x"00",       -- LDX #0
        25 => x"8A",                    -- loop: TXA
        26 => x"9D", 27 => x"00", 28 => x"22", -- STA $2200,X
        29 => x"BD", 30 => x"00", 31 => x"22", -- LDA $2200,X
        32 => x"49", 33 => x"5A",       -- EOR #$5A
        34 => x"48", 35 => x"68",       -- PHA / PLA
        36 => x"9D", 37 => x"00", 38 => x"23", -- STA $2300,X
        39 => x"E8",                    -- INX
        40 => x"D0", 41 => x"EF",       -- BNE loop
        42 => x"A9", 43 => x"03",
        44 => x"8D", 45 => x"00", 46 => x"00", -- VDC register select
        47 => x"8D", 48 => x"02", 49 => x"00", -- VDC data write
        50 => x"AD", 51 => x"00", 52 => x"00", -- VDC status read
        53 => x"A9", 54 => x"12",
        55 => x"8D", 56 => x"04", 57 => x"04", -- palette write
        58 => x"A9", 59 => x"00",
        60 => x"8D", 61 => x"00", 62 => x"08", -- PSG channel 0
        63 => x"A9", 64 => x"FF",
        65 => x"8D", 66 => x"01", 67 => x"08", -- PSG master volume
        68 => x"8D", 69 => x"05", 70 => x"08", -- channel pan
        71 => x"A9", 72 => x"DF",
        73 => x"8D", 74 => x"04", 75 => x"08", -- DDA channel on
        76 => x"A9", 77 => x"15",
        78 => x"8D", 79 => x"06", 80 => x"08", -- DDA value
        81 => x"A9", 82 => x"03",
        83 => x"8D", 84 => x"00", 85 => x"10", -- controller port
        86 => x"54",                    -- CSL
        87 => x"EA", 88 => x"EA", 89 => x"D4", -- NOP / NOP / CSH
        90 => x"A9", 91 => x"A5",
        92 => x"8D", 93 => x"FF", 94 => x"24", -- completion marker
        95 => x"EE", 96 => x"00", 97 => x"22", 98 => x"4C", 99 => x"5F", 100 => x"E0",       -- BRA forever
        8190 => x"00", 8191 => x"E0", others => x"EA");
signal ss_do_s : std_logic_vector(15 downto 0);
signal ss_safe_s : std_logic;
signal ss_cd_unsafe_s : std_logic;
signal ss_adpcm_do_s : std_logic_vector(3 downto 0);
signal ss_rdo_s : std_logic_vector(15 downto 0);
signal rom_rd_s : std_logic;
signal rom_a_s : std_logic_vector(21 downto 0);
signal rom_clken_s : std_logic;
signal brm_a_s : std_logic_vector(10 downto 0);
signal brm_di_s : std_logic_vector(7 downto 0);
signal brm_we_s : std_logic;
signal gg_avail_s : std_logic;
signal joy_out_s : std_logic_vector(1 downto 0);
signal cd_ram_a_s : std_logic_vector(21 downto 0);
signal cd_ram_do_s : std_logic_vector(7 downto 0);
signal cd_ram_rd_s : std_logic;
signal cd_ram_wr_s : std_logic;
signal cd_comm_s : std_logic_vector(95 downto 0);
signal cd_comm_send_s : std_logic;
signal cd_dout_s : std_logic_vector(79 downto 0);
signal cd_dout_send_s : std_logic;
signal cd_reset_s : std_logic;
signal cd_data_end_s : std_logic;
signal cdda_sl_s : signed(15 downto 0);
signal cdda_sr_s : signed(15 downto 0);
signal adpcm_s_s : signed(15 downto 0);
signal psg_sl_s : signed(15 downto 0);
signal psg_sr_s : signed(15 downto 0);
signal video_r_s : std_logic_vector(2 downto 0);
signal video_g_s : std_logic_vector(2 downto 0);
signal video_b_s : std_logic_vector(2 downto 0);
signal video_bw_s : std_logic;
signal video_ce_s : std_logic;
signal video_ce_fs_s : std_logic;
signal video_vs_s : std_logic;
signal video_hs_s : std_logic;
signal video_hbl_s : std_logic;
signal video_vbl_s : std_logic;

type snapshot_t is array(0 to 196607) of std_logic_vector(15 downto 0);
type trace_t is array(0 to 2047) of std_logic_vector(511 downto 0);
function lastword(bank:integer) return integer is begin
 case bank is when 0=>return 8191;when 1=>return 32767;when 2=>return 255;when others=>return 511;end case;end;
begin
clk<=not clk after 5 ns;
rom_byte<=code(to_integer(unsigned(rom_a_s(12 downto 0))));
dut:entity work.pce_top generic map(LITE=>1) port map(
SS_ADDR => addr,
SS_DI => din,
SS_WE => we,
SS_DO => ss_do_s,
SS_SAFE => ss_safe_s,
SS_CD_UNSAFE => ss_cd_unsafe_s,
SS_ADPCM_ADDR => (others => '0'),
SS_ADPCM_DI => (others => '0'),
SS_ADPCM_WE => '0',
SS_ADPCM_DO => ss_adpcm_do_s,
SS_RROTATE => rotate,
SS_RADDR => addr(14 downto 0),
SS_RDI => din,
SS_RWE => rwe,
SS_RDO => ss_rdo_s,
SS_FREEZE => frozen,
SS_SAVE => save,
SS_LOAD => load,
RESET => rst,
COLD_RESET => cold,
CLK => clk,
CPU_TURBO => std_logic_vector(to_unsigned(MODE,2)),
ROM_RD => rom_rd_s,
ROM_RDY => '1',
ROM_A => rom_a_s,
ROM_DO => rom_byte,
ROM_SZ => x"020",
ROM_POP => '0',
ROM_CLKEN => rom_clken_s,
BRM_A => brm_a_s,
BRM_DI => brm_di_s,
BRM_DO => (others => '0'),
BRM_WE => brm_we_s,
GG_EN => '0',
GG_CODE => (others => '0'),
GG_RESET => '0',
GG_AVAIL => gg_avail_s,
SP64 => '1',
SGX => '0',
JOY_OUT => joy_out_s,
JOY_IN => "1111",
CD_EN => '0',
CD_RAM_A => cd_ram_a_s,
CD_RAM_DO => cd_ram_do_s,
CD_RAM_DI => (others => '0'),
CD_RAM_RD => cd_ram_rd_s,
CD_RAM_WR => cd_ram_wr_s,
AC_EN => '0',
CD_STAT => (others => '0'),
CD_MSG => (others => '0'),
CD_STAT_GET => '0',
CD_COMM => cd_comm_s,
CD_COMM_SEND => cd_comm_send_s,
CD_DOUT_REQ => '0',
CD_DOUT => cd_dout_s,
CD_DOUT_SEND => cd_dout_send_s,
CD_REGION => '0',
CD_RESET => cd_reset_s,
CD_DATA => (others => '0'),
CD_DATA_WR => '0',
CD_AUDIO_WR => '0',
CD_SUBCD_WR => '0',
CD_DATA_END => cd_data_end_s,
CD_DM => '0',
CDDA_SL => cdda_sl_s,
CDDA_SR => cdda_sr_s,
ADPCM_S => adpcm_s_s,
PSG_SL => psg_sl_s,
PSG_SR => psg_sr_s,
BG_EN => '1',
SPR_EN => '1',
GRID_EN => (others => '0'),
CPU_PAUSE_EN => '0',
BORDER_EN => '0',
ReducedVBL => '0',
VIDEO_R => video_r_s,
VIDEO_G => video_g_s,
VIDEO_B => video_b_s,
VIDEO_BW => video_bw_s,
VIDEO_CE => video_ce_s,
VIDEO_CE_FS => video_ce_fs_s,
VIDEO_VS => video_vs_s,
VIDEO_HS => video_hs_s,
VIDEO_HBL => video_hbl_s,
VIDEO_VBL => video_vbl_s);
process
variable snap:snapshot_t;variable regs:snapshot_t;variable trace:trace_t;variable v:std_logic_vector(511 downto 0);
procedure halt(capture:boolean) is begin
 loop wait until rising_edge(clk);exit when ss_safe_s='1';end loop;
 frozen<='1';if capture then save<='1';end if;
 wait until rising_edge(clk);save<='0';wait until falling_edge(clk);
end;
begin
wait for 100 ns;wait until falling_edge(clk);rst<='0';cold<='0';
for i in 0 to 80000 loop wait until falling_edge(clk);end loop;
halt(true);
assert ss_cd_unsafe_s='0' report "test program unexpectedly used CD subsystem" severity failure;
for b in 0 to 5 loop for a in 0 to lastword(b) loop
 addr<=std_logic_vector(to_unsigned(b*32768+a,18));
 wait until falling_edge(clk);wait until falling_edge(clk);
 snap(b*32768+a):=ss_do_s;
end loop;end loop;
for a in 0 to 680 loop
 addr<=std_logic_vector(to_unsigned(a,18));
 wait until falling_edge(clk);wait until falling_edge(clk);
 if a>=401 and a<=424 then assert not is_x(ss_rdo_s) report "unknown CPU scan word " & integer'image(a) severity failure;end if;
 regs(a):=ss_rdo_s;rotate<='1';wait until falling_edge(clk);rotate<='0';
end loop;
frozen<='0'; -- BASELINE_START
for i in 0 to 2047 loop
 wait until falling_edge(clk);
 assert not is_x(rom_a_s & rom_rd_s) report "unknown CPU ROM bus" severity failure;
 assert not is_x(video_r_s & video_g_s & video_b_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s & video_ce_s) report "unknown video signals" severity failure;
 assert not is_x(std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s)) report "unknown PSG samples" severity failure;
 v:=std_logic_vector(resize(unsigned(ss_cd_unsafe_s & ss_adpcm_do_s & rom_rd_s & rom_a_s & rom_clken_s & brm_a_s & brm_di_s & brm_we_s & gg_avail_s & joy_out_s & cd_ram_a_s & cd_ram_do_s & cd_ram_rd_s & cd_ram_wr_s & cd_comm_s & cd_comm_send_s & cd_dout_s & cd_dout_send_s & cd_reset_s & cd_data_end_s & std_logic_vector(cdda_sl_s) & std_logic_vector(cdda_sr_s) & std_logic_vector(adpcm_s_s) & std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s) & video_r_s & video_g_s & video_b_s & video_bw_s & video_ce_s & video_ce_fs_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s),512));
 trace(i):=to_x01(v);
end loop;
-- BASELINE_END
for repetition in 0 to 1 loop
 for i in 0 to 5000 loop wait until falling_edge(clk);end loop;
 -- Reset the actual console before importing. The snapshot must survive
 -- destruction of the live CPU/video/audio machine as well as shadow overwrite.
 rst<='1';for i in 0 to 7 loop wait until falling_edge(clk);end loop;
 rst<='0';for i in 0 to 80000 loop wait until falling_edge(clk);end loop;
 halt(false);
 -- Destroy the old private snapshot with a different capture. A load must
 -- now recover the externally held register words, not those shadow values.
 save<='1';wait until falling_edge(clk);save<='0';
 for i in 0 to 3 loop wait until falling_edge(clk);end loop;
 for a in 0 to 680 loop
   addr<=std_logic_vector(to_unsigned(a,18));din<=regs(a);rwe<='1';
   wait until falling_edge(clk);
 end loop;
 rwe<='0';
 for a in 0 to 680 loop
   addr<=std_logic_vector(to_unsigned(a,18));
   wait until falling_edge(clk);wait until falling_edge(clk);
   assert to_x01(ss_rdo_s)=to_x01(regs(a)) report "register scan readback address="&integer'image(a)&" expected="&to_hstring(regs(a))&" actual="&to_hstring(ss_rdo_s) severity failure;
   rotate<='1';wait until falling_edge(clk);rotate<='0';
 end loop;
 for b in 0 to 5 loop for a in 0 to lastword(b) loop
   addr<=std_logic_vector(to_unsigned(b*32768+a,18));din<=snap(b*32768+a);we<='1';
   wait until falling_edge(clk);
 end loop;end loop;
 we<='0';load<='1';wait until falling_edge(clk);load<='0';
 for i in 0 to 7 loop wait until falling_edge(clk);end loop;
 frozen<='0'; -- REPLAY_START
 for i in 0 to 2047 loop
  wait until falling_edge(clk);
  assert not is_x(rom_a_s & rom_rd_s) report "unknown CPU ROM bus" severity failure;
  assert not is_x(video_r_s & video_g_s & video_b_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s & video_ce_s) report "unknown video signals" severity failure;
  assert not is_x(std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s)) report "unknown PSG samples" severity failure;
  v:=std_logic_vector(resize(unsigned(ss_cd_unsafe_s & ss_adpcm_do_s & rom_rd_s & rom_a_s & rom_clken_s & brm_a_s & brm_di_s & brm_we_s & gg_avail_s & joy_out_s & cd_ram_a_s & cd_ram_do_s & cd_ram_rd_s & cd_ram_wr_s & cd_comm_s & cd_comm_send_s & cd_dout_s & cd_dout_send_s & cd_reset_s & cd_data_end_s & std_logic_vector(cdda_sl_s) & std_logic_vector(cdda_sr_s) & std_logic_vector(adpcm_s_s) & std_logic_vector(psg_sl_s) & std_logic_vector(psg_sr_s) & video_r_s & video_g_s & video_b_s & video_bw_s & video_ce_s & video_ce_fs_s & video_vs_s & video_hs_s & video_hbl_s & video_vbl_s),512));
  v:=to_x01(v);
  for bitnum in 0 to 511 loop
    if v(bitnum)/=trace(i)(bitnum) then report "bit="&integer'image(bitnum)&" expected="&std_logic'image(trace(i)(bitnum))&" actual="&std_logic'image(v(bitnum));end if;
  end loop;
  assert v=trace(i) report "expected="&to_hstring(trace(i))&" actual="&to_hstring(v)&" full-core replay mismatch cycle="&integer'image(i)&" pass="&integer'image(repetition) severity failure;
 end loop;
 -- REPLAY_END
end loop;
report "PASS: vendor-FIFO real-CD HuCard registers + RAM, console reset + overwritten shadow bank, replay twice, mode="&integer'image(MODE);finish;
end process;
end;
