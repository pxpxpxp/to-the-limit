Production RTL identity: all 47 rtl/ files, TurboGrafx16.sv, serialized_layout.json and the synthetic program input matched byte-for-byte between the tested clone and tg16_guarded_build_candidate. `source_identity.sha256` records the common hashes.

GHDL vendor_hucard_replay.log shows PASS for all three CPU Turbo modes, using actual PCE/CD/SCSI RTL and Quartus 23.1 vendor FIFO models. It captured and restored real PCE RAM/registers after console reset and shadow overwrite, then compared two short traces. The ROM is synthetic and FIFO queues remained empty; Arcade is stubbed. The harness substitutes behavioral dpram for Altera RAM primitives. It does not test top-level audio filters, the snapshot controller/DDR, MiSTer HPS/file I/O, real Ninja Spirit, FPGA timing or hardware. Optional Intel FIFO port-binding warnings appear in the log.

Caution: trace and register vector comparisons convert meta-values to X and compare; matching X values are not proof of defined hardware state. Further no-X assertions on selected observables are needed.

Early no-X negative finding: `early_video_unknown_failure.log` shows mode 0 baseline `VIDEO_VBL='U'` after 42,001 live clocks. Production huc6260.vhd does not reset VBL_FF; it is first assigned at vertical count TOP_BL_LINES (23 lines in this harness, approximately 62,790 clocks). This is a real RTL startup interval in simulation; actual FPGA power-up behavior is unverified. A longer live warmup test is pending and must not erase this early result.
Evidence runner copies adjust only their source-root lookup for this directory; set GHDL and QUARTUS_ROOTDIR to the installed tool paths before running.

Warmed no-X result: after 80,001 live clocks following reset, all 3 Turbo modes passed checks that CPU ROM address/read, RGB, H/V sync, H/V blank, video enable and PSG L/R sample outputs were defined on every baseline and replay sample. This does not make the earlier VBL startup unknown go away and does not establish that all serialized state is free of unknowns. See `warmed_no_x_replay.log`.

CPU scan no-X extension passed all three Turbo modes: CPU-related serialized words 401-424 were defined at capture after warm-up, in addition to the selected live outputs noted above. It does not establish no-X for every serialized peripheral or every point in time; early VBL caveat still applies.

NOTE: These PCE-only vendor-FIFO runs preceded the top-level audio initializer/schema revision. Their PCE/CD RTL remains byte-identical, but their top-level hash/schema are old; they are not an exact-final whole-design test.
