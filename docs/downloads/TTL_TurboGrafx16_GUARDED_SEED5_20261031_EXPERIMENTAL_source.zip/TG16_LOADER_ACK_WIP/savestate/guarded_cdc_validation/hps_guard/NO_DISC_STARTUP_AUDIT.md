# No-disc HPS startup / sticky guard audit — no hardware observation

Target: `tg16_guarded_audio_cdc_candidate`, schema a58e5a8c9764267f. Original source identity is in source_identity.sha256; the audit uses a separate clone and does not mutate the target.

## Source reasoning (official Main source, pinned commit)

Official MiSTer-devel/Main_MiSTer commit 08271656799ede50358de1248f6ee878dd7ce5c4, inspected 2026-10-31 (the user's deployed Main version is unknown):
* support/pcecd/pcecd.cpp blob 46b0de4e9e5bacafa6ac8fff6d845828d967d6db: pcecd_poll starts last_req=0 and polls UIO_CD_GET. It sends status/request only when pending, or while handling a core CD command; clean polling alone does not issue UIO_CD_SET.
* support/pcecd/pcecdd.cpp blob e767fed14e68c996704989aa145b6c4813a0b296: global object starts no disc, has_status=0, data_req=false; global/static zero-initialization plus Reset() clear subq_pend. A TESTUNIT command in no-disc state DOES send a status using UIO_CD_SET. In no-disc state Update can also send if a previous subq request is pending; history is relevant.
* fpga_io.cpp blob b64cfe5f5e5c5df2eee53ba29e83cfd2660b3655: normal fpga_load_rbf calls app_restart, which re-execs Main; this path does not preserve old process-local `last_req` into the newly loaded core. Other startup paths were not exhaustively modelled.
* user_io.cpp blob 0717aa0cda4561771d4d6601227f91099fbb7c4f and osd.cpp blob fd165e8003d32205fc0a09e5293af535f7c0650c call pcecd_poll for PCE cores. Specific user firmware and event ordering are unknown.

Pinned source links: https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/support/pcecd/pcecd.cpp ; https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/support/pcecd/pcecdd.cpp ; https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/fpga_io.cpp ; https://github.com/MiSTer-devel/Main_MiSTer/blob/08271656799ede50358de1248f6ee878dd7ce5c4/user_io.cpp .

## Exact candidate behavior

`hps_ext.v` initializes CD_SET toggle high, top initializes last-seen toggle high, cd_in and CD_GET request counter initialize zero. `cd_stat_rec` and `cd_dataout_req` are cleared every cycle but new toggles are processed only outside reset/cart_download. A CD_SET sent during either interval is therefore delivered after release, rather than ignored. In cd.vhd, CD_STAT_GET, CD_DOUT_REQ, data/audio/subcode writes, certain internal memory writes and selected CPU accesses drive SS_CD_EVENT; it sets SS_UNSAFE_LATCH with no soft-reset/cart-download clear. `ss_available` then goes false. FPGA/core reconfiguration initializes the latch again. This intentionally conservative behavior can leave states unavailable for the rest of a core session after any relevant event, even with no disc.

The same guard also covers CPU accesses to CD register range 0x1ff800–0x1ff8ff and CD RAM select physical banks 0x68–0x87; `CD_EN=0` does not by itself disable all selection. No Ninja Spirit ROM or real CPU address trace was available, so whether it ever probes those addresses cannot be decided here. Do not claim no-disc gameplay can never trip the guard.

## Directed evidence

* hps_cd_clean_get.log, EXIT_STATUS=0: actual hps_ext plus exact top handshake, synthetic clean state, 128 GET polls return zero with no status/request pulse; a deliberate CD_SET positive control triggers once. Runner tests/run_hps_cd_clean_get.py and tests/tb_hps_cd_clean_get.sv.
* hps_cd_overlap.log, HPS_EXIT=0: actual hps_ext/top handshake; deliberate status during reset and request during cart download each delivered once after release, not during the blocked interval; subsequent reset does not duplicate. Runner tests/run_hps_cd_overlap.py and tests/tb_hps_cd_startup.sv.
* cd_guard_reset_sticky.log, GUARD_EXIT=0: nine event classes on actual CD/SCSI RTL with empty behavioral FIFO models; guard blocks at the event and remains asserted after an RST_N cycle. Runner tests/real_cd_test/run_guard.py and modified tests/real_cd_test/tb_cd_guard.vhd. Model initialization warnings are logged.
* cd_no_media_idle.log, EXIT_STATUS=0: actual CD/SCSI and Intel vendor FIFO simulation models, behavioral dpram, no CPU/HPS bus events; 80,000 live clocks after reset saw guard=0 and no outgoing HPS commands/requests/reset. Runner tests/real_cd_test/run_cd_no_media_idle.py and tb_cd_no_media_idle.vhd. This is isolated simulation, not an executed firmware trace.

Conclusions: clean modeled no-media startup is plausible and no unconditional SET was found in the inspected upstream source; an actual unexpected no-media SET or selected CPU access provably disables states until reconfiguration in the RTL. Whether this occurs in the user's boot path, firmware build or Ninja Spirit remains unknown and needs MiSTer hardware observation. Never claim hardware success from these tests; do not weaken the sticky guard merely to make the menu available.

Additional top-level detail: pce_top.vhd independently ORs SS_CD_RAM_UNSAFE and immediate CD_RAM_RD/CD_RAM_WR into SS_CD_UNSAFE; SS_CD_RAM_UNSAFE is also sticky until reconfiguration. This adds conservative RAM-selection protection even when the internal CD latch itself is clear.
