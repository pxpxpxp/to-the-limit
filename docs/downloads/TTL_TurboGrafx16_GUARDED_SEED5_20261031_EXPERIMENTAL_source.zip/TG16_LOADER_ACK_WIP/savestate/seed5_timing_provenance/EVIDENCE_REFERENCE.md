# Complete routed timing evidence

This lightweight source package includes the exact bounded-review verdict, evidence manifest, packaging receipt and standard build logs. The 31,038,400-byte raw routed evidence archive is intentionally omitted from this copy to make the source package practical to attach in chat; it is not deleted. The complete source-and-evidence bundle is saved separately in Library as `TurboGrafx16_GUARDED_EXPERIMENTAL_seed5_20261031_source.zip`, Library ID `libfile_1706d64da0e881918918a40a1189084f`, version 2; that bundle contains `seed5_routed_evidence.zip` at this path.

SHA-256 `seed5_routed_evidence.zip`: `b50211124fde8cf9eed736682565a71987b8197db3a30b154bd91c08ce089d7a`.

The full archive and its 2,484 members were read back and checked. The verdict is assistant-reviewed for bounded experimental test conditions only, not human review, production signoff, hardware or SD-persistence proof.
