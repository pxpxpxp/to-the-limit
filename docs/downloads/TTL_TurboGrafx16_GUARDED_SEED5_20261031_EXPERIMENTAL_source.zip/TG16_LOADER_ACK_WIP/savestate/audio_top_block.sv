reg [17:0] audio_l = 0, audio_r = 0;
reg [15:0] cmp_l = 0, cmp_r = 0;

logic [4:0] div_audio = 0;
logic adpcm_ce = 0, psg_ce = 0;

logic [15:0] adpcm_filt, psg_l_filt, psg_r_filt;
reg [17:0] pre_l = 0, pre_r = 0;
reg signed [16:0] adpcm_boost = 0;
wire [352:0] ss_psg_filter_live, ss_adpcm_filter_live;
localparam integer SS_AUDIO_BASE = 627;
localparam integer SS_AUDIO_WORDS = 54;
reg [863:0] ss_audio_shadow = 0;
wire [863:0] ss_audio_live = {15'd0, ss_adpcm_filter_live, 15'd0, ss_psg_filter_live,
    div_audio, adpcm_ce, psg_ce, audio_l, audio_r, cmp_l, cmp_r, pre_l, pre_r, adpcm_boost};
wire ss_audio_sel = ss_addr[17:15] == 6 && ss_addr[14:0] >= SS_AUDIO_BASE &&
                    ss_addr[14:0] < SS_AUDIO_BASE + SS_AUDIO_WORDS;
wire [15:0] ss_audio_dout = ss_audio_sel ? ss_audio_shadow[15:0] : 16'd0;
always @(posedge clk_sys) begin
    if (ss_save) ss_audio_shadow <= ss_audio_live;
    else if (ss_we && ss_audio_sel)
        ss_audio_shadow <= {ss_din, ss_audio_shadow[863:16]};
    else if (ss_reg_rotate && ss_audio_sel)
        ss_audio_shadow <= {ss_audio_shadow[15:0], ss_audio_shadow[863:16]};
end

always @(posedge clk_sys) begin
    if (ss_load_commit) {div_audio,adpcm_ce,psg_ce} <= ss_audio_shadow[127:121];
    else if (!ss_machine_freeze) begin
	// 2684650 and 1342323
	div_audio <= div_audio + 1'd1;

	adpcm_ce <= &div_audio[4:0];
	psg_ce <= &div_audio[3:0];
    end
end

tgfx_IIR_filter #(
	.coeff_x   (0.00200339512841342642),
	.coeff_x0  (2),
	.coeff_x1  (1),
	.coeff_x2  (0),
	.coeff_y0  (-1.95511712863912712201),
	.coeff_y1  (0.95667938324280066276),
	.coeff_y2  (0),
	.stereo    (1)
) psg_filter (
    .ss_freeze(ss_machine_freeze), .ss_load(ss_load_commit), .ss_d(ss_audio_shadow[128 +: 353]), .ss_q(ss_psg_filter_live),
	.clk       (clk_sys),
	.ce        (psg_ce), // (1342323 * 2)
	.sample_ce (1),
	.input_l   (psg_sl),
	.input_r   (psg_sr),
	.output_l  (psg_l_filt),
	.output_r  (psg_r_filt)
);

tgfx_IIR_filter #(
	.coeff_x   (0.00002488367092441635),
	.coeff_x0  (3),
	.coeff_x1  (3),
	.coeff_x2  (1),
	.coeff_y0  (-2.94383188882174362533),
	.coeff_y1  (2.88923013608993572987),
	.coeff_y2  (-0.94537670406128904155),
	.stereo    (0)
) adpcm_filter (
    .ss_freeze(ss_machine_freeze), .ss_load(ss_load_commit), .ss_d(ss_audio_shadow[496 +: 353]), .ss_q(ss_adpcm_filter_live),
	.clk       (clk_sys),
	.ce        (adpcm_ce), // 1342323
	.sample_ce (1),
	.input_l   (adpcm_s),
	.output_l  (adpcm_filt)
);

always @(posedge clk_sys) begin
    if (ss_load_commit) {audio_l,audio_r,cmp_l,cmp_r,pre_l,pre_r,adpcm_boost} <= ss_audio_shadow[120:0];
    else if (!ss_machine_freeze) begin
	adpcm_boost <= $signed({adpcm_filt[15], adpcm_filt}) + $signed((status[22] ? {{3{adpcm_filt[15]}}, adpcm_filt[15:2]} : 17'd0));

	pre_l <= ( CDDA_EN                  ? {{2{cdda_sl[15]}},         cdda_sl} : 18'd0)
			 + ((CDDA_EN && status[20]) ? {{2{cdda_sl[15]}},         cdda_sl} : 18'd0)
			 + ( PSG_EN                 ? {{2{psg_l_filt[15]}},   psg_l_filt} : 18'd0)
			 + ( ADPCM_EN               ? {adpcm_boost[16],   adpcm_boost} : 18'd0);

	pre_r <= ( CDDA_EN                  ? {{2{cdda_sr[15]}},         cdda_sr} : 18'd0)
			 + ((CDDA_EN && status[20]) ? {{2{cdda_sr[15]}},         cdda_sr} : 18'd0)
			 + ( PSG_EN                 ? {{2{psg_r_filt[15]}},   psg_r_filt} : 18'd0)
			 + ( ADPCM_EN               ? {adpcm_boost[16],   adpcm_boost} : 18'd0);

	if(~status[20]) begin
		// 3/4 + 1/4 to cover the whole range.
		audio_l <= $signed(pre_l) + ($signed(pre_l)>>>2);
		audio_r <= $signed(pre_r) + ($signed(pre_r)>>>2);
	end
	else begin
		audio_l <= pre_l;
		audio_r <= pre_r;
	end

	cmp_l <= compr(audio_l[17:2]);
	cmp_r <= compr(audio_r[17:2]);
    end
end

assign AUDIO_L = status[19:18] ? cmp_l : audio_l[17:2];
assign AUDIO_R = status[19:18] ? cmp_r : audio_r[17:2];
assign AUDIO_S = 1;
assign AUDIO_MIX = 0;
