> **CDC-integrated WIP:** This source has not been fitted or tested on hardware. See `GUARDED_CDC_WIP_NOTICE.md`; earlier evidence may use the prior schema.

# Experimental guarded HuCard snapshots — compact no-FIFO fallback

**Work in progress, not a release.** Target: Ninja Spirit HuCard with four
persistent slots and the existing CPU Turbo and extra-sprites behavior. Whole
fit, targeted timing, firmware persistence, and actual MiSTer gameplay have not
been tested. A strict CD guard may leave states unavailable even in HuCard
mode; read `CD_EXPERIMENTAL_INTEGRATION.md`. Do not rely on these states as
only copies of progress.

**No-disc startup guard:** A CD status/request sent by MiSTer Main using
`UIO_CD_SET` can permanently mark snapshot operation unsafe even with no disc
mounted. If it arrives while reset or cartridge download is active, the status
is delivered after release and can still trip the guard. Soft reset and loading
another cartridge do not clear that sticky condition; reloading the core is
required to retry, and the guard may trip again. Slots may consequently remain
unavailable, so verify save and reload on disposable progress before relying on
them. The inspected Main source initializes a clean no-disc state without a
pending status/request and normally polls `UIO_CD_GET`; source review found no
unconditional startup `CD_SET`. This does **not** establish what real MiSTer
firmware or Ninja Spirit actually sends. Icarus reset/download-overlap tests and
nine actual-CD-RTL guard/reset event simulations support the sticky behavior;
logs and input hashes are in `savestate/guarded_cdc_validation/hps_guard/`.
Physical hardware, the full Main-to-core path, and game startup remain untested.
The source review pinned MiSTer Main commit
`08271656799ede50358de1248f6ee878dd7ce5c4`, specifically
`support/pcecd/pcecd.cpp`, `support/pcecd/pcecdd.cpp`, `fpga_io.cpp`, and
`user_io.cpp`; the deployed Main version is unknown. A separate extracted RTL
simulation passed 128 clean GET polls without a phantom status and detected an
injected SET positive control. Actual CD/SCSI RTL with Intel vendor FIFO
models also remained guard-clear and issued no HPS command/request/reset during
80,000 simulated cycles of no-media idle after reset. These isolated tests do
not simulate Main end-to-end, the actual game, or real hardware.

F5 saves and F8 loads the OSD-selected slot, 1–4. MiSTer convention uses
`SS3F000000:80000`, reserving 512 KiB per slot, and current compact format-2
images are 416,640 bytes including the change word. Use the same ROM and
configuration. CRC and schema checks reject corrupt/incompatible images. Actual
SD write/reload and poweroff behavior remain untested.

The 681-word register map (`a58e5a8c9764267f`) covers HuCard CPU/video/PSG,
input and read latches, guarded CD registers, and core audio state. Work/VRAM,
sprite/palette, backup RAM, ADPCM RAM and CD RAM are scanned. FIFO contents are
not captured; activity or nonempty FIFO prevents save/load. Normal CD gameplay
is not intentionally disabled, but CD save states are unsupported. SuperGrafx,
Populous RAM, SNAC, MB128, cheats and special controllers are outside scope.
The downstream display pipeline is not captured.

Each slot begins with generation + length, magic `54474c5353000002`, schema,
ROM/config identity and payload count + CRC as five little-endian 64-bit words.
Four core 16-bit values pack per word, followed by ADPCM and CD RAM. CRC covers
all packed 64-bit payload bytes. Use `python3 savestate/snapshot_file.py FILE`
to inspect. Before import, controller checks metadata and checksum; a second
pass rechecks while staging atomic bank swaps. DDR accepted requests drain on
abort. Directed models are not a substitute for hardware verification.

Exact-schema full-capacity controller phases (12/12) passed, including four
synthetic slot exports/reloads, integrity checks, and interrupted-apply retries.
These use behavioral DDR/HPS models, not actual firmware or physical storage.
Current evidence is in `savestate/guarded_cdc_validation/`; other logs are
historical unless identified otherwise. Audio replay is synthetic and extracted, controller tests
use behavioral memory and synthetic HuCard replay is not Ninja Spirit or HPS.
Strict routed timing analysis must examine paths hidden by inherited timing
exceptions, including audio-filter-to-shadow capture.

## Additional verification and unresolved startup questions

* The deferred cold-clear circuit has 12 directed modeled sweeps: four PCE
  starting addresses × three VDC starting addresses. Extracted production logic
  covered all 32,768 PCE addresses and 256 VDC addresses; a deliberately
  shortened negative control failed as expected. This is not a full FPGA timing
  or physical reset test. The production deferred-reset logic and VHDL clear
  logic match the pre-initializer tested source; the old top hash differs only
  in the separately reviewed audio initializer and schema revision. Evidence is
  in `savestate/final_evidence/clear_sweep/`.
* In synthetic real-CD/vendor-FIFO HuCard replay after 80,001 clocks, 176
  PCE/CD scan words contained at least one 4-state X/U bit in each Turbo mode:
  56 VDC/PCE, 114 PSG and 6 CD. CPU scan words 401–424 were defined. PSG
  waveform data can affect audible output when enabled; VDC sprite state can
  affect rendering or collision behavior. These cannot all be assumed harmless.
  Actual FPGA registers are binary, not literal simulation X; the synthetic ROM
  does not establish which values or writes occur in Ninja Spirit. A separate
  six-case binary-filled PCE replay passed on matching PCE/CD source for the
  two selected fill patterns and all three Turbo modes, not an exhaustive game
  or top-level test. Full word/field inventory
  is in `savestate/final_evidence/scan_unknowns/`.
* The PCE-only inventory excludes top-level input words 561–578 and audio words
  627–680. In a separate top-input harness, synthetic regular joy polling leaves
  five mouse-related words unknown; the corresponding special-controller mode
  is disabled by the eligibility guard. Word 578 was defined in a separate
  production-SDRAM/behavioral-memory test after a completed synthetic ROM read;
  capture before the first successful read was not tested. No real HPS or game
  was exercised by these checks.
* Before the initializer, a separate natural-start 4-state simulation left audio
  divider/filter output and all 54 audio words unknown. The new explicit
  configuration-time initializers make that harness defined; they do not change
  soft-reset or restore priority. A sampled common-binary-state old/new replay
  and standalone Quartus pre-fit probe found equivalent logic/power-up netlist
  bodies. The probe is not post-fit or physical-hardware proof; check the actual
  integrated build's power-up inference. Tests and provenance are under
  `savestate/audio_init_validation/` and `savestate/final_evidence/`.
* A stronger separate clear test preloaded every one of 32,768 VRAM and 256 SAT
  words to `FFFF`, then used production `dpram` with Intel `altsyncram` models
  and the extracted deferred-reset trace to verify every word read back `0000`.
  A shortened-trace negative control failed at the expected VRAM address. This
  covers one binary PCE/VDC start-address pair (11,693/183), not all phases,
  whole-core behavior, routed timing or hardware. Logs and testbench are under
  `savestate/final_evidence/clear_sweep/vendor_dpram*`.
* Representative binary-state PCE/CD replay replaced only X/U bits in targeted
  PSG and VDC sprite scan fields with all-zero or all-one fills, imported that
  image before the reference trace, then reset, destroyed shadows and imported
  again twice. All six combinations of three Turbo modes and two fill patterns
  passed with selected live outputs known and equal. This samples two patterns,
  not all binary startup states; it does not test the top SV audio, production
  controller/DDR/HPS path, real Ninja Spirit or physical hardware. Scoped logs,
  scripts, generated benches and hashes are in
  `savestate/final_evidence/binary_filled_pce/`.
* The initialized candidate's full-capacity production controller passed 12
  independently checkpointed behavioral-model phases: four independent slot
  saves, four binary-file reloads after reset, metadata/CRC rejection and
  interrupted core/ADPCM/CD-RAM apply followed by retry. Markers bind source
  and slot hashes. `tests/run_controller_segmented.py` resumes/validates these
  phases. This models HPS file movement and DDR/RAM; it is not an SD-card,
  MiSTer firmware, real-game or hardware power-cycle test.
