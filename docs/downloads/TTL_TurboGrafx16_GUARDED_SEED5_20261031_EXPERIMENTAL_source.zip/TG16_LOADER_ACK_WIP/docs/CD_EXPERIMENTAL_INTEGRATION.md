> **CDC-integrated WIP:** This source has not been fitted or tested on hardware. See `GUARDED_CDC_WIP_NOTICE.md`; earlier evidence may use the prior schema.

# Guarded no-disc CD subset — no FIFO snapshot fallback

This branch preserves ordinary CD hardware operation but does **not** support
CD save states. It scans CD registers, ADPCM RAM and CD RAM, but not the vendor
FIFO contents. A conservative sticky guard blocks snapshots after CD activity,
HPS CD events, RAM access or internal writes; nonempty/active FIFOs also block
snapshots. It persists until FPGA reconfiguration and may trip during ordinary
HuCard startup, so Ninja Spirit eligibility is not yet established. Actual HPS
quiescence and real MiSTer startup have not been traced. Do not weaken this
guard simply to enable the menu.

CD RAM pre-requests are guarded; pages 0x68–0x7f can include harmless ROM reads.
The FPGA configuration initializes the old uninitialized CD DMA-pending flag
low and initializes the HPS output toggle to match its detector. Targeted models
exercise these mechanisms, not actual powerup. Format-2 schema is
`a58e5a8c9764267f`; 681 register words and a 416,640-byte slot. No whole fit,
routed timing, firmware persistence, real game or hardware test is implied.
