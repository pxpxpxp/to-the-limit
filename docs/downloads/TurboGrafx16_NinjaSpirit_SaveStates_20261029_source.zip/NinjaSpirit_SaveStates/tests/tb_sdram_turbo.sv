`timescale 1ns/1ps
// Exercise the real upstream SDRAM controller with the shortened CPU periods.
module tb_sdram_turbo;
  reg clk=0;
  always #5 clk=~clk; // RAM clock is 2x CPU master clock.
  reg init=1, clkref=0, rd=0;
  reg ss_save=0, ss_load=0;
  reg [7:0] saved_byte;
  reg [24:0] raddr=0;
  wire ready;
  wire [7:0] dout;
  tri [15:0] dq;
  wire [12:0] addr;
  wire [1:0] ba;
  wire nras, ncas, nwe;
  sdram dut(.ss_save(ss_save), .ss_load(ss_load), .init(init), .clk(clk), .clkref(clkref), .raddr(raddr),
    .rd(rd), .rd_rdy(ready), .dout(dout), .waddr(25'd0), .din(16'd0),
    .we(1'b0), .we_req(1'b0), .we_ack(), .SDRAM_DQ(dq), .SDRAM_A(addr),
    .SDRAM_BA(ba), .SDRAM_nCS(), .SDRAM_nWE(nwe), .SDRAM_nRAS(nras),
    .SDRAM_nCAS(ncas), .SDRAM_DQML(), .SDRAM_DQMH(), .SDRAM_CLK(), .SDRAM_CKE());

  function [15:0] contents(input [23:0] word_addr);
    contents = word_addr[15:0] ^ {word_addr[23:16], word_addr[23:16]} ^ 16'hA75C;
  endfunction
  reg [12:0] row [0:3];
  reg [15:0] read_data;
  reg [1:0] pending=0;
  reg [15:0] drive_data;
  reg drive=0;
  assign dq=drive ? drive_data : 16'hzzzz;
  // CAS=2 data on the SDRAM clock, opposite to the controller clock.
  always @(negedge clk) begin
    drive <= pending[1];
    if (pending[1]) drive_data <= read_data;
    pending <= {pending[0],1'b0};
    if ({nras,ncas,nwe} == 3'b011) row[ba] <= addr;
    if ({nras,ncas,nwe} == 3'b101) begin
      read_data <= contents({ba,addr[8],row[ba],addr[7:0]});
      pending[0] <= 1;
    end
  end

  integer period, i, t, reads, stalls;
  reg [15:0] expected;
  initial begin
    repeat(20) @(negedge clk);
    init=0;
    // Startup needs refresh cycles with regular reference edges.
    repeat(100) begin
      clkref=1; repeat(2) @(negedge clk);
      clkref=0; repeat(10) @(negedge clk);
    end
    for (period=6; period>=4; period=period-1) begin
      stalls=0; reads=0;
      for(i=0;i<300;i=i+1) begin
        raddr=(i*7919 + period*17) & 25'h1ffffff;
        expected=contents(raddr[24:1]);
        rd=1; clkref=1;
        repeat(2) @(negedge clk);
        clkref=0;
        // CPU samples WAIT at its terminal phase, two RAM ticks before
        // consuming the bus at the next CPU edge. Retain that pipeline.
        repeat(2*period-4) @(negedge clk);
        t=0;
        while(!ready) begin
          repeat(2) @(negedge clk);
          t=t+2; stalls=stalls+1;
          if(t>64) $fatal(1,"SDRAM read deadlocked");
        end
        repeat(2) @(negedge clk);
        if (dout !== (raddr[0] ? expected[15:8] : expected[7:0]))
          $fatal(1,"read mismatch period=%0d addr=%h got=%h expected=%h",period,raddr,dout,expected);
        reads=reads+1;
      end
      $display("PASS: real SDRAM controller period=%0d reads=%0d wait_extensions=%0d",period,reads,stalls);
    end
    rd=0; repeat(32) @(negedge clk);
    saved_byte=dout;
    ss_save=1;repeat(2) @(negedge clk);ss_save=0;
    raddr=raddr ^ 25'hff;rd=1;clkref=1;
    repeat(2) @(negedge clk);clkref=0;
    repeat(32) @(negedge clk);rd=0;
    repeat(32) @(negedge clk);
    if(dout===saved_byte) $fatal(1,"test failed to change ROM latch");
    ss_load=1;repeat(2) @(negedge clk);ss_load=0;
    repeat(4) @(negedge clk);
    if(dout!==saved_byte) $fatal(1,"ROM byte not restored");
    $display("PASS: last ROM byte restored while SDRAM refresh continues");
    $finish;
  end
  initial begin #1000000; $fatal(1,"timeout"); end
endmodule

// Clock output primitive only; the actual SDRAM controller is unchanged.
module altddio_out #(parameter extend_oe_disable="", intended_device_family="",
  invert_output="", lpm_hint="", lpm_type="", oe_reg="", power_up_high="", width=1)
  (input [width-1:0] datain_h, datain_l, input outclock,
   output [width-1:0] dataout, input aclr, aset, oe, outclocken, sclr, sset);
  assign dataout=outclock ? datain_h : datain_l;
endmodule
