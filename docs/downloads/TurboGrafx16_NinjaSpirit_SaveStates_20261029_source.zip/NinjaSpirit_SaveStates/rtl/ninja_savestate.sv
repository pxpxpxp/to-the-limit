// To the Limit: one volatile HuCard snapshot. No ROM/BIOS content is stored.
// Game registers use local shadow banks; mutable RAM is streamed to DDR3.
module ninja_savestate (
 input clk, ram_clk, reset, enabled, safe,
 input save_button, load_button,
 output reg freeze=0, save_pulse=0, load_pulse=0,
 output reg valid=0, fault_reset=0,
 output reg [17:0] scan_addr=0,
 input [15:0] scan_dout,
 output [15:0] scan_din,
 output scan_we,
 input ram_busy, ram_ready,
 input [63:0] ram_dout,
 output take_ddr,
 output [28:0] ram_addr,
 output [63:0] ram_din,
 output ram_rd, ram_we
);
 localparam IDLE=0, WAIT_SAFE=1, SETTLE=2, SCAN=3, REQUEST=4,
            RESPONSE=5, WRITE_RAM=6, NEXT=7, RESTORE=8, WARM=9;
 reg [3:0] state=IDLE;
 reg loading=0, old_save=0, old_load=0;
 reg [5:0] delay_count=0;
 reg [23:0] watchdog=0;
 reg req=0;
 reg [15:0] payload=0;
 reg [17:0] mailbox_addr=0;
 reg mailbox_write=0;
 reg [15:0] response=0;
 reg ack=0;
 (* async_reg="true" *) reg ack_meta=0, ack_sync=0;
 assign scan_din=response;
 assign scan_we=(state==WRITE_RAM);
 function automatic [14:0] last_word(input [2:0] bank);
   case(bank)
    0: last_word=8191; 1: last_word=32767;
    2: last_word=255; default:last_word=511;
   endcase
 endfunction
 always @(posedge clk) begin
   ack_meta<=ack; ack_sync<=ack_meta;
   old_save<=save_button; old_load<=load_button;
   save_pulse<=0; load_pulse<=0; fault_reset<=0;
   if(reset || !enabled) begin
     if(freeze && loading) fault_reset<=1;
     state<=IDLE; freeze<=0; valid<=0; watchdog<=0;
   end else begin
     if(state==IDLE) watchdog<=0; else watchdog<=watchdog+1'd1;
     if(&watchdog) begin
       // A partial restore cannot safely resume. Reset the game on timeout.
       state<=IDLE; freeze<=0; valid<=0; fault_reset<=1;
     end else case(state)
       IDLE: if(req==ack_sync) begin
         if(save_button && !old_save) begin
           loading<=0; valid<=0; state<=WAIT_SAFE;
         end else if(load_button && !old_load && valid) begin
           loading<=1; state<=WAIT_SAFE;
         end
       end
       WAIT_SAFE: if(safe) begin
         freeze<=1; save_pulse<=!loading; scan_addr<=0;
         delay_count<=0; state<=SETTLE;
       end
       SETTLE: begin
         delay_count<=delay_count+1'd1;
         if(delay_count==31) state<=SCAN;
       end
       SCAN: state<=REQUEST; // synchronous memory read latency
       REQUEST: begin
         payload<=scan_dout; mailbox_addr<=scan_addr;
         mailbox_write<=!loading; req<=!req; state<=RESPONSE;
       end
       RESPONSE: if(ack_sync==req) state<=loading ? WRITE_RAM : NEXT;
       WRITE_RAM: state<=NEXT;
       NEXT: begin
         if(scan_addr[14:0]==last_word(scan_addr[17:15])) begin
           if(scan_addr[17:15]==5) state<=RESTORE;
           else begin scan_addr<={scan_addr[17:15]+3'd1,15'd0}; state<=SCAN; end
         end else begin scan_addr<=scan_addr+1'd1; state<=SCAN; end
       end
       RESTORE: begin
         load_pulse<=loading; valid<=1; delay_count<=0; state<=WARM;
       end
       WARM: begin
         delay_count<=delay_count+1'd1;
         if(delay_count==7) begin freeze<=0; state<=IDLE; end
       end
       default: begin state<=IDLE; freeze<=0; valid<=0; end
     endcase
   end
 end

 // Bundled-data toggle mailbox. Address, direction and payload remain stable
 // until the acknowledgement has crossed back into the game clock domain.
 (* async_reg="true" *) reg req_meta=0, req_sync=0;
 (* async_reg="true" *) reg freeze_meta=0, freeze_sync=0;
 reg [1:0] dstate=0;
 reg [28:0] daddr=0;
 reg [63:0] ddata=0;
 reg dwrite=0, dread=0;
 assign take_ddr=freeze_sync;
 assign ram_addr=daddr;
 assign ram_din=ddata;
 assign ram_rd=dread;
 assign ram_we=dwrite;
 always @(posedge ram_clk) begin
   req_meta<=req; req_sync<=req_meta;
   freeze_meta<=freeze; freeze_sync<=freeze_meta;
   case(dstate)
     0: if(req_sync!=ack && freeze_sync && !ram_busy) begin
       // 0x3f000000, away from the ordinary ROM/CD memory windows.
       daddr<=29'h07e00000+{11'd0,mailbox_addr};
       ddata<={48'd0,payload};
       dwrite<=mailbox_write; dread<=!mailbox_write; dstate<=1;
     end
     1: if(!freeze_sync) begin
       // The mux no longer owns DDR and this command has not been accepted.
       // Accepted reads are already in state 2 and are drained normally.
       dwrite<=0; dread<=0; ack<=req_sync; dstate<=0;
     end else if(!ram_busy) begin
       dwrite<=0; dread<=0;
       if(dwrite) begin ack<=req_sync; dstate<=0; end
       else if(ram_ready) begin response<=ram_dout[15:0]; ack<=req_sync; dstate<=0; end
       else dstate<=2;
     end
     2: if(ram_ready) begin response<=ram_dout[15:0]; ack<=req_sync; dstate<=0; end
   endcase
 end
endmodule
