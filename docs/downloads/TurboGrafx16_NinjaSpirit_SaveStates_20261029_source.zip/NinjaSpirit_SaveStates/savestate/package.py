"""Package only a fresh, timing-clean RBF and its exact source/validation."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
P=Path(__file__).resolve().parents[1]
O=P.parent/'deliverables';O.mkdir(exist_ok=True)
name='TurboGrafx16_NinjaSpirit_SaveStates_20261029'
rbf=P/'output_files/TurboGrafx16.rbf'
assert rbf.is_file() and rbf.stat().st_size>4_000_000,'No complete RBF'
slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',(P/'output_files/TurboGrafx16.sta.summary').read_text(),re.M)]
assert slacks and min(slacks)>=0,'Timing does not pass'
assert rbf.stat().st_mtime>(P/'savestate/build-inputs.json').stat().st_mtime,'Stale RBF'
inputs=json.loads((P/'savestate/build-inputs.json').read_text())
changed=[n for n,h in inputs.items() if hashlib.sha256((P/n).read_bytes()).hexdigest()!=h]
assert not changed,('Build input changed',changed)
checks={
 'cpu-validation.log':'PASS: all ten CPU write traces match',
 'full-replay.log':'mode=2',
 'stress-replay.log':'PASS: complete HuCard CPU/video/PSG replay twice',
 'controller-validation.log':'interrupted-load recovery',
 'sdram-validation.log':'PASS: last ROM byte restored',
 'video-validation.log':'PASS: actual pixel-repeat RTL',
 'ram-latch-validation.log':'PASS: deselected RAM output-latch replay',
 'reproduction-validation.log':'PASS: all 14 generated RTL/project files',
}
for f,needle in checks.items():assert needle in (P/'savestate'/f).read_text(),f
assert (P/'savestate/full-replay.log').read_text().count('PASS: complete HuCard')==3
for f in ['quartus_map','quartus_fit','quartus_sta','quartus_asm']:
    assert (P/(f+'.log')).exists(),f
reports=P/'savestate/build_reports';reports.mkdir(exist_ok=True)
for f in (P/'output_files').iterdir():
    if f.suffix in ['.rpt','.summary']:shutil.copy2(f,reports/f.name)
for f in ['quartus_map.log','quartus_fit.log','quartus_sta.log','quartus_asm.log','TurboGrafx16.qsf','TurboGrafx16.sdc']:
    shutil.copy2(P/f,reports/f)
dest=O/(name+'.rbf');shutil.copy2(rbf,dest)
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
meta={'filename':dest.name,'bytes':dest.stat().st_size,'sha256':digest,
      'timing_checks':len(slacks),'minimum_slack_ns':min(slacks),
      'target':'5CSEBA6U23I7','quartus':'23.1std.0 Build 991',
      'fit_summary':(P/'output_files/TurboGrafx16.fit.summary').read_text(),
      'validation':checks,'hardware_tested':False}
(P/'savestate/final-build.json').write_text(json.dumps(meta,indent=2)+'\n')
(reports/(name+'.sha256')).write_text(f'{digest}  {dest.name}\n')
doc=P/'docs/NinjaSpirit_SaveStates.md';s=doc.read_text()
marker='## Final FPGA build\n'
if marker in s:s=s[:s.index(marker)]
s+='\n'+marker+'\n'+f'''Quartus synthesis, Standard Fit, assembly and multi-corner timing analysis
completed for `{meta['target']}`. All **{len(slacks)} reported timing-summary
checks pass**; minimum slack is **{min(slacks):.3f} ns**. The inherited constraints
and clock frequencies are unchanged. This only establishes the reported
constrained checks; it does not claim every external interface is constrained.

RBF: `{dest.name}`, {dest.stat().st_size:,} bytes.

SHA-256: `{digest}`.

Resource summary:

```text
{meta['fit_summary'].strip()}
```

Full reports, input hashes and test logs accompany the matching source archive.
Physical MiSTer/Ninja Spirit gameplay testing remains outstanding.
'''
doc.write_text(s)
archive=O/(name+'_source.zip')
skipdirs={'db','incremental_db','output_files','temp','releases','build_reports','__pycache__','.git'}
skiplogs={'debug-run.log','build-progress.log'}
count=0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(P.rglob('*')):
        if not f.is_file():continue
        rel=f.relative_to(P);parts=rel.parts
        # Include only this build's report directory, not inherited reports.
        if set(parts)&skipdirs and not parts[:2]==('savestate','build_reports'):continue
        if parts[:2]==('savestate','sim'):continue
        if parts[0]=='docs' and f.suffix.lower()!='.md':continue
        if len(parts)==1 and f.suffix=='.log':continue
        if f.name in skiplogs:continue
        if parts[0]=='tests' and f.suffix=='.txt':continue
        if f.suffix in ['.pyc','.rbf','.sof','.qws','.bak']:continue
        z.write(f,'NinjaSpirit_SaveStates/'+str(rel));count+=1
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,h in inputs.items():
        assert hashlib.sha256(z.read('NinjaSpirit_SaveStates/'+n)).hexdigest()==h,n
print(json.dumps({'rbf':str(dest),'source':str(archive),'sha256':digest,
 'source_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'source_files':count,'minimum_slack_ns':min(slacks)},indent=2))
