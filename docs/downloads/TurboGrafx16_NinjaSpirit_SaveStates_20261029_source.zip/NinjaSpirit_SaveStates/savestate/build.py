from pathlib import Path
import os,subprocess,re,time
root=Path('/workspace/scratch/7d59a85ff68e/.tooling')
p=Path(__file__).resolve().parents[1]
(p/'temp').mkdir(exist_ok=True)
e=os.environ.copy();e['TMP']=e['TMPDIR']=str(p/'temp')
base=str(root/'quartus-downloads/quartus_host_compat3.so')+':/usr/lib/x86_64-linux-gnu/libstdc++.so.6'
for name,args in [('quartus_map',['TurboGrafx16']),('quartus_fit',['--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16']),('quartus_sta',['TurboGrafx16','-c','TurboGrafx16','--multicorner=on','--do_report_timing']),('quartus_asm',['--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16'])]:
 e['LD_PRELOAD']=base+(':'+str(root/'root/usr/lib/x86_64-linux-gnu/libtcmalloc_minimal.so.4') if name=='quartus_map' else '')
 log=p/(name+'.log')
 print('Starting',name,time.strftime('%H:%M:%S'),flush=True)
 with log.open('w') as f:
  r=subprocess.Popen([str(root/'quartus23/quartus/bin'/name),*args],cwd=p,env=e,stdout=f,stderr=subprocess.STDOUT)
  started=time.monotonic()
  while True:
   try:
    r.wait(timeout=25)
    break
   except subprocess.TimeoutExpired:
    lines=log.read_text(errors='replace').splitlines()
    print(name,'running',round(time.monotonic()-started),'s:',lines[-1][:180] if lines else '',flush=True)
 print(name,r.returncode,flush=True);print('\n'.join(log.read_text(errors='replace').splitlines()[-8:]),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if name=='quartus_sta':
  slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*(-?\d+(?:\.\d+)?)',(p/'output_files/TurboGrafx16.sta.summary').read_text(),re.M)]
  print('Minimum slack:',min(slacks),flush=True)
  if not slacks or min(slacks)<0:raise SystemExit(2)
