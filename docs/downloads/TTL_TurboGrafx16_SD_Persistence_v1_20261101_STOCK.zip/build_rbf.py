#!/usr/bin/env python3
"""Ordinary Quartus stages; assemble only a fit with nonnegative reported timing."""
from pathlib import Path
import subprocess,os,json,re,hashlib,time
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'build/tg16_nodup_candidate_20261031'
BIN=Path(os.environ.get('QUARTUS_BIN',str(ROOT/'toolchain/quartus23/quartus/bin')))
LOG=ROOT/'logs';LOG.mkdir(exist_ok=True)
env={**os.environ,'QUARTUS_64BIT':'1'}
# Optional host-only compatibility for this environment's mismatched PID view.
# It resolves only the running compiler's own executable through /proc/self.
compat=ROOT/'toolchain/quartus_self_path.so'
if compat.exists(): env['LD_PRELOAD']=str(compat)
inputs={str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest()
 for p in SRC.rglob('*') if p.is_file() and
 p.relative_to(SRC).parts[0] not in ('db','incremental_db','output_files') and
 p.suffix.lower() in ('.sv','.v','.vhd','.qsf','.qpf','.qip','.sdc','.tcl','.mif','.vh')}
(LOG/'new_source_sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
def check_inputs():
 for name,digest in inputs.items():
  assert hashlib.sha256((SRC/name).read_bytes()).hexdigest()==digest, name
def run(stage,args):
 check_inputs();start=time.time();cmd=[str(BIN/args[0]),*args[1:]]
 print('Starting',stage,flush=True)
 with (LOG/(stage+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=SRC,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt={'stage':stage,'command':cmd,'exit_code':r.returncode,'seconds':round(time.time()-start,2)}
 (LOG/(stage+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(receipt,flush=True)
 check_inputs()
 if r.returncode:raise SystemExit('Failed: '+stage)
run('quartus_map',['quartus_map','--parallel=2','--read_settings_files=on','--write_settings_files=off','TurboGrafx16'])
for seed in (7,11,19,29):
 run('quartus_fit_seed'+str(seed),['quartus_fit','--parallel=2','--effort=standard','--seed='+str(seed),'--set=PHYSICAL_SYNTHESIS_REGISTER_RETIMING=OFF','--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16'])
 run('quartus_sta_seed'+str(seed),['quartus_sta','TurboGrafx16','-c','TurboGrafx16','--multicorner=on','--do_report_timing'])
 summary=(SRC/'output_files/TurboGrafx16.sta.summary').read_text()
 (LOG/('timing_seed'+str(seed)+'.summary')).write_text(summary)
 slacks=[float(x) for x in re.findall(r'^Slack\s*:\s*(-?[0-9.]+)',summary,re.M)]
 tns=[float(x) for x in re.findall(r'^TNS\s*:\s*(-?[0-9.]+)',summary,re.M)]
 assert len(slacks)>=100 and len(tns)==len(slacks),'Unexpected timing summary'
 gate={'seed':seed,'summary_rows':len(slacks),'minimum_slack_ns':min(slacks),'all_tns_zero':all(x==0 for x in tns),'passed':min(slacks)>=0 and all(x==0 for x in tns)}
 (LOG/('timing_gate_seed'+str(seed)+'.json')).write_text(json.dumps(gate,indent=2)+'\n');print(gate,flush=True)
 if gate['passed']:break
else:raise SystemExit('No passing fit; assembler was not run')
run('quartus_asm',['quartus_asm','--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16'])
rbf=SRC/'output_files/TurboGrafx16.rbf'
assert rbf.stat().st_size>3000000
result={**gate,'rbf_bytes':rbf.stat().st_size,'rbf_sha256':hashlib.sha256(rbf.read_bytes()).hexdigest(),'source_files':len(inputs)}
(LOG/'rbf_build_result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
