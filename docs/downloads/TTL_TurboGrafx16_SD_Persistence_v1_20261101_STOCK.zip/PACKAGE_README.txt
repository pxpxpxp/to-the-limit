Stock Main package. No Main installation is needed. Read STOCK_MAIN_GUIDE.txt.
RBF and corresponding HDL/build inputs are unchanged; documentation corrected.
Full corresponding core source is under build/tg16_nodup_candidate_20261031.
Original notices and licenses are preserved there. Historical candidate notes
are build-time records, not the current verification summary. No CD support.
