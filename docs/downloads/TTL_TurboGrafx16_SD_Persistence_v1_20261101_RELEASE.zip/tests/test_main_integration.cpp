// Compile the exact patched process_ss plus the upstream path function.
#include "../host_patch/tg16_sd_persistence.h"
#include <cassert>
#include <map>
#include <fstream>
#include <sys/stat.h>
using Bytes=std::vector<unsigned char>;
static std::string root_path;
static uint32_t ss_base=0x3f000000,ss_size=0x80000;
static char CoreName2[]="TGFX16";
struct fileTYPE { int fd=-1; uint64_t size=0; char name[1024]{}; };
static fileTYPE sd_image[16];
static std::vector<uint32_t> mapped[4];
static int success_messages=0,failure_messages=0,legacy_writes=0;
static bool is_apple2(){return false;}static bool is_arcade(){return false;}
static const char* user_io_get_core_name(){return "TGFX16";}
static const char* getRootDir(){return root_path.c_str();}
static void create_path(const char* dir,const char* subdir){
 mkdir((root_path+"/"+dir).c_str(),0700);mkdir((root_path+"/"+dir+"/"+subdir).c_str(),0700);
}
#define SAVESTATE_DIR "savestates"
#include "file_path.inc"
static void* shmem_map(uint32_t addr,uint32_t len){
 assert(len==ss_size&&addr>=ss_base);auto i=(addr-ss_base)/ss_size;assert(i<4);mapped[i].resize(len/4);return mapped[i].data();
}
static int FileExists(const char* p){return access((root_path+"/"+p).c_str(),F_OK)==0;}
static int FileOpen(fileTYPE* f,const char* p){f->fd=open((root_path+"/"+p).c_str(),O_RDONLY);return f->fd>=0;}
static int FileReadAdv(fileTYPE* f,void* b,int n){return read(f->fd,b,n);}
static void FileClose(fileTYPE* f){close(f->fd);f->fd=-1;}
static int FileSave(const char*,void*,int n){++legacy_writes;return n;}
static bool CheckTimer(unsigned long){return true;}static unsigned long GetTimer(int){return 1;}
static void MenuHide(){}
static void Info(const char* s,int){if(!strcmp(s,"Saved to SD"))++success_messages;if(strstr(s,"failed"))++failure_messages;}
#include "process_ss.inc"
static Bytes bytes(const std::string& p){std::ifstream f(p,std::ios::binary);assert(f);return Bytes(std::istreambuf_iterator<char>(f),{});}
static void put32(Bytes& b,size_t o,uint32_t v){for(int j=0;j<4;++j)b[o+j]=v>>(j*8);}
int main(int argc,char** argv){
 assert(argc==4);root_path=argv[1];mkdir(root_path.c_str(),0700);std::string input=argv[2],output=argv[3];
 assert(process_ss("games/Ninja Spirit.pce",1));
 Bytes originals[4];
 for(int i=0;i<4;++i){originals[i]=bytes(input+"/rtl_slot"+std::to_string(i+1)+".ss");assert(tg16_sd::valid_image(originals[i]));memcpy(mapped[i].data(),originals[i].data(),originals[i].size());}
 process_ss(nullptr,1);assert(success_messages==4);
 for(int i=0;i<4;++i)assert(bytes(root_path+"/savestates/TGFX16/Ninja Spirit_"+std::to_string(i+1)+".ss")==originals[i]);
 // Missing directory forces an I/O failure. The same generation must retry
 // successfully once storage is available again, without a second F5.
 std::string dir=root_path+"/savestates/TGFX16",parked=dir+".parked";
 assert(!rename(dir.c_str(),parked.c_str()));auto updated=originals[0];put32(updated,0,2);
 memcpy(mapped[0].data(),updated.data(),updated.size());process_ss(nullptr,1);
 assert(failure_messages==1&&success_messages==4);
 assert(!rename(parked.c_str(),dir.c_str()));process_ss(nullptr,1);
 assert(success_messages==5&&bytes(dir+"/Ninja Spirit_1.ss")==updated);
 // Import from actual saved files after destroying the FPGA mapping.
 for(auto& m:mapped)std::fill(m.begin(),m.end(),0xcccccccc);
 assert(process_ss("games/Ninja Spirit.pce",1));
 for(int i=0;i<4;++i){auto disk=bytes(dir+"/Ninja Spirit_"+std::to_string(i+1)+".ss");assert(mapped[i][0]==0xffffffff);assert(!memcmp((unsigned char*)mapped[i].data()+4,disk.data()+4,disk.size()-4));}
 // Export the exact host-imported mapping for a NEW RTL simulation instance.
 std::ofstream f(output);assert(f);
 for(int i=0;i<4;++i)for(size_t n=0;n<mapped[i].size();n+=2){char s[32];snprintf(s,sizeof(s),"%08x%08x\n",mapped[i][n+1],mapped[i][n]);f<<s;}
 f.close();assert(success_messages==5);process_ss(nullptr,1);assert(success_messages==5&&legacy_writes==0);
 // A globally installed Main must preserve older TG16 cores' stock handler.
 auto legacy=originals[0];put32(legacy,0,3);put32(legacy,8,2);
 memcpy(mapped[0].data(),legacy.data(),legacy.size());process_ss(nullptr,1);assert(legacy_writes==1);
 puts("PASS: exact patched Main handler + upstream path function: four real files, failed-write retry without new save, cold host import, no phantom rewrite, old-format compatibility");
}
