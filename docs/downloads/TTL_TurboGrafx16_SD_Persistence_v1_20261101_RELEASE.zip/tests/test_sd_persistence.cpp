#include "../host_patch/tg16_sd_persistence.h"
#include <cassert>
#include <fstream>
#include <algorithm>
#include <sys/stat.h>
using Bytes=std::vector<unsigned char>;
static void put32(Bytes& b,size_t o,uint32_t v) { for(int j=0;j<4;++j)b[o+j]=v>>(8*j); }
static void put64(Bytes& b,size_t o,uint64_t v) { put32(b,o,v);put32(b,o+4,v>>32); }
static Bytes fixture(int slot,uint32_t generation) {
 Bytes b(tg16_sd::image_bytes);
 for(size_t i=40;i<b.size();++i)b[i]=(i*17+slot*53)^(i>>9);
 put32(b,0,generation);put32(b,4,(b.size()-8)/4);
 put64(b,8,tg16_sd::magic);put64(b,16,tg16_sd::schema);put64(b,24,0x1234000012345678ULL+slot);
 put32(b,32,tg16_sd::crc32(b.data()+40,b.size()-40));put32(b,36,tg16_sd::payload_words);
 assert(tg16_sd::valid_image(b));return b;
}
static Bytes readback(const std::string& p) {
 std::ifstream f(p,std::ios::binary); return Bytes(std::istreambuf_iterator<char>(f),{});
}
static int calls=0,fail_sync=0;
static int sync_test(int fd) { if(++calls==fail_sync){errno=EIO;return -1;}return fsync(fd); }
static ssize_t short_write(int fd,const void* b,size_t n) {
 static bool first=true; if(first){first=false;errno=EINTR;return -1;}return write(fd,b,std::min<size_t>(n,137));
}
static ssize_t failed_write(int,const void*,size_t){errno=ENOSPC;return -1;}
static int failed_rename(const char*,const char*){errno=EIO;return -1;}
int main(int argc,char** argv) {
 assert(argc==2);std::string dir=argv[1];mkdir(dir.c_str(),0700);
 std::vector<uint32_t> mapping(0x80000/4);Bytes out;
 auto a=fixture(0,1),b=fixture(1,2);
 memcpy(mapping.data(),a.data(),a.size());
 assert(tg16_sd::copy_committed(mapping.data(),0x80000,0xffffffff,out)&&out==a);
 assert(!tg16_sd::copy_committed(mapping.data(),0x80000,1,out)&&out.empty());
 mapping[1]=0;assert(!tg16_sd::copy_committed(mapping.data(),0x80000,0xffffffff,out));
 mapping[1]=(a.size()-8)/4;mapping[100]^=1;
 assert(!tg16_sd::copy_committed(mapping.data(),0x80000,0xffffffff,out)&&out.empty());
 memcpy(mapping.data(),a.data(),a.size());mapping[1]=0xffffffff;
 assert(!tg16_sd::copy_committed(mapping.data(),0x80000,0xffffffff,out));
 assert(!tg16_sd::copy_committed(mapping.data(),32,0xffffffff,out));
 for(int slot=0;slot<4;++slot) {
  auto x=fixture(slot,slot+1);std::string p=dir+"/Ninja Spirit_"+std::to_string(slot+1)+".ss";
  assert(tg16_sd::store(p.c_str(),x));assert(readback(p)==x);
  std::ofstream f(dir+"/fixture"+std::to_string(slot)+".ss",std::ios::binary);f.write((char*)x.data(),x.size());
 }
 std::string p=dir+"/failure.ss";assert(tg16_sd::store(p.c_str(),a));
 tg16_sd::Ops ops=tg16_sd::posix_ops();ops.write_file=failed_write;
 assert(!tg16_sd::store(p.c_str(),b,ops)&&readback(p)==a);
 ops=tg16_sd::posix_ops();ops.sync_file=sync_test;calls=0;fail_sync=1;
 assert(!tg16_sd::store(p.c_str(),b,ops)&&readback(p)==a);
 ops=tg16_sd::posix_ops();ops.rename_file=failed_rename;
 assert(!tg16_sd::store(p.c_str(),b,ops)&&readback(p)==a);
 // Directory sync fails AFTER rename: caller must not mark the generation seen.
 ops=tg16_sd::posix_ops();ops.sync_file=sync_test;calls=0;fail_sync=2;
 assert(!tg16_sd::store(p.c_str(),b,ops));
 assert(tg16_sd::store(p.c_str(),b)&&readback(p)==b);
 ops=tg16_sd::posix_ops();ops.write_file=short_write;
 assert(tg16_sd::store(p.c_str(),a,ops)&&readback(p)==a);
 auto invalid=b;invalid[100]^=1;
 assert(!tg16_sd::store(p.c_str(),invalid)&&readback(p)==a);
 puts("PASS: four real filesystem slots, stable-copy/CRC rejection, short writes/EINTR, ENOSPC, file-fsync/rename/directory-fsync failures, retry and prior-file preservation");
}
