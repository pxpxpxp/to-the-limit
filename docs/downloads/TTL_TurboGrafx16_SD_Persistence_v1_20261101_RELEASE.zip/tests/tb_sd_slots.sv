`timescale 1ns/1ps
module tb_sd_slots #(parameter RW=43777, REGW=681, AW=8192, DW=32768);
 localparam CW=RW+REGW, CG=(CW+3)/4;
 localparam WORDS=CG+AW+DW, IW=WORDS+5;
 reg clk=0,ram_clk=0;always #5 clk=~clk;always #2.5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,save_button=0,load_button=0;reg [1:0] slot=0;
 wire freeze,save_pulse,load_pulse,valid,fault_reset;wire [3:0] error;
 wire [17:0] scan_addr;reg [15:0] scan_dout=0;wire [15:0] scan_din;wire scan_we,reg_rotate;
 wire [16:0] adpcm_addr;wire [3:0] adpcm_din;reg [3:0] adpcm_dout=0;wire adpcm_we;
 wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;
 reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;
 wire take_ddr;wire [28:0] ram_addr;wire [63:0] ram_din;wire ram_rd,ram_we;
 reg ram_ready=0;reg [63:0] ram_dout=0;integer rc=0,read_delay=0;reg [63:0] pending=0;
 wire ram_busy=(rc%11==3 || rc%11==4);
 reg [63:0] mem[0:262143];reg [15:0] core[0:CW-1];reg [3:0] adpcm[0:131071];reg [7:0] cd[0:262143];
 reg [63:0] disk[0:262143];reg unpublished[0:3];integer commits=0;
 ninja_savestate #(.RAM_WORDS(RW),.REGISTER_WORDS(REGW),.ADPCM_WORDS(AW),.CDRAM_WORDS(DW)) dut(.clk(clk),.ram_clk(ram_clk),.reset(reset),.enabled(enabled),.safe(1'b1),
  .save_button(save_button),.load_button(load_button),.start_block(1'b0),.slot(slot),
  .rom_id(32'h12345678),.config_id(16'h1234),.freeze(freeze),.save_pulse(save_pulse),.load_pulse(load_pulse),
  .valid(valid),.fault_reset(fault_reset),.error(error),.scan_addr(scan_addr),.scan_dout(scan_dout),
  .scan_din(scan_din),.scan_we(scan_we),.reg_rotate(reg_rotate),.adpcm_addr(adpcm_addr),
  .adpcm_din(adpcm_din),.adpcm_we(adpcm_we),.adpcm_dout(adpcm_dout),.cd_ram_addr(cd_ram_addr),
  .cd_ram_din(cd_ram_din),.cd_ram_write(cd_ram_write),.cd_ram_req(cd_ram_req),.cd_ram_hold(cd_ram_hold),
  .cd_ram_ack(cd_ram_ack),.cd_ram_dout(cd_ram_dout),.normal_idle(1'b1),.ram_busy(ram_busy),
  .ram_ready(ram_ready),.ram_dout(ram_dout),.take_ddr(take_ddr),.ram_addr(ram_addr),.ram_din(ram_din),.ram_rd(ram_rd),.ram_we(ram_we));
 integer ma,ms,off;
 always @(posedge ram_clk) begin
  rc<=rc+1;ram_ready<=0;
  if(read_delay>0)begin
   read_delay<=read_delay-1;
   if(read_delay==1)begin ram_ready<=1;ram_dout<=pending;end
  end
  if(take_ddr && !ram_busy && (ram_rd || ram_we))begin
   ma=ram_addr-29'h07e00000;ms=ma/65536;off=ma%65536;
   if(ma<0 || ma>262143)$fatal(1,"DDR address out of range");
   if(ram_rd)begin
    if(read_delay!=0)$fatal(1,"multiple outstanding reads");
    pending<=mem[ma];read_delay<=3+(rc%3);
   end else begin
    if(off==0 && ram_din[63:32]==0)unpublished[ms]<=1;
    else if(off==0)begin
     if(!unpublished[ms] || ram_din[63:32]!=(IW-1)*2)$fatal(1,"bad publication");
     unpublished[ms]<=0;commits<=commits+1;
    end else if(!unpublished[ms])$fatal(1,"payload write before invalidation");
    mem[ma]<=ram_din;
   end
  end
 end
 always @(posedge clk)begin
  if(dut.core_scan_index<CW)scan_dout<=core[dut.core_scan_index];
  if(scan_we && dut.core_scan_index<CW)core[dut.core_scan_index]<=scan_din;
  adpcm_dout<=adpcm[adpcm_addr];if(adpcm_we)adpcm[adpcm_addr]<=adpcm_din;
  if(cd_ram_req!=cd_ram_ack)begin
   cd_ram_dout<=cd[cd_ram_addr];if(cd_ram_write)cd[cd_ram_addr]<=cd_ram_din;
   cd_ram_ack<=cd_ram_req;
  end
 end
 function automatic [15:0] cv(input integer n,s);cv=(n*29+s*103)^16'ha507;endfunction
 function automatic [3:0] av(input integer n,s);av=(n^s^(n>>7));endfunction
 function automatic [7:0] dv(input integer n,s);dv=(n*13+s*31)^(n>>8);endfunction
 task fill(input integer s);integer n;begin
  for(n=0;n<CW;n=n+1)core[n]=cv(n,s);
  for(n=0;n<131072;n=n+1)adpcm[n]=av(n,s);
  for(n=0;n<262144;n=n+1)cd[n]=dv(n,s);
 end endtask
 task check(input integer s);integer n;begin
  for(n=0;n<CW;n=n+1)if(core[n]!==cv(n,s))$fatal(1,"core mismatch slot %0d word %0d",s,n);
  for(n=0;n<AW*16;n=n+1)if(adpcm[n]!==av(n,s))$fatal(1,"ADPCM mismatch slot %0d cell %0d",s,n);
  for(n=0;n<DW*8;n=n+1)if(cd[n]!==dv(n,s))$fatal(1,"CDRAM mismatch slot %0d cell %0d",s,n);
 end endtask
 task request(input bit loading);begin
  @(negedge clk);save_button=!loading;load_button=loading;
  @(negedge clk);save_button=0;load_button=0;
  wait(freeze);wait(!freeze);repeat(25)@(posedge clk);
  if(error!=0 || !valid)$fatal(1,"operation failed: slot %0d error %0d",slot,error);
 end endtask
 integer n,s,f,b;string mode,dir,name;
 initial begin
  if(!$value$plusargs("MODE=%s",mode))mode="save";
  if(!$value$plusargs("DIR=%s",dir))dir="tests/rtl_files";
  for(n=0;n<262144;n=n+1)begin mem[n]=0;disk[n]=0;end
  for(s=0;s<4;s=s+1)begin unpublished[s]=0;mem[s*65536]=64'h00000000ffffffff;end
  repeat(15)@(negedge clk);reset=0;repeat(15)@(negedge clk);
  if(mode=="save")begin
   for(s=0;s<4;s=s+1)begin
    slot=s;fill(s);request(0);
    name=$sformatf("%s/rtl_slot%0d.ss",dir,s+1);f=$fopen(name,"wb");if(!f)$fatal(1,"open %s",name);
    for(n=0;n<IW;n=n+1)for(b=0;b<8;b=b+1)$fwrite(f,"%c",mem[s*65536+n][b*8+:8]);
    $fclose(f);$display("PASS: slot %0d capture with invalidate-before-write/commit-last",s+1);
   end
   if(commits!=4)$fatal(1,"commit count");
   // Abort a resave after unpublishing. It must never advertise a complete image.
   slot=0;fill(7);@(negedge clk);save_button=1;@(negedge clk);save_button=0;
   wait(unpublished[0]);repeat(25)@(negedge clk);reset=1;
   repeat(40)@(negedge clk);reset=0;repeat(40)@(negedge clk);
   if(mem[0][63:32]!=0 || commits!=4)$fatal(1,"aborted capture published");
   $display("PASS: reset during capture leaves DDR image unpublished");
  end else begin
   name={dir,"/imported.hex"};$readmemh(name,disk);
   for(n=0;n<262144;n=n+1)mem[n]=disk[n];
   for(s=0;s<4;s=s+1)begin slot=s;fill(7);request(1);check(s);$display("PASS: cold SD import and exact complete restore slot %0d",s+1);end
  end
  $finish;
 end
 initial begin #2000000000;$fatal(1,"simulation timeout");end
 integer progress=0;
 always @(posedge clk)begin
  progress=progress+1;
  if(progress%250000==0)begin
   $display("Progress: slot=%0d state=%0d phase=%0d index=%0d",slot+1,dut.state,dut.phase,dut.index);$fflush();
  end
 end
endmodule
