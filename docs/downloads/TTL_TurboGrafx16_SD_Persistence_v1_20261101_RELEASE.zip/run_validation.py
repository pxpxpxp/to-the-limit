#!/usr/bin/env python3
"""Reproduce protocol tests with g++, Icarus Verilog 12 and ordinary local files."""
from pathlib import Path
import os,subprocess,json,hashlib
root=Path(__file__).resolve().parent
os.chdir(root)
logs=root/'logs';logs.mkdir(exist_ok=True)
sim=root/'simulators/bin'
iverilog=str(sim/'iverilog') if (sim/'iverilog').exists() else 'iverilog'
vvp=str(sim/'vvp') if (sim/'vvp').exists() else 'vvp'
def run(name,cmd):
 print(name,flush=True)
 with (logs/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
# The exact tested handler is supplied; verify extraction matches its source.
s=(root/'host_patch/user_io.cpp').read_text()
assert (root/'tests/process_ss.inc').read_text()==s[s.index('int process_ss('):s.index('\nvoid user_io_set_index(',s.index('int process_ss('))]
run('sd_filesystem_test',['g++','-std=c++14','-O2','-Wall','-Wextra','-Werror','tests/test_sd_persistence.cpp','-o','tests/test_sd_persistence'])
run('sd_filesystem_test',['tests/test_sd_persistence','tests/sd_files'])
src=root/'build/tg16_nodup_candidate_20261031/rtl'
run('rtl_compile',[iverilog,'-g2012','-s','tb_sd_slots','-o','tests/tb_sd_slots','tests/tb_sd_slots.sv',*[str(src/x) for x in ['ninja_savestate.sv','word_scan_pack_engine.sv','adpcm_pack_engine.sv','cd_ram_pack_engine.sv']]])
(root/'tests/rtl_files').mkdir(exist_ok=True)
run('rtl_capture',[vvp,'tests/tb_sd_slots','+MODE=save','+DIR=tests/rtl_files'])
run('main_integration_compile',['g++','-std=c++14','-O2','-Wall','-Wextra','-Werror','tests/test_main_integration.cpp','-o','tests/test_main_integration'])
run('main_integration',['tests/test_main_integration','tests/main_sd','tests/rtl_files','tests/rtl_files/imported.hex'])
run('rtl_cold_restore',[vvp,'tests/tb_sd_slots','+MODE=load','+DIR=tests/rtl_files'])
evidence={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in logs.glob('*.log') if p.name.startswith(('rtl_','sd_filesystem','main_integration'))}
(logs/'validation_result.json').write_text(json.dumps({'passed':True,'evidence_sha256':evidence,'hardware_tested':False},indent=2)+'\n')
print('PASS: RTL -> real files through patched Main -> fresh RTL restore, four full-size slots',flush=True)
