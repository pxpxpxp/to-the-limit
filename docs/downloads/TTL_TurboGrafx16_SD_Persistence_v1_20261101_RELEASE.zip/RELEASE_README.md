# TTL TurboGrafx16 SD Persistence v1 — 2026-11-01 release

## Release status and tested scope

This release packages the exact previously delivered RBF and companion Main
bytes, without rebuilding or changing code. On 2026-11-01 the user confirmed
“Yes” and “Works” when asked whether the paired RBF and Main worked with
Ninja Spirit for save/load, core reload, and a normal power cycle after
“Saved to SD”. These are user-reported hardware results, not an independently
observed or instrumented hardware test.

The release scope is that reported Ninja Spirit configuration. It is not a
guarantee for every HuCard, CD games, special devices, all slots/overwrites,
or abrupt power loss. The earlier simulation/build evidence and its limits
remain unchanged. Storage durability depends on the card and stack honoring
syncs. Full CDC closure and broad compatibility have not been established.

## Required paired installation and safe testing

Use BOTH included binaries:
- TurboGrafx16_SD_Persistent_20261101.rbf
- MiSTer_TG16_SD_20261101 (install as the card-root MiSTer binary and reboot)

Follow INSTALL_TEST_GUIDE.md. Back up the original root MiSTer binary, core,
and complete saves and savestates folders before installation; use a test card
and disposable progress. First tests should use a uniquely named Ninja Spirit
.pce, normal SDRAM HuCard mode and default clocks, without cheats, CD, SNAC,
MB128, SuperGrafx or special devices.

Wait for “Saved to SD” before reset, ROM/core changes, another save, or power
off. Snapshot completion alone is insufficient. If “SD save failed - retrying”
appears, do not interrupt it; the companion Main retries automatically.
Protocol 3 rejects old experimental format-2 states; keep backups and start
fresh. To roll back, restore the original Main, core, and save folders.

## Provenance and unchanged bytes

Source package: TG16_SD_Persistence_20261101_Test_Package.zip
Library ID: libfile_58ef75e95968819182ccf003dd2c1f0a
Source ZIP SHA-256:
ad8acad297d13e62a0be1e7cf752e2d3f1bbc45f9aa65bd57a7a1246ba6dd3ab

RBF SHA-256:
e9877034fd94ef4502527d342d1e9bc266e41913eb7766f1740c773aa8b6b9cb
Companion Main SHA-256:
f0c61725fa03e7f745c920e2103575203ee3ef154995ed06a1adc84d53973a16

All original package members, including sources, licenses, patch, historical
guide, build reports and evidence, are preserved byte-for-byte. Historical
statements that hardware testing had not occurred describe the build-time
status; the user-reported results above are the later update. The original
DELIVERY_SHA256.json is preserved; RELEASE_SHA256.json covers every member
except itself, including this release note and the original manifest.

The archived 159-entry build-source inventory includes three generated db/
intermediates omitted from the original package; the actual delivered files
match the original delivery manifest. No rebuild or new validation suite was
run to create this release. No separate backup/ROM-switch or loader-initialization
branch was resumed or promoted. No public/GitHub publication or deployment
is performed by packaging this release.
