// config.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <dirent.h>

#include "../../hardware.h"
#include "../../file_io.h"
#include "../../menu.h"
#include "../../user_io.h"
#include "../../input.h"
#include "../../cfg.h"
#include "../../ide.h"
#include "../../shmem.h"
#include "minimig_boot.h"
#include "minimig_fdd.h"
#include "minimig_config.h"
#include "minimig_share.h"
#include "minimig_a2065.h"
#include "akiko_cd32.h"
#include "cdtv_cd.h"
#include <unistd.h>

const char *config_memory_chip_msg[] = { "512K", "1M",   "1.5M", "2M" };
const char *config_memory_slow_msg[] = { "none", "512K", "1M",   "1.5M" };
const char *config_memory_fast_msg[][8] = { { "none", "2M", "4M", "8M", "8M",    "8M",    "8M",   "8M" } ,
											{ "none", "2M", "4M", "8M", "256M", "384M", "256M", "256M" } };
const char *config_cpu_msg[] = { "68000", "68010", "68030", "68020" };
const char *config_chipset_msg[] = { "OCS-A500", "OCS-A1000", "ECS", "---", "---", "---", "AGA", "---" };

typedef struct
{
	char            id[8];
	unsigned long   version;
	char            kickstart[1024];
	mm_filterTYPE   filter;
	unsigned char   memory;
	unsigned char   chipset;
	mm_floppyTYPE   floppy;
	unsigned char   disable_ar3;
	unsigned char   enable_ide;
	unsigned char   scanlines;
	unsigned char   audio;
	mm_hardfileTYPE hardfile[2];
	unsigned char   cpu;
	unsigned char   autofire;
} configTYPE_old;

mm_configTYPE minimig_config = { };
static unsigned char romkey[3072];

static void SendFileV2(fileTYPE* file, unsigned char* key, int keysize, int address, int size)
{
	static uint8_t buf[512];
	unsigned int keyidx = 0;
	printf("File size: %dkB\n", size >> 1);
	printf("[");
	if (keysize)
	{
		// read header
		FileReadAdv(file, buf, 0xb);
	}

	for (int i = 0; i<size; i++)
	{
		if (!(i & 31)) printf("*");
		FileReadAdv(file, buf, 512);

		if (keysize)
		{
			// decrypt ROM
			for (int j = 0; j<512; j++)
			{
				buf[j] ^= key[keyidx++];
				if ((int)keyidx >= keysize) keyidx -= keysize;
			}
		}
		EnableIO();
		unsigned int adr = address + i * 512;
		spi8(UIO_MM2_WR);
		spi8(adr & 0xff); adr = adr >> 8;
		spi8(adr & 0xff); adr = adr >> 8;
		spi8(adr & 0xff); adr = adr >> 8;
		spi8(adr & 0xff); adr = adr >> 8;
		for (int j = 0; j<512; j = j + 4)
		{
			spi8(buf[j + 0]);
			spi8(buf[j + 1]);
			spi8(buf[j + 2]);
			spi8(buf[j + 3]);
		}
		DisableIO();
	}

	printf("]\n");
}


const char* minimig_get_extrom()
{
	const size_t cap = sizeof(minimig_config.kickstart);
	size_t kicklen = strnlen(minimig_config.kickstart, cap);
	if (kicklen + 1 >= cap) return "";
	return &minimig_config.kickstart[kicklen + 1];
}

static void SendBufferV2(const uint8_t *buf, int address, int size_bytes)
{
	int sectors = size_bytes / 512;
	printf("Upload %dkB -> 0x%08x [", size_bytes >> 10, address);
	for (int i = 0; i < sectors; i++)
	{
		if (!(i & 31)) printf("*");
		EnableIO();
		unsigned int adr = address + i * 512;
		spi8(UIO_MM2_WR);
		spi8(adr & 0xff); adr >>= 8;
		spi8(adr & 0xff); adr >>= 8;
		spi8(adr & 0xff); adr >>= 8;
		spi8(adr & 0xff); adr >>= 8;
		const uint8_t *p = buf + i * 512;
		for (int j = 0; j < 512; j += 4)
		{
			spi8(p[j + 0]);
			spi8(p[j + 1]);
			spi8(p[j + 2]);
			spi8(p[j + 3]);
		}
		DisableIO();
	}
	printf("]\n");
}

static bool LoadRomSlot(const char *path, uint8_t *dst512k)
{
	fileTYPE file = {};
	if (!FileOpen(&file, path)) {
		printf("Ext-ROM open failed: %s\n", path);
		return false;
	}
	int sz = file.size;
	if (sz == 0x80000) {
		FileReadAdv(&file, dst512k, 0x80000);
	} else if (sz == 0x40000) {
		FileReadAdv(&file, dst512k, 0x40000);
		memcpy(dst512k + 0x40000, dst512k, 0x40000);
	} else {
		printf("Unsupported ROM size %d for slot upload\n", sz);
		FileClose(&file);
		return false;
	}
	FileClose(&file);
	return true;
}

static char UploadKickstartWithExtRom(const char *kick_path, const char *extrom_path)
{
	BootPrint("Loading Kickstart + Ext.ROM:");
	BootPrint(kick_path);
	BootPrint(extrom_path);

	static uint8_t img[0x100000];
	memset(img, 0, sizeof(img));

	if (!LoadRomSlot(extrom_path, img)) return 0;
	if (!LoadRomSlot(kick_path,   img + 0x80000)) return 0;

	EnableIO();
	spi8(UIO_MM2_WR);
	for (int i = 0; i < 8; i++) spi8(0);
	for (int i = 0; i < 4; i++) spi8(1);
	DisableIO();

	SendBufferV2(img,           0xe00000, 0x80000);
	SendBufferV2(img + 0x80000, 0xf80000, 0x80000);
	return 1;
}

static char UploadKickstart(char *name)
{
	fileTYPE file = {};
	int keysize = 0;

	BootPrint("Checking for Amiga Forever key file:");
	if (FileOpen(&file, user_io_make_filepath(HomeDir(), "ROM.KEY")) || FileOpen(&file, "ROM.KEY")) {
		keysize = file.size;
		if (file.size<sizeof(romkey))
		{
			FileReadAdv(&file, romkey, keysize);
			BootPrint("Loaded Amiga Forever key file");
		}
		else
		{
			BootPrint("Amiga Forever keyfile is too large!");
		}
		FileClose(&file);
	}
	BootPrint("Loading file: ");
	BootPrint(name);

	if (FileOpen(&file, name))
	{
		// discard from possible residents
		EnableIO();
		spi8(UIO_MM2_WR);
		for (int i = 0; i < 8; i++) spi8(0);
		for (int i = 0; i < 4; i++) spi8(1);
		DisableIO();

		if (file.size == 0x100000) {
			// 1MB Kickstart ROM
			BootPrint("Uploading 1MB Kickstart ...");
			SendFileV2(&file, NULL, 0, 0xe00000, file.size >> 10);
			SendFileV2(&file, NULL, 0, 0xf80000, file.size >> 10);
			FileClose(&file);
			return(1);
		}
		else if ((file.size == 8203) && keysize) {
			// Cloanto encrypted A1000 boot ROM
			BootPrint("Uploading encrypted A1000 boot ROM");
			SendFileV2(&file, romkey, keysize, 0xf80000, file.size >> 9);
			FileClose(&file);
			//clear tag (write 0 to $fc0000) to force bootrom to load Kickstart from disk
			//and not use one which was already there.
			spi_uio_cmd32_cont(UIO_MM2_WR, 0xfc0000);
			spi8(0x00);spi8(0x00);
			DisableIO();
			return(1);
		  }
		else if (file.size == 0x2000) {
			// 8KB A1000 boot ROM
			BootPrint("Uploading A1000 boot ROM");
			SendFileV2(&file, NULL, 0, 0xf80000, file.size >> 9);
			FileClose(&file);
			spi_uio_cmd32_cont(UIO_MM2_WR, 0xfc0000);
			spi8(0x00);spi8(0x00);
			DisableIO();
			return(1);
		  }
		else if (file.size == 0x80000) {
			// 512KB Kickstart ROM
			BootPrint("Uploading 512KB Kickstart ...");
			SendFileV2(&file, NULL, 0, 0xf80000, file.size >> 9);
			FileClose(&file);
			FileOpen(&file, name);
			SendFileV2(&file, NULL, 0, 0xe00000, file.size >> 9);
			FileClose(&file);
			return(1);
		}
		else if ((file.size == 0x8000b) && keysize) {
			// 512KB Kickstart ROM
			BootPrint("Uploading 512 KB Kickstart (Probably Amiga Forever encrypted...)");
			SendFileV2(&file, romkey, keysize, 0xf80000, file.size >> 9);
			FileClose(&file);
			FileOpen(&file, name);
			SendFileV2(&file, romkey, keysize, 0xe00000, file.size >> 9);
			FileClose(&file);
			return(1);
		}
		else if (file.size == 0x40000) {
			// 256KB Kickstart ROM
			BootPrint("Uploading 256 KB Kickstart...");
			SendFileV2(&file, NULL, 0, 0xf80000, file.size >> 9);
			FileClose(&file);
			FileOpen(&file, name); // TODO will this work
			SendFileV2(&file, NULL, 0, 0xfc0000, file.size >> 9);
			FileClose(&file);
			return(1);
		}
		else if ((file.size == 0x4000b) && keysize) {
			// 256KB Kickstart ROM
			BootPrint("Uploading 256 KB Kickstart (Probably Amiga Forever encrypted...");
			SendFileV2(&file, romkey, keysize, 0xf80000, file.size >> 9);
			FileClose(&file);
			FileOpen(&file, name); // TODO will this work
			SendFileV2(&file, romkey, keysize, 0xfc0000, file.size >> 9);
			FileClose(&file);
			return(1);
		}
		else {
			BootPrint("Unsupported ROM file size!");
		}
		FileClose(&file);
	}
	else {
		printf("No \"%s\" file!\n", name);
	}
	return(0);
}

static char UploadActionReplay()
{
	fileTYPE file = {};
	if (minimig_get_extcfg() & MINIMIG_EXTCFG_AR)
	{
		// the Action Replay: AR5's DeMoN v2 build, its ROM ($A80000) and RAM
		// ($AC0000) image, 512 KB at most; it takes no configuration
		if (FileOpen(&file, user_io_make_filepath(HomeDir(), "AR5.ROM")) || FileOpen(&file, "AR5.ROM"))
		{
			if (file.size > 0x80000)
			{
				printf("\nAR5.ROM is larger than 512 KB!\n");
				FileClose(&file);
				return(0);
			}
			puts("Uploading Action Replay ROM... ");
			SendFileV2(&file, NULL, 0, 0xa80000, (file.size + 511) >> 9);
			FileClose(&file);
			return(1);
		}
		puts("\nAR5.ROM not found!\n");
		return(0);
	}
	if(FileOpen(&file, user_io_make_filepath(HomeDir(), "HRTMON.ROM")) || FileOpen(&file, "HRTMON.ROM"))
	{
		int adr, data;
		puts("Uploading HRTmon ROM... ");
		SendFileV2(&file, NULL, 0, 0xa10000, (file.size + 511) >> 9);
		// HRTmon config
		adr = 0xa10000 + 20;
		spi_uio_cmd32_cont(UIO_MM2_WR, adr);
		data = 0x00800000; // mon_size, 4 bytes
		spi8((data >> 24) & 0xff); spi8((data >> 16) & 0xff);
		spi8((data >> 8) & 0xff); spi8((data >> 0) & 0xff);
		data = 0x00; // col0h, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0x5a; // col0l, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0x0f; // col1h, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // col1l, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // right, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0x00; // keyboard, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // key, 1 byte
		spi8((data >> 0) & 0xff);
		data = (minimig_config.ide_cfg & 1) ? 0xff : 0; // ide, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // a1200, 1 byte
		spi8((data >> 0) & 0xff);
		data = minimig_config.chipset&CONFIG_AGA ? 0xff : 0; // aga, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // insert, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0x0f; // delay, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // lview, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0x00; // cd32, 1 byte
		spi8((data >> 0) & 0xff);
		data = minimig_config.chipset&CONFIG_NTSC ? 1 : 0; // screenmode, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0xff; // novbr, 1 byte
		spi8((data >> 0) & 0xff);
		data = 0; // entered, 1 byte
		spi8((data >> 0) & 0xff);
		data = 1; // hexmode, 1 byte
		spi8((data >> 0) & 0xff);
		DisableIO();
		adr = 0xa10000 + 68;
		spi_uio_cmd32_cont(UIO_MM2_WR, adr);
		data = ((minimig_config.memory & 0x3) + 1) * 512 * 1024; // maxchip, 4 bytes TODO is this correct?
		spi8((data >> 24) & 0xff); spi8((data >> 16) & 0xff);
		spi8((data >> 8) & 0xff); spi8((data >> 0) & 0xff);
		DisableIO();

		FileClose(&file);
		return(1);
	}
	else {
		puts("\nhrtmon.rom not found!\n");
		return(0);
	}
	return(0);
}

static char* GetConfigurationName(int num, int chk)
{
	static char name[128];
	if (num) sprintf(name, CONFIG_DIR "/%s%d.cfg", user_io_get_core_name(), num);
	else sprintf(name, CONFIG_DIR "/%s.cfg", user_io_get_core_name());

	if (chk && !S_ISREG(getFileType(name))) return 0;
	return name+strlen(CONFIG_DIR)+1;
}

int minimig_cfg_save(int num)
{
	minimig_config.a2065_mode = a2065_cfg_get();
	return FileSaveConfig(GetConfigurationName(num, 0), &minimig_config, sizeof(minimig_config));
}

const char* minimig_get_cfg_info(int num, int label)
{
	char *filename = GetConfigurationName(num, 1);
	if (!filename) return NULL;

	static mm_configTYPE tmpconf;
	memset(&tmpconf, 0, sizeof(tmpconf));

	if (FileLoadConfig(filename, &tmpconf, sizeof(tmpconf)))
	{
		return (label && !tmpconf.kickstart[sizeof(tmpconf.kickstart)-1] && tmpconf.label[0]) ? tmpconf.label : tmpconf.info;
	}

	return "";
}

inline int hdd_open(int unit)
{
	return ide_open(unit, minimig_config.hardfile[unit].filename);
}

static int force_reload_kickstart = 0;
static void ApplyConfiguration(char reloadkickstart)
{
	if (force_reload_kickstart) reloadkickstart = 1;
	force_reload_kickstart = 0;

	minimig_ConfigCPU(minimig_config.cpu);

	if (!reloadkickstart)
	{
		minimig_ConfigChipset(&minimig_config);
		minimig_ConfigFloppy(minimig_config.floppy.drives, minimig_config.floppy.speed);
		minimig_ConfigFloppyExt(minimig_config.externalfloppy.exDrives[0], minimig_config.externalfloppy.exDrives[1], minimig_config.externalfloppy.exDrives[2], minimig_config.externalfloppy.exDrives[3]);
	}

	printf("CPU clock     : %s\n", minimig_config.chipset & 0x01 ? "turbo" : "normal");
	uint8_t memcfg = minimig_config.memory;

	printf("Chip RAM size : %s\n", config_memory_chip_msg[memcfg & 0x03]);
	printf("Slow RAM size : %s\n", config_memory_slow_msg[memcfg >> 2 & 0x03]);
	printf("Fast RAM size : %s\n", config_memory_fast_msg[((minimig_config.cpu & 0x23) != 0x23 && (minimig_config.cpu & 2)) ? 1 : 0][((memcfg >> 4) & 0x03) | ((memcfg & 0x80) >> 5)]);

	printf("Floppy drives : %u\n", minimig_floppy_requested_count(minimig_config.floppy.drives));
	printf("Floppy speed  : %s\n", minimig_config.floppy.speed ? "fast" : "normal");
	for (int drive = 0; drive < minimig_floppy_requested_count(minimig_config.floppy.drives); drive++) {
		if (minimig_config.externalfloppy.exDrives[drive]) {
	        printf("   Drive DF%u : External Drive ", drive);
			switch (minimig_config.externalfloppy.exDrives[drive]) {
				case 1: printf("0/A"); break;
				case 2: printf("1/B"); break;
				case 3: printf("2"); break;
				case 4: printf("3"); break;
			}
			printf("\n");
		}
	}

	printf("\n");

	printf("\nIDE state: %s.\n", (minimig_config.ide_cfg & 1) ? "enabled" : "disabled");
	if (minimig_config.ide_cfg & 1)
	{
		printf("Primary Master HDD is %s.\n", (minimig_config.hardfile[0].cfg == 2) ? "CD" : minimig_config.hardfile[0].cfg ? "HDD" : "disabled");
		printf("Primary Slave HDD is %s.\n", (minimig_config.hardfile[1].cfg == 2) ? "CD" : minimig_config.hardfile[1].cfg ? "HDD" : "disabled");
		printf("Secondary Master HDD is %s.\n", (minimig_config.hardfile[2].cfg == 2) ? "CD" : minimig_config.hardfile[2].cfg ? "HDD" : "disabled");
		printf("Secondary Slave HDD is %s.\n", (minimig_config.hardfile[3].cfg == 2) ? "CD" : minimig_config.hardfile[3].cfg ? "HDD" : "disabled");
	}

	uint8_t hotswap[4] = {
		minimig_config.hardfile[0].cfg == 2,
		minimig_config.hardfile[1].cfg == 2,
		minimig_config.hardfile[2].cfg == 2,
		minimig_config.hardfile[3].cfg == 2
	};
	ide_reset(hotswap);

	rstval = SPI_CPU_HLT;
	spi_uio_cmd8(UIO_MM2_RST, rstval);
	spi_uio_cmd8(UIO_MM2_HDD, (minimig_config.ide_cfg & 0x21) |
		(hdd_open(0) ? 2 : 0) |
		(hdd_open(1) ? 4 : 0) |
		(hdd_open(2) ? 8 : 0) |
		(hdd_open(3) ? 16 : 0));

	minimig_cd_drive_open(0, minimig_config.cd32_drive.cfg ? minimig_config.cd32_drive.filename : "");
	minimig_cd_drive_open(1, minimig_config.cdtv_drive.cfg ? minimig_config.cdtv_drive.filename : "");

	minimig_ConfigMemory(memcfg);
	minimig_ConfigCPU(minimig_config.cpu);

	minimig_ConfigChipset(&minimig_config);
	minimig_ConfigFloppy(minimig_config.floppy.drives, minimig_config.floppy.speed);
	minimig_ConfigFloppyExt(minimig_config.externalfloppy.exDrives[0], minimig_config.externalfloppy.exDrives[1], minimig_config.externalfloppy.exDrives[2], minimig_config.externalfloppy.exDrives[3]);

	// the cartridge's type before its image goes up, while the CPU is halted
	minimig_set_extcfg(minimig_get_extcfg() & ~1);
	if (minimig_config.memory & 0x40) UploadActionReplay();

	if (reloadkickstart)
	{
		printf("Reloading kickstart ...\n");
		rstval |= (SPI_RST_CPU | SPI_CPU_HLT);
		spi_uio_cmd8(UIO_MM2_RST, rstval);
		const char *extrom = minimig_get_extrom();
		bool uploaded = false;
		if (extrom[0])
		{
			uploaded = UploadKickstartWithExtRom(minimig_config.kickstart, extrom);
		}
		if (!uploaded && !UploadKickstart(minimig_config.kickstart))
		{
			snprintf(minimig_config.kickstart, sizeof(minimig_config.kickstart) - 1, "%s/%s", HomeDir(), "KICK.ROM");
			if (!UploadKickstart(minimig_config.kickstart))
			{
				strcpy(minimig_config.kickstart, "KICK.ROM");
				if (!UploadKickstart(minimig_config.kickstart))
				{
					BootPrintEx("No Kickstart loaded. Press F12 for settings.");
					BootPrintEx("** Halted! **");
					return;
				}
			}
		}
		rstval |= (SPI_RST_USR | SPI_RST_CPU);
		spi_uio_cmd8(UIO_MM2_RST, rstval);
	}
	else
	{
		printf("Resetting ...\n");
		rstval |= (SPI_RST_USR | SPI_RST_CPU);
		spi_uio_cmd8(UIO_MM2_RST, rstval);
	}

	rstval = 0;
	spi_uio_cmd8(UIO_MM2_RST, rstval);

	minimig_ConfigVideo(minimig_config.scanlines);
	minimig_ConfigAudio(minimig_config.audio);
	minimig_ConfigAutofire(minimig_config.autofire, 0xC);
	minimig_ConfigUserPort(minimig_config.userport);
	minimig_set_extcfg(minimig_get_extcfg() & ~1);
}



int minimig_cfg_load(int num)
{
	static const char config_id[] = "MNMGCFG0";
	int result = 0;

	const char* filename = GetConfigurationName(num, 1);

	// load configuration data
	int size;
	if (filename && (size = FileLoadConfig(filename, 0, 0)) > 0)
	{
		BootPrint("Opened configuration file\n");
		printf("Configuration file size: %s, %d\n", filename, size);
		if (size == sizeof(configTYPE_old))
		{
			static configTYPE_old tmpconf;
			printf("Old Configuration file.\n");
			if (FileLoadConfig(filename, &tmpconf, sizeof(tmpconf)))
			{
				// check file id and version
				if (strncmp(tmpconf.id, config_id, sizeof(minimig_config.id)) == 0) {
					// A few more sanity checks...
					if (tmpconf.floppy.drives <= 4) {
						memset((void*)&minimig_config, 0, sizeof(minimig_config));
						memcpy((void*)&minimig_config, (void*)&tmpconf, sizeof(tmpconf));
						minimig_config.cpu = tmpconf.cpu;
						minimig_config.autofire = tmpconf.autofire;
						memset(&minimig_config.hardfile[2], 0, sizeof(minimig_config.hardfile[2]));
						memset(&minimig_config.hardfile[3], 0, sizeof(minimig_config.hardfile[3]));
						result = 1; // We successfully loaded the config.
					}
					else BootPrint("Config file sanity check failed!\n");
				}
				else BootPrint("Wrong configuration file format!\n");
			}
			else printf("Cannot load configuration file\n");
		}
		else if ((size_t)size <= sizeof(minimig_config))
		{
			static mm_configTYPE tmpconf = {};
			memset((void*)&tmpconf, 0, sizeof(tmpconf));
			if (FileLoadConfig(filename, &tmpconf, sizeof(tmpconf)))
			{
				// check file id and version
				if (strncmp(tmpconf.id, config_id, sizeof(minimig_config.id)) == 0) {
					// A few more sanity checks...
					if (tmpconf.floppy.drives <= 4) {
						memcpy((void*)&minimig_config, (void*)&tmpconf, sizeof(minimig_config));
						result = 1; // We successfully loaded the config.
					}
					else BootPrint("Config file sanity check failed!\n");
				}
				else BootPrint("Wrong configuration file format!\n");
			}
			else printf("Cannot load configuration file\n");
		}
		else printf("Wrong configuration file size: %d (expected: %u)\n", size, sizeof(minimig_config));
	}

	if (result && (minimig_config.cpu & 0xe3) != 0x42 && (minimig_config.cpu & 0xe3) != 0x82 && (minimig_config.cpu & 0xe3) != 0x62 && (minimig_config.cpu & 0xe3) != 0xa2)
		minimig_config.cpu &= ~0xc0;

	if (result && (minimig_config.memory & 0xa0) == 0xa0)
		minimig_config.memory &= ~0x30;

	if (!result) {
		BootPrint("Can not open configuration file!\n");
		BootPrint("Setting config defaults\n");
		// set default configuration
		memset((void*)&minimig_config, 0, sizeof(minimig_config));
		memcpy(minimig_config.id, config_id, sizeof(minimig_config.id));
		snprintf(minimig_config.kickstart, sizeof(minimig_config.kickstart) - 1, "%s/%s", HomeDir(), "KICK.ROM");
		minimig_config.memory = 0x11;
		minimig_config.cpu = 0;
		minimig_config.chipset = 0;
		minimig_config.floppy.speed = CONFIG_FLOPPY2X;
		minimig_config.floppy.drives = 1;
		minimig_config.ide_cfg = 0;
		minimig_config.hardfile[0].cfg = 1;
		minimig_config.hardfile[0].filename[0] = 0;
		minimig_config.hardfile[1].cfg = 1;
		minimig_config.hardfile[1].filename[0] = 0;
		minimig_config.hardfile[2].cfg = 0;
		minimig_config.hardfile[2].filename[0] = 0;
		minimig_config.hardfile[3].cfg = 0;
		minimig_config.hardfile[3].filename[0] = 0;
		minimig_config.cd32_drive.cfg = 0;
		minimig_config.cd32_drive.filename[0] = 0;
		minimig_config.cdtv_drive.cfg = 0;
		minimig_config.cdtv_drive.filename[0] = 0;
		minimig_config.externalfloppy.exDrives[0] = 0;
		minimig_config.externalfloppy.exDrives[1] = 0;
		minimig_config.externalfloppy.exDrives[2] = 0;
		minimig_config.externalfloppy.exDrives[3] = 0;
		minimig_config.userport = mm_userportMode::mmup_mp32pi;  // default as before

		BootPrintEx(">>> No config found. Using defaults. <<<");
	}

	RefreshFloppyPopulation();
	if (minimig_config.floppy.drives == 4 && !floppy_zero_supported)
	{
		BootPrintEx("Zero floppy drives unsupported by this core; using DF0.");
		minimig_config.floppy.drives = 0;
	}

	a2065_cfg_set(minimig_config.a2065_mode);

	for (int i = 0; i < 4; i++)
	{
		df[i].status = 0;
		FileClose(&df[i].file);
	}

	// print config to boot screen
	char cfg_str[256];
	sprintf(cfg_str, "CPU: %s, Chipset: %s, ChipRAM: %s, FastRAM: %s, SlowRAM: %s",
		config_cpu_msg[minimig_config.cpu & 0x03], config_chipset_msg[(minimig_config.chipset >> 2) & 7],
		config_memory_chip_msg[(minimig_config.memory >> 0) & 0x03], config_memory_fast_msg[((minimig_config.cpu & 0x23) != 0x23 && (minimig_config.cpu & 2)) ? 1 : 0][((minimig_config.memory >> 4) & 0x03) | ((minimig_config.memory & 0x80) >> 5)], config_memory_slow_msg[(minimig_config.memory >> 2) & 0x03]
	);
	BootPrintEx(cfg_str);

	input_poll(0);
	if (is_key_pressed(59))
	{
		BootPrintEx("Forcing NTSC video ...");
		//force NTSC mode if F1 pressed
		minimig_config.chipset |= CONFIG_NTSC;
	}
	else if (is_key_pressed(60))
	{
		BootPrintEx("Forcing PAL video ...");
		// force PAL mode if F2 pressed
		minimig_config.chipset &= ~CONFIG_NTSC;
	}

	ApplyConfiguration(1);
	return(result);
}



void minimig_reset()
{
	ApplyConfiguration(0);
	user_io_rtc_reset();
	minimig_share_reset();
	a2065_start();
	akiko_cd32_init();
	cdtv_cd_init();
}

void minimig_set_kickstart(const char *name)
{
	uint len = strlen(name);
	if (len > (sizeof(minimig_config.kickstart) - 1)) len = sizeof(minimig_config.kickstart) - 1;
	memcpy(minimig_config.kickstart, name, len);
	memset(minimig_config.kickstart + len, 0, sizeof(minimig_config.kickstart) - len);
	force_reload_kickstart = 1;
}

void minimig_set_extrom(const char *name)
{
	int cap = sizeof(minimig_config.kickstart);
	int kicklen = strnlen(minimig_config.kickstart, cap) + 1;
	if (kicklen + 1 >= cap) return; // at least one additional byte for extrom is required (for NULL termination)
	int room = cap - kicklen;
	int nlen = strlen(name);
	if (nlen > room) nlen = room;
	memcpy(minimig_config.kickstart + kicklen, name, nlen);
	room = cap - kicklen - nlen;
	if(room > 0) memset(minimig_config.kickstart + kicklen + nlen, 0, room);
	minimig_config.kickstart[cap - 1] = 0; // make sure NULL is at the end
	force_reload_kickstart = 1;
}

static char minimig_adjust = 0;

typedef struct
{
	uint32_t mode;
	uint32_t hpos;
	uint32_t vpos;
	uint32_t reserved;
} vmode_adjust_t;

vmode_adjust_t vmodes_adj[64] = {};

static const char* get_shared_vadjust_path()
{
	static char path[1024] = {};
	if (!strlen(path))
	{
		if (strlen(cfg.shared_folder))
		{
			if (cfg.shared_folder[0] == '/')
			{
				snprintf(path, sizeof(path), "%s/%s_vadjust.dat", cfg.shared_folder, user_io_get_core_name());
			}
			else
			{
				snprintf(path, sizeof(path), "%s/%s/%s_vadjust.dat", HomeDir(), cfg.shared_folder, user_io_get_core_name());
			}
		}
		else
		{
			snprintf(path, sizeof(path), "%s/shared/%s_vadjust.dat", HomeDir(), user_io_get_core_name());
		}
	}
	return path;
}

void minimig_adjust_vsize(char force)
{
	static uint16_t nres = 0;
	spi_uio_cmd_cont(UIO_GET_VMODE);
	uint16_t res = spi_w(0);
	if ((res & 0x8000) && (nres != res || force))
	{
		nres = res;
		uint16_t scr_hsize = spi_w(0);
		uint16_t scr_vsize = spi_w(0);
		DisableIO();

		printf("\033[1;37mVMODE: resolution: %u x %u, mode: %u\033[0m\n", scr_hsize, scr_vsize, res & 255);

		static int loaded = 0;
		if (!loaded && FileExists(get_shared_vadjust_path(), 0))
		{
			FileLoad(get_shared_vadjust_path(), vmodes_adj, sizeof(vmodes_adj));
		}
		else if (!loaded)
		{
			static char name[256];
			snprintf(name, sizeof(name), "%s_vadjust.dat", user_io_get_core_name());
			FileLoadConfig(name, vmodes_adj, sizeof(vmodes_adj));
			loaded = 1;
		}

		uint32_t mode = scr_hsize | (scr_vsize << 12) | ((res & 0xFF) << 24);
		if (mode)
		{
			for (uint i = 0; i < sizeof(vmodes_adj) / sizeof(vmodes_adj[0]); i++)
			{
				if (vmodes_adj[i].mode == mode)
				{
					spi_uio_cmd_cont(UIO_SET_VPOS);
					spi_w(vmodes_adj[i].hpos >> 16);
					spi_w(vmodes_adj[i].hpos);
					spi_w(vmodes_adj[i].vpos >> 16);
					spi_w(vmodes_adj[i].vpos);
					printf("\033[1;37mVMODE: set positions: [%u-%u, %u-%u]\033[0m\n", vmodes_adj[i].hpos >> 16, (uint16_t)vmodes_adj[i].hpos, vmodes_adj[i].vpos >> 16, (uint16_t)vmodes_adj[i].vpos);
					DisableIO();
					return;
				}
			}
			printf("\033[1;37mVMODE: preset not found.\033[0m\n");
			spi_uio_cmd_cont(UIO_SET_VPOS); spi_w(0); spi_w(0); spi_w(0); spi_w(0);
			DisableIO();
		}
	}
	else
	{
		DisableIO();
	}
}

static void store_vsize()
{
	Info("Stored");
	minimig_adjust = 0;

	spi_uio_cmd_cont(UIO_GET_VMODE);
	uint16_t res = spi_w(0);
	uint16_t scr_hsize = spi_w(0);
	uint16_t scr_vsize = spi_w(0);
	uint16_t scr_hbl_l = spi_w(0);
	uint16_t scr_hbl_r = spi_w(0);
	uint16_t scr_vbl_t = spi_w(0);
	uint16_t scr_vbl_b = spi_w(0);
	DisableIO();

	printf("\033[1;37mVMODE: store position: [%u-%u, %u-%u]\033[0m\n", scr_hbl_l, scr_hbl_r, scr_vbl_t, scr_vbl_b);

	uint32_t mode = scr_hsize | (scr_vsize << 12) | ((res & 0xFF) << 24);
	if (mode)
	{
		int applied = 0;
		int empty = -1;
		for (int i = 0; (uint)i < sizeof(vmodes_adj) / sizeof(vmodes_adj[0]); i++)
		{
			if (vmodes_adj[i].mode == mode)
			{
				vmodes_adj[i].hpos = (scr_hbl_l << 16) | scr_hbl_r;
				vmodes_adj[i].vpos = (scr_vbl_t << 16) | scr_vbl_b;
				applied = 1;
			}
			if (empty < 0 && !vmodes_adj[i].mode) empty = i;
		}

		if (!applied && empty >= 0)
		{
			vmodes_adj[empty].mode = mode;
			vmodes_adj[empty].hpos = (scr_hbl_l << 16) | scr_hbl_r;
			vmodes_adj[empty].vpos = (scr_vbl_t << 16) | scr_vbl_b;
			applied = 1;
		}

		if (applied)
		{
			static char name[256];
			snprintf(name, sizeof(name), "%s_vadjust.dat", user_io_get_core_name());
			FileSaveConfig(name, vmodes_adj, sizeof(vmodes_adj));
		}
	}
}

// 0 - disable
// 1 - enable
// 2 - cancel
void minimig_set_adjust(char n)
{
	if (minimig_adjust && !n) store_vsize();
	minimig_adjust = (n == 1) ? 1 : 0;
	if (n == 2) minimig_adjust_vsize(1);
}

char minimig_get_adjust()
{
	return minimig_adjust;
}

void minimig_ConfigVideo(unsigned char scanlines)
{
	spi_uio_cmd16(UIO_MM2_VID, (((scanlines >> 6) & 0x03) << 10) | (((scanlines >> 4) & 0x03) << 8) | (scanlines & 0x07));
}

void minimig_ConfigAudio(unsigned char audio)
{
	spi_uio_cmd8(UIO_MM2_AUD, audio);
}

void minimig_ConfigMemory(unsigned char memory)
{
	spi_uio_cmd8(UIO_MM2_MEM, memory);
}

void minimig_ConfigCPU(unsigned char cpu)
{
	spi_uio_cmd8(UIO_MM2_CPU, cpu);
}

void minimig_ConfigChipset(mm_configTYPE *config)
{
	unsigned char chipset = config->cdtv_drive.cfg ? (config->chipset | CONFIG_CDTV) : (config->chipset & ~CONFIG_CDTV);
	spi_uio_cmd8(UIO_MM2_CHIP, chipset & 0x3f);
}

void minimig_ConfigFloppy(unsigned char drives, unsigned char speed)
{
	if (drives == 4 && !floppy_zero_supported)
	{
		printf("Zero floppy drives unsupported by this core; using DF0.\n");
		drives = 0;
	}
	spi_uio_cmd8(UIO_MM2_FLP, ((drives & 7) << 2) | (speed & 3));
}

void minimig_ConfigFloppyExt(unsigned char drive0, unsigned char drive1, unsigned char drive2, unsigned char drive3)
{
	printf("Floppy Ext 01: %x\n", drive0 | (drive1 << 3));
	printf("Floppy Ext 23: %x\n", drive2 | (drive3 << 3));
	spi_uio_cmd8(UIO_MM2_FLPEX01, drive0 | (drive1 << 3));
	spi_uio_cmd8(UIO_MM2_FLPEX23, drive2 | (drive3 << 3));
}

void minimig_ConfigUserPort(mm_userportMode mode) {
	printf("User Port: %s\n", mode == mm_userportMode::mmup_mp32pi ? "MT32pi":"MiSTer Floppy");
	spi_uio_cmd8(UIO_MM2_USRPORT, mode == mm_userportMode::mmup_mp32pi ? 0 : 1);
}

void minimig_ConfigAutofire(unsigned char autofire, unsigned char mask)
{
	uint16_t param = mask;
	param = (param << 8) | autofire;
	spi_uio_cmd16(UIO_MM2_JOY, param);
}

void minimig_set_extcfg(unsigned int ext_cfg)
{
	minimig_config.ext_cfg = (unsigned short)ext_cfg;
	minimig_config.ext_cfg2 = (unsigned short)(ext_cfg >> 16);

	spi_uio_cmd_cont(UIO_SET_STATUS2);
	spi32_w(0);
	spi32_w(minimig_core_extcfg());
	DisableIO();
}

unsigned int minimig_get_extcfg()
{
	return (minimig_config.ext_cfg2 << 16) | minimig_config.ext_cfg;
}

#define DSND_ADDR 0x27800000
#define DSND_SLOT 0x40000

static int dsnd_ok = 0;

int minimig_dsnd_loaded()
{
	return dsnd_ok;
}

unsigned int minimig_core_extcfg()
{
	return dsnd_ok ? minimig_get_extcfg() : (minimig_get_extcfg() & ~0x180000);
}

void minimig_dsnd_load()
{
	fileTYPE f = {};
	dsnd_ok = 0;
	if (!FileOpen(&f, user_io_make_filepath(HomeDir(), "drivesounds.bin"), 1)) return;

	uint32_t size = (uint32_t)f.size;
	uint8_t *b = (size > 16 && size <= 16 * DSND_SLOT + 0x1000) ? (uint8_t*)malloc(size) : NULL;
	uint16_t *mem = b ? (uint16_t*)shmem_map(DSND_ADDR, 16 * DSND_SLOT) : NULL;
	if (mem && FileReadAdv(&f, b, size) == (int)size && !memcmp(b, "DRIVESND", 8))
	{
		for (int n = 0; n < 16; n++) mem[n * (DSND_SLOT / 2)] = 0x8000;
		for (uint32_t o = 8; o + 8 <= size;)
		{
			uint32_t n = (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3];
			uint32_t len = (b[o + 4] << 24) | (b[o + 5] << 16) | (b[o + 6] << 8) | b[o + 7];
			o += 8;
			if (!len) break;
			if (n < 16)
			{
				uint32_t k = len / 2;
				if (k > (size - o) / 2) k = (size - o) / 2;
				if (k > DSND_SLOT / 2 - 1) k = DSND_SLOT / 2 - 1;
				uint16_t *d = mem + n * (DSND_SLOT / 2);
				for (uint32_t i = 0; i < k; i++)
				{
					uint16_t x = (b[o + 2 * i] << 8) | b[o + 2 * i + 1];
					d[i] = (x == 0x8000) ? 0x8001 : x;
				}
				d[k] = 0x8000;
			}
			if (len > size - o) break;
			o += len;
		}
		dsnd_ok = 1;
	}
	if (mem) shmem_unmap(mem, 16 * DSND_SLOT);
	free(b);
	FileClose(&f);
	printf("Drive sounds: %s\n", dsnd_ok ? "loaded" : "bad file");
}

#define CD32_MAIN_ROM  "CD32.rom"
#define CD32_EXT_ROM   "CD32_ext.rom"
#define CDTV_MAIN_ROM  "CDTV.rom"
#define CDTV_EXT_ROM   "CDTV_ext.rom"
#define A500_MAIN_ROM  "a500.rom"
#define A600_MAIN_ROM  "a600.rom"
#define A1200_MAIN_ROM "a1200.rom"

static const char *preset_rom_path(const char *name)
{
	static char path[1024];
	snprintf(path, sizeof(path), "%s/%s", HomeDir(), name);
	return path;
}

void minimig_cfg_set(int preset)
{
	switch (preset)
	{
	case CONFIG_PRESET_CD32:
		minimig_config.cpu = 0x23; // 68020 14MHz, d-cache off;
		minimig_config.chipset = (6 << 2); // AGA
		minimig_config.memory = 3; // ChipRAM 2MB, FastRAM 0MB
		minimig_set_kickstart(preset_rom_path(CD32_MAIN_ROM));
		if(getFileSize(minimig_config.kickstart) < 1024 * 1024) minimig_set_extrom(preset_rom_path(CD32_EXT_ROM));
		minimig_config.autofire = 2 << 1; // CD32 joystick
		minimig_config.cd32_drive.cfg = 1;
		minimig_config.cdtv_drive.cfg = 0;
		minimig_config.ide_cfg = 0;
		if (floppy_zero_supported) minimig_config.floppy.drives = 4;
		break;

	case CONFIG_PRESET_CDTV:
		minimig_config.cpu = 0; // 68000
		minimig_config.chipset = (2 << 2); // ECS
		minimig_config.memory = 1; // ChipRAM 1MB, FastRAM 0MB
		minimig_set_kickstart(preset_rom_path(CDTV_MAIN_ROM));
		if (getFileSize(minimig_config.kickstart) < 1024 * 1024) minimig_set_extrom(preset_rom_path(CDTV_EXT_ROM));
		minimig_config.autofire = 0; // Digital joystick
		minimig_config.cd32_drive.cfg = 0;
		minimig_config.cdtv_drive.cfg = 1;
		minimig_config.ide_cfg = 0;
		if (minimig_config.floppy.drives == 4) minimig_config.floppy.drives = 0;
		break;

	case CONFIG_PRESET_A500:
		minimig_config.cpu = 0; // 68000
		minimig_config.chipset = (0 << 2); // OCS
		minimig_config.memory = 0; // ChipRAM 512KB, FastRAM 0MB
		minimig_set_kickstart(preset_rom_path(A500_MAIN_ROM));
		minimig_config.autofire = 0; // Digital joystick
		minimig_config.cd32_drive.cfg = 0;
		minimig_config.cdtv_drive.cfg = 0;
		minimig_config.ide_cfg = 0;
		if (minimig_config.floppy.drives == 4) minimig_config.floppy.drives = 0;
		break;

	case CONFIG_PRESET_A600:
		minimig_config.cpu = 0; // 68000
		minimig_config.chipset = (2 << 2); // ECS
		minimig_config.memory = 1; // ChipRAM 1MB, FastRAM 0MB
		minimig_set_kickstart(preset_rom_path(A600_MAIN_ROM));
		minimig_config.autofire = 0; // Digital joystick
		minimig_config.cd32_drive.cfg = 0;
		minimig_config.cdtv_drive.cfg = 0;
		minimig_config.ide_cfg = 0;
		if (minimig_config.floppy.drives == 4) minimig_config.floppy.drives = 0;
		break;

	case CONFIG_PRESET_A1200:
		minimig_config.cpu = 0x23; // 68020 14MHz, d-cache off;
		minimig_config.chipset = (6 << 2); // AGA
		minimig_config.memory = 3; // ChipRAM 2MB, FastRAM 0MB
		minimig_set_kickstart(preset_rom_path(A1200_MAIN_ROM));
		minimig_config.autofire = 0; // Digital joystick
		minimig_config.cd32_drive.cfg = 0;
		minimig_config.cdtv_drive.cfg = 0;
		minimig_config.ide_cfg = 0;
		if (minimig_config.floppy.drives == 4) minimig_config.floppy.drives = 0;
		break;
	}
}

bool minimig_cfg_available(int preset)
{
	switch (preset)
	{
	case CONFIG_PRESET_CD32:
		if (is_minimig() == 2)
		{
			uint64_t sz = getFileSize(preset_rom_path(CD32_MAIN_ROM));
			return (sz >= 1024 * 1024) || ((sz >= 512 * 1024) && getFileSize(preset_rom_path(CD32_EXT_ROM)) >= 512 * 1024);
		}
		break;

	case CONFIG_PRESET_CDTV:
		if (is_minimig() == 2)
		{
			uint64_t sz = getFileSize(preset_rom_path(CDTV_MAIN_ROM));
			return (sz >= 1024 * 1024) || ((sz >= 256 * 1024) && getFileSize(preset_rom_path(CDTV_EXT_ROM)) >= 256 * 1024);
		}
		break;

	case CONFIG_PRESET_A500:
		return getFileSize(preset_rom_path(A500_MAIN_ROM)) >= 256 * 1024;

	case CONFIG_PRESET_A600:
		return getFileSize(preset_rom_path(A600_MAIN_ROM)) >= 512 * 1024;

	case CONFIG_PRESET_A1200:
		return getFileSize(preset_rom_path(A1200_MAIN_ROM)) >= 512 * 1024;
	}

	return 0;
}

static drive_t cd32_drive = {};
static drive_t cdtv_drive = {};

int minimig_cd_drive_open(int slot, const char *filename)
{
	static fileTYPE cd_drive_file[2] = {};

	drive_t *drv = slot ? &cdtv_drive : &cd32_drive;
	drv->cd = 1;

	const char *res = cd_drive_parse(drv, slot, filename);

	int present = res ? ide_img_mount(&cd_drive_file[slot], res, 0) : 0;
	drv->f = present ? &cd_drive_file[slot] : NULL;

	const char *full = present ? res : "";
	if (slot) cdtv_cd_set_cd_path(full);
	else akiko_cd32_set_cd_path(full);

	return present;
}

drive_t* minimig_cd_drive_get(int slot)
{
	drive_t *drive = slot ? &cdtv_drive : &cd32_drive;
	if (drive->cd && (drive->chd_f || drive->f)) return drive;
	return NULL;
}
