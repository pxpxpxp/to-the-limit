// TG16 SD snapshot publication, GPL-3.0-or-later.
// Companion to TGLSS format 3. No new FPGA opcode or privileged service.
#ifndef TG16_SD_PERSISTENCE_H
#define TG16_SD_PERSISTENCE_H
#include <stdint.h>
#include <stddef.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>

namespace tg16_sd {
static const uint64_t magic = UINT64_C(0x54474c5353000003);
static const uint64_t schema = UINT64_C(0x7b4a4831e0d369a8);
static const size_t image_bytes = 416640;
static const uint32_t payload_words = 52075;
inline uint32_t le32(const unsigned char *p) {
 return uint32_t(p[0]) | (uint32_t(p[1])<<8) | (uint32_t(p[2])<<16) | (uint32_t(p[3])<<24);
}
inline uint64_t le64(const unsigned char *p) { return le32(p) | (uint64_t(le32(p+4))<<32); }
inline uint32_t crc32(const unsigned char *p, size_t n) {
 uint32_t c=0xffffffff;
 while(n--) { c^=*p++; for(int b=0;b<8;++b) c=(c>>1)^((0u-(c&1))&0xedb88320); }
 return ~c;
}
inline bool valid_image(const std::vector<unsigned char>& b) {
 return b.size()==image_bytes && le32(b.data()+4)==(image_bytes-8)/4 &&
  le64(b.data()+8)==magic && le64(b.data()+16)==schema &&
  le32(b.data()+36)==payload_words && le32(b.data()+32)==crc32(b.data()+40,b.size()-40);
}

// All reads from the FPGA mapping are volatile; this runs only on little-endian
// MiSTer ARM. A header length of zero means the producer is changing the slot.
// The producer orders invalidate -> payload -> CRC -> header commit.
inline bool copy_committed(volatile const uint32_t *src, size_t capacity,
                           uint32_t seen, std::vector<unsigned char>& out) {
 out.clear();
 if(capacity<image_bytes) return false;
 const uint32_t generation=src[0], length=src[1];
 if(generation==seen || length!=(image_bytes-8)/4) return false;
 __sync_synchronize();
 out.resize(image_bytes);
 for(size_t i=0;i<image_bytes/4;++i) {
  uint32_t v=src[i];
  for(int j=0;j<4;++j) out[i*4+j]=(unsigned char)(v>>(j*8));
 }
 __sync_synchronize();
 if(src[0]!=generation || src[1]!=length || le32(out.data())!=generation || !valid_image(out)) {
  out.clear(); return false;
 }
 return true;
}

// Injectable POSIX calls keep failure tests on the production code path.
struct Ops {
 ssize_t (*write_file)(int,const void*,size_t);
 int (*sync_file)(int);
 int (*rename_file)(const char*,const char*);
};
inline const Ops& posix_ops() {
 static const Ops ops={::write,::fsync,::rename}; return ops;
}
inline bool store(const char *path, const std::vector<unsigned char>& image,
                  const Ops& ops=posix_ops()) {
 if(!valid_image(image)) { errno=EINVAL; return false; }
 std::string target(path), parent=".";
 const size_t slash=target.find_last_of('/');
 if(slash!=std::string::npos) parent=slash==0?"/":target.substr(0,slash);
 // Hold the directory FD through the rename and directory sync.
 int dirfd=open(parent.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC);
 if(dirfd<0) return false;
 std::string pattern=target+".tmp.XXXXXX";
 std::vector<char> tmp(pattern.begin(),pattern.end()); tmp.push_back(0);
 int fd=mkstemp(tmp.data());
 if(fd<0) { int e=errno; close(dirfd); errno=e; return false; }
 bool ok=true; size_t offset=0;
 while(offset<image.size()) {
  ssize_t n=ops.write_file(fd,image.data()+offset,image.size()-offset);
  if(n<0 && errno==EINTR) continue;
  if(n<=0 || size_t(n)>image.size()-offset) { if(!n) errno=EIO; ok=false; break; }
  offset+=size_t(n);
 }
 if(ok && ops.sync_file(fd)) ok=false;
 int e=errno;
 if(close(fd) && ok) { ok=false; e=errno; }
 if(ok && ops.rename_file(tmp.data(),path)) { ok=false; e=errno; }
 if(ok && ops.sync_file(dirfd)) { ok=false; e=errno; }
 // Before rename a failure leaves the old file intact. After rename a failed
 // directory sync remains unacknowledged and is retried on the next poll.
 if(!ok) unlink(tmp.data());
 if(close(dirfd) && ok) { ok=false; e=errno; }
 errno=e; return ok;
}
}
#endif
