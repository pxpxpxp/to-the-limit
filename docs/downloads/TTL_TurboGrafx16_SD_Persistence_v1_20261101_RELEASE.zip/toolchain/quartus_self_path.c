#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

/* This host exposes /proc with different PID numbering from getpid().
 * Quartus asks for its OWN executable using /proc/<getpid()>/exe. Resolve
 * precisely that one self-reference through the normal /proc/self/exe alias.
 * All other readlink calls remain unchanged. No tool binary is modified.
 */
ssize_t readlink(const char *path, char *buffer, size_t capacity)
{
    ssize_t (*original)(const char *, char *, size_t);
    original = (ssize_t (*)(const char *, char *, size_t))dlsym(RTLD_NEXT, "readlink");
    char own_path[80];
    snprintf(own_path, sizeof(own_path), "/proc/%ld/exe", (long)getpid());
    if (strcmp(path, own_path) == 0) path = "/proc/self/exe";
    return original(path, buffer, capacity);
}
