# TG16 SD persistence v1 — build and validation

New protocol-3 RBF and matching patched MiSTer Main. Experimental HuCard
hardware test build; no real MiSTer, SD-card power cut or game was tested here.
Use both binaries and follow INSTALL_TEST_GUIDE.md.

## Compiler results

| Stage | Errors | Warnings |
|---|---:|---:|
| quartus_map | 0 | 100 |
| quartus_fit_seed7 | 0 | 10 |
| quartus_sta_seed7 | 0 | 1 |
| quartus_asm | 0 | 0 |

Quartus Prime Lite 23.1std Build 991, Cyclone V 5CSEBA6U23I7.
Standard fitter seed 7; physical register retiming disabled.
All 172 reported multicorner timing rows have nonnegative
slack and zero TNS. Minimum reported slack: +0.027 ns.
The inherited constraints and incomplete I/O/MTBF coverage remain limitations;
this is not full CDC closure or a hardware correctness proof.

RBF: 4,367,032 bytes,
SHA-256 `e9877034fd94ef4502527d342d1e9bc266e41913eb7766f1740c773aa8b6b9cb`.
Companion ARM Main: 1,349,764 bytes,
SHA-256 `f0c61725fa03e7f745c920e2103575203ee3ef154995ed06a1adc84d53973a16`.
Upstream Main commit: `afb917fce1f3089e3d242331ddae6456ac0da8e4`.
The Main binary was compiled and linked; it was not run on ARM or deployed.

## Persistence validation

Four complete 416,640-byte images were captured by production controller RTL.
The exact patched Main handler wrote them to real filesystem files, retried
a deliberate failed write without another save, and imported them again.
A fresh RTL process restored every modeled register/core-RAM/ADPCM/CD-RAM
value exactly for every slot. Machine memories, DDR and peripherals are models;
this is not an actual Ninja Spirit execution or physical board/SD test.

Additional production-path tests covered invalidate-before-write and commit-last,
reset during capture, CRC/header refusal, short writes/EINTR, ENOSPC, file sync,
rename and directory-sync failure, prior-file preservation before rename, retry,
and retaining the stock host handler for older formats. See the included logs.

## Build environment

The first map failed in debug-fabric generation because the environment exposes
different PID numbering to `/proc` and `getpid()`. The successful build used the
included self-path adapter, scoped to compiler processes. It redirects only a
compiler's own numbered executable reference to `/proc/self/exe`. Vendor
binaries, licensing and FPGA source are not modified by the adapter. Initial
failure logs are retained separately. No stopped review was retried.

The separate system-signing-key replacement was rejected by automatic approval
review and was not performed. Simulators were instead verified with a private
keyring and extracted locally, without changing system trust.

## Scope

Relative to the delivered FPGA baseline, synthesis changes are only
`TurboGrafx16.sv`, `rtl/ninja_savestate.sv` and `build_id.v`. Snapshot payload
layout and timing constraints are unchanged. Format 3 intentionally rejects
old format-2 files. This does not complete the separate ROM/backup-switch work
or enable CD/SuperGrafx/special-device save states. Wait for Saved to SD before
resetting, changing ROM/core, or powering off. SD hardware must honor syncs.
