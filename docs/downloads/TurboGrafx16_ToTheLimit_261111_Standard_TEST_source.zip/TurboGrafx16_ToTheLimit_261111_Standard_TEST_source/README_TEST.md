# TurboGrafx16 To the Limit Standard TEST: matching source

This is the experimental matching-source archive for **TurboGrafx16_ToTheLimit_261111_Standard_TEST.rbf**. It is not a final qualified release, an official MiSTer release, or a completed distribution-validation package.

- Matching RBF SHA-256: `7fba6e8920f3f2424da8dd2e7bc073da1329ffeffa3f1dd2b745a7a1a86db869`
- Matching RBF size: 4,494,748 bytes. The RBF is delivered separately and is not inside this source ZIP.
- Build: Standard; fitter seed 35; build date code 261111 (11 November 2026); Quartus Prime Lite 23.1std.0 Build 991; Cyclone V device 5CSEBA6U23I7.
- Frozen source manifest SHA-256: `1a25c89daa148f301963ee2f4697559444b18a68493abd1662ae702506a54ccb`

The `source/` directory preserves all 203 frozen source files, including project files and test code, and their original relative structure. `SOURCE_MANIFEST.json` hashes those files relative to `source/`. The original four license texts and substantive author attributions are retained in `COPYING`, `CREDITS.md` and `LICENSES/`. File-specific copyright and license notices remain unchanged.

`PACKAGE_MANIFEST.json` hashes every other member in this source archive. `TEST_BUILD.json` records public build and matching-binary provenance. Read `BUILD_TEST.md` and `LIMITATIONS_TEST.md` before rebuilding or testing.

After reloading the core, select the ROM again through **Load TurboGrafx** before using save states. Retained memory may show the previous game, but a fresh ROM load is required. This is a usage note for the existing TEST binary, not a new fix.

Limited user feedback is not broad hardware or game qualification. Final distribution validation remains unfinished, and this archive makes no nine-group timing or distribution pass claim. It matches the named TEST binary, not subsequent menu, reload or autoload changes. Back up important saves and retain your original core.
