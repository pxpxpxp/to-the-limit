# Rebuilding these exact TEST sources

The main project and revision are named TurboGrafx16. Use Intel Quartus Prime Lite 23.1std.0 Build 991 with Cyclone V support, device 5CSEBA6U23I7 and fitter seed 35. The preserved build date code is 261111 (11 November 2026). Install the toolchain separately; none is bundled.

Extract the full archive and copy the pristine source directory to a new writable build directory. Keep its complete relative structure. With Quartus's bin directory on PATH, run these direct module commands from that new source copy, in order:

    quartus_map --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
    quartus_fit --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
    quartus_asm --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16

Stop on any failed command or changed input. Check all 203 source files against SOURCE_MANIFEST.json before and after each stage. Output is output_files/TurboGrafx16.rbf in your build copy. Do not build in the pristine source directory.

Do not use GUI full compile or quartus_sh --flow compile to reproduce the frozen inputs: the retained pre-flow hook can rewrite build_id.v to today's date and generate JTAG metadata. Direct module commands preserve the intended settings. Keep the frozen project files unchanged.

A restricted static check verified 122 local synthesis, include and initialization references by walking 15 QSF, QIP and Tcl files belonging to the main project. Optional .cmp component metadata and generated jtag.cdf are not synthesis inputs. This is not compiler elaboration or a regression-suite pass. The Quartus 13 project and historical descriptors are not qualified alternative builds.

Successful mapping, fitting and assembly do not establish timing acceptance. Byte-identical output is not promised across environments. Any changed source, toolchain, settings or rebuilt RBF needs fresh source-bound timing and constraint review and suitable hardware testing. Do not transfer this TEST binary's identity or observations to another build. The included test fixtures do not constitute a complete runnable regression suite.
