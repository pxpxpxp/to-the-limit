# Credits and architectural references

This is an independent To the Limit experimental derivative, not an official MiSTer release or an endorsement by the people credited below. Existing copyright and license notices are preserved. No game ROM or BIOS is included.

## TurboGrafx-16 / PC Engine foundation

The recorded upstream base is [MiSTer-devel/TurboGrafx16_MiSTer, commit 827d45f45799b8ab3a536510847f2108a92e81bd](https://github.com/MiSTer-devel/TurboGrafx16_MiSTer/tree/827d45f45799b8ab3a536510847f2108a92e81bd). Its [README](https://github.com/MiSTer-devel/TurboGrafx16_MiSTer/blob/827d45f45799b8ab3a536510847f2108a92e81bd/ReadMe.md), freshly checked for this package, credits:

- **Gregory Estrade (Torlus)**: original [FPGAPCE](https://github.com/Torlus/FPGAPCE).
- **Sorgelig / Alexey Melnikov**: MiSTer port, Arcade Card, DDR3, mappers and other changes.
- **srg320**: tweaks and CD support.
- **greyrogue**: additional bug fixes.
- **Kitrinx**: palettes and audio filters.
- **dshadoff**: further refinements and maintenance.

Palette work additionally credits **furrtek** for VDP reverse engineering and **ArtemioUrbina** for color-output verification, as retained in the historical upstream attribution inventory. This is not an exhaustive contributor list; upstream history and individual source notices remain authoritative.

## Save-state architectural references

The project's earlier attribution audit records the SNES, GBA and PlayStation implementations as **architectural references, not code ports**. These projects and their contributors deserve credit for their prior save-state work:

- **paulb-nl and SNES_MiSTer contributors**: the SNES save-state addition is explicitly attributed by [commit 7e9ec639b2066411b098bf5446adaff99abe2071, “Add Save states”](https://github.com/MiSTer-devel/SNES_MiSTer/commit/7e9ec639b2066411b098bf5446adaff99abe2071). The SNES core itself credits srg320. Reference: [rtl/savestates.sv](https://github.com/MiSTer-devel/SNES_MiSTer/blob/master/rtl/savestates.sv).
- **Robert Peip (RobertPeip) and GBA_MiSTer contributors**: [gba_savestates.vhd](https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/gba_savestates.vhd), [reg_savestates.vhd](https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/rtl/reg_savestates.vhd), and the [multislot save-state change 44f376a4ae9813591a8001584b1b314e40cfcac9](https://github.com/MiSTer-devel/GBA_MiSTer/commit/44f376a4ae9813591a8001584b1b314e40cfcac9).
- **Robert Peip (RobertPeip) and PSX_MiSTer contributors**: [rtl/savestates.vhd](https://github.com/MiSTer-devel/PSX_MiSTer/blob/main/rtl/savestates.vhd), with authored state-handling history including [35fc3b653f20455a430a1bec92c80d4712f79103](https://github.com/MiSTer-devel/PSX_MiSTer/commit/35fc3b653f20455a430a1bec92c80d4712f79103) and [ea30dc0f467574086d9524f7582c672ae6407865](https://github.com/MiSTer-devel/PSX_MiSTer/commit/ea30dc0f467574086d9524f7582c672ae6407865).

These acknowledgments do not claim source transplantation, save-file compatibility or endorsement. The TG-specific state serializer, register/RAM capture integration, eligibility guards, history controller and later live-capture work are documented as local extensions of the TG core. A filename such as ninja_savestate.sv is not an author attribution.

## Rewind idea and earlier work

Save states and rewind are established emulator/FPGA ideas, not inventions claimed by this project. In particular, **Robert Peip's GBA MiSTer rewind implementation** is acknowledged as earlier work: [commit 69e47d95baa9db3a3e3ea3dbfdfda0ab1daff2a3, “rewind added”](https://github.com/MiSTer-devel/GBA_MiSTer/commit/69e47d95baa9db3a3e3ea3dbfdfda0ab1daff2a3), dated January 23, 2020. The [GBA README](https://github.com/MiSTer-devel/GBA_MiSTer/blob/master/README.md#rewind) documents its rewind capture and restore feature.

The recorded TG work builds a private rewind history on its existing TG save-state backend and later replaces periodic frozen automatic capture with TG-specific background capture. The retained records do not establish that the GBA rewind code was copied into this core or that one person originated the general rewind concept. Credit for the reference and prior implementation is distinct from a claim of direct code borrowing.

## Shared MiSTer and other components

Preserve the notices in every supplied file. They include Till Harbaum and Alexey Melnikov/Sorgelig for HPS/video/SDRAM infrastructure; Ludvig Strigeus for HQ2x; Grabulosaure and Alexey Melnikov for video_freak; TEMLIB for ascal; Ultra-Embedded.com for SPDIF; Mike Simone for yc_out; bellwood420 for the F2SDRAM terminator; and Intel/Altera for generated IP. File-specific terms differ and are not replaced by this document.

The menu regression retains excerpts from official Main_MiSTer at commit cc47bad62f4c9b6edea55aee3de12bf90855667c. Its GPL-3.0 license is included beside the harness as MAIN_LICENSE. Main itself is not patched or bundled as an alternate firmware.

## Provenance and license scope

See COPYING and LICENSES/ for the supplied license texts. Missing or generic headers are not a public-domain declaration, an ownership assignment or permission to remove upstream notices. This inventory is not an exhaustive legal clearance or a new blanket license grant.
