# Experimental TEST limitations and save safety

Final distribution validation is unfinished. This is a matching-source TEST delivery, not a timing certificate, final acceptance, or broad hardware or full-system qualification. Limited successful user testing does not establish correctness across games, settings, controllers, video paths or long sessions.

Saving, loading and rewinding states target supported HuCard use. CD, SuperGrafx, Populous and other unsupported snapshot profiles are not qualified by this archive. Keep stock Main unchanged. After reloading the core, select the ROM again through **Load TurboGrafx** before using save states. Retained memory may show the previous game, but a fresh ROM load is required. Reselecting the ROM has restored state availability in testing. This is a usage note, not a new fix; later changes are not included in this exact binary and source pair.

Back up battery saves and state files before testing. Loading or rewinding an older state can restore older BRAM contents. A later backup-RAM save or autosave can write those older contents to SD and replace newer progress. Do not test against your only copy of important saves. Save-file compatibility and complete cartridge-change and reset behavior are not guaranteed.

Original strict timing failures and inherited clock and I/O findings have not been rewritten into an overall pass. Existing production FIFO and external clock-group cuts remain limitations. Positive diagnostic values on cut paths are not ordinary timing closure or CDC qualification. Ordinary negative timing, unexplained missing obligations, new exceptions and broad multicycle-equivalence waivers cannot be excused by this TEST delivery.

Audio asynchronous crossings, mute and unmute coherence, metastability, pulse-width and glitch behavior, other reset fanout, shared-memory contention and absolute capture invisibility remain outside broad proof. Analog video may flash. Test both HDMI and analog paths where used, controller mappings, saving and loading states, rewind, reset, cartridge changes and battery-save behavior.

The archive contains source, project and test code, initialization tables, attribution and license texts, manifests and public TEST notes only. It excludes game ROMs and BIOS files, traces, screenshots, fitted databases, caches, raw or private reports, proprietary tool installations and vendor simulation models. Source references to a ROM testbench are code, not bundled game data.

Original author attributions, source links and file-level license notices remain authoritative. This experimental derivative is not an endorsement by upstream authors.
