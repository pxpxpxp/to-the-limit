derive_pll_clocks
derive_clock_uncertainty

# Quartus 23.1 can crash in get_keepers on the synthesis-stage netlist.
# Keep derived clocks during synthesis; defer the original exceptions until
# fitter/TimeQuest, where the named keepers exist. Final constraints are intact.
set ttl_sdc_stage ""
foreach ttl_stage_variable {::TimingAnalyzerInfo(nameofexecutable) ::TimeQuestInfo(nameofexecutable) ::quartus(nameofexecutable)} {
    if {[info exists $ttl_stage_variable]} {set ttl_sdc_stage [set $ttl_stage_variable]}
}
if {$ttl_sdc_stage ne "quartus_map"} {
set_multicycle_path -from {emu|sdram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -setup 2
set_multicycle_path -from {emu|sdram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -hold 1
set_multicycle_path -from {emu|ddram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -setup 2
set_multicycle_path -from {emu|ddram|*} -to [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}] -start -hold 1

set_multicycle_path -from {emu|psg_filter|*} -setup 3
set_multicycle_path -from {emu|psg_filter|*} -hold 2
set_multicycle_path -from {emu|adpcm_filter|*} -setup 3
set_multicycle_path -from {emu|adpcm_filter|*} -hold 2

# The use_sdr source now drives snapshot restore/eligibility logic.
# Do not false-path it: both PLL clocks are related, so require timing closure.

# Append INSIDE the existing ($ttl_sdc_stage ne "quartus_map") block, AFTER
# the original multicycle declarations. No false paths, max/min delays or
# clock groups are added. Fail closed if capture endpoints disappear.
proc pf_required_regs {label pattern minimum} {
    set result [get_registers [list $pattern]]
    set count [get_collection_size $result]
    if {$count < $minimum} {
        error "Pause-free capture constraint missing $label: expected >=$minimum registers, matched $count ($pattern)"
    }
    return $result
}
set pf_sys_clock [get_clocks {*|pll|pll_inst|altera_pll_i|*[1].*|divclk}]
if {[get_collection_size $pf_sys_clock] != 1} {
    error "Pause-free capture requires exactly one verified clk_sys PLL clock"
}
set pf_sdram_sources [pf_required_regs sdram_sources {emu|sdram|*} 1]
set pf_sdram_dout [pf_required_regs sdram_dout {emu|sdram|dout[*]} 8]
# Bits 15:8 are constants, so only eight physical capture registers are expected.
set pf_sdram_live [pf_required_regs sdram_live {emu|sdram|ss_live_reg_dout[*]} 8]
set pf_audio_shadow [pf_required_regs audio_shadow {emu|ss_audio_shadow[*]} 864]
set pf_psg_sources [pf_required_regs psg_sources {emu|psg_filter|*} 1]
set pf_adpcm_sources [pf_required_regs adpcm_sources {emu|adpcm_filter|*} 1]

# The pre-clk_sys-edge snapshot cannot use the foreground SDRAM multicycle.
# Node-to-node exceptions override the old node-to-clock exceptions.
set_multicycle_path -from $pf_sdram_sources -to $pf_sdram_live -start -setup 1
set_multicycle_path -from $pf_sdram_sources -to $pf_sdram_live -start -hold 0
# This NEW bank is itself clocked by clk_sys. Do not inherit the old SDRAM
# source multicycle when its stable captured value reaches the exporter.
set_multicycle_path -from $pf_sdram_live -to $pf_sys_clock -start -setup 1
set_multicycle_path -from $pf_sdram_live -to $pf_sys_clock -start -hold 0

# Arbitrary bg_cut captures every filter state bit on this sys edge. The filter
# arithmetic's legacy 3-cycle exception is not valid for these direct copies.
set_multicycle_path -from $pf_psg_sources -to $pf_audio_shadow -end -setup 1
set_multicycle_path -from $pf_psg_sources -to $pf_audio_shadow -end -hold 0
set_multicycle_path -from $pf_adpcm_sources -to $pf_audio_shadow -end -setup 1
set_multicycle_path -from $pf_adpcm_sources -to $pf_audio_shadow -end -hold 0

# BEGIN READY_ORDINARY_TIMING
# Live ready/control can affect the next clk_sys edge. Require ordinary timing.
# Resolve every role each fit; do not reuse fitted endpoint IDs or FF sites.
# Default get_registers includes automatic replicas. Unexpected matches stop.
set pf_backend_ready_patterns {
    emu|sdram|rd_rdy
    emu|ddram|we_rdy
    emu|ddram|rd_rdy
}
set pf_ram_clock [get_clocks {*|pll|pll_inst|altera_pll_i|*[0].*|divclk}]
if {[get_collection_size $pf_ram_clock] != 1 || [get_collection_size $pf_sys_clock] != 1} {
    error "Live readiness timing requires exactly one RAM and one SYS clock"
}
set pf_backend_ready_sources [get_registers $pf_backend_ready_patterns]
if {[get_collection_size $pf_backend_ready_sources] != 3} {
    error "Live readiness timing requires exactly three distinct ready registers; review missing or replicated roles"
}
foreach pf_ready_pattern $pf_backend_ready_patterns {
    set pf_ready_source [get_registers [list $pf_ready_pattern]]
    if {[get_collection_size $pf_ready_source] != 1} {
        error "Live readiness timing requires one register for $pf_ready_pattern; review missing or replicated role"
    }
    set_multicycle_path -from $pf_ready_source -to $pf_sys_clock -start -setup 1
    set_multicycle_path -from $pf_ready_source -to $pf_sys_clock -start -hold 0
}
# END READY_ORDINARY_TIMING

# Publisher and append supervisor crossings retain ordinary related-PLL setup
# and hold timing. The dcfifo's generated pointer exceptions remain IP-local.
# Do not add an asynchronous clock group or any bundle/whole-instance false path.
}
