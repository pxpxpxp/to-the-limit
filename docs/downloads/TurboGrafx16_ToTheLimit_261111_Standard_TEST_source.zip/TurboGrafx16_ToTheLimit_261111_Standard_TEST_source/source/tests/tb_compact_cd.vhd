library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity tb_compact_cd is end;
architecture test of tb_compact_cd is
 signal clk:std_logic:='0';signal rst:std_logic:='0';
 signal freeze,save,load,compact,swe:std_logic:='0';
 signal sa:std_logic_vector(16 downto 0):=(others=>'0');
 signal sd,sq:std_logic_vector(3 downto 0):=(others=>'0');signal unsafe:std_logic;
 signal ra:std_logic_vector(14 downto 0):=std_logic_vector(to_unsigned(625,15));
 signal rdi,rdo:std_logic_vector(15 downto 0):=(others=>'0');signal rwe:std_logic:='0';
begin
 clk<=not clk after 5 ns;
 dut:entity work.cd port map(CLK=>clk,RST_N=>rst,EN=>'1',EXT_A=>(others=>'0'),EXT_DI=>x"00",EXT_DO=>open,EXT_WR_N=>'1',EXT_RD_N=>'1',CPU_CE=>'0',
 SEL_N=>open,IRQ_N=>open,RAM_CS_N=>open,BRAM_EN=>open,CD_STAT=>x"00",CD_MSG=>x"00",CD_STAT_GET=>'0',CD_COMM=>open,CD_COMM_SEND=>open,
 CD_DOUT_REQ=>'0',CD_DOUT=>open,CD_DOUT_SEND=>open,CD_REGION=>'0',CD_RESET=>open,CD_DATA=>x"00",CD_DATA_WR=>'0',CD_AUDIO_WR=>'0',CD_SUBCD_WR=>'0',
 CD_DATA_END=>open,DM=>'0',CD_SL=>open,CD_SR=>open,AD_S=>open,SS_RDO=>rdo,SS_RADDR=>ra,SS_RDI=>rdi,SS_RWE=>rwe,SS_UNSAFE=>unsafe,
 SS_FREEZE=>freeze,SS_SAVE=>save,SS_LOAD=>load,SS_COMPACT=>compact,SS_ADPCM_ADDR=>sa,SS_ADPCM_DI=>sd,SS_ADPCM_WE=>swe,SS_ADPCM_DO=>sq);
 process
 procedure tick is begin wait until rising_edge(clk);wait until falling_edge(clk);end;
 procedure stage(variant:natural) is begin
  for i in 0 to 15 loop sa<=std_logic_vector(to_unsigned(i,17));sd<=std_logic_vector(to_unsigned((i+variant)mod 16,4));swe<='1';tick;end loop;
  swe<='0';tick;
 end;
 procedure verify(variant:natural) is begin
  for i in 0 to 15 loop sa<=std_logic_vector(to_unsigned(i,17));tick;tick;
   assert sq=std_logic_vector(to_unsigned((i+variant)mod 16,4)) report "wrong active ADPCM bank for snapshot profile" severity failure;
  end loop;
 end;
 begin
  for i in 1 to 100 loop tick;end loop;rst<='1';for i in 1 to 100 loop tick;end loop;
  assert unsafe='0' report "clean CD session not eligible" severity failure;
  freeze<='1';save<='1';tick;save<='0';tick;
  stage(3);load<='1';tick;load<='0';tick;verify(3);
  -- Deliberately leave a different image in the inactive bank. A compact
  -- restore imports register/read-latch state, but must not expose this image.
  stage(9);rdi<=x"000b";rwe<='1';tick;rwe<='0';tick;
  assert rdo(3 downto 0)=x"b" report "active bank read-latch import failed" severity failure;
  compact<='1';load<='1';tick;load<='0';tick;verify(3);
  assert rdo(3 downto 0)=x"b" report "compact load lost active read-latch" severity failure;
  for k in 1 to 3 loop load<='1';tick;load<='0';tick;verify(3);end loop;
  -- Legacy full/manual restore must still select its staged RAM image.
  compact<='0';load<='1';tick;load<='0';tick;verify(9);
  assert rdo(3 downto 0)=x"b" report "full bank swap lost imported read-latch" severity failure;
  compact<='1';load<='1';tick;load<='0';tick;verify(9);
  assert unsafe='0' report "snapshot-only traffic changed CD safety guard" severity failure;
  report "PASS actual CD compact/manual ADPCM bank profiles: 112 cells; idle FIFO and behavioral RAM scope" severity note;
  std.env.finish;
 end process;
 process begin wait for 100 us;assert false report "compact CD watchdog" severity failure;end process;
end;
