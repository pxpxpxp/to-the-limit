`timescale 1ns/1ps
// The synchronous stub preserves ninja_savestate's acceptance contract:
// sample edge-triggered requests at a rising edge, register request_accept and
// busy using NBA, and deliver completion later. The scheduler therefore sees
// accept one clock AFTER the edge on which the backend consumed the request.
module tb_rewind_registered_backend;
 reg clk=0; always #5 clk=~clk;
 reg reset=1,enabled=1,frame_tick=0,rewind_held=0,osd_open=0,manual_request=0;
 reg backend_busy=0,backend_accept=0,backend_done=0,backend_failed=0;
 reg [1:0] history_depth=0,capture_rate=0;
 wire save_request,load_request,private_mode,held_active;
 wire [1:0] private_slot;
 wire [2:0] count;
 rewind_history #(.SLOT_BITS(2),.CAPTURE_FRAMES(3),.REWIND_FRAMES(2)) dut(.*);
 reg old_save=0,old_load=0,accepted_private=0;
 reg [1:0] accepted_slot=0;
 integer remaining=0,accepted_loads=0,accepted_saves=0,checks=0,before_loads;

 always @(posedge clk) begin
  backend_accept<=0; backend_done<=0; backend_failed<=0;
  old_save<=save_request; old_load<=load_request;
  if(reset) begin
   backend_busy<=0; remaining<=0; old_save<=0; old_load<=0;
   accepted_loads<=0; accepted_saves<=0; accepted_private<=0; accepted_slot<=0;
  end else if(!backend_busy) begin
   // Same save priority and registered acceptance as ninja_savestate IDLE.
   if((save_request&&!old_save)||(load_request&&!old_load)) begin
    backend_accept<=1; backend_busy<=1; remaining<=6;
    accepted_private<=private_mode; accepted_slot<=private_slot;
    if(save_request&&!old_save) accepted_saves<=accepted_saves+1;
    else accepted_loads<=accepted_loads+1;
   end
  end else if(remaining==1) begin
   remaining<=0; backend_busy<=0; backend_done<=1;
  end else remaining<=remaining-1;
 end

 task cycle; begin @(posedge clk); #1; end endtask
 task check(input bit ok,input string what);
  begin checks=checks+1; if(!ok)$fatal(1,"CHECK %0d: %s",checks,what);end
 endtask
 task frame;
  begin @(negedge clk);frame_tick=1;cycle();@(negedge clk);frame_tick=0;cycle();end
 endtask
 task await_count(input integer expected);
  integer guard;
  begin
   guard=0;
   while(count!=expected && guard<25)begin cycle();guard=guard+1;end
   check(count==expected,"bounded completion commits expected count");
  end
 endtask
 task capture(input integer expected);
  begin frame();frame();frame();await_count(expected);end
 endtask
 task start_rewind;
  begin
   @(negedge clk);rewind_held=1;cycle();
   check(load_request && private_mode && !backend_accept,"scheduler presents load before consuming edge");
  end
 endtask
 initial begin #20000;$fatal(1,"WATCHDOG registered backend");end
 initial begin
  repeat(3)cycle();@(negedge clk);reset=0;cycle();
  capture(1);capture(2);
  check(accepted_saves==2 && accepted_loads==0,"history seeded by actual registered save transactions");

  $display("CASE release before backend consuming edge");
  start_rewind();
  @(negedge clk);rewind_held=0;
  cycle();
  check(accepted_loads==0 && !backend_accept && !backend_busy,
        "RELEASE_CANCEL: release before consuming edge must prevent backend acceptance");
  check(!private_mode && !load_request && count==2,"cancelled pending load preserves history");
  repeat(4)cycle();check(accepted_loads==0 && count==2,"cancelled load cannot appear later");

  $display("CASE release after consuming edge before registered acceptance delivery");
  start_rewind();cycle();
  check(backend_accept && backend_busy && accepted_loads==1,"backend registered acceptance on consuming edge");
  check(accepted_private && accepted_slot==1,"backend latched private profile and newest slot");
  @(negedge clk);rewind_held=0;cycle();
  check(private_mode && private_slot==1 && !load_request,"delayed accept wins release and retains ownership");
  while(backend_busy)begin
   check(private_mode && private_slot==accepted_slot,"accepted load retains private owner until completion");
   cycle();
  end
  check(backend_done && private_mode,"private ownership survives registered done delivery");
  cycle();check(count==1 && !private_mode,"accepted restore completion pops newest exactly once");
  repeat(4)cycle();check(accepted_loads==1 && count==1,"release causes neither duplicate load nor duplicate pop");
  capture(2);check(accepted_saves==3,"capture resumes on branched history");
  $display("CASE configuration change before backend consuming edge");
  before_loads=accepted_loads;start_rewind();
  @(negedge clk);capture_rate=1;cycle();
  check(accepted_loads==before_loads && !backend_accept && !backend_busy,
        "CONFIG_CANCEL: setting change before consuming edge prevents backend acceptance");
  check(!private_mode && count==0,"changed setting cancels pending restore and history");
  @(negedge clk);capture_rate=0;rewind_held=0;cycle();capture(1);capture(2);
  $display("CASE configuration change after consumption before registered acceptance");
  start_rewind();cycle();
  check(backend_accept && backend_busy && accepted_slot==1,"actual backend accepted old settings restore");
  @(negedge clk);history_depth=1;cycle();
  check(private_mode && private_slot==1 && count==0,"configuration race cannot release accepted owner");
  while(backend_busy)begin
   check(private_mode && private_slot==accepted_slot && count==0,"changed config preserves owner until registered completion");
   cycle();
  end
  check(backend_done && private_mode,"changed config drains through registered done");
  cycle();check(count==0 && !private_mode,"config-invalidated completion never restores metadata");
  @(negedge clk);rewind_held=0;cycle();capture(1);
  $display("PASS tb_rewind_registered_backend: %0d checks",checks);$finish;
 end
endmodule
