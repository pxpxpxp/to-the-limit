library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity tb_video_phase_restore is end;
architecture test of tb_video_phase_restore is
 signal clk:std_logic:='0';signal rst:std_logic:='0';
 signal freeze,save,load,rotate,rwe:std_logic:='0';
 signal ra:std_logic_vector(14 downto 0):=std_logic_vector(to_unsigned(2,15));
 signal rdi,rdo:std_logic_vector(15 downto 0):=(others=>'0');
 signal phase:std_logic_vector(51 downto 0);
 signal ce_n,wr_n:std_logic:='1';signal di:std_logic_vector(7 downto 0):=(others=>'0');
 type image_t is array(0 to 9) of std_logic_vector(15 downto 0);
 type images_t is array(0 to 2) of image_t;
 type phases_t is array(0 to 2) of std_logic_vector(51 downto 0);
 constant configs:std_logic_vector(23 downto 0):=x"060100";
begin
 clk<=not clk after 5 ns;
 dut:entity work.huc6260 port map(CLK=>clk,RESET_N=>rst,SS_RDO=>rdo,SS_RADDR=>ra,SS_RDI=>rdi,SS_RWE=>rwe,
 SS_RROTATE=>rotate,SS_FREEZE=>freeze,SS_SAVE=>save,SS_LOAD=>load,SS_VIDEO_PHASE=>phase,SS_DO=>open,
 A=>"000",CE_N=>ce_n,WR_N=>wr_n,RD_N=>'1',DI=>di,DO=>open,COLNO=>(others=>'0'),CLKEN=>open,CLKEN_F=>open,
 HSYNC_F=>open,HSYNC_R=>open,VSYNC_F=>open,VSYNC_R=>open,CLKEN_FS=>open,RVBL=>'0',GRID_EN=>"00",
 BORDER_EN=>'0',BORDER=>'0',GRID=>"00",R=>open,G=>open,B=>open,BW=>open,VS_N=>open,HS_N=>open,HBL=>open,VBL=>open);
 process
 variable images:images_t;variable phases:phases_t;
 procedure tick is begin wait until rising_edge(clk);wait until falling_edge(clk);end;
 procedure write_cr(value:std_logic_vector(7 downto 0)) is begin
  di<=value;ce_n<='0';wr_n<='0';for i in 1 to 4 loop tick;end loop;
  ce_n<='1';wr_n<='1';for i in 1 to 4 loop tick;end loop;
 end;
 begin
  for i in 1 to 8 loop tick;end loop;rst<='1';
  for k in 0 to 2 loop
   write_cr(configs(k*8+7 downto k*8));
   for i in 1 to 2*2730*263 loop tick;end loop;
   if k=2 then
    while not (unsigned(phase(21 downto 12))=80 and unsigned(phase(11 downto 0))=1000) loop tick;end loop;
    write_cr(x"00");
    while not (unsigned(phase(21 downto 12))=261 and unsigned(phase(11 downto 0))=1000) loop tick;end loop;
    assert phase(34)='1' report "MULTIRES fixture was not active" severity failure;
   end if;
   freeze<='1';tick;save<='1';tick;save<='0';for i in 1 to 4 loop tick;end loop;
   phases(k):=phase;
   for i in 0 to 9 loop
    ra<=std_logic_vector(to_unsigned(2+i,15));wait for 1 ns;images(k)(i):=rdo;
    rotate<='1';tick;rotate<='0';
   end loop;
   freeze<='0';tick;
  end loop;
  for pass in 0 to 2 loop
   for k in 0 to 2 loop
    for i in 1 to 2730 loop tick;end loop;
    freeze<='1';tick;
    for i in 0 to 9 loop
     ra<=std_logic_vector(to_unsigned(2+i,15));rdi<=images(k)(i);rwe<='1';tick;
    end loop;
    rwe<='0';tick;load<='1';tick;load<='0';tick;
    assert phase=phases(k) report "restored VCE presentation phase differs from saved snapshot" severity failure;
    freeze<='0';tick;
   end loop;
  end loop;
  report "PASS actual VCE saved/restored 52-bit presentation phase: 3 fixtures, 9 restores, MULTIRES active" severity note;
  std.env.finish;
 end process;
 process begin wait for 200 ms;assert false report "watchdog" severity failure;end process;
end;
