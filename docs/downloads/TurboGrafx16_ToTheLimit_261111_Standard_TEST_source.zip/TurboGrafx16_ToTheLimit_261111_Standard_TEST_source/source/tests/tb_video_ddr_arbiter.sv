`timescale 1ns/1ps
module tb_video_ddr_arbiter;
 reg clk=0;
 reg [28:0] primary_addr=29'h100,video_addr=29'h1000010;
 reg [63:0] primary_din=64'h1020304050607080,video_din=64'hfedcba9876543210;
 reg [7:0] primary_byteenable=8'h5a,primary_burst=1,video_burst=1;
 reg primary_pulse_read=1;
 reg primary_rd=0,primary_we=0,primary_idle=0,video_rd=0,video_we=0;
 wire primary_busy,primary_ready,video_busy,video_ready;
 wire [63:0] primary_dout,video_dout;
 wire [28:0] ddr_addr;
 wire [63:0] ddr_din;
 wire [7:0] ddr_byteenable,ddr_burst;
 wire ddr_rd,ddr_we;
 reg ddr_busy=0,ddr_ready=0;
 reg [63:0] ddr_dout=0;
 video_ddr_arbiter dut(.*);
 integer pending=0,owner=0,reads=0,writes=0,responses=0,cycles=0;
 integer n,b,k,seed=32'h7106;
 integer new_owner;
 // Independent transaction scoreboard. Address ranges identify initiators;
 // ownership is never inferred from the DUT's internal state.
 always @(posedge clk) begin
  cycles=cycles+1;
  if(ddr_rd && ddr_we) $fatal(1,"simultaneous read/write");
  if((ddr_rd || ddr_we) && !ddr_busy) begin
   if(pending!=0) $fatal(1,"overlapped outstanding command");
   new_owner=ddr_addr[24] ? 2 : 1;
   if(new_owner==1 && primary_busy) $fatal(1,"primary acceptance while busy");
   if(new_owner==2 && (video_busy || !primary_busy)) $fatal(1,"video grant/BUSY race");
   if(new_owner==1 && ddr_byteenable!==primary_byteenable) $fatal(1,"primary byteenable damaged");
   if(new_owner==2 && ddr_byteenable!==8'hff) $fatal(1,"video byteenable damaged");
   if(ddr_rd) begin
    if(ddr_burst==0) $fatal(1,"zero burst");
    owner=new_owner; pending=ddr_burst; reads=reads+1;
   end else begin
    writes=writes+1;
    if(new_owner==2 && ddr_burst!=1) $fatal(1,"video write not single beat");
   end
  end
  if(primary_ready !== (ddr_ready && pending!=0 && owner==1)) $fatal(1,"primary ready misrouted cycle %0d actual=%b ready=%b pending=%d owner=%d state=%d accepted=%b",cycles,primary_ready,ddr_ready,pending,owner,dut.state,dut.accepted_read);
  if(video_ready !== (ddr_ready && pending!=0 && owner==2)) $fatal(1,"video ready misrouted cycle %0d",cycles);
  if(ddr_ready && pending!=0) begin
   if(owner==1 && primary_dout!==ddr_dout) $fatal(1,"primary data");
   if(owner==2 && video_dout!==ddr_dout) $fatal(1,"video data");
   pending=pending-1; responses=responses+1;
  end
 end
 task tick; begin #5; clk=1; #1; clk=0; #4; end endtask
 task check_idle; begin
  if(pending) $fatal(1,"undrained transaction");
  ddr_ready=1; tick(); ddr_ready=0; // unsolicited READY must be filtered
 end endtask
 initial begin
  tick(); check_idle();
  // Video must not steal an unqualified primary idle cycle.
  video_rd=1; repeat(8) begin tick(); if(!video_busy) $fatal(1,"unsafe video grant"); end
  // Primary wins a simultaneous command/grant opportunity. A one-cycle
  // legacy RD survives external stalls and disappearing upstream signals.
  primary_idle=1; primary_rd=1; ddr_busy=1; tick();
  primary_rd=0; primary_addr=29'h200;
  repeat(7) begin tick(); if(ddr_addr!==29'h100 || !ddr_rd || !video_busy) $fatal(1,"lost normal pulse"); end
  ddr_busy=0; tick();
  repeat(9) begin tick(); if(!video_busy) $fatal(1,"video stole pending response"); end
  ddr_ready=1; ddr_dout=64'h1122334455667788; tick(); ddr_ready=0;
  // Registered grant, no combinational primary/video command selection.
  #1; if(!video_busy) $fatal(1,"grant was combinational");
  tick(); if(video_busy || !primary_busy) $fatal(1,"video not granted");
  // Same-edge acceptance/response is routed without leaving a phantom owner.
  ddr_ready=1; tick(); video_rd=0; ddr_ready=0; check_idle();
  // Back-to-back single-beat reads with same-cycle responses never acquire
  // a phantom owner or lose the second accepted command.
  primary_idle=0; primary_rd=1; ddr_ready=1; tick(); tick();
  primary_rd=0; ddr_ready=0; check_idle();
  // Snapshot reads can be canceled while waitrequest is asserted. Unlike
  // legacy normal pulses they must not be remembered by the arbiter.
  primary_pulse_read=0; primary_rd=1; ddr_busy=1; tick();
  primary_rd=0; primary_idle=1; tick();
  ddr_busy=0; tick();
  if(ddr_rd || pending) $fatal(1,"canceled snapshot read was issued");
  primary_pulse_read=1; check_idle();
  // Level-held primary write payload and byte enables survive BUSY.
  primary_idle=0; primary_we=1; ddr_busy=1; tick();
  repeat(4) tick();
  if(ddr_din!==64'h1020304050607080 || ddr_byteenable!==8'h5a) $fatal(1,"write corrupt");
  ddr_busy=0; tick(); primary_we=0; check_idle();
  // Cancel a granted video request before acceptance, then resume primary.
  primary_idle=1; video_rd=1; ddr_busy=1; tick();
  video_rd=0; tick(); ddr_busy=0; primary_rd=1; ddr_ready=1; tick();
  primary_rd=0; ddr_ready=0; check_idle();
  // Primary burst ownership is also retained (current clients use one beat).
  for(n=0;n<3;n=n+1) begin
   b=(n==0) ? 1 : ((n==1) ? 2 : 255);
   primary_idle=0; primary_burst=b; primary_rd=1; ddr_ready=1;
   tick(); primary_rd=0; ddr_ready=0;
   for(k=1;k<b;k=k+1) begin
    tick(); ddr_ready=1; tick(); ddr_ready=0;
   end
   check_idle();
  end
  primary_burst=1;
  // Deterministic pseudo-random burst lengths, acceptance stalls, first-beat
  // same-cycle responses, delayed and gapped responses. Withdraw video after
  // acceptance (models abort/reset at requester), but drain all owned beats.
  for(n=0;n<120;n=n+1) begin
   b=(n==0) ? 255 : 1+($random(seed)&32'h7fffffff)%255;
   video_burst=b; video_rd=1; primary_idle=1; ddr_busy=1;
   tick();
   repeat(($random(seed)&7)+1) tick();
   ddr_busy=0; ddr_ready=(n%2)==0; tick();
   k=ddr_ready ? 1 : 0;
   video_rd=0; ddr_ready=0;
   // A waiting primary command must not leak onto DDR during this burst.
   primary_rd=1; primary_idle=0;
   for(;k<b;k=k+1) begin
    repeat($random(seed)&3) tick();
    ddr_ready=1; ddr_dout={32'(n),32'(k)}; tick(); ddr_ready=0;
   end
   // Primary wins immediately after the final video beat.
   ddr_ready=1; tick(); primary_rd=0; ddr_ready=0;
   check_idle();
   primary_idle=1; video_we=1; video_burst=255; tick();
   ddr_busy=1; repeat(3) tick(); ddr_busy=0; tick(); video_we=0;
   check_idle();
  end
  if(reads!=248 || writes!=121 || pending!=0) $fatal(1,"unexpected counts %0d %0d",reads,writes);
  $display("PASS video_ddr_arbiter: %0d cycles, %0d read commands, %0d writes, %0d correctly owned response beats",cycles,reads,writes,responses);
  $finish;
 end
 initial begin #2000000; $fatal(1,"timeout"); end
endmodule
