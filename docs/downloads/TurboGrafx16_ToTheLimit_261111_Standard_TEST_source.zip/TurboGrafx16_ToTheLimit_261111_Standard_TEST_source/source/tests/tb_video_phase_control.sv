`timescale 1ns/1ps
module tb_video_phase_control;
 reg clk=0;always #5 clk=~clk;
 reg request=0,cancel=0;reg[51:0]phase=0;
 wire hold,freeze,busy,ce,hs,vs,hb,vb,fault;
 video_phase_align #(.FLUSH_CLOCKS(8),.TIMEOUT_CLOCKS(32)) dut(
 .clk(clk),.freeze_request(request),.cancel(cancel),.core_phase(phase),
 .machine_hold(hold),.video_freeze(freeze),.busy(busy),.reference_ce(ce),
 .reference_hs(hs),.reference_vs(vs),.reference_hbl(hb),.reference_vbl(vb),.fault(fault));
 integer checks=0,i;
 task tick;begin @(posedge clk);@(negedge clk);checks=checks+1;end endtask
 initial begin
  // An invalid restored phase cannot release the machine by coincidence.
  phase[11:0]=4095;phase[31:22]=262;
  request=1;repeat(3)tick;
  if(!hold||!freeze||!busy)$fatal(1,"request did not prime both holds");
  request=0;
  for(i=0;i<31;i=i+1)begin tick;if(!hold||fault)$fatal(1,"early timeout/release");end
  tick;if(!fault||!hold||!busy)$fatal(1,"timeout failed to retain machine for reset arming");
  repeat(4)begin tick;if(!hold||fault)$fatal(1,"fault must be one pulse and hold must persist");end
  cancel=1;tick;if(hold||!freeze||!busy)$fatal(1,"armed reset did not release core separately from video flush");
  cancel=0;repeat(8)tick;if(freeze||busy)$fatal(1,"flush did not drain");
  // Reset/eligibility cancellation cannot override an active backend hold.
  request=1;cancel=1;repeat(4)tick;if(!hold||!freeze)$fatal(1,"cancel broke active backend freeze");
  request=0;tick;if(hold||!freeze)$fatal(1,"cancel did not release when backend drained");
  // A brief eligibility/config cancellation during drain must survive
  // until the backend releases, without waiting for the alignment timeout.
  cancel=0;repeat(8)tick;request=1;tick;cancel=1;tick;cancel=0;repeat(3)tick;
  if(!hold)$fatal(1,"pulsed cancel broke backend ownership");
  request=0;tick;if(hold||fault)$fatal(1,"pulsed cancel was lost during drain");
  // A new request during the output-only flush primes fresh ownership.
  cancel=0;repeat(3)tick;request=1;tick;if(!hold||!freeze)$fatal(1,"repeated request failed");
  request=0;cancel=1;tick;cancel=0;repeat(8)tick;
  if(hold||freeze||busy)$fatal(1,"repeated request did not finish");
  $display("PASS video phase hold/reset/timeout controls checks=%0d",checks);$finish;
 end
 initial begin #10000;$fatal(1,"watchdog");end
endmodule
