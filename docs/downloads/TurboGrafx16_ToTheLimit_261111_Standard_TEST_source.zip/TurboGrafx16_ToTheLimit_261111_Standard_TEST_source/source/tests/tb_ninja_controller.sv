`timescale 1ns/1ps
module tb_ninja_controller;
 reg clk=0, ram_clk=0;
 always #10 clk=~clk;
 always #5 ram_clk=~ram_clk;
 reg reset=1, enabled=1, safe=1, save_button=0, load_button=0;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we;
 wire [17:0] scan_addr;
 reg [15:0] scan_dout;
 wire [15:0] scan_din;
 reg ram_busy=0,ram_ready=0;
 reg [63:0] ram_dout=0;
 wire [28:0] ram_addr;
 wire [63:0] ram_din;
 wire start_block=0;
 // Optional rewind ports: retain the legacy snapshot profile.
 wire private_mode=1'b0;wire [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 ninja_savestate dut(.manual_stage_allowed(1'b0),.*);
 reg [15:0] memory[0:196607];
 reg [15:0] ddr[0:196607];
 integer i,j,bank,limit,writes=0,reads=0,saves=0,loads=0;
 integer ticks=0,delay_left=0;
 reg expect_fault=0;
 reg [17:0] pending;
 function [15:0] pattern(input integer a);
   pattern=(a ^ (a>>8) ^ 16'h9d35);
 endfunction
 function integer banklimit(input integer b);
   case(b) 0:banklimit=8192;1:banklimit=32768;2:banklimit=256;default:banklimit=512;endcase
 endfunction
 always @(posedge clk) begin
   scan_dout<=memory[scan_addr];
   if(scan_we) begin
     if(!freeze) $fatal(1,"RAM write outside freeze");
     memory[scan_addr]<=scan_din;
   end
   if(save_pulse) saves<=saves+1;
   if(load_pulse) loads<=loads+1;
   if(fault_reset && !expect_fault) $fatal(1,"unexpected timeout");
 end
 always @(negedge ram_clk) begin
   ticks=ticks+1;
   ram_busy=((ticks%13)<4);
 end
 always @(posedge ram_clk) begin
   ram_ready<=0;
   if(delay_left!=0) begin
     delay_left<=delay_left-1;
     if(delay_left==1) begin ram_dout<={48'd0,ddr[pending]};ram_ready<=1;end
   end
   if((ram_we||ram_rd)&&!ram_busy) begin
     if(!take_ddr || (ram_addr<29'h7e00000) || (ram_addr>=29'h7e30000)) $fatal(1,"bad DDR ownership/address");
     if(ram_we) begin ddr[ram_addr-29'h7e00000]<=ram_din[15:0];writes<=writes+1;end
     if(ram_rd) begin pending<=ram_addr-29'h7e00000;delay_left<=2+(ticks%9);reads<=reads+1;end
   end
 end
 task press_save;
   begin wait(!busy);@(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);end
 endtask
 task press_load;
   begin wait(!busy);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);end
 endtask
 task check_memory;
   begin
     for(bank=0;bank<6;bank=bank+1)
       for(j=0;j<banklimit(bank);j=j+1)
         if(memory[bank*32768+j]!==pattern(bank*32768+j)) $fatal(1,"restore mismatch bank=%0d word=%0d got=%h",bank,j,memory[bank*32768+j]);
   end
 endtask
 initial begin
   for(i=0;i<196608;i=i+1) memory[i]=pattern(i);
   repeat(4) @(negedge clk);reset=0;
   // Empty-slot load must leave the machine alone.
   load_button=1;@(negedge clk);load_button=0;repeat(10) @(negedge clk);
   if(freeze||valid) $fatal(1,"empty-slot load accepted");
   press_save();
   if(!valid||writes!=42752||saves!=1) $fatal(1,"save count mismatch %0d",writes);
   for(i=0;i<196608;i=i+1) memory[i]=16'hdead;
   press_load();check_memory();
   for(i=0;i<196608;i=i+1) memory[i]=16'hbeef;
   press_load();check_memory();
   if(reads!=85504||loads!=2) $fatal(1,"load count mismatch");
   // Interrupt a load after a RAM word has been written. It must reset the
   // game, invalidate the slot, drain its mailbox and permit a new save.
   @(negedge clk);load_button=1;@(negedge clk);load_button=0;
   wait(scan_we);@(negedge clk);expect_fault=1;reset=1;
   @(negedge clk);if(!fault_reset) $fatal(1,"partial restore resumed without reset");
   reset=0;repeat(8) @(negedge clk);expect_fault=0;
   if(valid) $fatal(1,"aborted load remained valid");
   press_save();if(!valid) $fatal(1,"mailbox failed to recover after aborted load");
   @(negedge clk);reset=1;@(negedge clk);reset=0;
   if(valid) $fatal(1,"slot survived reset");
   $display("PASS: 42752-word save, two exact restores, DDR stalls/latency, empty load, reset invalidation and interrupted-load recovery");
   $finish;
 end
 initial begin #200000000; $fatal(1,"test timeout");end
endmodule
