`timescale 1ns/1ps
module tb_rewind_tint;
 reg active=0; reg [23:0] rgb=0; wire [23:0] result;
 rewind_tint dut(.active(active),.rgb_in(rgb),.rgb_out(result));
 integer i,r,g,b,y,rr,gg,bb,checks=0;
 task check(input [23:0] value);
 begin
   rgb=value;active=0;#1;
   if(result!==value)$fatal(1,"tint changes released picture");checks=checks+1;
   r=value[23:16];g=value[15:8];b=value[7:0];y=(r+2*g+b)/4;
   rr=(r+y)/2;gg=(g+y)/2;bb=(b+y)/2;
   active=1;#1;
   if(result!=={rr[7:0],gg[7:0],bb[7:0]})$fatal(1,"tint arithmetic");checks=checks+1;
   active=0;#1;
   if(result!==value)$fatal(1,"tint release is delayed");checks=checks+1;
 end
 endtask
 initial begin
   for(i=0;i<256;i=i+1)begin
     check({i[7:0],i[7:0],i[7:0]});
     check({i[7:0],8'd0,8'd0});check({8'd0,i[7:0],8'd0});check({8'd0,8'd0,i[7:0]});
   end
   check(24'hffffff);check(24'h000000);check(24'hff00ff);check(24'hffff00);check(24'h00ffff);
   for(i=0;i<10000;i=i+1)check($random);
   $display("PASS rewind tint checks=%0d",checks);$finish;
 end
endmodule
