`timescale 1ns/1ps
module tb_video_phase_extended;
  localparam integer H=2730;
  reg clk=0,video_clk=0; always #2 clk=~clk; always #1 video_clk=~video_clk;
  reg reset_n=0,request=0,cancel=0,save=0,load=0,rotate=0,rwe=0;
  reg rvbl=1;
  reg [14:0] ra=2;reg [15:0] rdi=0; wire [15:0] rdo;
  reg ce_n=1,wr_n=1;reg [7:0] di=0;
  wire hold,video_freeze,busy,ref_ce,ref_hs,ref_vs,ref_hb,ref_vb,fault;
  wire machine_freeze=request|hold;
  wire [51:0] phase; wire core_ce,hs_n,vs_n,hb,vb;
  huc6260 vce(.CLK(clk),.RESET_N(reset_n),.SS_ADDR(18'd0),.SS_DI(16'd0),.SS_WE(1'b0),.SS_DO(),
    .SS_RROTATE(rotate),.SS_RADDR(ra),.SS_RDI(rdi),.SS_RWE(rwe),.SS_RDO(rdo),
    .SS_FREEZE(machine_freeze),.SS_SAVE(save),.SS_LOAD(load),.SS_VIDEO_PHASE(phase),
    .A(3'd0),.CE_N(ce_n),.WR_N(wr_n),.RD_N(1'b1),.DI(di),.DO(),.COLNO(9'd0),
    .CLKEN(),.CLKEN_F(),.HSYNC_F(),.HSYNC_R(),.VSYNC_F(),.VSYNC_R(),.CLKEN_FS(core_ce),
    .RVBL(rvbl),.GRID_EN(2'b0),.BORDER_EN(1'b0),.BORDER(1'b0),.GRID(2'b0),
    .R(),.G(),.B(),.BW(),.VS_N(vs_n),.HS_N(hs_n),.HBL(hb),.VBL(vb));
  video_phase_align aligner(.clk(clk),.freeze_request(request),.cancel(cancel),.core_phase(phase),
    .machine_hold(hold),.video_freeze(video_freeze),.busy(busy),.reference_ce(ref_ce),
    .reference_hs(ref_hs),.reference_vs(ref_vs),.reference_hbl(ref_hb),.reference_vbl(ref_vb),.fault(fault));

  reg ce_pix=0,old_ce=0;
  always @(posedge video_clk) begin old_ce<=ref_ce;ce_pix<=!old_ce&&ref_ce;end
  wire [7:0] R,G,B;wire HS,VS,HBlank,VBlank;
  color_mix color_stage(.clk_vid(video_clk),.ce_pix(ce_pix),.mix(3'd0),
    .R_in(video_freeze?8'd0:8'h80),.G_in(video_freeze?8'd0:8'h40),.B_in(video_freeze?8'd0:8'h20),
    .HSync_in(ref_hs),.VSync_in(ref_vs),.HBlank_in(ref_hb),.VBlank_in(ref_vb),
    .R_out(R),.G_out(G),.B_out(B),.HSync_out(HS),.VSync_out(VS),.HBlank_out(HBlank),.VBlank_out(VBlank));
  reg HSync,VSync;
  always @(posedge video_clk) begin HSync<=HS;if(!HSync&&HS)VSync<=VS;end
  wire [21:0] gamma_bus; assign gamma_bus[20:0]=0;
  wire [7:0] vr,vg,vbcol;wire vhs,vvs,vde,pixout;
  video_mixer #(.LINE_LENGTH(560),.GAMMA(1)) mixer(
    .CLK_VIDEO(video_clk),.CE_PIXEL(pixout),.ce_pix(ce_pix),.scandoubler(1'b0),.hq2x(1'b0),.gamma_bus(gamma_bus),
    .R(R),.G(G),.B(B),.HSync(HSync),.VSync(VSync),.HBlank(HBlank),.VBlank(VBlank),
    .HDMI_FREEZE(1'b0),.freeze_sync(),.VGA_R(vr),.VGA_G(vg),.VGA_B(vbcol),.VGA_VS(vvs),.VGA_HS(vhs),.VGA_DE(vde));
  integer cycles=0;always @(posedge clk)cycles<=cycles+1;
  integer vc=0;always @(posedge video_clk)vc<=vc+1;
  reg checking=0,was_frozen=0;
  integer live_checks=0,resumes=0;
  integer freeze_start=-1,video_start=-1;reg old_machine=0,old_video=0;
  always @(negedge clk) begin
    if(machine_freeze && !old_machine) freeze_start=cycles;
    if(video_freeze && !old_video) video_start=cycles;
    if(!machine_freeze && old_machine) begin
      $display("MACHINE_PAUSE scenario=%0d cycles=%0d microseconds=%0f",scenario,cycles-freeze_start,(cycles-freeze_start)*1000000.0/42954545.0);$fflush();
    end
    if(!video_freeze && old_video) begin
      $display("VIDEO_HOLD scenario=%0d cycles=%0d microseconds=%0f",scenario,cycles-video_start,(cycles-video_start)*1000000.0/42954545.0);$fflush();
    end
    old_machine=machine_freeze;old_video=video_freeze;
  end
  always @(negedge clk) begin
    if(checking && !machine_freeze && !was_frozen) begin
      // Every active-cycle comparison is against the actual synthesized VHDL,
      // not a second handwritten VCE model.
      if({aligner.reference_phase[50:35],aligner.reference_phase[21:0]} !== {phase[50:35],phase[21:0]}) begin
        $display("MIRROR actual=%h expected=%h cycle=%0d",aligner.reference_phase,phase,cycles);
        $fatal(1,"live VCE presentation mismatch");
      end
      live_checks=live_checks+1;
    end
    if(checking && was_frozen && !machine_freeze) begin
      if(aligner.reference_phase !== phase) $fatal(1,"resume phase mismatch");
      resumes=resumes+1;
    end
    if(checking && fault) $fatal(1,"unexpected alignment timeout");
    was_frozen=machine_freeze;
  end
  integer rh=-1,rf=-1,rv=-1,rvf=-1,oh=-1,ohf=-1,ov=-1,ovf=-1;
  integer raw_lines=0,raw_fields=0,out_lines=0,out_fields=0;
  integer max_h_error=0,max_h_width_error=0,max_v_error=0,max_v_width_error=0,e=0,e2=0;
  function integer abs(input integer value);abs=value<0?-value:value;endfunction
  always @(posedge ref_hs) if(checking)begin
    if(rh>=0 && cycles-rh!=H)$fatal(1,"raw H period %0d",cycles-rh);rh=cycles;raw_lines=raw_lines+1;
  end
  always @(negedge ref_hs) if(checking)begin
    if(rh>=0 && cycles-rh!=192)$fatal(1,"raw H width %0d",cycles-rh);
  end
  always @(posedge ref_vs) if(checking)begin
    if(rv>=0 && cycles-rv!=H*262 && cycles-rv!=H*263)$fatal(1,"raw V period %0d",cycles-rv);rv=cycles;raw_fields=raw_fields+1;
  end
  always @(negedge ref_vs) if(checking)begin
    if(rv>=0 && cycles-rv!=3*H)$fatal(1,"raw V width %0d",cycles-rv);
  end
  always @(posedge vhs) if(checking)begin
    if(oh>=0) begin e=abs(vc-oh-2*H);if(e>max_h_error)max_h_error=e;end
    if(oh>=0 && abs(vc-oh-2*H)>128)$fatal(1,"native H period %0d",vc-oh);oh=vc;out_lines=out_lines+1;
  end
  always @(negedge vhs) if(checking)begin
    if(oh>=0) begin e=abs(vc-oh-384);if(e>max_h_width_error)max_h_width_error=e;end
    if(oh>=0 && abs(vc-oh-384)>128)$fatal(1,"native H width %0d",vc-oh);
  end
  always @(posedge vvs) if(checking)begin
    if(ov>=0) begin e=abs(vc-ov-2*H*262);e2=abs(vc-ov-2*H*263);if(e2<e)e=e2;if(e>max_v_error)max_v_error=e;end
    if(ov>=0 && abs(vc-ov-2*H*262)>128 && abs(vc-ov-2*H*263)>128)$fatal(1,"native V period %0d",vc-ov);ov=vc;out_fields=out_fields+1;
  end
  always @(negedge vvs) if(checking)begin
    if(ov>=0) begin e=abs(vc-ov-6*H);if(e>max_v_width_error)max_v_width_error=e;end
    if(ov>=0 && abs(vc-ov-6*H)>128)$fatal(1,"native V width %0d",vc-ov);
  end
  integer black_count=0;
  always @(posedge video_clk) if(video_freeze)begin
    black_count<=black_count+1;
    if(checking && black_count>256 && {vr,vg,vbcol}!==24'd0)$fatal(1,"RGB not black during video hold");
  end else black_count<=0;
  task tick;begin @(posedge clk);@(negedge clk);end endtask
  task write_cr(input [7:0] value);begin
    @(negedge clk);di=value;ce_n=0;wr_n=0;repeat(4)tick;
    ce_n=1;wr_n=1;repeat(4)tick;
  end endtask
  reg [15:0] image[0:9];reg[51:0]saved_phase;
  integer i,scenario=10,unused,old_lines,new_lines;
  integer save_h,save_v,load_h,load_v,save_extra,load_extra;
  reg[7:0]old_cr,new_cr;
  initial begin
    unused=$value$plusargs("SCENARIO=%d",scenario);
    case(scenario)
      10: begin
        rvbl=1;old_cr=8'h07;new_cr=8'h00;
        save_h=2728;save_v=262;load_h=0;load_v=0;
        save_extra=0;load_extra=1;
      end
      11: begin
        rvbl=1;old_cr=8'h03;new_cr=8'h05;
        save_h=0;save_v=0;load_h=2728;load_v=262;
        save_extra=H*263+19;load_extra=2*H*263+37;
      end
      12: begin
        rvbl=1;old_cr=8'h00;new_cr=8'h03;
        save_h=46;save_v=19;load_h=238;load_v=3;
        save_extra=H-7;load_extra=H+13;
      end
      13: begin
        rvbl=0;old_cr=8'h07;new_cr=8'h02;
        save_h=0;save_v=3;load_h=2729;load_v=261;
        save_extra=20;load_extra=1048;
      end
      default:$fatal(1,"unknown extended scenario");
    endcase
    old_lines=old_cr[2]?263:262;new_lines=new_cr[2]?263:262;
    $display("CONDITIONS scenario=%0d RVBL=%0d old_dotclock=%0d old_lines=%0d new_dotclock=%0d new_lines=%0d save=(%0d,%0d) load=(%0d,%0d) save_extra=%0d load_extra=%0d",scenario,rvbl,old_cr[1:0],old_lines,new_cr[1:0],new_lines,save_v,save_h,load_v,load_h,save_extra,load_extra);$fflush();
    repeat(8)tick;reset_n=1;write_cr(old_cr);
    repeat(2*H*263)tick;checking=1;
    if(phase[51]!==rvbl || phase[33:32]!==old_cr[1:0] || phase[31:22]!=old_lines)$fatal(1,"initial mode fixture incorrect");
    while(!(phase[21:12]==save_v && phase[11:0]==save_h))tick;
    request=1;tick;save=1;tick;save=0;repeat(4)tick;saved_phase=phase;
    for(i=0;i<10;i=i+1)begin ra=2+i;#0.1;image[i]=rdo;rotate=1;tick;rotate=0;end
    repeat(save_extra)tick;request=0;wait(!busy);tick;
    $display("SAVE_RESUMED scenario=%0d cycle=%0d",scenario,cycles);$fflush();
    while(!(phase[21:12]==80 && phase[11:0]==1000))tick;
    write_cr(new_cr);repeat(2*H*263)tick;
    if(phase[51]!==rvbl || phase[33:32]!==new_cr[1:0] || phase[31:22]!=new_lines)$fatal(1,"changed mode fixture incorrect");
    while(!(phase[21:12]==load_v && phase[11:0]==load_h))tick;
    request=1;tick;repeat(20)tick;
    for(i=0;i<10;i=i+1)begin ra=2+i;rdi=image[i];rwe=1;tick;rwe=0;end
    load=1;tick;load=0;tick;
    if(phase!==saved_phase)$fatal(1,"loaded presentation state differs from saved image");
    repeat(load_extra)tick;request=0;wait(!busy);tick;
    $display("LOAD_RESUMED scenario=%0d cycle=%0d",scenario,cycles);$fflush();
    repeat(H*263)tick;
    if(resumes!=2||raw_fields<4||out_fields<4)$fatal(1,"incomplete coverage");
    $display("NATIVE_MAX_SAMPLING_ERROR video_clocks H_period=%0d H_width=%0d V_period=%0d V_width=%0d",max_h_error,max_h_width_error,max_v_error,max_v_width_error);
    $display("PASS extended actual VCE native video phase scenario=%0d live_checks=%0d resumes=%0d raw_lines=%0d raw_fields=%0d output_lines=%0d output_fields=%0d",scenario,live_checks,resumes,raw_lines,raw_fields,out_lines,out_fields);$finish;
  end
  initial begin #120000000;$fatal(1,"test watchdog");end
endmodule
// Unselected scandoubler output is irrelevant to this explicitly native path
// bench. Its real RTL remains part of full-project compilation/qualification.
module scandoubler #(parameter LENGTH=560,HALF_DEPTH=0)(input clk_vid,hq2x,ce_pix,hs_in,vs_in,hb_in,vb_in,input[7:0]r_in,g_in,b_in,output ce_pix_out,hs_out,vs_out,hb_out,vb_out,output[7:0]r_out,g_out,b_out);
  assign {ce_pix_out,hs_out,vs_out,hb_out,vb_out,r_out,g_out,b_out}={ce_pix,hs_in,vs_in,hb_in,vb_in,r_in,g_in,b_in};
endmodule
