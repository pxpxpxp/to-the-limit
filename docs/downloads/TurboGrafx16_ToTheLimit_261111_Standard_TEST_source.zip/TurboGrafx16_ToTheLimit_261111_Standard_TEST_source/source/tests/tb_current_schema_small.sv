`timescale 1ns/1ps
module tb_current_schema_small;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;reg [31:0] rom_id=32'h1234abcd;reg [15:0] config_id=16'h42;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,reg_rotate,take_ddr,ram_rd,ram_we;
 wire [3:0] error;wire [17:0] scan_addr;reg [15:0] scan_dout=0;wire [15:0] scan_din;
 wire [16:0] adpcm_addr;wire [3:0] adpcm_din;wire adpcm_we;reg [3:0] adpcm_dout=0;
 wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;
 reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;
 reg [7:0] cd0[0:31],cd1[0:31];integer cd_delay=0;reg cd_pending=0,cd_pending_write=0,cd_block=0;
 reg [17:0] cd_pending_addr=0;reg [7:0] cd_pending_data=0;
 reg normal_idle=1;reg ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;wire [28:0] ram_addr;wire [63:0] ram_din;
 localparam RM=5,AM=8,CM=4,RG=4,CG=(RM+RG+3)/4,N=CG+AM+CM;
 wire start_block=0;
 // Optional rewind ports: retain the legacy snapshot profile.
 wire private_mode=1'b0;wire [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 ninja_savestate #(.RAM_WORDS(RM),.ADPCM_WORDS(AM),.CDRAM_WORDS(CM),.REGISTER_WORDS(RG)) dut(.manual_stage_allowed(1'b0),.*);
 reg [15:0] live[0:7],regs[0:3];reg [3:0] a0[0:127],a1[0:127];reg bank=0;
 reg [63:0] ddr[0:262143];integer i,j,k,r,fd,ticks=0,pending=0,delay_left=0,writes=0,adwrites=0;reg expect_fault=0;reg [63:0] backup,checkword;reg [31:0] checksum;integer cbit,cbyte;
 function [3:0] pat(input integer idx,input integer variant);pat=(idx^(idx>>3)^(variant*7))&15;endfunction
 always @(posedge clk) begin
  scan_dout <= scan_addr[17:15]==6 ? regs[0] : live[scan_addr[2:0]];
  adpcm_dout <= bank ? a1[adpcm_addr] : a0[adpcm_addr];
  if(scan_we) begin
   if(!freeze)$fatal(1,"scan write outside freeze");
   if(scan_addr[17:15]==6)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=scan_din;end
   else live[scan_addr[2:0]]<=scan_din;
   writes<=writes+1;
  end
  if(reg_rotate)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=regs[0];end
  if(adpcm_we)begin
   if(!freeze)$fatal(1,"ADPCM write outside freeze");
   if(bank)a0[adpcm_addr]<=adpcm_din;else a1[adpcm_addr]<=adpcm_din;
   adwrites<=adwrites+1;
  end
  if(load_pulse)bank<=!bank;
  if(fault_reset && !expect_fault)$fatal(1,"unexpected fault reset");
 end
 always @(negedge ram_clk)begin ticks=ticks+1;ram_busy=((ticks%11)<3);end
 always @(posedge ram_clk)begin
  if(cd_ram_req!=cd_ram_ack && cd_delay==0)begin cd_pending<=cd_ram_req;cd_pending_write<=cd_ram_write;cd_pending_addr<=cd_ram_addr;cd_pending_data<=cd_ram_din;cd_delay<=3+(ticks%7);end
  else if(cd_delay!=0 && !cd_block)begin
   if(cd_ram_addr!==cd_pending_addr||cd_ram_din!==cd_pending_data||cd_ram_write!==cd_pending_write)$fatal(1,"CD mailbox changed before ack");
   cd_delay<=cd_delay-1;
   if(cd_delay==1)begin
    if(cd_pending_write)begin if(bank)cd0[cd_pending_addr]<=cd_pending_data;else cd1[cd_pending_addr]<=cd_pending_data;end
    else cd_ram_dout<=bank?cd1[cd_pending_addr]:cd0[cd_pending_addr];
    cd_ram_ack<=cd_pending;
   end
  end
 end
 always @(posedge ram_clk)begin
  ram_ready<=0;
  if(delay_left!=0)begin delay_left<=delay_left-1;if(delay_left==1)begin ram_dout<=ddr[pending];ram_ready<=1;end end
  if((ram_we||ram_rd)&&!ram_busy)begin
   if(!take_ddr)$fatal(1,"DDR ownership");
   if(ram_we)ddr[ram_addr-29'h7e00000]<=ram_din;
   if(ram_rd)begin pending<=ram_addr-29'h7e00000;delay_left<=2+(ticks%5);end
  end
 end
 task fill(input integer v);begin
  for(i=0;i<RM;i=i+1)live[i]=16'h1100+i+v;
  for(i=0;i<RG;i=i+1)regs[i]=16'h2200+i+v;
  for(i=0;i<128;i=i+1)if(bank)a1[i]=pat(i,v);else a0[i]=pat(i,v);
  for(i=0;i<32;i=i+1)if(bank)cd1[i]=8'(i^(v*37));else cd0[i]=8'(i^(v*37));
 end endtask
 task check(input integer v);begin
  for(i=0;i<RM;i=i+1)if(live[i]!==16'h1100+i+v)$fatal(1,"RAM %0d",i);
  for(i=0;i<RG;i=i+1)if(regs[i]!==16'h2200+i+v)$fatal(1,"REG %0d",i);
  for(i=0;i<128;i=i+1)if((bank?a1[i]:a0[i])!==pat(i,v))$fatal(1,"ADPCM %0d",i);
  for(i=0;i<32;i=i+1)if((bank?cd1[i]:cd0[i])!==8'(i^(v*37)))$fatal(1,"CD RAM %0d",i);
 end endtask
 task save;begin wait(!busy);@(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);if(error)$fatal(1,"save err %0d",error);end endtask
 task load;begin wait(!busy);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);end endtask
 initial begin
  for(i=0;i<262144;i=i+1)ddr[i]=0;
  repeat(4)@(negedge clk);reset=0;
  for(k=0;k<4;k=k+1) begin slot=k;fill(k+1);save();end
  // Write the precise MiSTer binary image for independent CRC inspection.
  fd=$fopen("adpcm_small.ss","wb");if(!fd)$fatal(1,"file open");
  for(i=0;i<N+5;i=i+1)for(j=0;j<8;j=j+1)$fwrite(fd,"%c",ddr[3*65536+i][j*8+:8]);
  $fclose(fd);
  for(k=0;k<4;k=k+1) begin fill(7);slot=k;load();if(error)$fatal(1,"load %0d err %0d",k,error);check(k+1);end
  slot=1;
  // Header must carry the actual new default schema and reject older images.
  if(ddr[65536+2]!==64'h7b4a4831e0d369a8)$fatal(1,"wrong default schema");
  backup=ddr[65536+2];ddr[65536+2]=64'ha58e5a8c9764267f;
  r=writes;i=adwrites;load();if(error!=3||writes!=r||adwrites!=i)$fatal(1,"prior guarded schema was not rejected safely");
  ddr[65536+2]=64'ha3cc2ac4db47f0ab;
  r=writes;i=adwrites;load();if(error!=3||writes!=r||adwrites!=i)$fatal(1,"earlier v3 swap schema was not rejected safely");
  ddr[65536+2]=64'h0d1868ea0f16826d;
  r=writes;i=adwrites;load();if(error!=3||writes!=r||adwrites!=i)$fatal(1,"earlier v2 swap schema was not rejected safely");
  ddr[65536+2]=64'h6525bc50c15dfae9;
  r=writes;i=adwrites;load();if(error!=3||writes!=r||adwrites!=i)$fatal(1,"earlier unshipped swap schema was not rejected safely");
  ddr[65536+2]=64'h41b8fbf1bfeadf72;
  r=writes;i=adwrites;load();if(error!=3||writes!=r||adwrites!=i)$fatal(1,"older schema was not rejected safely");
  ddr[65536+2]=backup;
  // A high ADPCM nibble is protected by CRC, and rejected before any apply.
  backup=ddr[65536+5+CG+3];ddr[65536+5+CG+3]=backup^64'h1000000000000000;
  r=writes;i=adwrites;load();if(error!=6||writes!=r||adwrites!=i)$fatal(1,"bad packed CRC applied state");
  ddr[65536+5+CG+3]=backup;
  backup=ddr[65536+5+CG+AM+3];ddr[65536+5+CG+AM+3]=backup^64'h8000000000000000;
  r=writes;i=adwrites;load();if(error!=6||writes!=r||adwrites!=i)$fatal(1,"bad packed CD CRC applied state");
  ddr[65536+5+CG+AM+3]=backup;
  // Nonzero unused padding must reject even if its CRC was recomputed correctly.
  backup=ddr[65536+5+CG-1];checkword=ddr[65536+4];
  ddr[65536+5+CG-1]=backup^64'h1000000000000000;
  checksum=32'hffffffff;
  for(cbyte=0;cbyte<N*8;cbyte=cbyte+1)
   for(cbit=0;cbit<8;cbit=cbit+1)
    checksum=(checksum>>1)^(((checksum[0]^ddr[65536+5+cbyte/8][8*(cbyte%8)+cbit])!=0)?32'hedb88320:0);
  ddr[65536+4]={32'(N),~checksum};r=writes;i=adwrites;load();
  if(error!=8||writes!=r||adwrites!=i)$fatal(1,"nonzero padding not rejected");
  ddr[65536+5+CG-1]=backup;ddr[65536+4]=checkword;
  // Abort after staging begins: active bank remains unchanged, then retry.
  fill(7);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(adpcm_we);
  repeat(6)@(negedge clk);expect_fault=1;enabled=0;@(negedge clk);
  if(!fault_reset)$fatal(1,"aborted apply lacked reset");enabled=1;repeat(10)@(negedge clk);expect_fault=0;
  for(i=0;i<128;i=i+1)if((bank?a1[i]:a0[i])!==pat(i,7))$fatal(1,"abort changed active ADPCM %0d",i);
  load();if(error)$fatal(1,"retry err %0d",error);check(2);
  // Abort a stalled CD stage request: ownership remains held until its ack.
  fill(7);@(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(cd_ram_write && cd_ram_req!=cd_ram_ack);cd_block=1;@(negedge clk);expect_fault=1;enabled=0;@(negedge clk);
  if(!fault_reset||!cd_ram_hold)$fatal(1,"CD abort did not hold outstanding request");
  repeat(12)@(negedge clk);if(!cd_ram_hold)$fatal(1,"CD ownership released before ack");
  cd_block=0;wait(!cd_ram_hold);@(negedge clk);enabled=1;repeat(12)@(negedge clk);expect_fault=0;
  for(i=0;i<32;i=i+1)if((bank?cd1[i]:cd0[i])!==8'(i^(7*37)))$fatal(1,"CD abort changed active RAM");
  load();if(error)$fatal(1,"CD retry err %0d",error);check(2);
  $display("PASS: current-schema compact core/ADPCM/CD RAM controller four slots, binary image, high-bit CRC, atomic abort/retry");$finish;
 end
 initial begin #5000000;$fatal(1,"timeout");end
endmodule
