`timescale 1ns/1ps
module tb_video_frame_replay_e2e;
 parameter integer LINE_CLOCKS=120, LINES=8;
 parameter integer RANDOM_STALLS=1;
 parameter integer FREEZE_SWEEPS=0;
 parameter integer INITIAL_PUBLICATIONS=5;
 parameter integer STARVE_CAPTURE=0;
 localparam integer WORDS=LINE_CLOCKS/6;
 localparam [28:0] BASE=29'h07a00000, STRIDE=29'h00020000;
 reg clk=0,reset=0,enabled=1,freeze=0;
 reg [51:0] source_phase=0,reference_phase=0;
 reg [9:0] pixel_in=0;
 wire [9:0] pixel_out;
 wire reference_ce,reference_hs,reference_vs,reference_hbl,reference_vbl;
 wire frame_valid,replay_valid,underflow,capture_fault;
 wire [28:0] video_addr;
 wire [63:0] video_din,video_dout;
 wire [7:0] video_burst;
 wire video_rd,video_we,video_busy,video_ready;
 reg [28:0] primary_addr=29'h06000000;
 reg [63:0] primary_din=64'h123456789abcdef0;
 reg [7:0] primary_byteenable=8'h69,primary_burst=1;
 reg primary_rd=0,primary_we=0,primary_idle=1,primary_pulse_read=1;
 wire primary_busy,primary_ready;
 wire [63:0] primary_dout;
 wire [28:0] ddr_addr;
 wire [63:0] ddr_din;
 wire [7:0] ddr_burst,ddr_byteenable;
 wire ddr_rd,ddr_we;
 reg ddr_busy=0,ddr_ready=0;
 reg [63:0] ddr_dout=0;
 video_frame_replay #(.LINE_CLOCKS(LINE_CLOCKS),.MAX_LINES(LINES),.READ_BURST(32)) dut(
  .clk(clk),.reset(reset),.enabled(enabled),.freeze(freeze),
  .source_phase(source_phase),.reference_phase(reference_phase),.pixel_in(pixel_in),
  .pixel_out(pixel_out),.reference_ce(reference_ce),.reference_hs(reference_hs),
  .reference_vs(reference_vs),.reference_hbl(reference_hbl),.reference_vbl(reference_vbl),
  .frame_valid(frame_valid),.replay_valid(replay_valid),.underflow(underflow),.capture_fault(capture_fault),
  .ram_addr(video_addr),.ram_din(video_din),.ram_burst(video_burst),.ram_rd(video_rd),.ram_we(video_we),
  .ram_busy(video_busy),.ram_ready(video_ready),.ram_dout(video_dout));
 video_ddr_arbiter arb(.*);
 reg [63:0] memory [0:393215];
 integer bank_fid [0:2];
 integer bank_writes [0:2];
 integer reference_lines=LINES, dot_mode=0;
 integer sh=0,sv=0,rh=0,rv=0,fid=1,ref_fid=1,phase_div=0;
 integer cycles=0,writes=0,read_commands=0,read_beats=0,primary_reads=0,primary_writes=0;
 integer publications=0,checked_replay=0,blank_misses=0,active_misses=0;
 integer pending=0,read_address=0,pending_owner=0;
 integer seed=32'h123767,n,k,old_bank=-1,old_valid=0;
 integer bank,offset,line_no,word_no,owner_now,accepted,responded;
 integer sweep,target_h;
 integer exp_fid,exp_h,exp_v,exp_live,exp_freeze,exp_valid;
 // Independent second-stage oracle. These are the previous sampled inputs,
 // not DUT pipeline registers; no sample/first-active-pixel is skipped.
 integer qexp_fid=0,qexp_h=0,qexp_v=0,qexp_live=0;
 reg qexp_freeze=0,qexp_valid=0,qcheck_frozen=0;
 reg [4:0] qexp_timing=5'b00011;
 reg [63:0] expect_word;
 reg p_wait=0,source_runs=1,stress_primary=1,force_busy=0,force_response_pause=0;
 reg check_frozen=0;
 reg publication_collision_hold=0, publication_collision_done=0;
 reg exp_publication=0;
 integer last_cap_bank=-1;
 function automatic [9:0] pattern(input integer f,input integer v,input integer h);
  // Every output bit, including BW, depends on physical position and frame.
  pattern=((h*37) ^ (v*119) ^ (f*277) ^ (h>>4) ^ (v<<3)) & 1023;
 endfunction
 function automatic [63:0] read_memory(input integer addr);
  if(addr>=BASE && addr<BASE+3*STRIDE) read_memory=memory[addr-BASE];
  else read_memory=64'h13579bdf2468ace0 ^ addr;
 endfunction
 function automatic [51:0] phase(input integer h,input integer v);
  reg [51:0] p;
  begin
   p=0; p[11:0]=h; p[21:12]=v; p[31:22]=LINES;
   p[33:32]=dot_mode; p[38]=(h%((dot_mode==0)?8:((dot_mode==1)?6:4)))==0; p[47]=(h<LINE_CLOCKS/8 || h>=LINE_CLOCKS*7/8);
   p[48]=(v<2 || v>=LINES-1); p[49]=(h<8); p[50]=(v==0);
   phase=p;
  end
 endfunction
 task tick;
  begin
   source_phase=phase(sh,sv); reference_phase=phase(rh,rv);
   reference_phase[31:22]=reference_lines;
   pixel_in=pattern(fid,sv,sh);
   primary_idle=!p_wait && !primary_rd && !primary_we;
   ddr_busy=force_busy || (RANDOM_STALLS && (($random(seed)&15)<3));
   #1;
   // Drive response combinationally before the sampling edge, including a
   // true same-cycle first beat on selected command acceptances.
   ddr_ready=0; ddr_dout=0;
   if(pending>0 && (!force_response_pause || pending_owner==1) && (!RANDOM_STALLS || (($random(seed)&7)!=0))) begin
    ddr_ready=1; ddr_dout=read_memory(read_address);
   end else if(pending==0 && ddr_rd && !ddr_busy && (!force_response_pause || ddr_addr<BASE || ddr_addr>=BASE+3*STRIDE) &&
               (!RANDOM_STALLS || (($random(seed)&3)==0))) begin
    ddr_ready=1; ddr_dout=read_memory(ddr_addr);
   end
   // Once a candidate is fully drained, legally stall the final beat of a
   // prefetch until the next publication edge. This explicitly exercises
   // cache invalidation winning over a coincident line-valid assignment.
   if(!publication_collision_done && dut.cap_state==3 && pending>0 &&
      pending_owner==2 && dut.read_word+dut.ram_burst==WORDS && dut.beats_left==1)
    publication_collision_hold=1;
   if(publication_collision_hold) begin
    ddr_ready=dut.source_boundary;
    ddr_dout=read_memory(read_address);
   end
   #1;
   exp_publication=dut.start_capture && dut.cap_state==3;
   if(exp_publication && publication_collision_hold) begin
    if(!ddr_ready || pending!=1 || dut.beats_left!=1)
     $fatal(1,"publication collision was not a final read completion");
    publication_collision_hold=0; publication_collision_done=1;
   end
   exp_h=rh; exp_v=rv; exp_live=pixel_in; exp_freeze=freeze;
   exp_valid=dut.current_line_valid && !reset && enabled;
   exp_fid=bank_fid[dut.front_bank];
   accepted=(ddr_rd || ddr_we) && !ddr_busy;
   responded=ddr_ready;
   if(dut.start_capture) begin
    bank_fid[dut.starting_bank]=fid;
    bank_writes[dut.starting_bank]=0;
    last_cap_bank=dut.starting_bank;
   end
   if(accepted) begin
    if(pending) $fatal(1,"DDR command overlaps an outstanding response");
    owner_now=(ddr_addr>=BASE && ddr_addr<BASE+3*STRIDE) ? 2 : 1;
    if(owner_now==2 && !primary_busy) $fatal(1,"primary not blocked during video ownership");
    if(owner_now==1 && (video_rd || video_we) && !video_busy) $fatal(1,"both clients accepted");
    if(ddr_rd) begin
     pending=ddr_burst; read_address=ddr_addr; pending_owner=owner_now;
     if(owner_now==2) read_commands=read_commands+1;
    end else if(owner_now==2) begin
     if(!video_we || video_busy) $fatal(1,"video acceptance mismatch");
     if(ddr_byteenable!==8'hff || ddr_burst!=1) $fatal(1,"bad video write byteenable/burst");
     offset=ddr_addr-BASE; bank=offset/STRIDE; offset=offset%STRIDE;
     if(offset>=LINES*WORDS) $fatal(1,"video wrote outside its frame, including snapshot region");
     line_no=offset/WORDS; word_no=offset%WORDS;
     expect_word=0;
     for(k=0;k<6;k=k+1) expect_word[k*10 +: 10]=pattern(bank_fid[bank],line_no,word_no*6+k);
     if(ddr_din!==expect_word) $fatal(1,"packed pixel mismatch cycle=%0d bank=%0d frame=%0d line=%0d word=%0d got=%h expected=%h",cycles,bank,bank_fid[bank],line_no,word_no,ddr_din,expect_word);
     memory[ddr_addr-BASE]=ddr_din;
     bank_writes[bank]=bank_writes[bank]+1; writes=writes+1;
    end else begin
     if(ddr_addr!==primary_addr || ddr_din!==primary_din || ddr_byteenable!==primary_byteenable)
      $fatal(1,"primary write changed during arbitration");
     primary_writes=primary_writes+1;
    end
   end
   if(primary_ready !== (responded && pending>0 && pending_owner==1)) $fatal(1,"primary response ownership lost");
   if(video_ready !== (responded && pending>0 && pending_owner==2)) $fatal(1,"video response ownership lost");
   if(primary_ready) begin
    if(primary_dout!==(64'h13579bdf2468ace0 ^ primary_addr)) $fatal(1,"wrong primary response");
    p_wait=0; primary_reads=primary_reads+1;
   end
   if(responded) begin
    if(pending<=0) $fatal(1,"model response without owner");
    if(pending_owner==2) read_beats=read_beats+1;
    pending=pending-1; read_address=read_address+1;
   end
   #1; clk=1; #1; clk=0;
   if(exp_publication && dut.line_valid!==2'b00)
    $fatal(1,"publication retained old-generation replay cache validity");
   cycles=cycles+1;
   if(LINE_CLOCKS>1000 && cycles%1000000==0) $display("INFO full-geometry progress cycles=%0d publications=%0d writes=%0d replay_pixels=%0d",cycles,publications,writes,checked_replay);
   if({reference_ce,reference_hs,reference_vs,reference_hbl,reference_vbl}!==qexp_timing)
    $fatal(1,"two-stage timing/control delay changed physical position");
   if(replay_valid!==qexp_valid) $fatal(1,"two-stage replay validity/reset latency mismatch");
   if(!qexp_freeze && pixel_out!==qexp_live) $fatal(1,"live path pixel/control mismatch");
   if(qexp_freeze && replay_valid) begin
    if(pixel_out!==pattern(qexp_fid,qexp_v,qexp_h)) $fatal(1,"replay pixel mismatch cycle=%0d frame=%0d h=%0d v=%0d got=%h want=%h",cycles,qexp_fid,qexp_h,qexp_v,pixel_out,pattern(qexp_fid,qexp_v,qexp_h));
    checked_replay=checked_replay+1;
   end
   if(qexp_freeze && !replay_valid && pixel_out!==10'd0) $fatal(1,"invalid replay did not fall back to black");
   if(qexp_freeze && qcheck_frozen && !replay_valid) begin
    if(reference_hbl || reference_vbl) blank_misses=blank_misses+1;
    else begin
     active_misses=active_misses+1;
     $fatal(1,"first/steady active frozen pixel missing at H=%0d V=%0d",qexp_h,qexp_v);
    end
   end
   qexp_h=exp_h; qexp_v=exp_v; qexp_live=exp_live;
   qexp_freeze=exp_freeze; qexp_valid=exp_valid; qexp_fid=exp_fid;
   qcheck_frozen=check_frozen;
   qexp_timing={reference_phase[38],~reference_phase[49],~reference_phase[50],reference_phase[47],reference_phase[48]};
   if(frame_valid && (!old_valid || old_bank!=dut.front_bank)) begin
    if(bank_writes[dut.front_bank]!=LINES*WORDS) $fatal(1,"published undrained/partial frame bank=%0d words=%0d expected=%0d",dut.front_bank,bank_writes[dut.front_bank],LINES*WORDS);
    publications=publications+1;
   end
   old_bank=dut.front_bank; old_valid=frame_valid;
   primary_rd=0;
   if(primary_we && !primary_busy && accepted && owner_now==1) primary_we=0;
   if(stress_primary && !primary_busy && !p_wait && !primary_we && cycles%37==0) begin
    primary_addr=29'h06000000+(cycles%16384);
    if(cycles%111==0) primary_we=1;
    else begin primary_rd=1; p_wait=1; end
   end
   phase_div=phase_div+1;
   if(phase_div==2) begin
    phase_div=0;
    if(source_runs) begin
     if(sh==LINE_CLOCKS-1) begin sh=0; if(sv==LINES-1) begin sv=0; fid=fid+1; end else sv=sv+1; end
     else sh=sh+1;
    end
    if(rh==LINE_CLOCKS-1) begin rh=0; if(rv==reference_lines-1) begin rv=0; ref_fid=ref_fid+1; end else rv=rv+1; end
    else rh=rh+1;
   end
  end
 endtask
 task run_cycles(input integer count); integer j; begin for(j=0;j<count;j=j+1) tick(); end endtask
 task wait_publication(input integer target); integer limit; begin
  limit=cycles+LINE_CLOCKS*LINES*12*(target-publications);
  while(publications<target && cycles<limit) tick();
  if(publications<target) $fatal(1,"no complete frame published cap=%0d fault=%b words=%0d",dut.cap_state,capture_fault,writes);
 end endtask
 initial begin
  for(n=0;n<3;n=n+1) begin bank_fid[n]=0; bank_writes[n]=0; end
  // First fully drained publication; no hand-crafted internal RAM/state.
  wait_publication(INITIAL_PUBLICATIONS);
  if(INITIAL_PUBLICATIONS>1 && !publication_collision_done)
   $fatal(1,"publication/read-completion collision was not exercised");
  $display("INFO initial publication: geometry=%0dx%0d cycles=%0d writes=%0d",LINE_CLOCKS,LINES,cycles,writes);
  // Warm prefetch then freeze partway through a newly started partial field.
  run_cycles(LINE_CLOCKS*6+LINE_CLOCKS/3+17);
  if(dut.cap_state!=1) $fatal(1,"partial-freeze test did not interrupt CAP_RUN");
  freeze=1; source_runs=0; check_frozen=1;
  run_cycles(LINE_CLOCKS*LINES*6); check_frozen=0;
  if(active_misses) $fatal(1,"steady frozen active-pixel underflow: %0d samples, blank misses=%0d",active_misses,blank_misses);
  if(capture_fault) $fatal(1,"capture bandwidth fault with nominal test memory");
  if(checked_replay==0) $fatal(1,"no replay pixels checked");
  for(sweep=0;sweep<FREEZE_SWEEPS;sweep=sweep+1) begin
   freeze=0; source_runs=1;
   wait_publication(publications+1);
   // Warm both physical-line buffers before testing an arbitrary H edge.
   run_cycles(LINE_CLOCKS*4);
   case(sweep%6)
    0: target_h=0;
    1: target_h=1;
    2: target_h=5;
    3: target_h=6;
    4: target_h=LINE_CLOCKS-1;
    default: target_h=LINE_CLOCKS/2;
   endcase
   while(rh!=target_h) tick();
   freeze=1; source_runs=0; check_frozen=1;
   run_cycles(LINE_CLOCKS*LINES*4); check_frozen=0;
   if(active_misses) $fatal(1,"arbitrary-H freeze underflow at H=%0d, %0d samples",target_h,active_misses);
  end
  // Dot-mode changes alter CE but must never reindex stored physical pixels.
  // Change only the presentation field length while the source is held, as
  // happens when a restored VCE switches its legal 262/263-line geometry.
  for(sweep=0;sweep<3;sweep=sweep+1) begin
   while(rh!=0 || rv!=0) tick();
   dot_mode=sweep; reference_lines=(sweep==1) ? LINES-1 : LINES;
   check_frozen=1; run_cycles(LINE_CLOCKS*LINES*4); check_frozen=0;
   if(active_misses) $fatal(1,"dot-mode/field-length change caused active underflow");
  end
  reference_lines=LINES;
  // Reset while an accepted video burst is pending. Pause DDR responses so
  // reset cannot accidentally coincide only with a command gap.
  force_response_pause=1;
  n=cycles+LINE_CLOCKS*LINES*4;
  while(!(pending>0 && pending_owner==2) && cycles<n) tick();
  if(!(pending>0 && pending_owner==2)) $fatal(1,"could not stage pending video read");
  reset=1; run_cycles(9); reset=0; force_response_pause=0;
  run_cycles(LINE_CLOCKS*LINES*2);
  if(frame_valid || replay_valid) $fatal(1,"reset revived stale replay");
  if(pending) $fatal(1,"accepted read did not drain after reset");
  // Re-enable capture, then reset an asserted write held under waitrequest.
  freeze=0; source_runs=1;
  n=cycles+LINE_CLOCKS*LINES*8;
  while(!video_we && cycles<n) tick();
  if(!video_we) $fatal(1,"could not stage pending video write");
  force_busy=1; reset=1; run_cycles(13); reset=0; force_busy=0;
  run_cycles(LINE_CLOCKS*LINES*2);
  if(frame_valid) $fatal(1,"reset partial capture was published");
  wait_publication(publications+1);
  if(STARVE_CAPTURE) begin
   // Provoke a real line-buffer overrun. The previously published frame must
   // survive, and the damaged candidate must never become the front frame.
   old_bank=dut.front_bank; n=publications;
   force_busy=1; run_cycles(LINE_CLOCKS*8); force_busy=0;
   if(!capture_fault) $fatal(1,"capture starvation failed to raise diagnostic");
   freeze=1; source_runs=0; run_cycles(LINE_CLOCKS*LINES*2);
   if(!frame_valid || dut.front_bank!=old_bank || publications!=n)
    $fatal(1,"starved partial capture replaced valid front frame");
   freeze=0; source_runs=1;
   wait_publication(publications+1);
  end
  $display("PASS video_frame_replay e2e geometry=%0dx%0d random=%0d cycles=%0d publications=%0d writes=%0d video_reads=%0d video_beats=%0d primary_reads=%0d primary_writes=%0d replay_pixels=%0d blank_misses=%0d",LINE_CLOCKS,LINES,RANDOM_STALLS,cycles,publications,writes,read_commands,read_beats,primary_reads,primary_writes,checked_replay,blank_misses);
  $finish;
 end
endmodule
