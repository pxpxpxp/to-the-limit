`timescale 1ns/1ps
// Production ddram/cache and snapshot controller with behavioral internal RAM.
// Not an Altera primitive model, full-core test, or timing analysis.
module tb_ddr_real_integration;
reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
reg [1:0] slot=0;reg [31:0] rom_id=32'h1234;reg [15:0] config_id=0;
wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,reg_rotate;
wire [3:0] error;wire [17:0] scan_addr;wire [15:0] scan_din;reg [15:0] scan_dout=0;
wire [28:0] ss_addr;wire [63:0] ss_data;wire ss_rd,ss_we;
reg busy=0,ready=0;reg [63:0] dout=0;
wire [7:0] norm_burst,norm_be;wire [28:0] norm_addr;wire [63:0] norm_data;wire norm_rd,norm_we,normal_idle;
reg clkref=0,we_req=0,we=0,rd=0;reg [27:0] wraddr=0,rdaddr=0;reg [15:0] din=16'h1234;
wire we_rdy,we_ack,rd_rdy;wire [7:0] normal_dout;
wire physical_rd=take_ddr ? ss_rd : norm_rd;
wire physical_we=take_ddr ? ss_we : norm_we;
wire snapshot_busy;
ninja_savestate snap(.busy(snapshot_busy),.start_block(1'b0),.clk(clk),.ram_clk(ram_clk),.reset(reset),.enabled(enabled),.safe(safe),
 .save_button(save_button),.load_button(load_button),.slot(slot),.rom_id(rom_id),.config_id(config_id),
 .freeze(freeze),.save_pulse(save_pulse),.load_pulse(load_pulse),.valid(valid),.fault_reset(fault_reset),.error(error),
 .scan_addr(scan_addr),.scan_dout(scan_dout),.scan_din(scan_din),.scan_we(scan_we),.reg_rotate(reg_rotate),
 .normal_idle(normal_idle),.ram_busy(busy),.ram_ready(ready),.ram_dout(dout),.take_ddr(take_ddr),
 .ram_addr(ss_addr),.ram_din(ss_data),.ram_rd(ss_rd),.ram_we(ss_we));
ddram normal(.DDRAM_CLK(ram_clk),.DDRAM_BUSY(busy|take_ddr),.DDRAM_BURSTCNT(norm_burst),.DDRAM_ADDR(norm_addr),
 .DDRAM_DOUT(dout),.DDRAM_DOUT_READY(ready & !take_ddr),.DDRAM_RD(norm_rd),.DDRAM_DIN(norm_data),.DDRAM_BE(norm_be),.DDRAM_WE(norm_we),
 .clkref(clkref),.wraddr(wraddr),.din(din),.we(we),.we_rdy(we_rdy),.we_req(we_req),.we_ack(we_ack),
 .rdaddr(rdaddr),.dout(normal_dout),.rd(rd),.rd_rdy(rd_rdy),.idle(normal_idle));
integer normal_reads=0,normal_writes=0;
always @(posedge ram_clk) begin
 if(!take_ddr && physical_rd && !busy) normal_reads<=normal_reads+1;
 if(!take_ddr && physical_we && !busy) begin normal_writes<=normal_writes+1; $display("normal write accepted %t count %0d",$time,normal_writes+1);end
end
task pulse_save; begin wait(!snapshot_busy);@(negedge clk);$display("save trigger %t state=%0d req=%b ack=%b en=%b reset=%b",$time,snap.state,snap.req,snap.ack_sync,enabled,reset);save_button=1;@(negedge clk);save_button=0;wait(freeze);end endtask
task pulse_reset; begin @(negedge clk);reset=1;repeat(2)@(negedge clk);reset=0;wait(!freeze);wait(!take_ddr);end endtask
initial begin
 // FPGA power-up model for the original ddram's uninitialized ack; then a
 // real write toggles it and resets/initializes the production cache.
 force normal.we_ack=0;repeat(3)@(negedge ram_clk);release normal.we_ack;
 @(negedge ram_clk);we_req=1;wait(we_ack==1);wait(norm_we);@(posedge ram_clk);@(negedge ram_clk);
 $display("initial write acknowledged %t",$time);wait(normal.cache.cache_init_done);$display("cache initialized %t",$time);wait(normal_idle);reset=0;
 // Start a production cache miss before save-state arbitration.
 @(negedge ram_clk);rd=1;clkref=1;repeat(3)@(negedge ram_clk);clkref=0;
 wait(norm_rd);$display("normal miss emitted %t",$time);@(posedge ram_clk);@(negedge ram_clk);rd=0;
 pulse_save();$display("freeze reached %t",$time);repeat(40) begin @(negedge ram_clk);if(take_ddr)$fatal(1,"took DDR while normal read pending");end
 // Deliver the delayed normal reply to its cache. Only once fully idle may
 // the snapshot owner acquire the bus.
 dout=64'habcdef0123456789;ready=1;@(negedge ram_clk);ready=0;
 wait(normal_idle);$display("normal idle after reply %t",$time);wait(take_ddr);$display("snapshot granted %t",$time);if(normal_reads!=1)$fatal(1,"normal cache read not issued exactly once");
 pulse_reset();
 // On the next acquisition, enqueue a normal write just after freeze has
 // synchronized, but before its grant edge. The production idle qualifier
 // must suppress grant and let the write reach the DDR master first.
 wait(normal_idle);$display("second scenario %t",$time);pulse_save();wait(snap.freeze_sync);@(negedge ram_clk);
 if(take_ddr)$fatal(1,"ownership unexpectedly granted before race setup");
 we_req=~we_req;
 repeat(2) @(negedge ram_clk);
 if(take_ddr)$fatal(1,"ownership seized over queued normal write");
 wait(we_ack==we_req);wait(normal_idle);
 wait(take_ddr);if(normal_writes!=2)$fatal(1,"normal write lost, count=%0d",normal_writes);
 // Once a snapshot read has been accepted, enqueue a normal download write
 // and abort. Its ack must wait until the snapshot response has drained.
 wait(ss_rd);@(posedge ram_clk);@(negedge ram_clk);we_req=~we_req;
 @(negedge clk);reset=1;repeat(2)@(negedge clk);reset=0;wait(!freeze);
 repeat(20) begin @(negedge ram_clk);
   if(!take_ddr || we_ack==we_req)$fatal(1,"ownership/normal ack escaped while read outstanding");
 end
 ready=1;@(negedge ram_clk);ready=0;wait(!take_ddr);wait(we_ack==we_req);@(negedge ram_clk);wait(normal_idle);@(negedge ram_clk);
 if(normal_writes!=3)$fatal(1,"queued normal write lost, count=%0d",normal_writes);
 $display("PASS: production normal cache read and grant-edge/queued writes, late snapshot drain");$finish;
end
initial begin #2000000;$display("timeout state=%0d freeze=%b own=%b req=%b ack=%b oldsave=%b busy=%b idle=%b freeze_sync=%b",snap.state,freeze,take_ddr,snap.req,snap.ack_sync,snap.old_save,busy,normal_idle,snap.freeze_sync);$fatal(1,"test timeout");end
endmodule

// Behavioral approximations of the FPGA RAM wrappers. Unconnected data_b on
// tag RAM is tied low, matching the VHDL input default; startup forcing above
// is limited to original uninitialized ddram.we_ack.
module dpram #(parameter AW=8,DW=8)(input clock,input [AW-1:0] address_a,input [DW-1:0] data_a,input wren_a,output reg [DW-1:0] q_a,input [AW-1:0] address_b,input tri0 [DW-1:0] data_b,input wren_b,output reg [DW-1:0] q_b);
reg [DW-1:0] m[0:(1<<AW)-1];
always @(posedge clock) begin if(wren_a)begin m[address_a]<=data_a;q_a<=data_a;end else q_a<=m[address_a];if(wren_b)begin m[address_b]<=data_b;q_b<=data_b;end else q_b<=m[address_b];end
endmodule
module spram #(parameter AW=8,DW=8,INIT=" ",NAME="MEM")(input clock,input [AW-1:0] address,input [DW-1:0] data,input wren,input cs,output [DW-1:0] q);
reg [DW-1:0] m[0:(1<<AW)-1],r;always @(posedge clock)if(wren)begin m[address]<=data;r<=data;end else r<=m[address];assign q=cs?r:{DW{1'b1}};
endmodule
