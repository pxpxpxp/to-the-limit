`timescale 1ns/1ps
module state_feedback_tb;
reg clk=0;always #5 clk=~clk;
reg reset=1,available=1,manual_edge=0,request_accept=0,operation_private=0,accepted_loading=0,backend_done=0,backend_failed=0;
reg [1:0] selected_slot=0,accepted_slot=0;
reg [3:0] backend_error=0;
wire info_req;wire [7:0] info;
state_feedback dut(.*);
integer count=0;reg [7:0] seen=0;reg previous_req=0;
always @(negedge clk) begin
 if(info_req && previous_req) $fatal(1,"No low cycle between notifications");
 previous_req=info_req;
 if(info_req) begin count=count+1;seen=info;end
end
task tick;begin @(posedge clk);#1;end endtask
task settle;begin repeat(5) tick();end endtask
task expect_msg(input integer before_count,input [7:0] id);begin settle();if(count!=before_count+1 || seen!=id) $fatal(1,"Expected id %0d count %0d, got id %0d count %0d",id,before_count+1,seen,count);end endtask
task accept_op(input bit priv,input bit load_op,input [1:0] slot);begin operation_private=priv;accepted_loading=load_op;accepted_slot=slot;request_accept=1;tick();request_accept=0;end endtask
integer n,i;
initial begin
 tick();reset=0;settle();if(count!=0)$fatal(1,"Startup popup");
 for(i=1;i<4;i=i+1)begin n=count;selected_slot=i;tick();expect_msg(n,i+1);end
 n=count;selected_slot=0;tick();expect_msg(n,1);
 // Accepted slot must survive selector and request input changes.
 n=count;accept_op(0,0,2);accepted_slot=0;accepted_loading=1;settle();if(count!=n)$fatal(1,"Early capture notification");
 backend_done=1;tick();backend_done=0;expect_msg(n,7);
 for(i=0;i<4;i=i+1)begin n=count;accept_op(0,1,i);backend_done=1;tick();backend_done=0;expect_msg(n,9+i);end
 n=count;accept_op(1,0,0);backend_done=1;tick();backend_done=0;settle();if(count!=n)$fatal(1,"Private save popup");
 accept_op(1,1,0);backend_failed=1;backend_error=6;tick();backend_failed=0;settle();if(count!=n)$fatal(1,"Private failure popup");
 for(i=1;i<=8;i=i+1)begin n=count;accept_op(0,1,0);backend_error=i;backend_failed=1;tick();backend_failed=0;expect_msg(n,i==6?14:i==7?16:13);end
 n=count;available=0;manual_edge=1;tick();manual_edge=0;expect_msg(n,15);
 available=1;accept_op(0,0,0);n=count;available=0;backend_error=0;backend_failed=1;tick();backend_failed=0;expect_msg(n,15);
 available=1;accept_op(0,1,0);n=count;available=0;backend_error=7;backend_failed=1;tick();backend_failed=0;expect_msg(n,16);
 available=1;accept_op(0,0,0);n=count;reset=1;backend_failed=1;tick();reset=0;backend_failed=0;backend_done=1;tick();backend_done=0;settle();if(count!=n)$fatal(1,"Reset aborted operation popup");
 // Adjacent events have distinct rising edges (host mailbox remains best effort).
 selected_slot=1;tick();selected_slot=2;tick();selected_slot=3;tick();settle();
 $display("PASS state_feedback: slots, manual completion, private silence, errors, unavailable, timeout, reset, pulse spacing");$finish;
end
endmodule
