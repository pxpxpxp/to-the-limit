`timescale 1ns/1ps
// Directed arbitration regression: normal-owner drain, accepted read after
// abort, fail-stop, and cancellation of a command still held under busy.
module tb_ddr_ownership;
parameter integer PHASE=0;
reg clk=0,ram_clk=0; initial begin #(PHASE); forever #10 clk=~clk; end
always #5 ram_clk=~ram_clk;
reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
reg [1:0] slot=0;reg [31:0] rom_id=32'h1234abcd;reg [15:0] config_id=0;
wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we,reg_rotate;
wire [3:0] error;wire [17:0] scan_addr;wire [15:0] scan_din;
reg [15:0] scan_dout=0;reg normal_idle=0,ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;
wire [28:0] ram_addr;wire [63:0] ram_din;
wire [16:0] adpcm_addr;wire [3:0] adpcm_din;wire adpcm_we;reg [3:0] adpcm_dout=0;
wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;
wire start_block=0;
 // Optional rewind ports: retain the legacy snapshot profile.
 wire private_mode=1'b0;wire [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 ninja_savestate dut(.manual_stage_allowed(1'b0),.*);
integer normal_ready_count=0, accepted_reads=0; reg [31:0] last_normal;
always @(posedge ram_clk) begin
 if(ram_ready && !take_ddr) normal_ready_count<=normal_ready_count+1;
 if(take_ddr && ram_rd && !ram_busy) accepted_reads<=accepted_reads+1;
end
task start_save;
begin wait(!busy);@(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);end endtask
task abort_now;
begin @(negedge clk);reset=1; repeat(2) @(negedge clk);reset=0;wait(!freeze);end endtask
initial begin
 repeat(4) @(negedge clk);reset=0;start_save();
 // A prior normal operation/response owns the bus until it drains.
 repeat(40) begin @(negedge ram_clk);if(take_ddr || ram_rd || ram_we)$fatal(1,"premature ownership");end
 ram_ready=1;repeat(2) @(negedge ram_clk);ram_ready=0; normal_idle=1;
 wait(take_ddr);wait(ram_rd);@(posedge ram_clk); // the first read is accepted
 abort_now();normal_idle=0;
 last_normal=normal_ready_count;
 // A response may be arbitrarily late; ownership must not leak to normal.
 repeat(60) begin @(negedge ram_clk);if(!take_ddr)$fatal(1,"ownership released before response");end
 ram_dout=64'h1122334455667788;ram_ready=1;@(negedge ram_clk);ram_ready=0;
 wait(!take_ddr);repeat(4) @(negedge ram_clk);
 if(normal_ready_count!=last_normal)$fatal(1,"snapshot response leaked to normal master");
 if(accepted_reads!=1)$fatal(1,"expected exactly one accepted read, got %0d",accepted_reads);
 // A not-yet-accepted command under busy is canceled without waiting for a
 // fictitious response. An ordinary normal requester then retains ownership.
 normal_idle=1;repeat(4) @(negedge clk);start_save();wait(take_ddr);wait(ram_rd);
 @(negedge ram_clk);ram_busy=1;abort_now();
 repeat(12) @(negedge ram_clk);ram_busy=0;wait(!take_ddr);
 if(accepted_reads!=1)$fatal(1,"busy command was unexpectedly accepted");
 // A command already asserted while busy becomes acceptable exactly on the
 // first clock after freeze_sync drops. Acceptance outranks cancellation.
 normal_idle=1;repeat(4) @(negedge clk);start_save();wait(take_ddr);wait(ram_rd);
 @(negedge ram_clk);ram_busy=1;@(negedge clk);reset=1;wait(!dut.freeze_sync);
 @(negedge ram_clk);ram_busy=0;@(posedge ram_clk);@(negedge ram_clk);reset=0;
 if(accepted_reads!=2)$fatal(1,"command accepted on abort edge was lost");
 repeat(20) begin @(negedge ram_clk);if(!take_ddr)$fatal(1,"abort-edge accepted read leaked");end
 ram_ready=1;@(negedge ram_clk);ram_ready=0;wait(!take_ddr);
 // Force the watchdog near overflow to test its actual timeout path without
 // waiting 16 million system clocks. No response: it must fail-stop the bus.
 normal_idle=1;repeat(4) @(negedge clk);start_save();wait(take_ddr);wait(ram_rd);
 @(posedge ram_clk);@(negedge clk);dut.watchdog=28'hffffffe;
 wait(!freeze);if(error!=7)$fatal(1,"watchdog did not report timeout");
 repeat(30) begin @(negedge ram_clk);if(!take_ddr)$fatal(1,"watchdog released a pending DDR read");end
 ram_ready=1;@(negedge ram_clk);ram_ready=0;wait(!take_ddr);
 $display("PASS: normal DDR drain, late accepted response quarantine, watchdog fail-stop, busy cancellation and abort-edge acceptance");$finish;
end
initial begin #1000000;$fatal(1,"test timeout");end
endmodule
