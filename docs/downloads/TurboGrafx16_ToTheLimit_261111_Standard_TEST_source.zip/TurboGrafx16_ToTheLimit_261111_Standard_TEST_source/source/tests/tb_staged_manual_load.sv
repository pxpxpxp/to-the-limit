`timescale 1ns/1ps
module tb_staged_manual_load;
 parameter STAGING=1, CM_PARAM=4;
 reg manual_stage_allowed=1;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;reg [31:0] rom_id=32'h1234abcd;reg [15:0] config_id=16'h42;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,reg_rotate,take_ddr,ram_rd,ram_we;
 wire [3:0] error;wire [17:0] scan_addr;reg [15:0] scan_dout=0;wire [15:0] scan_din;
 wire [16:0] adpcm_addr;wire [3:0] adpcm_din;wire adpcm_we;reg [3:0] adpcm_dout=0;
 wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;
 reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;
 reg [7:0] cd0[0:31],cd1[0:31];integer cd_delay=0;reg cd_pending=0,cd_pending_write=0,cd_block=0;
 reg [17:0] cd_pending_addr=0;reg [7:0] cd_pending_data=0;
 reg normal_idle=1;reg ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;wire [28:0] ram_addr;wire [63:0] ram_din;
 localparam RM=5,AM=8,CM=CM_PARAM,RG=4,CG=(RM+RG+3)/4,N=CG+AM+CM;
 reg private_mode=0;reg [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 integer successes=0,failures=0,accepts=0,cdwrites=0;
 reg old_done=0,old_failed=0,stall_ddr=0;
 always @(posedge clk) begin
  old_done<=done;old_failed<=failed;
  if(done)begin
   successes<=successes+1;
   if(freeze||take_ddr||old_done)$fatal(1,"premature or repeated success");
  end
  if(failed)begin failures<=failures+1;if(old_failed)$fatal(1,"repeated failure");end
  if(request_accept)accepts<=accepts+1;
  if(operation_private && (adpcm_we||cd_ram_hold))$fatal(1,"private operation touched CD/ADPCM payload");
 end
 wire start_block=0;
 ninja_savestate #(.RAM_WORDS(RM),.ADPCM_WORDS(AM),.CDRAM_WORDS(CM),.REGISTER_WORDS(RG),.MANUAL_LOAD_STAGING(STAGING)) dut(.*);
 reg [15:0] live[0:7],regs[0:3];reg [3:0] a0[0:127],a1[0:127];reg bank=0;
 reg [63:0] ddr[0:2359295];integer i,j,k,r,fd,ticks=0,pending=0,delay_left=0,writes=0,adwrites=0;reg expect_fault=0;reg [63:0] backup,checkword;reg [31:0] checksum;integer cbit,cbyte;
 function [3:0] pat(input integer idx,input integer variant);pat=(idx^(idx>>3)^(variant*7))&15;endfunction
 always @(posedge clk) begin
  scan_dout <= scan_addr[17:15]==6 ? regs[0] : live[scan_addr[2:0]];
  adpcm_dout <= bank ? a1[adpcm_addr] : a0[adpcm_addr];
  if(scan_we) begin
   if(!freeze)$fatal(1,"scan write outside freeze");
   if(scan_addr[17:15]==6)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=scan_din;end
   else live[scan_addr[2:0]]<=scan_din;
   writes<=writes+1;
  end
  if(reg_rotate)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=regs[0];end
  if(adpcm_we)begin
   if(!freeze)$fatal(1,"ADPCM write outside freeze");
   if(bank)a0[adpcm_addr]<=adpcm_din;else a1[adpcm_addr]<=adpcm_din;
   adwrites<=adwrites+1;
  end
  if(load_pulse && !operation_private)bank<=!bank;
  if(fault_reset && !expect_fault)$fatal(1,"unexpected fault reset");
 end
 always @(negedge ram_clk)begin ticks=ticks+1;ram_busy=((ticks%11)<3);end
 always @(posedge ram_clk)begin
  if(cd_ram_req!=cd_ram_ack && cd_delay==0)begin cd_pending<=cd_ram_req;cd_pending_write<=cd_ram_write;cd_pending_addr<=cd_ram_addr;cd_pending_data<=cd_ram_din;cd_delay<=3+(ticks%7);end
  else if(cd_delay!=0 && !cd_block)begin
   if(cd_ram_addr!==cd_pending_addr||cd_ram_din!==cd_pending_data||cd_ram_write!==cd_pending_write)$fatal(1,"CD mailbox changed before ack");
   cd_delay<=cd_delay-1;
   if(cd_delay==1)begin
    if(cd_pending_write)begin if(bank)cd0[cd_pending_addr]<=cd_pending_data;else cd1[cd_pending_addr]<=cd_pending_data;end
    else cd_ram_dout<=bank?cd1[cd_pending_addr]:cd0[cd_pending_addr];
    cd_ram_ack<=cd_pending;
   end
  end
 end
 always @(posedge ram_clk)begin
  ram_ready<=0;
  if(delay_left!=0 && !stall_ddr)begin delay_left<=delay_left-1;if(delay_left==1)begin ram_dout<=ddr[pending];ram_ready<=1;end end
  if((ram_we||ram_rd)&&!ram_busy)begin
   if(!take_ddr)$fatal(1,"DDR ownership");
   if(operation_private)begin
    if(ram_addr<29'h7c00000 || ram_addr>=29'h7e00000 ||
       ram_addr<(29'h7c00000+dut.active_private_slot*16384) ||
       ram_addr>=(29'h7c00000+dut.active_private_slot*16384+CG+5))$fatal(1,"private bounds");
   end else if(dut.mailbox_stage)begin
    if(!dut.staged_manual_load || operation_private || ram_addr<29'h7c00005 || ram_addr>=29'h7c00005+N)
      $fatal(1,"staging bounds/type");
   end else if(ram_addr<(29'h7e00000+dut.active_slot*65536) ||
               ram_addr>=(29'h7e00000+dut.active_slot*65536+N+5))$fatal(1,"manual bounds");
   if(dut.applying && !operation_private && ram_rd && !dut.mailbox_stage)
    $fatal(1,"apply reread public mutable image");
   if(ram_we)ddr[ram_addr-29'h7c00000]<=ram_din;
   if(ram_rd)begin pending<=ram_addr-29'h7c00000;delay_left<=2+(ticks%5);end
  end
 end
 task fill(input integer v);begin
  for(i=0;i<RM;i=i+1)live[i]=16'h1100+i+v;
  for(i=0;i<RG;i=i+1)regs[i]=16'h2200+i+v;
  for(i=0;i<128;i=i+1)if(bank)a1[i]=pat(i,v);else a0[i]=pat(i,v);
  for(i=0;i<32;i=i+1)if(bank)cd1[i]=8'(i^(v*37));else cd0[i]=8'(i^(v*37));
 end endtask
 task check(input integer v);begin
  for(i=0;i<RM;i=i+1)if(live[i]!==16'h1100+i+v)$fatal(1,"RAM %0d",i);
  for(i=0;i<RG;i=i+1)if(regs[i]!==16'h2200+i+v)$fatal(1,"REG %0d",i);
  for(i=0;i<128;i=i+1)if((bank?a1[i]:a0[i])!==pat(i,v))$fatal(1,"ADPCM %0d",i);
  for(i=0;i<32;i=i+1)if((bank?cd1[i]:cd0[i])!==8'(i^(v*37)))$fatal(1,"CD RAM %0d",i);
 end endtask
 task check_crc(input integer b,input integer n);reg [31:0] c;integer w,l;begin
  c=32'hffffffff;
  for(w=0;w<n;w=w+1)for(l=0;l<64;l=l+1)
   c=(c>>1)^((c[0]^ddr[b+5+w][l])?32'hedb88320:0);
  if(ddr[b+4][31:0]!==~c)$fatal(1,"independent CRC mismatch");
 end endtask
 task op(input bit isload,input integer expected_error);integer before_done,before_failed;begin
  wait(!busy);repeat(2)@(negedge clk);
  before_done=successes;before_failed=failures;
  if(isload)load_button=1;else save_button=1;
  @(negedge clk);load_button=0;save_button=0;
  wait(busy);wait(!busy);repeat(3)@(negedge clk);
  if(error!=expected_error)$fatal(1,"operation error %0d expected %0d",error,expected_error);
  if(expected_error==0)begin
   if(successes!=before_done+1||failures!=before_failed)$fatal(1,"missing success");
  end else if(successes!=before_done||failures!=before_failed+1)$fatal(1,"bad failure completion");
 end endtask
 task check_core(input integer v);begin
  for(j=0;j<RM;j=j+1)if(live[j]!==16'h1100+j+v)$fatal(1,"core RAM %0d",j);
  for(j=0;j<RG;j=j+1)if(regs[j]!==16'h2200+j+v)$fatal(1,"core register %0d",j);
 end endtask
 integer base_addr,prior_done,prior_failed,prior_writes,prior_adwrites;
 integer case_no;
 initial begin
  for(i=0;i<2359296;i=i+1)ddr[i]=0;
  repeat(4)@(negedge clk);reset=0;
  if(N+5>65536) begin
   prior_writes=writes;op(1,9);op(0,9);
   if(writes!=prior_writes||take_ddr||freeze)$fatal(1,"oversized staging image acquired memory");
   $display("PASS: oversized manual staging image rejected before memory ownership");$finish;
  end
  // Identical manual bytes and all four slots with deterministic backpressure.
  for(k=0;k<4;k=k+1) begin
   slot=k;fill(k+1);op(0,0);base_addr=2097152+k*65536;check_crc(base_addr,N);
   if(ddr[base_addr][63:32]!=(N+4)*2 || ddr[base_addr+1]!==64'h54474c5353000003 ||
      ddr[base_addr+2]!==64'h7b4a4831e0d369a8)$fatal(1,"manual format changed");
   fill(100);op(1,0);check(k+1);
  end
  // All public payload/header bytes may change once immutable apply starts.
  slot=2;fill(17);op(0,0);base_addr=2097152+2*65536;fill(8);
  fork
   begin op(1,0);check(17);end
   begin wait(dut.applying);@(negedge ram_clk);
    for(r=0;r<N+5;r=r+1)ddr[base_addr+r]=64'hdeadbeefbad01234;
    slot=1;rom_id=32'h55;config_id=16'h77;manual_stage_allowed=0;
   end
  join
  if(operation_private)$fatal(1,"manual staging changed profile");
  rom_id=32'h1234abcd;config_id=16'h42;manual_stage_allowed=1;slot=0;
  // Missing or unknown borrow permission fails before freeze or memory writes.
  fill(19);op(0,0);prior_writes=writes;manual_stage_allowed=0;op(1,9);
  if(writes!=prior_writes)$fatal(1,"ungranted apply");
  manual_stage_allowed=1'bx;op(1,9);manual_stage_allowed=1;
  // Corrupt incoming payload must reject without live mutation.
  base_addr=2097152;ddr[base_addr+5]=ddr[base_addr+5]^64'h1;prior_writes=writes;
  op(1,6);if(writes!=prior_writes)$fatal(1,"bad CRC applied");
  // Header replacement after staged copy must reject before any live apply.
  fill(23);op(0,0);fill(8);prior_writes=writes;
  fork
   begin op(1,9);end
   begin wait(dut.rechecking_header);@(negedge ram_clk);ddr[base_addr]=ddr[base_addr]^64'h1;end
  join
  if(writes!=prior_writes)$fatal(1,"changed header applied");
  // Reset during first-pass validation never applies live bytes, and drains
  // the accepted public read before the scratch loan can be returned.
  fill(24);op(0,0);fill(8);prior_done=successes;prior_failed=failures;prior_writes=writes;
  @(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(dut.phase==5 && !dut.applying && ram_rd);stall_ddr=1;wait(dut.dstate==2);
  @(negedge clk);reset=1;repeat(12)@(negedge clk);
  if(!busy||!take_ddr||fault_reset||writes!=prior_writes)$fatal(1,"validation abort lost owner or applied state");
  stall_ddr=0;wait(!busy);@(negedge clk);reset=0;repeat(4)@(negedge clk);
  if(failures!=prior_failed+1||successes!=prior_done)$fatal(1,"validation abort completion");
  // Cancellation while a stage read is accepted keeps bus ownership until drain.
  fill(25);op(0,0);fill(8);prior_done=successes;prior_failed=failures;
  @(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(dut.applying && ram_rd);stall_ddr=1;wait(dut.dstate==2);
  @(negedge clk);enabled=0;expect_fault=1;
  repeat(12)@(negedge clk);
  if(!busy||!take_ddr||operation_private||successes!=prior_done)$fatal(1,"staging drain owner lost");
  stall_ddr=0;wait(!busy);@(negedge clk);enabled=1;expect_fault=0;
  repeat(4)@(negedge clk);
  if(failures!=prior_failed+1||successes!=prior_done)$fatal(1,"staging abort completion");
  // Rewind may reuse slot0 only after draining the manual operation completely.
  private_mode=1;private_slot=0;fill(33);op(0,0);fill(7);op(1,0);check_core(33);
  // Manual staging then safely reclaims the same scratch area after private drain.
  private_mode=0;slot=0;fill(25);op(0,0);fill(8);op(1,0);check(25);
  $display("PASS: staged manual immutability, grant/header/CRC rejection, four slots, interrupted drain and scratch reuse");$finish;
 end
 initial begin #20000000;$fatal(1,"timeout");end
endmodule
