`timescale 1ns/1ps
// Public-interface tests: all settings, more than two physical ring wraps,
// repeated oldest restore, settings/accept/done races, manual priority and guards.
module tb_rewind_controls #(
 parameter integer SLOT_BITS=3,
 parameter integer CAPTURE_FRAMES=3
);
 localparam integer SLOTS=1<<SLOT_BITS;
 reg clk=0; always #5 clk=~clk;
 reg reset=1,enabled=1,frame_tick=0,rewind_held=0,osd_open=0,manual_request=0;
 reg backend_busy=0,backend_accept=0,backend_done=0,backend_failed=0;
 reg [1:0] history_depth=0,capture_rate=0;
 wire save_request,load_request,private_mode,held_active;
 wire [SLOT_BITS-1:0] private_slot;
 wire [SLOT_BITS:0] count;
 rewind_history #(.SLOT_BITS(SLOT_BITS),.CAPTURE_FRAMES(CAPTURE_FRAMES),.REWIND_FRAMES(2)) dut(.*);
 integer checks=0,depth,rate,n,j,capacity,interval,newest,expected;
 reg [SLOT_BITS-1:0] retained_slot;
 initial begin #100000000; $fatal(1,"WATCHDOG adjustable rewind controls"); end
 task cycle; begin @(posedge clk); #1; end endtask
 task check(input bit ok,input string what);
  begin checks=checks+1;if(!ok)$fatal(1,"CHECK %0d @%0t: %s (depth=%0d rate=%0d count=%0d slot=%0d)",checks,$time,what,history_depth,capture_rate,count,private_slot);end
 endtask
 task frame; begin frame_tick=1;cycle();frame_tick=0;cycle();end endtask
 function integer cadence(input integer setting);
  case(setting)
   1:cadence=(CAPTURE_FRAMES+1)/2;
   2:cadence=CAPTURE_FRAMES*2;
   3:cadence=CAPTURE_FRAMES*4;
   default:cadence=CAPTURE_FRAMES;
  endcase
 endfunction
 task fresh(input integer d,input integer r);
  begin
   reset=1;enabled=1;frame_tick=0;rewind_held=0;osd_open=0;manual_request=0;
   backend_busy=0;backend_accept=0;backend_done=0;backend_failed=0;
   history_depth=d;capture_rate=r;repeat(3)cycle();reset=0;repeat(2)cycle();
   check(count==0&&!private_mode&&!save_request&&!load_request,"reset clears all ring metadata");
  end
 endtask
 task request_save(input integer slot);
  integer k;
  begin
   for(k=1;k<cadence(capture_rate);k=k+1)begin frame();check(!save_request&&!load_request,"no capture before selected interval");end
   frame();check(save_request&&!load_request&&private_mode,"capture at exact selected frame interval");
   check(private_slot==slot,"capture keeps fixed physical ring addresses");
  end
 endtask
 task accept;
  begin
   backend_busy=1;backend_accept=1;cycle();backend_accept=0;cycle();
   check(private_mode&&!save_request&&!load_request,"accepted transaction retains private owner");
  end
 endtask
 task finish;
  begin
   backend_done=1;cycle();backend_done=0;repeat(2)cycle();
   check(!save_request&&!load_request,"backend busy tail suppresses requests");
   backend_busy=0;cycle();
  end
 endtask
 task capture(input integer slot,input integer expected_count);
  begin request_save(slot);accept();finish();check(count==expected_count,"capture commits selected history limit");end
 endtask
 task request_load(input integer slot);
  integer guard;
  begin
   guard=0;
   while(!load_request&&guard<5)begin frame();guard=guard+1;end
   check(load_request&&!save_request&&private_slot==slot,"rewind returns newest retained slot");
  end
 endtask
 task assert_empty;
  begin check(count==0&&!save_request&&!load_request,"invalidated history cannot be requested");end
 endtask
 always @(negedge clk)if(!reset)begin
  if(save_request&&load_request)$fatal(1,"simultaneous private save/load");
  if((save_request||load_request)&&!private_mode)$fatal(1,"request without private owner");
  if(count>SLOTS)$fatal(1,"physical capacity exceeded");
 end
 initial begin
  $display("CASE all depth/rate combinations and physical ring wrap (slots=%0d, base frames=%0d)",SLOTS,CAPTURE_FRAMES);
  for(depth=0;depth<4;depth=depth+1)begin
   capacity=SLOTS>>depth;if(capacity<1)capacity=1;
   for(rate=0;rate<4;rate=rate+1)begin
    fresh(depth,rate);
    for(n=0;n<2*SLOTS+3;n=n+1)capture(n%SLOTS, n+1<capacity ? n+1 : capacity);
    rewind_held=1;
    newest=(2*SLOTS+2)%SLOTS;
    for(n=0;n<capacity+3;n=n+1)begin
     expected=(newest-(n<capacity ? n : capacity-1)+SLOTS)%SLOTS;
     request_load(expected);accept();finish();
     check(count==(capacity-n-1>1 ? capacity-n-1 : 1),"depth-limited rewind stops at oldest snapshot");
    end
    rewind_held=0;cycle();cycle();
    capture((newest-capacity+2+SLOTS)%SLOTS,capacity>1 ? 2 : 1);
   end
  end

  $display("CASE configuration change discards history and restarts capture cadence");
  fresh(0,0);capture(0,1);frame();
  capture_rate=3;cycle();assert_empty();
  capture(0,1);history_depth=3;cycle();assert_empty();capture(0,1);

  $display("CASE pending capture and restore are gated before configuration is sampled");
  fresh(0,0);request_save(0);capture_rate=1;#1;
  check(!save_request,"new setting immediately gates unaccepted capture");cycle();
  check(!private_mode&&count==0,"config cancels pending capture");capture(0,1);
  rewind_held=1;request_load(0);history_depth=1;#1;
  check(!load_request&&!held_active,"new setting immediately gates pending restore");cycle();
  check(!private_mode&&count==0,"config cancels pending restore");rewind_held=0;cycle();capture(0,1);

  $display("CASE configuration changes race registered acceptance and completion");
  fresh(0,0);capture(0,1);request_save(1);
  backend_busy=1;backend_accept=1;history_depth=1;cycle();backend_accept=0;
  check(private_mode&&private_slot==1&&count==0,"late acceptance retains pre-change private slot");
  capture_rate=3;cycle();history_depth=0;capture_rate=0;cycle();
  check(private_mode&&private_slot==1,"multiple setting changes cannot redirect accepted write");
  finish();check(count==0&&!private_mode,"reverted settings cannot recommit invalidated transfer");capture(0,1);
  request_save(1);accept();capture_rate=2;backend_done=1;cycle();backend_done=0;
  check(count==0&&!private_mode,"setting change on completion edge wins commit");backend_busy=0;cycle();capture(0,1);

  $display("CASE accepted restore drains privately across config changes");
  fresh(0,1);capture(0,1);capture(1,2);rewind_held=1;request_load(1);accept();
  history_depth=2;cycle();check(private_mode&&private_slot==1&&count==0,"restore owner survives depth change");
  finish();assert_empty();rewind_held=0;cycle();capture(0,1);

  $display("CASE manual requests remain higher priority at every interval setting");
  for(rate=0;rate<4;rate=rate+1)begin
   fresh(1,rate);capture(0,1);request_save(1);accept();
   manual_request=1;history_depth=2;cycle();
   check(private_mode&&private_slot==1&&count==0,"manual request and config change preserve accepted owner");
   finish();assert_empty();manual_request=0;cycle();capture(0,1);
   manual_request=1;frame();assert_empty();manual_request=0;cycle();capture(0,1);
  end

  $display("CASE guard loss invalidates every history/rate setting");
  for(rate=0;rate<4;rate=rate+1)begin
   fresh(rate,rate);capture(0,1);request_save(1);accept();
   enabled=0;cycle();check(private_mode&&private_slot==1&&count==0,"guard loss drains accepted slot");
   enabled=1;history_depth=(rate+1)%4;capture_rate=(rate+1)%4;cycle();
   finish();check(count==0,"guard loss cannot revive history after eligibility returns");capture(0,1);
  end

  $display("CASE OSD pauses cadence; configuration changes still take effect while open");
  fresh(0,3);capture(0,1);osd_open=1;
  for(n=0;n<cadence(3)+2;n=n+1)frame();
  check(count==1&&!save_request&&!load_request,"OSD retains existing history and pauses captures");
  capture_rate=1;history_depth=1;cycle();assert_empty();
  for(n=0;n<cadence(1)+2;n=n+1)frame();assert_empty();
  osd_open=0;cycle();capture(0,1);

  $display("CASE nondefault reset, failed capture and failed restore invalidate history");
  for(rate=0;rate<4;rate=rate+1)begin
   fresh(rate,rate);capture(0,1);request_save(1);accept();
   reset=1;cycle();check(count==0&&!private_mode,"reset clears active ownership with backend reset contract");
   reset=0;finish();check(count==0,"pre-reset completion cannot commit old metadata");capture(0,1);
   request_save(1);accept();backend_failed=1;cycle();backend_failed=0;backend_busy=0;cycle();assert_empty();
   capture(0,1);rewind_held=1;request_load(0);accept();backend_failed=1;cycle();
   backend_failed=0;backend_busy=0;cycle();assert_empty();
  end
  $display("PASS tb_rewind_controls: %0d checks",checks);$finish;
 end
endmodule
