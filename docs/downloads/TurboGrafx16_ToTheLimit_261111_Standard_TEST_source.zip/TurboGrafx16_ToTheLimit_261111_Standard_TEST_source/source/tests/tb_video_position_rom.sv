`timescale 1ns/1ps
module tb_video_position_rom;
 parameter integer LINE_CLOCKS=2730;
 localparam integer AW=$clog2(LINE_CLOCKS/6), DEPTH=1<<AW;
 reg clk=0,reset=0,enabled=1,freeze=0;
 reg [51:0] source_phase=0,reference_phase=0;
 reg [9:0] pixel_in=0;
 wire [9:0] pixel_out;
 wire reference_ce,reference_hs,reference_vs,reference_hbl,reference_vbl;
 wire frame_valid,replay_valid,underflow,capture_fault;
 wire [28:0] ram_addr;
 wire [63:0] ram_din;
 wire [7:0] ram_burst;
 wire ram_rd,ram_we;
 reg ram_busy=0,ram_ready=0;
 reg [63:0] ram_dout=0;
 video_frame_replay #(.LINE_CLOCKS(LINE_CLOCKS)) dut(.*);
 integer i,h,half,qword=0,qpos=0,qhalf=0,checks=0;
 reg qfreeze=0;
 reg [9:0] qlive=0;
 reg [4:0] qtiming=5'b00011;
 reg [AW+2:0] expected_decode;
 function automatic [63:0] fixture(input integer parity,input integer word_index);
  fixture=64'h0123456789abcdef ^ (64'h1020304050607081*word_index) ^ (parity ? 64'hf000000000000000 : 64'd0);
 endfunction
 task sample(input integer coordinate,input integer parity,input integer ordinal);
  begin
   reference_phase=0;
   reference_phase[11:0]=coordinate; reference_phase[21:12]=parity;
   reference_phase[31:22]=263;
   reference_phase[38]=ordinal[0]; reference_phase[49]=ordinal[1];
   reference_phase[50]=ordinal[2]; reference_phase[47]=ordinal[3]; reference_phase[48]=ordinal[4];
   pixel_in=(ordinal*73)&1023; freeze=ordinal[2];
   reset=ordinal[5]; enabled=!ordinal[6];
   expected_decode=(coordinate<LINE_CLOCKS) ? ((coordinate/6)<<3)|(coordinate%6) : 0;
   #2; clk=1; #1;
   if(dut.display_decode_q!==expected_decode)
    $fatal(1,"coordinate ROM mismatch H=%0d got=%h expected=%h",coordinate,dut.display_decode_q,expected_decode);
   if(dut.display_half_q!==parity[0]) $fatal(1,"parity ROM-stage mismatch");
   if(dut.replay_q!==fixture(qhalf,qword)) $fatal(1,"second-stage RAM address did not follow previous physical H/parity");
   if(dut.display_pos_q!==qpos[2:0]) $fatal(1,"second-stage remainder mismatch");
   if({reference_ce,reference_hs,reference_vs,reference_hbl,reference_vbl}!==qtiming)
    $fatal(1,"control latency is not exactly two edges");
   if(pixel_out!==(qfreeze ? 10'd0 : qlive)) $fatal(1,"live/freeze latency is not exactly two edges");
   if(replay_valid || ram_rd || ram_we) $fatal(1,"invalid source/frame generated replay or DDR activity");
   checks=checks+1;
   qword=expected_decode>>3; qpos=expected_decode&7; qhalf=parity;
   qlive=pixel_in; qfreeze=freeze;
   qtiming={reference_phase[38],~reference_phase[49],~reference_phase[50],reference_phase[47],reference_phase[48]};
   clk=0; #1;
  end
 endtask
 initial begin
  // Unit-only RAM fixture; the end-to-end test independently fills replay
  // memory via real capture, DDR writes, and accepted DDR read responses.
  for(i=0;i<2*DEPTH;i=i+1) dut.replay_ram[i]=fixture(i/DEPTH,i%DEPTH);
  #1;
  for(i=0;i<4096;i=i+1) begin
   expected_decode=(i<LINE_CLOCKS) ? ((i/6)<<3)|(i%6) : 0;
   if(dut.position_rom[i]!==expected_decode) $fatal(1,"ROM initialization entry %0d",i);
  end
  // Two complete address traversals, one discontinuous permutation. Repeats,
  // backward jumps, half switches and invalid H cannot be treated as counters.
  for(i=0;i<4096;i=i+1) sample(i,i&1,i);
  for(i=0;i<4096;i=i+1) sample((i*2053+17)&4095,(i>>1)&1,i+4096);
  repeat(8) sample(0,0,0);
  $display("PASS video position ROM: LINE_CLOCKS=%0d all 4096 entries checked, %0d two-stage address/control samples",LINE_CLOCKS,checks);
  $finish;
 end
endmodule
