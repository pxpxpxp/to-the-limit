`timescale 1ns/1ps
module tb_video_replay_golden;
  localparam integer H=2730;
  reg clk=0,video_clk=0; initial begin #1; forever #2 clk=~clk; end always #1 video_clk=~video_clk;
  reg reset_n=0,request=0,cancel=0,save=0,load=0,rotate=0,rwe=0;
  reg [14:0] ra=2;reg [15:0] rdi=0; wire [15:0] rdo;
  reg ce_n=1,wr_n=1;reg [7:0] di=0; reg [2:0] cpu_a=0; wire [2:0] raw_r,raw_g,raw_b; wire raw_bw;
  wire hold,video_freeze,busy,ref_ce,ref_hs,ref_vs,ref_hb,ref_vb,fault;
  wire machine_freeze=request|hold;
  wire [51:0] phase; wire core_ce,hs_n,vs_n,hb,vb;
  huc6260 vce(.CLK(clk),.RESET_N(reset_n),.SS_ADDR(18'd0),.SS_DI(16'd0),.SS_WE(1'b0),.SS_DO(),
    .SS_RROTATE(rotate),.SS_RADDR(ra),.SS_RDI(rdi),.SS_RWE(rwe),.SS_RDO(rdo),
    .SS_FREEZE(machine_freeze),.SS_SAVE(save),.SS_LOAD(load),.SS_VIDEO_PHASE(phase),
    .A(cpu_a),.CE_N(ce_n),.WR_N(wr_n),.RD_N(1'b1),.DI(di),.DO(),.COLNO({phase[15:12],phase[10:6]}),
    .CLKEN(),.CLKEN_F(),.HSYNC_F(),.HSYNC_R(),.VSYNC_F(),.VSYNC_R(),.CLKEN_FS(core_ce),
    .RVBL(1'b0),.GRID_EN(2'b0),.BORDER_EN(1'b0),.BORDER(1'b0),.GRID(2'b0),
    .R(raw_r),.G(raw_g),.B(raw_b),.BW(raw_bw),.VS_N(vs_n),.HS_N(hs_n),.HBL(hb),.VBL(vb));
  video_phase_align aligner(.clk(clk),.freeze_request(request),.cancel(cancel),.core_phase(phase),
    .machine_hold(hold),.video_freeze(video_freeze),.busy(busy),.reference_ce(),
    .reference_hs(),.reference_vs(),.reference_hbl(),.reference_vbl(),.presentation_phase(ref_phase),.fault(fault));

  wire [51:0] ref_phase;
  wire [9:0] replay_pixel;
  wire frame_valid,replay_valid,underflow,capture_fault;
  wire [28:0] va,da; wire [63:0] vdin,vdout,ddin,ddout;
  wire [7:0] vburst,dburst,dbe;
  wire vrd,vwe,vbusy,vready,drd,dwe,dbusy,dready;
  video_frame_replay replay(.clk(video_clk),.reset(!reset_n),.enabled(1'b1),.freeze(video_freeze),
    .source_phase(phase),.reference_phase(ref_phase),.pixel_in({raw_bw,raw_g,raw_r,raw_b}),.pixel_out(replay_pixel),
    .reference_ce(ref_ce),.reference_hs(ref_hs),.reference_vs(ref_vs),.reference_hbl(ref_hb),.reference_vbl(ref_vb),
    .frame_valid(frame_valid),.replay_valid(replay_valid),.underflow(underflow),.capture_fault(capture_fault),
    .ram_addr(va),.ram_din(vdin),.ram_burst(vburst),.ram_rd(vrd),.ram_we(vwe),
    .ram_busy(vbusy),.ram_ready(vready),.ram_dout(vdout));
  video_ddr_arbiter arb(.clk(video_clk),.primary_addr(29'd0),.primary_din(64'd0),
    .primary_byteenable(8'hff),.primary_burst(8'd1),.primary_rd(1'b0),.primary_we(1'b0),
    .primary_idle(1'b1),.primary_pulse_read(1'b0),.primary_busy(),.primary_ready(),.primary_dout(),
    .video_addr(va),.video_din(vdin),.video_burst(vburst),.video_rd(vrd),.video_we(vwe),
    .video_busy(vbusy),.video_ready(vready),.video_dout(vdout),
    .ddr_addr(da),.ddr_din(ddin),.ddr_byteenable(dbe),.ddr_burst(dburst),.ddr_rd(drd),.ddr_we(dwe),
    .ddr_busy(dbusy),.ddr_ready(dready),.ddr_dout(ddout));
  replay_actual_ddr memory(.clk(video_clk),.addr(da),.din(ddin),.dout(ddout),.burst(dburst),
    .rd(drd),.we(dwe),.busy(dbusy),.ready(dready));
  // Exact production palette bytes, one-clock synchronous ROM contract.
  // This models dpram's registered address; vendor RAM analog timing is not modeled.
  reg [23:0] palette[0:511]; reg [23:0] palette_q;
  initial $readmemh("palette.hex",palette);
  always @(posedge video_clk) palette_q<=palette[replay_pixel[8:0]];
  wire [7:0] replay_r=palette_q[23:16];
  wire [7:0] replay_g=palette_q[15:8];
  wire [7:0] replay_b=palette_q[7:0];
  reg tint=0;
  reg ce_pix=0,old_ce=0;
  always @(posedge video_clk) begin old_ce<=ref_ce;ce_pix<=!old_ce&&ref_ce;end
  wire [7:0] R,G,B,cR,cG,cB;wire HS,VS,HBlank,VBlank;
  color_mix color_stage(.clk_vid(video_clk),.ce_pix(ce_pix),.mix(replay_pixel[9] ? 3'd5 : 3'd0),
    .R_in(replay_r),.G_in(replay_g),.B_in(replay_b),
    .HSync_in(ref_hs),.VSync_in(ref_vs),.HBlank_in(ref_hb),.VBlank_in(ref_vb),
    .R_out(cR),.G_out(cG),.B_out(cB),.HSync_out(HS),.VSync_out(VS),.HBlank_out(HBlank),.VBlank_out(VBlank));
  rewind_tint tint_stage(.active(tint),.rgb_in({cR,cG,cB}),.rgb_out({R,G,B}));
  reg HSync,VSync;
  always @(posedge video_clk) begin HSync<=HS;if(!HSync&&HS)VSync<=VS;end
  wire [21:0] gamma_bus; assign gamma_bus[20:0]=0;
  wire [7:0] vr,vg,vbcol;wire vhs,vvs,vde,pixout;
  video_mixer #(.LINE_LENGTH(560),.GAMMA(1)) mixer(
    .CLK_VIDEO(video_clk),.CE_PIXEL(pixout),.ce_pix(ce_pix),.scandoubler(1'b0),.hq2x(1'b0),.gamma_bus(gamma_bus),
    .R(R),.G(G),.B(B),.HSync(HSync),.VSync(VSync),.HBlank(HBlank),.VBlank(VBlank),
    .HDMI_FREEZE(1'b0),.freeze_sync(),.VGA_R(vr),.VGA_G(vg),.VGA_B(vbcol),.VGA_VS(vvs),.VGA_HS(vhs),.VGA_DE(vde));
  // Independent full-frame oracle bypasses both production line caches and
  // their metadata. The raw spatial suite separately verifies DDR writes.
  wire [28:0] gold_addr=29'h07a00000+replay.front_bank*29'h20000+
    ref_phase[21:12]*455+ref_phase[11:0]/6;
  wire [63:0] gold_word=memory.mem[gold_addr-29'h07a00000];
  wire [9:0] gold_pixel=video_freeze ?
    ((frame_valid && ref_phase[21:12]<replay.front_lines) ?
      ((gold_word >> ((ref_phase[11:0]%6)*10)) & 10'h3ff) : 10'd0) : {raw_bw,raw_g,raw_r,raw_b};
  reg [9:0] gp_d=0,gp=0;reg[51:0] gphase_d=0,gphase=0;
  reg gce_old=0,gce=0;reg[23:0] gpal;
  always @(posedge video_clk)begin
    gp_d<=gold_pixel;gphase_d<=ref_phase;
    gp<=gp_d;gphase<=gphase_d;gpal<=palette[gp[8:0]];
    gce_old<=gphase[38];gce<=!gce_old&&gphase[38];
  end
  wire[7:0] gr0,gg0,gb0,gr1,gg1,gb1;
  wire ghs0,gvs0,ghb0,gvb0;
  color_mix gold_color(.clk_vid(video_clk),.ce_pix(gce),.mix(gp[9]?3'd5:3'd0),
    .R_in(gpal[23:16]),.G_in(gpal[15:8]),.B_in(gpal[7:0]),
    .HSync_in(!gphase[49]),.VSync_in(!gphase[50]),.HBlank_in(gphase[47]),.VBlank_in(gphase[48]),
    .R_out(gr0),.G_out(gg0),.B_out(gb0),.HSync_out(ghs0),.VSync_out(gvs0),.HBlank_out(ghb0),.VBlank_out(gvb0));
  function automatic[23:0] gray_oracle(input[23:0] value);
    integer r,g,b,y;
    begin r=value[23:16];g=value[15:8];b=value[7:0];y=(r+2*g+b)/4;
    gray_oracle={8'((r+y)/2),8'((g+y)/2),8'((b+y)/2)};end
  endfunction
  assign {gr1,gg1,gb1}=tint ? gray_oracle({gr0,gg0,gb0}) : {gr0,gg0,gb0};
  reg ghs1,gvs1;
  always @(posedge video_clk)begin ghs1<=ghs0;if(!ghs1&&ghs0)gvs1<=gvs0;end
  wire[7:0] gr2,gg2,gb2;wire ghs2,gvs2,gde2,gce2;
  wire[21:0] ggamma;assign ggamma[20:0]=0;
  video_mixer #(.LINE_LENGTH(560),.GAMMA(1)) gold_mixer(.CLK_VIDEO(video_clk),.CE_PIXEL(gce2),.ce_pix(gce),
    .scandoubler(1'b0),.hq2x(1'b0),.gamma_bus(ggamma),.R(gr1),.G(gg1),.B(gb1),
    .HSync(ghs1),.VSync(gvs1),.HBlank(ghb0),.VBlank(gvb0),.HDMI_FREEZE(1'b0),.freeze_sync(),
    .VGA_R(gr2),.VGA_G(gg2),.VGA_B(gb2),.VGA_VS(gvs2),.VGA_HS(ghs2),.VGA_DE(gde2));
  integer golden_checks=0;
  always @(negedge video_clk)if(checking)begin
    if({vhs,vvs,vde,pixout}!=={ghs2,gvs2,gde2,gce2})$fatal(1,"golden presentation timing mismatch");
    if(vde&&pixout)begin
      if({vr,vg,vbcol}!=={gr2,gg2,gb2})$fatal(1,"golden palette/native RGB mismatch actual=%h expected=%h h=%0d v=%0d freeze=%b",{vr,vg,vbcol},{gr2,gg2,gb2},ref_phase[11:0],ref_phase[21:12],video_freeze);
      golden_checks=golden_checks+1;
    end
  end
  integer cycles=0;always @(posedge clk)cycles<=cycles+1;
  integer vc=0;always @(posedge video_clk)vc<=vc+1;
  reg checking=0,was_frozen=0;
  integer live_checks=0,resumes=0;
  integer freeze_start=-1,video_start=-1;reg old_machine=0,old_video=0;
  always @(negedge clk) begin
    if(machine_freeze && !old_machine) freeze_start=cycles;
    if(video_freeze && !old_video) video_start=cycles;
    if(!machine_freeze && old_machine) begin
      $display("MACHINE_PAUSE scenario=%0d cycles=%0d microseconds=%0f",scenario,cycles-freeze_start,(cycles-freeze_start)*1000000.0/42954545.0);$fflush();
    end
    if(!video_freeze && old_video) begin
      $display("VIDEO_HOLD scenario=%0d cycles=%0d microseconds=%0f",scenario,cycles-video_start,(cycles-video_start)*1000000.0/42954545.0);$fflush();
    end
    old_machine=machine_freeze;old_video=video_freeze;
  end
  always @(negedge clk) begin
    if(checking && !machine_freeze && !was_frozen) begin
      // Every active-cycle comparison is against the actual synthesized VHDL,
      // not a second handwritten VCE model.
      if({aligner.reference_phase[50:35],aligner.reference_phase[21:0]} !== {phase[50:35],phase[21:0]}) begin
        $display("MIRROR actual=%h expected=%h cycle=%0d",aligner.reference_phase,phase,cycles);
        $fatal(1,"live VCE presentation mismatch");
      end
      live_checks=live_checks+1;
    end
    if(checking && was_frozen && !machine_freeze) begin
      if(aligner.reference_phase !== phase) $fatal(1,"resume phase mismatch");
      resumes=resumes+1;
    end
    if(checking && fault) $fatal(1,"unexpected alignment timeout");
    was_frozen=machine_freeze;
  end
  integer rh=-1,rf=-1,rv=-1,rvf=-1,oh=-1,ohf=-1,ov=-1,ovf=-1;
  integer raw_lines=0,raw_fields=0,out_lines=0,out_fields=0;
  integer max_h_error=0,max_h_width_error=0,max_v_error=0,max_v_width_error=0,e=0,e2=0;
  function integer abs(input integer value);abs=value<0?-value:value;endfunction
  always @(posedge aligner.reference_hs) if(checking)begin
    if(rh>=0 && cycles-rh!=H)$fatal(1,"raw H period %0d",cycles-rh);rh=cycles;raw_lines=raw_lines+1;
  end
  always @(negedge aligner.reference_hs) if(checking)begin
    if(rh>=0 && cycles-rh!=192)$fatal(1,"raw H width %0d",cycles-rh);
  end
  always @(posedge aligner.reference_vs) if(checking)begin
    if(rv>=0 && cycles-rv!=H*262 && cycles-rv!=H*263)$fatal(1,"raw V period %0d",cycles-rv);rv=cycles;raw_fields=raw_fields+1;
  end
  always @(negedge aligner.reference_vs) if(checking)begin
    if(rv>=0 && cycles-rv!=3*H)$fatal(1,"raw V width %0d",cycles-rv);
  end
  always @(posedge vhs) if(checking)begin
    if(oh>=0) begin e=abs(vc-oh-2*H);if(e>max_h_error)max_h_error=e;end
    if(oh>=0 && abs(vc-oh-2*H)>128)$fatal(1,"native H period %0d",vc-oh);oh=vc;out_lines=out_lines+1;
  end
  always @(negedge vhs) if(checking)begin
    if(oh>=0) begin e=abs(vc-oh-384);if(e>max_h_width_error)max_h_width_error=e;end
    if(oh>=0 && abs(vc-oh-384)>128)$fatal(1,"native H width %0d",vc-oh);
  end
  always @(posedge vvs) if(checking)begin
    if(ov>=0) begin e=abs(vc-ov-2*H*262);e2=abs(vc-ov-2*H*263);if(e2<e)e=e2;if(e>max_v_error)max_v_error=e;end
    if(ov>=0 && abs(vc-ov-2*H*262)>128 && abs(vc-ov-2*H*263)>128)$fatal(1,"native V period %0d",vc-ov);ov=vc;out_fields=out_fields+1;
  end
  always @(negedge vvs) if(checking)begin
    if(ov>=0) begin e=abs(vc-ov-6*H);if(e>max_v_width_error)max_v_width_error=e;end
    if(ov>=0 && abs(vc-ov-6*H)>128)$fatal(1,"native V width %0d",vc-ov);
  end
  integer hold_pixels=0, black_pixels=0, tint_checks=0;
  integer visible_runs=0, longest_black_run=0, black_run=0;
  always @(posedge video_clk) begin
    if(checking && video_freeze && vde && pixout) begin
      hold_pixels=hold_pixels+1;
      if({vr,vg,vbcol}===24'd0) begin
        black_pixels=black_pixels+1;black_run=black_run+1;
        if(black_run>longest_black_run)longest_black_run=black_run;
      end else begin visible_runs=visible_runs+1;black_run=0;end
    end else black_run=0;
    if(checking && tint && {R,G,B}!={cR,cG,cB}) tint_checks=tint_checks+1;
    if(checking && underflow) $fatal(1,"active-line replay underflow");
  end
  task tick;begin @(posedge clk);@(negedge clk);end endtask
  task write_cpu(input [2:0] addr,input [7:0] value);begin
    @(negedge clk);cpu_a=addr;di=value;ce_n=0;wr_n=0;repeat(4)tick;
    ce_n=1;wr_n=1;repeat(4)tick;
  end endtask
  reg [15:0] image[0:9];integer i,scenario=0,unused,old_lines;reg[7:0]old_cr,new_cr;
  initial begin
    unused=$value$plusargs("SCENARIO=%d",scenario);
    old_cr=scenario==1?8'h06:scenario==2?8'h01:8'h00;new_cr=scenario==1?8'h01:8'h06;
    old_lines=scenario==1?263:262;
    repeat(8)tick;reset_n=1;
    // Program the actual VCE palette through its production CPU interface.
    // Every entry has nonzero blue, making black active pixels an objective miss.
    write_cpu(3'd2,0);write_cpu(3'd3,0);
    for(i=0;i<512;i=i+1)begin
      write_cpu(3'd4,{i[4:0],3'b111});write_cpu(3'd5,{7'd0,i[5]});
    end
    write_cpu(3'd0,old_cr);
    repeat(4*H*263)tick;checking=1;
    if(!frame_valid)$fatal(1,"no completed frame available");
    if(scenario==2) begin
      while(!(phase[21:12]==80 && phase[11:0]==1000))tick;
      write_cpu(3'd0,8'h00); // a real mid-active-line dot-clock write arms MULTIRES
    end
    while(!(phase[21:12]==old_lines-1 && phase[11:0]==1000))tick;
    request=1;tick;save=1;tick;save=0;repeat(4)tick;
    for(i=0;i<10;i=i+1)begin ra=2+i;#0.1;image[i]=rdo;rotate=1;tick;rotate=0;end
    repeat(202385)tick;request=0;wait(!busy);tick;
    $display("SAVE_RESUMED scenario=%0d cycle=%0d",scenario,cycles);$fflush();
    while(!(phase[21:12]==80 && phase[11:0]==1000))tick;
    write_cpu(3'd0,new_cr);repeat(2*H*263)tick;
    while(!(phase[21:12]==90 && phase[11:0]==123))tick;
    tint=1;request=1;tick;repeat(20)tick;
    for(i=0;i<10;i=i+1)begin ra=2+i;rdi=image[i];rwe=1;tick;rwe=0;end
    load=1;tick;load=0;
    repeat(313385)tick;request=0;wait(!busy);tick;tint=0;
    $display("LOAD_RESUMED scenario=%0d cycle=%0d",scenario,cycles);$fflush();
    repeat(H*263)tick;
    if(resumes!=2||raw_fields<4||out_fields<4)$fatal(1,"incomplete coverage");
    $display("NATIVE_MAX_SAMPLING_ERROR video_clocks H_period=%0d H_width=%0d V_period=%0d V_width=%0d",max_h_error,max_h_width_error,max_v_error,max_v_width_error);
    if(hold_pixels<1000 || black_pixels!=0 || tint_checks==0)$fatal(1,"picture coverage hold=%0d black=%0d longest=%0d tint=%0d",hold_pixels,black_pixels,longest_black_run,tint_checks);
    $display("GOLDEN_NATIVE_RGB comparisons=%0d",golden_checks);
    $display("PICTURE_HOLD pixels=%0d black=%0d longest_black_run=%0d tint_checks=%0d",hold_pixels,black_pixels,longest_black_run,tint_checks);
    $display("PASS actual VCE native video replay scenario=%0d live_checks=%0d resumes=%0d raw_lines=%0d raw_fields=%0d output_lines=%0d output_fields=%0d",scenario,live_checks,resumes,raw_lines,raw_fields,out_lines,out_fields);$finish;
  end
  initial begin #120000000;$fatal(1,"test watchdog");end
endmodule
// Unselected scandoubler output is irrelevant to this explicitly native path
// bench. Its real RTL remains part of full-project compilation/qualification.
module scandoubler #(parameter LENGTH=560,HALF_DEPTH=0)(input clk_vid,hq2x,ce_pix,hs_in,vs_in,hb_in,vb_in,input[7:0]r_in,g_in,b_in,output ce_pix_out,hs_out,vs_out,hb_out,vb_out,output[7:0]r_out,g_out,b_out);
  assign {ce_pix_out,hs_out,vs_out,hb_out,vb_out,r_out,g_out,b_out}={ce_pix,hs_in,vs_in,hb_in,vb_in,r_in,g_in,b_in};
endmodule

module replay_actual_ddr(input clk,input[28:0]addr,input[63:0]din,output[63:0]dout,
 input[7:0]burst,input rd,we,output busy,output ready);
 reg[63:0]mem[0:393215];
 reg[28:0]ra=0;integer left=0,delay_count=0,c=0;
 assign busy=(c%29==0);
 assign ready=left>0 && delay_count==0 && c%11!=0;
 assign dout=mem[ra-29'h07a00000];
 always @(posedge clk)begin
   c<=c+1;
   if(ready)begin ra<=ra+1;left<=left-1;end
   if(delay_count>0)delay_count<=delay_count-1;
   if((rd||we)&&!busy)begin
     if(addr<29'h07a00000||addr>=29'h07a60000)$fatal(1,"DDR replay range");
     if(we)mem[addr-29'h07a00000]<=din;
     if(rd)begin
       if(left!=0)$fatal(1,"DDR overlapping reads");
       ra<=addr;left<=burst;delay_count<=7;
     end
   end
 end
endmodule
