// Single-outstanding DDR arbiter for the normal/snapshot and video clients.
// All ports are synchronous to clk. DDR read bursts contain 1..255 beats;
// writes are single-beat. Video uses full byte enables. No reset is intentional:
// a core soft reset must not discard an accepted DDR transaction's owner.
//
// primary_idle must exclude every internal normal-cache request that could
// produce a pulse on the next edge. The existing ddram.idle provides this.
// A normal-cache read pulse is retained across DDR waitrequest, even though
// that legacy client does not hold RD. Other clients must hold commands until
// !busy. Only legacy normal reads may be buffered (primary_pulse_read=1).
// Snapshot commands and writes remain withdrawable before DDR acceptance.
// Upstream normal/snapshot arbitration must itself retain its owner
// through the primary response, exactly as before this arbiter is inserted.
module video_ddr_arbiter (
 input wire clk,
 input wire [28:0] primary_addr,
 input wire [63:0] primary_din,
 input wire [7:0] primary_byteenable, primary_burst,
 input wire primary_rd, primary_we, primary_idle, primary_pulse_read,
 output reg primary_busy, primary_ready,
 output wire [63:0] primary_dout,
 // Safe opportunity for an outer, lower-priority arbiter. Exclude live
 // video requests as well as pending/accepted primary or video traffic.
 output wire idle,
 input wire [28:0] video_addr,
 input wire [63:0] video_din,
 input wire [7:0] video_burst,
 input wire video_rd, video_we,
 output reg video_busy, video_ready,
 output wire [63:0] video_dout,
 output reg [28:0] ddr_addr,
 output reg [63:0] ddr_din,
 output reg [7:0] ddr_byteenable, ddr_burst,
 output wire ddr_rd, ddr_we,
 input wire ddr_busy, ddr_ready,
 input wire [63:0] ddr_dout
);
 localparam [2:0] PRIMARY=0, PRIMARY_PENDING=1, PRIMARY_READ=2,
                  VIDEO_COMMAND=3, VIDEO_READ=4;
 reg [2:0] state=PRIMARY;
 reg [28:0] saved_addr;
 reg [63:0] saved_din;
 reg [7:0] saved_be, saved_burst;
 reg saved_rd, saved_we;
 reg [7:0] remaining=0;
 wire accepted_read=ddr_rd && !ddr_busy;
 assign primary_dout=ddr_dout;
 assign video_dout=ddr_dout;
 assign idle=(state==PRIMARY) && primary_idle &&
             !primary_rd && !primary_we && !video_rd && !video_we;

 // Drive command strobes once, independently of the BUSY/READY return mux.
 // This is logically identical to the original case mux, but prevents delta
 // oscillation when an outer arbiter feeds combinational READY back to us.
 assign ddr_rd=(state==PRIMARY && primary_rd) ||
               (state==PRIMARY_PENDING && saved_rd) ||
               (state==VIDEO_COMMAND && video_rd);
 assign ddr_we=(state==PRIMARY && primary_we) ||
               (state==PRIMARY_PENDING && saved_we) ||
               (state==VIDEO_COMMAND && video_we);

 always_comb begin
  ddr_addr=primary_addr; ddr_din=primary_din;
  ddr_byteenable=primary_byteenable; ddr_burst=primary_burst;
  primary_busy=1; video_busy=1;
  primary_ready=0; video_ready=0;
  case(state)
   PRIMARY: begin
    primary_busy=ddr_busy;
    primary_ready=ddr_ready && accepted_read;
   end
   PRIMARY_PENDING: begin
    ddr_addr=saved_addr; ddr_din=saved_din;
    ddr_byteenable=saved_be; ddr_burst=saved_burst;
    primary_busy=ddr_busy;
    primary_ready=ddr_ready && accepted_read;
   end
   PRIMARY_READ: primary_ready=ddr_ready;
   VIDEO_COMMAND: begin
    ddr_addr=video_addr; ddr_din=video_din;
    ddr_byteenable=8'hff; ddr_burst=video_rd ? video_burst : 8'd1;
    video_busy=ddr_busy;
    video_ready=ddr_ready && accepted_read;
   end
   VIDEO_READ: video_ready=ddr_ready;
   default: begin end
  endcase
 end

 always @(posedge clk) begin
  case(state)
   PRIMARY, PRIMARY_PENDING: begin
    if(ddr_rd || ddr_we) begin
     if(ddr_busy) begin
      if(state==PRIMARY && primary_rd && primary_pulse_read) begin
       saved_addr<=primary_addr; saved_din<=primary_din;
       saved_be<=primary_byteenable; saved_burst<=primary_burst;
       saved_rd<=primary_rd; saved_we<=primary_we;
       state<=PRIMARY_PENDING;
      end
     end else if(ddr_rd) begin
      remaining<=ddr_burst - (ddr_ready ? 8'd1 : 8'd0);
      if(ddr_ready && ddr_burst==1) state<=PRIMARY;
      else state<=PRIMARY_READ;
     end else state<=PRIMARY;
    end else if(state==PRIMARY && primary_idle && (video_rd || video_we)) begin
     // Registered ownership prevents a same-cycle grant/BUSY combinational
     // race: primary saw !busy at the previous edge and must be idle there.
     state<=VIDEO_COMMAND;
    end
   end
   PRIMARY_READ: if(ddr_ready) begin
    remaining<=remaining-8'd1;
    if(remaining==1) state<=PRIMARY;
   end
   VIDEO_COMMAND: begin
    // Cancellation before acceptance is safe; accepted reads cannot cancel.
    if(!video_rd && !video_we) state<=PRIMARY;
    else if(!ddr_busy) begin
     if(video_rd) begin
      remaining<=video_burst - (ddr_ready ? 8'd1 : 8'd0);
      if(ddr_ready && video_burst==1) state<=PRIMARY;
      else state<=VIDEO_READ;
     end else state<=PRIMARY;
    end
   end
   VIDEO_READ: if(ddr_ready) begin
    remaining<=remaining-8'd1;
    if(remaining==1) state<=PRIMARY;
   end
   default: state<=PRIMARY;
  endcase
 end
 // Scheduling: at least one PRIMARY cycle follows each video command. A
 // waiting primary always wins that cycle. Video is served on the first
 // explicitly safe idle opportunity. No finite video latency can be promised
 // if the legacy normal client never declares idle. Once granted, occupancy
 // is bounded by one video command and its <=255 DDR response beats (assuming
 // the external DDR eventually accepts commands and returns every beat).
endmodule
