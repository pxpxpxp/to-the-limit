// Volatile native-scan picture hold for snapshot pauses. This is presentation
// memory, never part of the machine snapshot or any battery/manual save slot.
// Six exact, consecutive VCE master-clock samples fit in one DDR word. Keeping
// physical H positions (rather than pixel ordinals) makes dot-mode changes safe.
module video_frame_replay #(
    parameter integer LINE_CLOCKS = 2730,
    parameter integer MAX_LINES = 263,
    parameter integer READ_BURST = 32,
    parameter [28:0] DDR_BASE = 29'h07a00000,
    parameter [28:0] FRAME_STRIDE = 29'h00020000
)(
    input wire clk,
    input wire reset, enabled, freeze,
    input wire [51:0] source_phase, reference_phase,
    input wire [9:0] pixel_in, // {BW,G[2:0],R[2:0],B[2:0]}
    output wire [9:0] pixel_out,
    output reg reference_ce = 0,
    output reg reference_hs = 0, reference_vs = 0,
    output reg reference_hbl = 1, reference_vbl = 1,
    output reg frame_valid = 0,
    output wire replay_valid,
    output reg underflow = 0,
    output reg capture_fault = 0,
    output reg [28:0] ram_addr = 0,
    output reg [63:0] ram_din = 0,
    output reg [7:0] ram_burst = 1,
    output reg ram_rd = 0, ram_we = 0,
    input wire ram_busy, ram_ready,
    input wire [63:0] ram_dout
);
    localparam integer WORDS = LINE_CLOCKS / 6;
    localparam integer AW = $clog2(WORDS);
    localparam integer DEPTH = 1 << AW;
    localparam [2:0] CAP_IDLE=0, CAP_RUN=1, CAP_DRAIN=2, CAP_READY=3, CAP_ABORT=4;
    localparam [2:0] BUS_IDLE=0, BUS_READ=1, BUS_READ_DRAIN=2,
                     BUS_WRITE_PREP=3, BUS_WRITE_DATA=4, BUS_WRITE=5;

    // Four logical line buffers. No initializer or full-RAM reset: validity
    // metadata, not power-up contents, controls every replay read.
    (* ramstyle = "M10K" *) reg [63:0] capture_ram [0:2*DEPTH-1];
    (* ramstyle = "M10K" *) reg [63:0] replay_ram [0:2*DEPTH-1];
    reg [63:0] capture_q, replay_q;
    reg [2:0] cap_state=CAP_IDLE, bus_state=BUS_IDLE;
    reg [1:0] front_bank=0, capture_bank=1;
    reg [9:0] front_lines=0, capture_lines=0;
    reg frame_good=0, line_good=0;
    reg [59:0] pack=0;
    reg [2:0] pack_pos=0;
    reg [AW-1:0] pack_word=0;
    reg [1:0] cap_pending=0;
    reg [9:0] cap_line [0:1];
    reg [1:0] cap_bank [0:1];
    reg cap_draining=0, cap_drain_half=0;
    reg [AW-1:0] cap_drain_word=0;
    reg [9:0] cap_drain_line=0;
    reg [1:0] cap_drain_bank=0;
    reg [11:0] old_source_h=12'hfff, old_ref_h=12'hfff;
    reg [9:0] old_source_v=10'h3ff, old_ref_v=10'h3ff;
    wire [11:0] sh=source_phase[11:0], rh=reference_phase[11:0];
    wire [9:0] sv=source_phase[21:12], rv=reference_phase[21:12];
    wire source_step=(sh!=old_source_h || sv!=old_source_v);
    wire reference_step=(rh!=old_ref_h || rv!=old_ref_v);
    wire source_boundary=source_step && sh==0 && sv==0;
    wire source_valid=sh<LINE_CLOCKS && sv<source_phase[31:22] &&
                      source_phase[31:22]<=MAX_LINES && source_phase[31:22]!=0;
    wire invalidate=reset || !enabled;

    // Each read descriptor is immutable until all accepted beats arrive.
    // Reset/freeze never clear bus_state or abandon accepted DDR ownership.
    reg read_active=0, read_half=0;
    reg [9:0] read_line=0;
    reg [1:0] read_bank=0;
    reg [AW:0] read_word=0;
    reg [AW:0] response_word=0;
    reg [7:0] beats_left=0;
    reg [1:0] line_valid=0;
    reg [9:0] replay_line [0:1];
    reg [1:0] replay_bank [0:1];
    reg [9:0] desired_line=0;
    reg [1:0] desired_bank=0;
    reg desired_half=0, desired_valid=0;
    reg read_discard=0;

    // Decode physical H with a synchronous constant ROM. A combinational
    // divide-by-six exceeded the related-clock setup budget on Cyclone V.
    // The ROM and line RAM are two matched video-clock stages; live color,
    // freeze, validity and all timing controls receive the identical delay.
    // Values outside this parameterized line are benign and never valid.
    (* romstyle = "M10K" *) reg [AW+2:0] position_rom [0:4095];
    integer position_init;
    initial begin
        for(position_init=0;position_init<4096;position_init=position_init+1)
            position_rom[position_init] = position_init<LINE_CLOCKS ?
                ((position_init/6)<<3) | (position_init%6) : 0;
    end
    reg [AW+2:0] display_decode_q=0;
    wire display_half=rv[0];
    reg display_half_q=0;
    reg [2:0] display_pos_q=0;
    reg [9:0] live_d=0, live_q=0;
    reg freeze_d=0, freeze_q=0, valid_d=0, valid_q=0;
    reg [4:0] timing_d=5'b00011;
    wire current_line_valid=frame_valid && rv<front_lines && rh<LINE_CLOCKS &&
                            line_valid[display_half] &&
                            replay_line[display_half]==rv &&
                            replay_bank[display_half]==front_bank;
    assign replay_valid=valid_q;
    assign pixel_out=freeze_q ? (valid_q ? replay_q[display_pos_q*10 +: 10] : 10'd0) : live_q;

    function automatic [28:0] address(input [1:0] bank, input [9:0] line,
                                      input [AW:0] word_index);
        address=DDR_BASE + bank*FRAME_STRIDE + line*WORDS + word_index;
    endfunction
    function automatic [1:0] free_bank(input [1:0] new_front, input [1:0] busy_bank,
                                       input busy_valid);
        begin
            if(new_front!=0 && (!busy_valid || busy_bank!=0)) free_bank=0;
            else if(new_front!=1 && (!busy_valid || busy_bank!=1)) free_bank=1;
            else free_bank=2;
        end
    endfunction
    wire start_capture=source_boundary && !invalidate && !freeze && source_valid &&
                       (cap_state==CAP_IDLE || cap_state==CAP_READY) &&
                       cap_pending==0 && !cap_draining;
    wire [1:0] starting_bank=free_bank(cap_state==CAP_READY ? capture_bank : front_bank,
                                     read_bank,read_active);
    wire cap_half_busy=cap_pending[sv[0]] || (cap_draining && cap_drain_half==sv[0]);
    wire cap_sample=source_step && !invalidate && !freeze && source_valid &&
                    (cap_state==CAP_RUN || start_capture);
    wire [7:0] next_burst=(WORDS-read_word > READ_BURST) ? READ_BURST : WORDS-read_word;

    always @(posedge clk) begin
        capture_q <= capture_ram[{cap_drain_half,cap_drain_word}];
        display_decode_q <= position_rom[rh];
        display_half_q <= display_half;
        replay_q <= replay_ram[{display_half_q,display_decode_q[AW+2:3]}];
        display_pos_q <= display_decode_q[2:0];
        live_d <= pixel_in;
        live_q <= live_d;
        freeze_d <= freeze;
        freeze_q <= freeze_d;
        valid_d <= current_line_valid && !invalidate;
        valid_q <= valid_d;
        timing_d <= {reference_phase[38], ~reference_phase[49],
                     ~reference_phase[50], reference_phase[47], reference_phase[48]};
        {reference_ce,reference_hs,reference_vs,reference_hbl,reference_vbl} <= timing_d;
        old_source_h <= sh; old_source_v <= sv;
        old_ref_h <= rh; old_ref_v <= rv;

        // A miss never emits uninitialized/stale data. Sticky diagnostics are
        // visible to tests; fallback remains the baseline black picture hold.
        if(freeze && frame_valid && !reference_phase[47] && !reference_phase[48] &&
           !current_line_valid) underflow<=1;

        if(invalidate) begin
            frame_valid<=0; line_valid<=0; desired_valid<=0;
            frame_good<=0; line_good<=0;
            cap_state<=CAP_ABORT;
            cap_pending<=0;
            // A line that was already accepted still drains into a private
            // scratch buffer. It cannot become valid after cancellation.
            if(read_active) read_discard<=1;
            underflow<=0; capture_fault<=0;
        end else begin
            if(freeze && cap_state==CAP_RUN) begin
                frame_good<=0; line_good<=0; cap_state<=CAP_ABORT;
            end
            if(cap_state==CAP_ABORT && cap_pending==0 && !cap_draining)
                cap_state<=CAP_IDLE;
            if(cap_state==CAP_DRAIN && cap_pending==0 && !cap_draining)
                cap_state<=frame_good ? CAP_READY : CAP_IDLE;

            // Publish only a complete, fully written frame, and only at a
            // field boundary while live. Capture one full field, drain during
            // the next, then publish; this deliberately avoids partial frames.
            if(start_capture) begin
                if(cap_state==CAP_READY) begin
                    front_bank<=capture_bank; front_lines<=capture_lines;
                    frame_valid<=1;
                end
                capture_bank<=starting_bank;
                capture_lines<=source_phase[31:22];
                cap_state<=CAP_RUN; frame_good<=1;
            end else if(source_boundary && cap_state==CAP_RUN && !freeze)
                cap_state<=CAP_DRAIN;

            if(cap_sample && !(source_boundary && cap_state==CAP_RUN)) begin
                if(!start_capture && source_phase[31:22]!=capture_lines) begin
                    frame_good<=0; capture_fault<=1;
                end
                if(sh==0) begin
                    pack_pos<=1; pack_word<=0; pack<={50'd0,pixel_in};
                    line_good<=!cap_half_busy;
                    if(cap_half_busy) begin frame_good<=0; capture_fault<=1; end
                end else begin
                    if(pack_pos==5) begin
                        if(line_good) capture_ram[{sv[0],pack_word}]<={4'd0,pixel_in,pack[49:0]};
                        pack_pos<=0; pack_word<=pack_word+1'b1;
                    end else begin
                        pack[pack_pos*10 +: 10]<=pixel_in;
                        pack_pos<=pack_pos+1'b1;
                    end
                    if(sh==LINE_CLOCKS-1 && line_good) begin
                        cap_pending[sv[0]]<=1;
                        cap_line[sv[0]]<=sv;
                        cap_bank[sv[0]]<=capture_bank;
                    end
                end
            end

            // Prefetch the next physical line. Metadata is changed only after
            // an entire line arrives, so an incomplete burst cannot be shown.
            if(reference_step && rh==0 && frame_valid) begin
                desired_line <= rv+1'b1>=reference_phase[31:22] ? 10'd0 : rv+1'b1;
                desired_half <= rv+1'b1>=reference_phase[31:22] ? 1'b0 : ~rv[0];
                desired_bank <= front_bank;
                desired_valid <= 1;
                if(start_capture && cap_state==CAP_READY) desired_bank<=capture_bank;
            end
        end

        // Launch queued capture-line writes. The pending bit is cleared on
        // taking the descriptor; cap_draining protects that RAM until done.
        if(!cap_draining && cap_pending!=0 && !invalidate) begin
            cap_draining<=1;
            cap_drain_half<=cap_pending[0] ? 0 : 1;
            cap_drain_line<=cap_pending[0] ? cap_line[0] : cap_line[1];
            cap_drain_bank<=cap_pending[0] ? cap_bank[0] : cap_bank[1];
            cap_drain_word<=0;
            if(cap_pending[0]) cap_pending[0]<=0; else cap_pending[1]<=0;
        end

        // Start a prefetch only into the non-displayed line half. A slow old
        // burst drains before another begins; no cancellation reroutes beats.
        if(!read_active && desired_valid && !invalidate &&
           (desired_half!=display_half || reference_phase[48]) && desired_line<front_lines &&
           !(line_valid[desired_half] && replay_line[desired_half]==desired_line &&
             replay_bank[desired_half]==desired_bank)) begin
            read_active<=1; read_half<=desired_half;
            read_line<=desired_line; read_bank<=desired_bank;
            read_word<=0; response_word<=0; read_discard<=0;
            line_valid[desired_half]<=0;
            desired_valid<=0;
        end

        // Reads use bounded bursts; capture writes yield after each word.
        // The outer arbiter preserves the normal/snapshot client's ownership.
        case(bus_state)
            BUS_IDLE: begin
                if(read_active) begin
                    ram_addr<=address(read_bank,read_line,read_word);
                    ram_burst<=next_burst; beats_left<=next_burst;
                    ram_rd<=1; bus_state<=BUS_READ;
                end else if(cap_draining) bus_state<=BUS_WRITE_PREP;
            end
            BUS_READ: if(!ram_busy) begin
                ram_rd<=0;
                bus_state<=BUS_READ_DRAIN;
                if(ram_ready) begin
                    replay_ram[{read_half,response_word[AW-1:0]}]<=ram_dout;
                    response_word<=response_word+1'b1;
                    beats_left<=beats_left-1'b1;
                    if(beats_left==1) begin
                        read_word<=read_word+ram_burst;
                        bus_state<=BUS_IDLE;
                        if(read_word+ram_burst==WORDS) begin
                            read_active<=0;
                            if(!read_discard && !invalidate) begin
                                line_valid[read_half]<=1;
                                replay_line[read_half]<=read_line;
                                replay_bank[read_half]<=read_bank;
                            end
                        end
                    end
                end
            end
            BUS_READ_DRAIN: if(ram_ready) begin
                replay_ram[{read_half,response_word[AW-1:0]}]<=ram_dout;
                response_word<=response_word+1'b1;
                beats_left<=beats_left-1'b1;
                if(beats_left==1) begin
                    read_word<=read_word+ram_burst;
                    bus_state<=BUS_IDLE;
                    if(read_word+ram_burst==WORDS) begin
                        read_active<=0;
                        if(!read_discard && !invalidate) begin
                            line_valid[read_half]<=1;
                            replay_line[read_half]<=read_line;
                            replay_bank[read_half]<=read_bank;
                        end
                    end
                end
            end
            BUS_WRITE_PREP: bus_state<=BUS_WRITE_DATA;
            BUS_WRITE_DATA: begin
                ram_addr<=address(cap_drain_bank,cap_drain_line,{1'b0,cap_drain_word});
                ram_din<=capture_q; ram_burst<=1;
                ram_we<=1; bus_state<=BUS_WRITE;
            end
            BUS_WRITE: if(!ram_busy) begin
                ram_we<=0; bus_state<=BUS_IDLE;
                if(cap_drain_word==WORDS-1) cap_draining<=0;
                else cap_drain_word<=cap_drain_word+1'b1;
            end
            default: bus_state<=BUS_IDLE;
        endcase
        // Publication begins a new frame generation, even when a DDR bank
        // number has been reused. Clear both cached-line valid bits after all
        // completion assignments. A coincident old-bank response may drain,
        // but cannot leave a stale cache hit eligible in the new generation.
        // Publication is at field start in vertical blank; normal prefetch
        // repopulates the line halves before active video.
        if(start_capture && cap_state==CAP_READY) line_valid<=0;
    end
endmodule
