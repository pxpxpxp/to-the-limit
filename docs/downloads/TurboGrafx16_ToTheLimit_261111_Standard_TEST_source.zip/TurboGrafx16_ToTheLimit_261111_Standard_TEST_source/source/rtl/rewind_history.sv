// Volatile HuCard rewind history. Owns no external memory and never touches SD.
// The common snapshot backend serializes all private/manual transfers. Pointer
// changes require its explicit, fully drained completion, never sticky valid.
module rewind_history #(
 parameter integer SLOT_BITS=7,
 parameter integer CAPTURE_FRAMES=15,
 parameter integer REWIND_FRAMES=4
)(
 input wire clk,reset,enabled,frame_tick,rewind_held,osd_open,manual_request,
 input wire backend_busy,backend_accept,backend_done,backend_failed,
 // 0 preserves the original behavior. Depth 1/2/3 retains half/quarter/eighth
 // of the physical slots (at least one). Rate 1 captures twice as frequently
 // (rounded up); rate 2/3 captures every 2x/4x CAPTURE_FRAMES ticks.
 input wire [1:0] history_depth,capture_rate,
 output wire save_request,load_request,private_mode,
 output reg [SLOT_BITS-1:0] private_slot=0,
 output reg [SLOT_BITS:0] count=0,
 output wire held_active
);
 localparam integer CAP_BITS=(CAPTURE_FRAMES>1)?$clog2(4*CAPTURE_FRAMES+1):3;
 localparam [SLOT_BITS:0] PHYSICAL_SLOTS=(1<<SLOT_BITS);
 reg [1:0] active_depth=0,active_rate=0;
 wire config_changed=(history_depth!=active_depth)||(capture_rate!=active_rate);
 wire invalidate_history=!enabled||manual_request||config_changed;
 wire [SLOT_BITS:0] shifted_limit=PHYSICAL_SLOTS>>active_depth;
 wire [SLOT_BITS:0] history_limit=(shifted_limit!=0)?shifted_limit:1'b1;
 wire [CAP_BITS-1:0] capture_interval=
  (active_rate==2'd1) ? (CAPTURE_FRAMES+1)/2 :
  (active_rate==2'd2) ? 2*CAPTURE_FRAMES :
  (active_rate==2'd3) ? 4*CAPTURE_FRAMES : CAPTURE_FRAMES;
 localparam integer REW_BITS=(REWIND_FRAMES>1)?$clog2(REWIND_FRAMES+1):1;
 localparam [1:0] IDLE=0,REQUEST=1,INFLIGHT=2;
 reg [1:0] state=IDLE;
 reg loading=0,invalidated=0,old_held=0;
 reg [SLOT_BITS-1:0] head=0;
 reg [CAP_BITS-1:0] capture_count=0;
 reg [REW_BITS-1:0] rewind_wait=0;
 assign private_mode=(state!=IDLE);
 assign save_request=(state==REQUEST)&&!loading&&!rewind_held&&enabled&&!osd_open&&!manual_request&&!config_changed;
 assign load_request=(state==REQUEST)&&loading&&rewind_held&&enabled&&!osd_open&&!manual_request&&!config_changed;
 // This is not a machine-freeze signal: run between restores so the restored
 // video frame can reach HDMI/analog. At the oldest point reload that snapshot
 // periodically, rather than underflowing or running forward indefinitely.
 assign held_active=enabled&&!config_changed&&rewind_held&&((count!=0)||private_mode);
 always @(posedge clk) begin
  old_held<=rewind_held;
  // Settings are clk-synchronous HPS status inputs. A change invalidates only
  // the ring metadata. Never reset an accepted backend operation: its private
  // slot/owner must survive until the drained completion, even if settings
  // change again or return to their old value before completion.
  active_depth<=history_depth;active_rate<=capture_rate;
  if(reset) begin
   state<=IDLE;head<=0;count<=0;private_slot<=0;loading<=0;
   capture_count<=0;rewind_wait<=0;invalidated<=0;old_held<=0;
  end else begin
   if(invalidate_history) begin
    count<=0;head<=0;capture_count<=0;rewind_wait<=0;
   end
   case(state)
    IDLE: begin
     invalidated<=0;
     if(!rewind_held) rewind_wait<=0;
     if(!invalidate_history&&!osd_open&&!backend_busy) begin
      if(rewind_held) begin
       capture_count<=0;
       if(count!=0 && (rewind_wait==0 || !old_held)) begin
        private_slot<=head-1'b1;loading<=1;state<=REQUEST;
       end else if(frame_tick && rewind_wait!=0) rewind_wait<=rewind_wait-1'b1;
      end else if(frame_tick) begin
       if(capture_count==capture_interval-1'b1) begin
        private_slot<=head;loading<=0;state<=REQUEST;capture_count<=0;
       end else capture_count<=capture_count+1'b1;
      end
     end
    end
    REQUEST: begin
     // Acceptance precedes cancellation: it reports the previous consuming
     // edge, so an already accepted transaction must retain its ownership.
     if(backend_accept) begin
      state<=INFLIGHT;invalidated<=invalidate_history;
     end else if(invalidate_history||osd_open||(loading!=rewind_held)) begin
      state<=IDLE;capture_count<=0;rewind_wait<=0;
     end
    end
    INFLIGHT: begin
     if(invalidate_history) invalidated<=1;
     if(backend_failed) begin
      count<=0;head<=0;state<=IDLE;capture_count<=0;rewind_wait<=0;
     end else if(backend_done) begin
      state<=IDLE;capture_count<=0;rewind_wait<=REWIND_FRAMES;
      if(!invalidated&&!invalidate_history) begin
       if(loading) begin
        if(count>1) begin head<=private_slot;count<=count-1'b1;end
       end else begin
        // Keep the fixed physical modulo ring; count limits the retained
        // suffix. No dynamic address math can escape the 16 MiB reservation.
        head<=head+1'b1;
        if(count<history_limit) count<=count+1'b1;
       end
      end
     end
    end
    default: begin state<=IDLE;count<=0;head<=0;end
   endcase
  end
 end
endmodule
