library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.v3_event_pkg.all;

entity v3_decoder is
  generic (WRAM_WORDS : positive := 8192; VRAM_WORDS : positive := 32768; SAMPLE_STRIDE : positive := 15);
  port (
    clk, reset_n, stream_fault, record_valid, end_input : in std_logic;
    generation : in std_logic_vector(7 downto 0);
    record_address : in unsigned(16 downto 0);
    record_data : in word_t;
    operation_valid, operation_sample : out std_logic;
    operation_domain : out std_logic;
    operation_address : out address_t;
    operation_data : out value_t;
    canonical_valid : out std_logic;
    canonical_address : out unsigned(15 downto 0);
    canonical_data : out value_t;
    selected_valid : out std_logic;
    selected_domain : out unsigned(2 downto 0);
    selected_index : out unsigned(11 downto 0);
    selected_data : out value_t;
    tentative_cut, tentative_valid : out std_logic;
    cut_epoch : out std_logic_vector(7 downto 0);
    receipt_wram : out std_logic_vector(15 downto 0);
    receipt_vram : out std_logic_vector(31 downto 0);
    receipt_line : out std_logic_vector(35 downto 0);
    publish, descriptor_valid : out std_logic;
    published_header, published_end : out unsigned(16 downto 0);
    published_epoch : out std_logic_vector(7 downto 0);
    fault, sealed, end_ok : out std_logic;
    wram_samples, vram_samples : out natural range 0 to 32768
  );
end;

architecture rtl of v3_decoder is
  type coverage_t is array (0 to 1) of natural range 0 to 32768;
  type tags_t is array (0 to 1) of unsigned(14 downto 0);
  -- Both canonical domains divide 2**15 (enforced by the geometry assertion).
  -- Reduce the generic before converting so every positive stride fits, then
  -- discard the carry and mask to the selected domain without a divider.
  constant TAG_STRIDE : unsigned(14 downto 0) := to_unsigned(SAMPLE_STRIDE mod 32768, 15);
  constant TAG_MASK : tags_t := (to_unsigned(WRAM_WORDS - 1, 15), to_unsigned(VRAM_WORDS - 1, 15));
  type pending_t is (NONE, SINGLE_WRITE, RECEIPTS, COMMON_WRITES);
  type state_t is record
    bad, closed, active_image, selected_done, descriptor, tentative : boolean;
    cursor : natural range 0 to 131072;
    coverage : coverage_t;
    next_tag : tags_t;
    base_done : std_logic_vector(1 downto 0);
    pending : pending_t;
    continuation_domain : natural range 0 to 1;
    continuation_base : boolean;
    receipt_number : natural range 0 to 2;
    write_mask : std_logic_vector(1 downto 0);
    image_epoch : std_logic_vector(7 downto 0);
    header : unsigned(16 downto 0);
    selection_domain : natural range 2 to 5;
    selection_index : natural range 0 to 3497;
    q_wram : std_logic_vector(15 downto 0);
    q_vram : std_logic_vector(31 downto 0);
    q_line : std_logic_vector(35 downto 0);
    descriptor_header, descriptor_end : unsigned(16 downto 0);
    descriptor_epoch : std_logic_vector(7 downto 0);
    held_generation : std_logic_vector(7 downto 0);
  end record;
  constant INITIAL : state_t := (
    bad => false, closed => false, active_image => false, selected_done => false,
    descriptor => false, tentative => false, cursor => 0,
    coverage => (others => 0), next_tag => (others => (others => '0')),
    base_done => "00", pending => NONE, continuation_domain => 0,
    continuation_base => false, receipt_number => 0, write_mask => "00",
    image_epoch => (others => '0'), header => (others => '0'),
    selection_domain => 2, selection_index => 0,
    q_wram => (others => '0'), q_vram => (others => '0'), q_line => (others => '0'),
    descriptor_header => (others => '0'), descriptor_end => (others => '0'),
    descriptor_epoch => (others => '0'), held_generation => (others => '0'));
  signal state : state_t := INITIAL;
begin
  assert power_of_two(WRAM_WORDS) and power_of_two(VRAM_WORDS) and WRAM_WORDS <= 8192 and VRAM_WORDS <= 32768 report "canonical geometry" severity failure;
  assert SAMPLE_STRIDE mod 2 = 1 report "stride must be odd" severity failure;
  fault <= '1' when state.bad else '0';
  sealed <= '1' when state.closed else '0';
  descriptor_valid <= '1' when state.descriptor else '0';
  tentative_valid <= '1' when state.tentative else '0';
  cut_epoch <= state.image_epoch;
  receipt_wram <= state.q_wram; receipt_vram <= state.q_vram; receipt_line <= state.q_line;
  published_header <= state.descriptor_header; published_end <= state.descriptor_end;
  published_epoch <= state.descriptor_epoch;
  wram_samples <= state.coverage(0); vram_samples <= state.coverage(1);

  process(clk)
    variable next_state : state_t;
    variable valid_word, record_ok, op, sample_op, select_op, cut_op, publish_op : boolean;
    variable kind, domain_number, expected_domain, body_count, index_number, final_index : natural;
    variable flag : std_logic;
  begin
    if rising_edge(clk) then
      next_state := state;
      canonical_valid <= '0'; operation_valid <= '0'; selected_valid <= '0'; tentative_cut <= '0'; publish <= '0'; end_ok <= '0';
      record_ok := false; op := false; sample_op := false; select_op := false; cut_op := false; publish_op := false;
      if reset_n = '0' then
        next_state := INITIAL;
        operation_sample <= '0'; operation_domain <= '0'; operation_address <= (others => '0'); operation_data <= (others => '0');
        canonical_address <= (others => '0'); canonical_data <= (others => '0');
        selected_domain <= (others => '0'); selected_index <= (others => '0'); selected_data <= (others => '0');
      elsif not is_strong(reset_n & stream_fault & record_valid & end_input & generation) then
        next_state.bad := true;
      elsif state.bad then
        null;
      elsif stream_fault = '1' or (state.cursor > 0 and generation /= state.held_generation) then
        next_state.bad := true;
      else
        if record_valid = '1' then
          valid_word := not state.closed and is_strong(std_logic_vector(record_address) & record_data);
          if valid_word then
            valid_word := state.cursor < 131072 and to_integer(record_address) = state.cursor and record_data(59 downto 52) = generation;
          end if;
          if valid_word then
            kind := to_integer(unsigned(record_data(63 downto 60)));
            domain_number := to_integer(unsigned(record_data(51 downto 49)));
            flag := record_data(48);
            valid_word := domain_number /= 6;
            if (kind = 1 or kind = 2 or kind = 8) and domain_number <= 1 then
              valid_word := valid_word and to_integer(unsigned(record_data(47 downto 33))) < domain_size(domain_number, WRAM_WORDS, VRAM_WORDS);
            end if;
            if state.pending = SINGLE_WRITE or state.pending = COMMON_WRITES then
              expected_domain := state.continuation_domain;
              valid_word := valid_word and kind = 8 and domain_number = expected_domain and flag = '0' and record_data(16 downto 0) = (16 downto 0 => '0');
              if expected_domain = 0 and record_data(32 downto 25) /= x"00" then valid_word := false; end if;
              if valid_word then
                op := true;
                if state.pending = SINGLE_WRITE then
                  if state.continuation_base then next_state.base_done(expected_domain) := '1'; end if;
                  next_state.pending := NONE;
                else
                  next_state.write_mask(expected_domain) := '0';
                  if next_state.write_mask = "00" then next_state.pending := NONE;
                  else next_state.continuation_domain := 1; end if;
                end if;
              end if;
            elsif state.pending = RECEIPTS then
              if state.receipt_number = 0 then expected_domain := 0;
              elsif state.receipt_number = 1 then expected_domain := 1;
              else expected_domain := 4; end if;
              valid_word := valid_word and kind = 5 and domain_number = expected_domain and flag = '0' and
                record_data(47 downto 40) = state.image_epoch and record_data(3 downto 0) = x"3";
              if expected_domain = 0 and record_data(39 downto 20) /= x"00000" then valid_word := false; end if;
              if expected_domain = 1 and record_data(39 downto 36) /= x"0" then valid_word := false; end if;
              if valid_word then
                if expected_domain = 0 then next_state.q_wram := record_data(19 downto 4);
                elsif expected_domain = 1 then next_state.q_vram := record_data(35 downto 4);
                else next_state.q_line := record_data(39 downto 4); end if;
                if state.receipt_number < 2 then next_state.receipt_number := state.receipt_number + 1;
                else
                  cut_op := true; next_state.tentative := true;
                  if state.write_mask = "00" then next_state.pending := NONE;
                  else
                    next_state.pending := COMMON_WRITES;
                    if state.write_mask(0) = '1' then next_state.continuation_domain := 0;
                    else next_state.continuation_domain := 1; end if;
                  end if;
                end if;
              end if;
            elsif kind = 1 or kind = 2 then
              valid_word := valid_word and domain_number <= 1 and not state.active_image and not state.descriptor and record_data(16 downto 0) = (16 downto 0 => '0');
              if domain_number = 0 and record_data(32 downto 25) /= x"00" then valid_word := false; end if;
              if kind = 2 then valid_word := valid_word and flag = '0'; end if;
              if valid_word and kind = 1 then
                valid_word := not state.active_image and state.base_done(domain_number) = '0' and state.coverage(domain_number) < domain_size(domain_number, WRAM_WORDS, VRAM_WORDS);
                if state.coverage(domain_number) > 0 and unsigned(record_data(47 downto 33)) /= state.next_tag(domain_number) then valid_word := false; end if;
                if valid_word then
                  next_state.coverage(domain_number) := state.coverage(domain_number) + 1;
                  next_state.next_tag(domain_number) := (unsigned(record_data(47 downto 33)) + TAG_STRIDE) and TAG_MASK(domain_number);
                  if flag = '1' then next_state.pending := SINGLE_WRITE; next_state.continuation_domain := domain_number; next_state.continuation_base := false; end if;
                end if;
              end if;
              if valid_word then op := true; sample_op := kind = 1; end if;
            elsif kind = 3 then
              valid_word := valid_word and domain_number <= 1 and not state.active_image and
                unsigned(record_data(47 downto 32)) = domain_size(domain_number, WRAM_WORDS, VRAM_WORDS) and record_data(31 downto 8) = x"000000" and record_data(7 downto 0) = x"03";
              if valid_word then
                valid_word := state.coverage(domain_number) = domain_size(domain_number, WRAM_WORDS, VRAM_WORDS) and state.base_done(domain_number) = '0';
                if valid_word then
                  if flag = '1' then next_state.pending := SINGLE_WRITE; next_state.continuation_domain := domain_number; next_state.continuation_base := true;
                  else next_state.base_done(domain_number) := '1'; end if;
                end if;
              end if;
            elsif kind = 4 then
              body_count := 3;
              if record_data(31) = '1' then body_count := body_count + 1; end if;
              if record_data(30) = '1' then body_count := body_count + 1; end if;
              valid_word := valid_word and domain_number = 7 and flag = '1' and record_data(31 downto 30) = "00" and state.base_done = "11" and
                not state.active_image and not state.descriptor and record_data(39 downto 32) = std_logic_vector(to_unsigned(body_count, 8)) and
                record_data(29 downto 8) = (29 downto 8 => '0') and record_data(7 downto 0) = x"03";
              if valid_word then
                next_state.active_image := true; next_state.selected_done := false;
                next_state.selection_domain := 2; next_state.selection_index := 0;
                next_state.pending := RECEIPTS; next_state.receipt_number := 0;
                next_state.write_mask(0) := record_data(31); next_state.write_mask(1) := record_data(30);
                next_state.header := record_address; next_state.image_epoch := record_data(47 downto 40);
              end if;
            elsif kind = 6 then
              index_number := to_integer(unsigned(record_data(39 downto 28)));
              valid_word := valid_word and selected_payload_ok(index_number, record_data(15 downto 0)) and state.active_image and not state.selected_done and domain_number = state.selection_domain and
                index_number = state.selection_index and flag = '0' and record_data(47 downto 40) = state.image_epoch and
                record_data(27 downto 16) = (27 downto 16 => '0');
              if valid_word then
                select_op := true;
                if index_number = SELECTED_WORDS - 1 then next_state.selected_done := true;
                else next_state.selection_index := index_number + 1; end if;
              end if;
            elsif kind = 7 then
              valid_word := valid_word and domain_number = 7 and flag = '0' and state.active_image and state.selected_done and
                record_data(47 downto 40) = state.image_epoch and
                unsigned(record_data(39 downto 28)) = SELECTED_WORDS and
                record_data(27 downto 8) = x"00000" and record_data(7 downto 0) = x"03";
              if valid_word then
                next_state.descriptor := true; next_state.descriptor_header := state.header;
                next_state.descriptor_end := record_address; next_state.descriptor_epoch := state.image_epoch;
                next_state.active_image := false; next_state.tentative := false; publish_op := true;
              end if;
            else valid_word := false;
            end if;
          end if;
          if not valid_word then next_state.bad := true;
          else record_ok := true; next_state.cursor := state.cursor + 1; next_state.held_generation := generation; end if;
        end if;
        if end_input = '1' and not next_state.bad then
          if next_state.pending /= NONE or next_state.active_image or
            not next_state.descriptor then next_state.bad := true;
          else next_state.closed := true; end_ok <= '1'; end if;
        end if;
      end if;
      if next_state.bad then
        next_state.tentative := false; next_state.descriptor := false;
        if not record_ok then op := false; select_op := false; end if;
        cut_op := false; publish_op := false;
      end if;
      if op then
        canonical_valid <= '1'; canonical_data <= record_data(32 downto 17);
        canonical_address <= resize(unsigned(record_data(47 downto 33)),16);
        if record_data(49) = '1' then canonical_address <= to_unsigned(8192 + to_integer(unsigned(record_data(47 downto 33))),16); end if;
        operation_valid <= '1';
        if sample_op then operation_sample <= '1'; else operation_sample <= '0'; end if;
        operation_domain <= record_data(49); operation_address <= record_data(47 downto 33); operation_data <= record_data(32 downto 17);
      end if;
      if select_op then
        canonical_valid <= '1'; canonical_data <= record_data(15 downto 0);
        canonical_address <= to_unsigned(SELECTED_BASE + to_integer(unsigned(record_data(39 downto 28))),16);
        selected_valid <= '1'; selected_domain <= unsigned(record_data(51 downto 49));
        selected_index <= unsigned(record_data(39 downto 28)); selected_data <= record_data(15 downto 0);
      end if;
      if cut_op then tentative_cut <= '1'; end if;
      if publish_op then publish <= '1'; end if;
      state <= next_state;
    end if;
  end process;
end architecture;
