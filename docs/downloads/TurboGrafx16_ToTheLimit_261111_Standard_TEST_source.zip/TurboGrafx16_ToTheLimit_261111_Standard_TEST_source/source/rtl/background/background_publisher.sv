// One outstanding clk_sys -> clk_ram publication transaction. No gameplay ports.
// power_reset is initialization only. Console reset must drive cancel instead.
module background_publisher(
 input wire clk_sys, clk_ram, power_reset,
 input wire start, cancel,
 input wire [7:0] slot,
 input wire [31:0] rom, config_id, generation,
 input wire [17:0] journal_record_count,
 output wire ready,
 output reg busy=0, done=0, failed=0,
 output wire cmd_valid, cmd_write,
 output wire [28:0] cmd_address,
 output wire [63:0] cmd_data,
 output wire [7:0] cmd_byteenable,
 input wire cmd_ready, read_valid,
 input wire [63:0] read_data,
 input wire writes_drained
);
 localparam [1:0] S_IDLE=0, S_WAIT=1, S_CANCEL=2, S_RETIRE=3;
 localparam [3:0] R_IDLE=0, R_CAPTURE=1, R_START=2, R_RUN=3,
  R_OFFER=4, R_RESOLVE=5, R_CLEANUP_START=6, R_CLEANUP_RUN=7;
 reg [1:0] sys_state=S_IDLE;
 reg [3:0] ram_state=R_IDLE;
 // Bundled data: only change at accepted start; hold through release handshake.
 reg [104:0] metadata_sys=0;
 reg [104:0] metadata_ram=0;
 reg request_sys=0, resolve_sys=0, resolve_cancel_sys=0, cancel_hold_sys=0;
 reg offer_ram=0, offer_failed_ram=0, release_ram=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg request_meta_ram=0, request_sync_ram=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg cancel_meta_ram=0, cancel_sync_ram=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg resolve_meta_ram=0, resolve_sync_ram=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg offer_meta_sys=0, offer_sync_sys=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg release_meta_sys=0, release_sync_sys=0;
 wire publisher_busy, publisher_done, publisher_failed;
 wire publisher_start=(ram_state==R_START && !cancel_sync_ram) || ram_state==R_CLEANUP_START;
 // A late cancellation after RAM completion needs a fresh invalidation. Start
 // that transaction with cancel low, then assert cancel on its very next edge.
 wire publisher_cancel=((ram_state==R_START || ram_state==R_RUN) && cancel_sync_ram)
                       || ram_state==R_CLEANUP_RUN;
 assign ready=sys_state==S_IDLE && !power_reset && !cancel;
 v3_private_publisher publisher(
  .clk(clk_ram),.reset(1'b0),.start(publisher_start && !power_reset),.cancel(publisher_cancel),
  .slot(metadata_ram[104:98]),.rom(metadata_ram[97:66]),.config_id(metadata_ram[65:50]),
  .generation(metadata_ram[49:18]),.journal_record_count(metadata_ram[17:0]),
  .busy(publisher_busy),.done(publisher_done),.failed(publisher_failed),
  .cmd_valid(cmd_valid),.cmd_write(cmd_write),.cmd_address(cmd_address),.cmd_data(cmd_data),
  .cmd_byteenable(cmd_byteenable),.cmd_ready(cmd_ready),.read_valid(read_valid),
  .read_data(read_data),.writes_drained(writes_drained));

 always @(posedge clk_sys or posedge power_reset) begin
  if(power_reset) begin
   sys_state<=S_IDLE;metadata_sys<=0;request_sys<=0;resolve_sys<=0;
   resolve_cancel_sys<=0;cancel_hold_sys<=0;
   offer_meta_sys<=0;offer_sync_sys<=0;release_meta_sys<=0;release_sync_sys<=0;
   busy<=0;done<=0;failed<=0;
  end else begin
   offer_meta_sys<=offer_ram;offer_sync_sys<=offer_meta_sys;
   release_meta_sys<=release_ram;release_sync_sys<=release_meta_sys;
   done<=0;failed<=0;
   case(sys_state)
    S_IDLE: begin
     cancel_hold_sys<=0;
     if(start && ready) begin
      metadata_sys<={slot[6:0],rom,config_id[15:0],generation,journal_record_count};
      request_sys<=!request_sys;busy<=1;sys_state<=S_WAIT;
     end
    end
    S_WAIT: begin
     if(cancel) cancel_hold_sys<=1;
     if(offer_sync_sys==request_sys) begin
      // This edge is the source-domain terminal decision. Cancellation on this
      // edge wins; a later cancellation belongs to no active transaction.
      resolve_sys<=request_sys;
      resolve_cancel_sys<=cancel_hold_sys || cancel;
      if(cancel_hold_sys || cancel) sys_state<=S_CANCEL;
      else begin
       done<=!offer_failed_ram;failed<=offer_failed_ram;busy<=0;sys_state<=S_RETIRE;
      end
     end
    end
    S_CANCEL: if(release_sync_sys==request_sys) begin
     busy<=0;failed<=1;sys_state<=S_IDLE;
    end
    // Terminal status can release DDR ownership, but admission waits until the
    // return handshake has released the held metadata. A held start is retained
    // by valid/ready, never converted to a lossy edge detector.
    S_RETIRE: if(release_sync_sys==request_sys) sys_state<=S_IDLE;
    default: sys_state<=S_IDLE;
   endcase
  end
 end

 always @(posedge clk_ram or posedge power_reset) begin
  if(power_reset) begin
   ram_state<=R_IDLE;metadata_ram<=0;
   request_meta_ram<=0;request_sync_ram<=0;cancel_meta_ram<=0;cancel_sync_ram<=0;
   resolve_meta_ram<=0;resolve_sync_ram<=0;
   offer_ram<=0;offer_failed_ram<=0;release_ram<=0;
  end else begin
   request_meta_ram<=request_sys;request_sync_ram<=request_meta_ram;
   cancel_meta_ram<=cancel_hold_sys;cancel_sync_ram<=cancel_meta_ram;
   resolve_meta_ram<=resolve_sys;resolve_sync_ram<=resolve_meta_ram;
   case(ram_state)
    R_IDLE: if(request_sync_ram!=release_ram) ram_state<=R_CAPTURE;
    // One extra settling cycle after synchronized request detection. Metadata
    // remains held until release_sync_sys returns; constrain its flight time.
    R_CAPTURE: begin metadata_ram<=metadata_sys;ram_state<=R_START;end
    R_START: if(cancel_sync_ram) begin
     offer_failed_ram<=1;offer_ram<=request_sync_ram;ram_state<=R_OFFER;
    end else ram_state<=R_RUN;
    R_RUN: if(publisher_done || publisher_failed) begin
     offer_failed_ram<=publisher_failed;offer_ram<=request_sync_ram;ram_state<=R_OFFER;
    end
    R_OFFER: if(resolve_sync_ram==request_sync_ram) ram_state<=R_RESOLVE;
    // resolve_cancel_sys is bundled with resolve_sys, just like metadata.
    R_RESOLVE: if(resolve_cancel_sys && !offer_failed_ram) ram_state<=R_CLEANUP_START;
     else begin release_ram<=request_sync_ram;ram_state<=R_IDLE;end
    R_CLEANUP_START: ram_state<=R_CLEANUP_RUN;
    R_CLEANUP_RUN: if(publisher_failed) begin
     release_ram<=request_sync_ram;ram_state<=R_IDLE;
    end
    default: ram_state<=R_IDLE;
   endcase
  end
 end
 // synthesis translate_off
 always @(posedge clk_sys) if(!power_reset) begin
  assert(!(done && failed)) else $fatal(1,"conflicting publisher status");
  assert(!(ready && busy)) else $fatal(1,"publisher ready while occupied");
 end
 always @(posedge clk_ram) if(!power_reset && publisher_start)
  assert(!publisher_busy) else $fatal(1,"publisher start while busy");
 // synthesis translate_on
endmodule
