// Lowest-priority, single-outstanding DDR attachment for background capture.
// All signals use clk. Foreground read bursts contain 1..255 beats and writes
// are single-beat. Background commands are always single-beat, with all eight
// byte enables preserved. Command acceptance is exactly command && !busy.
//
// Foreground commands MUST be held until accepted or deliberately canceled.
// Attach the existing video_ddr_arbiter here, not the legacy cache directly:
// that inner arbiter retains normal-cache read pulses while foreground_busy
// is high. Do NOT add pulse retention here: it would resurrect canceled video
// or snapshot reads. foreground_idle must be the inner arbiter's idle output.
//
// No reset is intentional. Core reset/cancel may withdraw unaccepted commands
// but cannot discard ownership of any accepted DDR read. This adapter does
// not buffer writes; acceptance means the real DDR accepted that exact write.
module background_ddr_arbiter (
 input wire clk,
 input wire [28:0] foreground_addr,
 input wire [63:0] foreground_din,
 input wire [7:0] foreground_byteenable, foreground_burst,
 input wire foreground_rd, foreground_we, foreground_idle,
 output wire foreground_busy, foreground_ready,
 output wire [63:0] foreground_dout,
 input wire [28:0] background_addr,
 input wire [63:0] background_din,
 input wire [7:0] background_byteenable,
 input wire background_rd, background_we,
 output wire background_busy, background_ready,
 output wire [63:0] background_dout,
 output wire [28:0] ddr_addr,
 output wire [63:0] ddr_din,
 output wire [7:0] ddr_byteenable, ddr_burst,
 output wire ddr_rd, ddr_we,
 input wire ddr_busy, ddr_ready,
 input wire [63:0] ddr_dout
);
 localparam [1:0] FOREGROUND=0, FOREGROUND_READ=1,
                  BACKGROUND_COMMAND=2, BACKGROUND_READ=3;
 reg [1:0] state=FOREGROUND;
 reg [7:0] remaining=0;
 wire accepted_read=ddr_rd && !ddr_busy;
 assign foreground_dout=ddr_dout;
 assign background_dout=ddr_dout;

 // Continuous muxes avoid combinational feedback/delta-cycle glitches when
 // cascaded with a legacy combinational arbiter. There is no extra pipeline.
 assign ddr_addr=(state==BACKGROUND_COMMAND) ? background_addr : foreground_addr;
 assign ddr_din=(state==BACKGROUND_COMMAND) ? background_din : foreground_din;
 assign ddr_byteenable=(state==BACKGROUND_COMMAND) ? background_byteenable : foreground_byteenable;
 assign ddr_burst=(state==BACKGROUND_COMMAND) ? 8'd1 : foreground_burst;
 assign ddr_rd=(state==FOREGROUND && foreground_rd) ||
               (state==BACKGROUND_COMMAND && background_rd);
 assign ddr_we=(state==FOREGROUND && foreground_we) ||
               (state==BACKGROUND_COMMAND && background_we);
 assign foreground_busy=(state==FOREGROUND) ? ddr_busy : 1'b1;
 assign background_busy=(state==BACKGROUND_COMMAND) ? ddr_busy : 1'b1;
 assign foreground_ready=ddr_ready &&
  ((state==FOREGROUND && accepted_read) || state==FOREGROUND_READ);
 assign background_ready=ddr_ready &&
  ((state==BACKGROUND_COMMAND && accepted_read) || state==BACKGROUND_READ);

 always @(posedge clk) begin
  case(state)
   FOREGROUND: begin
    if(foreground_rd || foreground_we) begin
     if(!ddr_busy && foreground_rd) begin
      remaining<=foreground_burst - (ddr_ready ? 8'd1 : 8'd0);
      if(!(ddr_ready && foreground_burst==1)) state<=FOREGROUND_READ;
     end
    end else if(foreground_idle && (background_rd || background_we)) begin
     // Registered grant: foreground observed !busy at the previous edge.
     // inner.idle proves no primary or video command was launched there.
     state<=BACKGROUND_COMMAND;
    end
   end
   FOREGROUND_READ: if(ddr_ready) begin
    remaining<=remaining-8'd1;
    if(remaining==1) state<=FOREGROUND;
   end
   BACKGROUND_COMMAND: begin
    // An unaccepted held request may be withdrawn by its owner.
    if(!background_rd && !background_we) state<=FOREGROUND;
    else if(!ddr_busy) begin
     if(background_rd && !ddr_ready) state<=BACKGROUND_READ;
     else state<=FOREGROUND;
    end
   end
   BACKGROUND_READ: if(ddr_ready) state<=FOREGROUND;
   default: state<=FOREGROUND;
  endcase
 end
 // Background can starve indefinitely; it must never backpressure gameplay.
 // After a grant, occupancy is one command and at most one response beat,
 // subject to the external DDR's acceptance/response latency. An accepted
 // read cannot be preempted. Every completion restores a foreground cycle.
endmodule
