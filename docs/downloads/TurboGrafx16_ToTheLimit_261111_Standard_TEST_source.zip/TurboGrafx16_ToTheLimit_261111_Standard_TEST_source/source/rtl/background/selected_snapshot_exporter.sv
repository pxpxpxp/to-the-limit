// Read-only adapter between the capture epoch coordinator and immutable mirrors.
// All ports belong to clk_sys. No native/gameplay control port exists.
module selected_snapshot_exporter (
    input  wire        clk_sys,
    input  wire        power_reset,
    input  wire        selected_request_valid,
    output wire        selected_request_ready,
    input  wire [11:0] selected_index,
    output wire        selected_response_valid,
    input  wire        selected_response_ready,
    output wire [15:0] selected_response_data,
    input  wire        selected_cancel,
    output wire        selected_idle,

    output wire        pce_read_valid,
    input  wire        pce_read_ready,
    output wire [1:0]  pce_read_bank,
    output wire [8:0]  pce_read_addr,
    input  wire        pce_out_valid,
    output wire        pce_out_ready,
    input  wire [15:0] pce_out_data,

    output wire        bram_read_valid,
    input  wire        bram_read_ready,
    output wire [9:0]  bram_read_addr,
    input  wire        bram_out_valid,
    output wire        bram_out_ready,
    input  wire [15:0] bram_out_data,

    // Already captured at the common cut, never the live native RAM output.
    input  wire [7:0]  captured_bram_q,
    // Snapshot chain mux. Address settles for a full cycle before sampling.
    output wire [14:0] register_address,
    input  wire [15:0] register_data,
    output wire        register_rotate,

    // Explicit destructive-abort completion handshake for BOTH mirror buses.
    // The mirrors may have already discarded a request on controller release.
    output wire        native_abort,
    input  wire        native_abort_done
);
    localparam [3:0] IDLE=0, PCE_REQUEST=1, PCE_RESPONSE=2,
        BRAM_REQUEST=3, BRAM_RESPONSE=4, SCALAR_CAPTURE=5,
        RESPONSE=6, ABORT=7, CANCELLED=8;
    reg [3:0] state = IDLE;
    reg [1:0] bank = 0;
    reg [8:0] pce_address = 0;
    reg [9:0] bram_address = 0;
    reg [14:0] reg_address = 0;
    reg is_register = 0;
    reg [15:0] held_data = 0;

    wire run = !power_reset && !selected_cancel;
    wire no_native_output = !pce_out_valid && !bram_out_valid;
    assign selected_idle = !power_reset && no_native_output &&
        (state == IDLE || state == CANCELLED);
    assign selected_request_ready = run && state == IDLE &&
        no_native_output && selected_index < 12'd3498;
    assign selected_response_valid = run && state == RESPONSE;
    assign selected_response_data = held_data;
    assign pce_read_valid = run && state == PCE_REQUEST;
    assign pce_read_bank = bank;
    assign pce_read_addr = pce_address;
    assign bram_read_valid = run && state == BRAM_REQUEST;
    assign bram_read_addr = bram_address;
    assign pce_out_ready = !power_reset &&
        (state == PCE_RESPONSE || state == ABORT || selected_cancel);
    assign bram_out_ready = !power_reset &&
        (state == BRAM_RESPONSE || state == ABORT || selected_cancel);
    assign register_address = reg_address;
    // This combinational pulse is sampled on the SAME edge as response accept.
    // The chain rotates only after its previous value was copied to held_data.
    assign register_rotate = selected_response_valid &&
        selected_response_ready && is_register;
    assign native_abort = !power_reset && state == ABORT;

    always @(posedge clk_sys) begin
        if (power_reset) begin
            state <= IDLE;
            bank <= 0;
            pce_address <= 0;
            bram_address <= 0;
            reg_address <= 0;
            is_register <= 0;
            held_data <= 0;
        end else if (selected_cancel && state != ABORT && state != CANCELLED) begin
            // Masking combinational valids/rotate above makes cancellation win
            // over a selected/native request or selected response on this edge.
            state <= ABORT;
        end else begin
            case (state)
                IDLE: if (selected_request_valid && selected_request_ready) begin
                    is_register <= selected_index >= 12'd2817;
                    if (selected_index < 12'd1792) begin
                        state <= PCE_REQUEST;
                        if (selected_index < 12'd256) begin
                            bank <= 2'd0;
                            pce_address <= {1'b0, selected_index[7:0]};
                        end else if (selected_index < 12'd768) begin
                            bank <= 2'd1;
                            pce_address <= selected_index - 12'd256;
                        end else if (selected_index < 12'd1280) begin
                            bank <= 2'd2;
                            pce_address <= selected_index - 12'd768;
                        end else begin
                            bank <= 2'd3;
                            pce_address <= selected_index - 12'd1280;
                        end
                    end else if (selected_index < 12'd2816) begin
                        bram_address <= selected_index - 12'd1792;
                        state <= BRAM_REQUEST;
                    end else begin
                        if (selected_index >= 12'd2817)
                            reg_address <= selected_index - 12'd2817;
                        state <= SCALAR_CAPTURE;
                    end
                end
                PCE_REQUEST: if (pce_read_ready) state <= PCE_RESPONSE;
                PCE_RESPONSE: if (pce_out_valid) begin
                    held_data <= pce_out_data;
                    state <= RESPONSE;
                end
                BRAM_REQUEST: if (bram_read_ready) state <= BRAM_RESPONSE;
                BRAM_RESPONSE: if (bram_out_valid) begin
                    held_data <= bram_out_data;
                    state <= RESPONSE;
                end
                SCALAR_CAPTURE: begin
                    held_data <= is_register ? register_data : {8'h00, captured_bram_q};
                    state <= RESPONSE;
                end
                RESPONSE: if (selected_response_ready) state <= IDLE;
                ABORT: if (native_abort_done && no_native_output) state <= CANCELLED;
                CANCELLED: if (!selected_cancel) state <= IDLE;
                default: state <= ABORT;
            endcase
        end
    end
endmodule
