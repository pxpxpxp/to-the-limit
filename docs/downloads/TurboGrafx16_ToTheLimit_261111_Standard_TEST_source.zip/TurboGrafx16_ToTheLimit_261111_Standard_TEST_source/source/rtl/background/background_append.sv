// Write-only background journal transport. Native execution has no control inputs
// from this module. Console cancellation never resets the FIFO or withdraws a
// presented DDR write: accepted records drain once before a new lineage starts.
module background_append #(
 parameter integer DEPTH=128,
 parameter integer LIMIT=131072,
 parameter [28:0] BASE=29'h07a80000
)(
 input wire clk,ram_clk,
 // Power/configuration reset only, before DDR use. NOT console/reset/cancel.
 input wire power_reset,
 input wire start,cancel,finish,
 input wire [7:0] generation,
 input wire append_valid,
 input wire [16:0] append_address,
 input wire [63:0] append_data,
 output wire append_ready,
 output wire busy,
 output reg start_accept=0,done=0,failed=0,
 output reg [7:0] active_generation=0,
 output reg [17:0] accepted=0,
 output wire [28:0] ram_address,
 output wire [63:0] ram_data,
 output wire ram_write,
 input wire ram_busy
);
 localparam AW=$clog2(DEPTH);
 reg active=0,closing=0,aborted=0;
 reg start_toggle=0;
 reg ack_ram=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg ack_meta=0,ack_sync=0;
 (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS; -name PRESERVE_REGISTER ON" *) reg start_meta=0,start_sync=0;
 reg [17:0] retired=0;
 wire full,empty,wr_empty;
 wire [AW-1:0] wr_used;
 wire [63:0] fifo_q;
 wire epoch_ready=ack_sync==start_toggle;
 wire address_ok=append_address==accepted[16:0] && accepted<LIMIT;
 assign append_ready=active && epoch_ready && !full && !cancel && !power_reset && accepted<LIMIT;
 wire push=append_valid && append_ready && address_ok;
 wire pop=ram_write && !ram_busy;
 assign busy=active || closing || !wr_empty || !epoch_ready;
 assign ram_address=BASE+retired[16:0];
 assign ram_data=fifo_q;
 assign ram_write=!power_reset && !empty && ack_ram==start_sync && retired<LIMIT;

 dcfifo #(.lpm_width(64),.lpm_numwords(DEPTH),.lpm_widthu(AW),
  .lpm_showahead("ON"),.overflow_checking("ON"),.underflow_checking("ON"),
  .use_eab("ON"),.intended_device_family("Cyclone V"),
  .rdsync_delaypipe(4),.wrsync_delaypipe(4)) fifo(
  .aclr(power_reset),.wrclk(clk),.rdclk(ram_clk),.data(append_data),
  .wrreq(push),.rdreq(pop),.q(fifo_q),.wrfull(full),.rdempty(empty),
  .wrempty(wr_empty),.wrusedw(wr_used),.rdfull(),.rdusedw());

 always @(posedge clk or posedge power_reset) begin
  if(power_reset) begin
   active<=0;closing<=0;aborted<=0;start_toggle<=0;ack_meta<=0;ack_sync<=0;
   start_accept<=0;done<=0;failed<=0;accepted<=0;active_generation<=0;
  end else begin
   ack_meta<=ack_ram;ack_sync<=ack_meta;
   start_accept<=0;done<=0;failed<=0;
   if(start && !busy && !cancel) begin
    active<=1;closing<=0;aborted<=0;accepted<=0;
    active_generation<=generation;start_toggle<=!start_toggle;start_accept<=1;
   end
   if(push) accepted<=accepted+1'b1;
   if((cancel && (active || closing)) || (active && append_valid && append_ready && !address_ok)) begin
    active<=0;closing<=1;aborted<=1;
   end else if(active && finish) begin
    active<=0;closing<=1;
   end
   // wr_empty is based on the write-domain pointer and synchronized retired
   // pointer. It cannot precede physical acceptance of the last queued write.
   if(closing && wr_empty && epoch_ready) begin
    closing<=0;if(aborted || cancel) failed<=1;else done<=1;
   end
  end
 end
 always @(posedge ram_clk or posedge power_reset) begin
  if(power_reset) begin start_meta<=0;start_sync<=0;ack_ram<=0;retired<=0;end
  else begin
   start_meta<=start_toggle;start_sync<=start_meta;
   if(start_sync!=ack_ram && empty) begin ack_ram<=start_sync;retired<=0;end
   else if(pop) retired<=retired+1'b1;
  end
 end
 // synthesis translate_off
 initial begin
  if(DEPTH<8 || (DEPTH&(DEPTH-1))!=0 || LIMIT<1 || LIMIT>131072) $fatal(1,"invalid append geometry");
  if(BASE<29'h07a60000 || BASE+LIMIT>29'h07c00000) $fatal(1,"journal overlaps known video/private allocation");
 end
 always @(posedge ram_clk) if(!power_reset && ram_write)
  assert(ram_address>=BASE && ram_address<BASE+LIMIT) else $fatal(1,"append outside reservation");
 // synthesis translate_on
endmodule
