// Automatic private rewind capture. Every native tap is observation-only.
// The legacy backend remains the only source of machine/audio/video freeze.
reg bg_power_reset=1;
always @(posedge clk_sys) bg_power_reset<=0;
wire bg_busy,bg_start_accept,bg_done,bg_failed,bg_cut,bg_mirror_release;
wire bg_pce_ready,bg_pce_fault,bg_bram_ready,bg_bram_fault;
wire bg_native_clear,bg_native_freeze,bg_native_abort,bg_native_abort_done;
wire [14:0] bg_w_a_addr,bg_w_b_addr,bg_v_a_addr,bg_v_b_addr;
wire [7:0] bg_w_a_data,bg_w_b_raw;
wire [15:0] bg_v_a_data,bg_v_b_raw,bg_w_q;
wire [31:0] bg_v_q;
wire [35:0] bg_line_q;
wire bg_w_a_we,bg_w_b_we,bg_w_a_enable,bg_w_b_enable,bg_w_a_cs,bg_w_b_cs;
wire bg_v_a_we,bg_v_b_we,bg_v_a_enable,bg_v_b_enable,bg_v_a_cs,bg_v_b_cs;
wire bg_pce_read_valid,bg_pce_read_ready,bg_pce_out_valid,bg_pce_out_ready;
wire [8:0] bg_pce_read_addr;
wire [1:0] bg_pce_read_bank;
wire [15:0] bg_pce_out_data,bg_bram_out_data;
wire bg_bram_read_valid,bg_bram_read_ready,bg_bram_out_valid,bg_bram_out_ready;
wire [9:0] bg_bram_read_addr;
wire [14:0] bg_reg_addr;
wire bg_reg_rotate;
wire [15:0] bg_sdram_dout;
wire [15:0] bg_reg_data=ss_reg_dout | ss_input_dout | ss_audio_dout |
                            (bg_reg_addr==15'd578 ? bg_sdram_dout : 16'd0);
wire bg_sel_req_valid,bg_sel_req_ready,bg_sel_resp_valid,bg_sel_resp_ready,bg_sel_cancel,bg_sel_idle;
wire [11:0] bg_sel_index;
wire [15:0] bg_sel_data;
wire bg_append_start,bg_append_finish,bg_append_cancel,bg_append_start_accept;
wire bg_append_ready,bg_append_busy,bg_append_done,bg_append_failed,bg_append_valid;
wire [16:0] bg_append_addr;
wire [63:0] bg_append_data;
wire bg_pub_start,bg_pub_cancel,bg_pub_ready,bg_pub_busy,bg_pub_done,bg_pub_failed;
wire [17:0] bg_record_count;
wire [7:0] bg_slot,bg_stream_generation;
wire [31:0] bg_rom,bg_config,bg_generation;
wire [28:0] bg_append_ddr_addr,bg_pub_ddr_addr;
wire [63:0] bg_append_ddr_data,bg_pub_ddr_data;
wire [7:0] bg_pub_ddr_be;
wire bg_append_ddr_we,bg_append_ddr_busy,bg_pub_ddr_valid,bg_pub_ddr_write,bg_pub_ddr_ready,bg_pub_read_valid;
wire [63:0] bg_pub_read_data;

// All cancel sources are transaction cancellation, never transport resets.
// SS_SAFE is only a cut/start gate, not a continuous capture requirement.
wire bg_cancel=manual_request || ss_config_changed || cart_download || ss_fault_pending ||
               bg_pce_fault || bg_bram_fault;
capture_epoch_controller background_capture(
 .clk_sys(clk_sys),.power_reset(bg_power_reset),.console_reset(reset),.cancel_request(bg_cancel),
 .enabled(rw_enabled && !bg_native_clear),.safe(ss_safe && !ss_machine_freeze && !ss_video_busy),
 .mirror_all_ready(bg_pce_ready && bg_bram_ready),
 .start_request(ss_request_ready && rw_private && rw_save && !manual_request),
 .request_slot({1'b0,rw_slot}),.request_rom(ss_rom_id),.request_config({19'd0,ss_config}),
 .start_ready(),.start_accept(bg_start_accept),.busy(bg_busy),.history_done(bg_done),.capture_failed(bg_failed),
 .common_cut(bg_cut),.mirror_release(bg_mirror_release),.sample_start_out(),.track_out(),
 .w_a_address(bg_w_a_addr),.w_b_address(bg_w_b_addr),.v_a_address(bg_v_a_addr),.v_b_address(bg_v_b_addr),
 .w_a_data({8'd0,bg_w_a_data}),.w_b_raw({8'd0,bg_w_b_raw}),.v_a_data(bg_v_a_data),.v_b_raw(bg_v_b_raw),
 .w_a_enable(bg_w_a_enable),.w_a_cs(bg_w_a_cs),.w_a_write(bg_w_a_we),
 .w_b_enable(bg_w_b_enable),.w_b_cs(bg_w_b_cs),.w_b_write(bg_w_b_we),
 .v_a_enable(bg_v_a_enable),.v_a_cs(bg_v_a_cs),.v_a_write(bg_v_a_we),
 .v_b_enable(bg_v_b_enable),.v_b_cs(bg_v_b_cs),.v_b_write(bg_v_b_we),
 // The registered restore request is a conservative superset of commit.
 // Keep the raw backend-loss commit veto out of the passive-arm event path.
 .freeze_mode(bg_native_freeze),.load_mode(ss_load),.scan_mode(ss_we),.clear_mode(bg_native_clear),
 .wram_q(bg_w_q),.vram_q(bg_v_q),.line_q(bg_line_q),
 .selected_request_valid(bg_sel_req_valid),.selected_request_ready(bg_sel_req_ready),.selected_index(bg_sel_index),
 .selected_response_valid(bg_sel_resp_valid),.selected_response_data(bg_sel_data),.selected_response_ready(bg_sel_resp_ready),
 .selected_cancel(bg_sel_cancel),.selected_idle(bg_sel_idle),
 .append_start(bg_append_start),.append_finish(bg_append_finish),.append_cancel(bg_append_cancel),
 .append_start_accept(bg_append_start_accept),.append_ready(bg_append_ready),.append_busy(bg_append_busy),
 .append_done(bg_append_done),.append_failed(bg_append_failed),.append_valid(bg_append_valid),
 .append_address(bg_append_addr),.append_data(bg_append_data),
 .publisher_start(bg_pub_start),.publisher_cancel(bg_pub_cancel),.publisher_ready(bg_pub_ready),
 .publisher_busy(bg_pub_busy),.publisher_done(bg_pub_done),.publisher_failed(bg_pub_failed),
 .record_count(bg_record_count),.active_slot(bg_slot),.active_rom(bg_rom),.active_config(bg_config),
 .full_generation(bg_generation),.stream_generation(bg_stream_generation),.active_epoch()
);
background_bram_mirror background_bram(
 .clk(clk_sys),.reset(bg_power_reset),.abort_capture(bg_native_abort),.release_capture(bg_mirror_release),
 .cut(bg_cut),.active_bank(ss_bram_bank),.a_addr(bram_addr),.a_data(bram_data),
 .a_we({bram_wr && !ss_machine_freeze && ss_bram_bank,bram_wr && !ss_machine_freeze && !ss_bram_bank}),
 .b_addr(ss_bram_baddr),.b_data(ss_bram_bdata),
 .b_we({(ss_bram_host_write && ss_bram_bank)||(ss_bram_scan_write && !ss_bram_bank),
        (ss_bram_host_write && !ss_bram_bank)||(ss_bram_scan_write && ss_bram_bank)}),
 .cut_ready(bg_bram_ready),.fault(bg_bram_fault),
 .read_valid(bg_bram_read_valid),.read_addr(bg_bram_read_addr),.read_ready(bg_bram_read_ready),
 .out_valid(bg_bram_out_valid),.out_data(bg_bram_out_data),.out_ready(bg_bram_out_ready)
);
background_append background_append(
 .clk(clk_sys),.ram_clk(clk_ram),.power_reset(bg_power_reset),
 .start(bg_append_start),.cancel(bg_append_cancel),.finish(bg_append_finish),.generation(bg_stream_generation),
 .append_valid(bg_append_valid),.append_address(bg_append_addr),.append_data(bg_append_data),
 .append_ready(bg_append_ready),.busy(bg_append_busy),.start_accept(bg_append_start_accept),
 .done(bg_append_done),.failed(bg_append_failed),.active_generation(),.accepted(),
 .ram_address(bg_append_ddr_addr),.ram_data(bg_append_ddr_data),.ram_write(bg_append_ddr_we),.ram_busy(bg_append_ddr_busy)
);
// Exporter, publisher crossing, and lowest-priority DDR arbiter are appended below.
selected_snapshot_exporter background_exporter(
 .clk_sys(clk_sys),.power_reset(bg_power_reset),
 .selected_request_valid(bg_sel_req_valid),.selected_request_ready(bg_sel_req_ready),.selected_index(bg_sel_index),
 .selected_response_valid(bg_sel_resp_valid),.selected_response_ready(bg_sel_resp_ready),.selected_response_data(bg_sel_data),
 .selected_cancel(bg_sel_cancel),.selected_idle(bg_sel_idle),
 .pce_read_valid(bg_pce_read_valid),.pce_read_ready(bg_pce_read_ready),.pce_read_bank(bg_pce_read_bank),.pce_read_addr(bg_pce_read_addr),
 .pce_out_valid(bg_pce_out_valid),.pce_out_ready(bg_pce_out_ready),.pce_out_data(bg_pce_out_data),
 .bram_read_valid(bg_bram_read_valid),.bram_read_ready(bg_bram_read_ready),.bram_read_addr(bg_bram_read_addr),
 .bram_out_valid(bg_bram_out_valid),.bram_out_ready(bg_bram_out_ready),.bram_out_data(bg_bram_out_data),
 .captured_bram_q(ss_bram_q),.register_address(bg_reg_addr),.register_data(bg_reg_data),.register_rotate(bg_reg_rotate),
 .native_abort(bg_native_abort),.native_abort_done(bg_native_abort_done)
);
snapshot_abort_ack background_abort_ack(
 .clk_sys(clk_sys),.power_reset(bg_power_reset),.native_abort(bg_native_abort),
 .pce_out_valid(bg_pce_out_valid),.bram_out_valid(bg_bram_out_valid),.mirror_abort(),.native_abort_done(bg_native_abort_done)
);
background_publisher background_publisher(
 .clk_sys(clk_sys),.clk_ram(clk_ram),.power_reset(bg_power_reset),.start(bg_pub_start),.cancel(bg_pub_cancel),
 .slot(bg_slot),.rom(bg_rom),.config_id(bg_config),.generation(bg_generation),.journal_record_count(bg_record_count),
 .ready(bg_pub_ready),.busy(bg_pub_busy),.done(bg_pub_done),.failed(bg_pub_failed),
 .cmd_valid(bg_pub_ddr_valid),.cmd_write(bg_pub_ddr_write),.cmd_address(bg_pub_ddr_addr),.cmd_data(bg_pub_ddr_data),
 .cmd_byteenable(bg_pub_ddr_be),.cmd_ready(bg_pub_ddr_ready),.read_valid(bg_pub_read_valid),.read_data(bg_pub_read_data),
 // This adapter never buffers writes: each command-ready acknowledges actual
 // ordered DDR acceptance. CRC reads follow all payload writes on that port.
 .writes_drained(1'b1)
);
wire [28:0] bg_ddr_addr=bg_append_ddr_we ? bg_append_ddr_addr : bg_pub_ddr_addr;
wire [63:0] bg_ddr_data=bg_append_ddr_we ? bg_append_ddr_data : bg_pub_ddr_data;
wire [7:0] bg_ddr_be=bg_append_ddr_we ? 8'hff : bg_pub_ddr_be;
wire bg_ddr_we=bg_append_ddr_we || (bg_pub_ddr_valid && bg_pub_ddr_write);
wire bg_ddr_rd=bg_pub_ddr_valid && !bg_pub_ddr_write;
wire bg_ddr_busy,bg_ddr_ready;
wire [63:0] bg_ddr_dout;
assign bg_append_ddr_busy=bg_ddr_busy;
assign bg_pub_ddr_ready=!bg_ddr_busy && !bg_append_ddr_we;
assign bg_pub_read_valid=bg_ddr_ready;
assign bg_pub_read_data=bg_ddr_dout;
wire [28:0] bg_foreground_addr;
wire [63:0] bg_foreground_din,bg_foreground_dout;
wire [7:0] bg_foreground_be,bg_foreground_burst;
wire bg_foreground_rd,bg_foreground_we,bg_foreground_idle,bg_foreground_busy,bg_foreground_ready;
background_ddr_arbiter background_ddr_arbiter(
 .clk(DDRAM_CLK),.foreground_addr(bg_foreground_addr),.foreground_din(bg_foreground_din),
 .foreground_byteenable(bg_foreground_be),.foreground_burst(bg_foreground_burst),
 .foreground_rd(bg_foreground_rd),.foreground_we(bg_foreground_we),.foreground_idle(bg_foreground_idle),
 .foreground_busy(bg_foreground_busy),.foreground_ready(bg_foreground_ready),.foreground_dout(bg_foreground_dout),
 .background_addr(bg_ddr_addr),.background_din(bg_ddr_data),.background_byteenable(bg_ddr_be),
 .background_rd(bg_ddr_rd),.background_we(bg_ddr_we),.background_busy(bg_ddr_busy),.background_ready(bg_ddr_ready),.background_dout(bg_ddr_dout),
 .ddr_addr(DDRAM_ADDR),.ddr_din(DDRAM_DIN),.ddr_byteenable(DDRAM_BE),.ddr_burst(DDRAM_BURSTCNT),
 .ddr_rd(DDRAM_RD),.ddr_we(DDRAM_WE),.ddr_busy(DDRAM_BUSY),.ddr_ready(DDRAM_DOUT_READY),.ddr_dout(DDRAM_DOUT)
);
// synthesis translate_off
always @(posedge clk_sys) if(!bg_power_reset) begin
 if(bg_busy) assert(!ss_freeze && !ss_save && !ss_load_commit) else $fatal(1,"background capture interfered with legacy machine ownership");
 if(bg_cut) assert(!ss_machine_freeze && bg_pce_ready && bg_bram_ready) else $fatal(1,"invalid common live cut");
end
always @(posedge clk_ram) assert(!(bg_append_ddr_we && bg_pub_ddr_valid)) else $fatal(1,"journal/publisher DDR overlap");
// synthesis translate_on
