// Single-clock, strictly serialized journal-to-private-image publisher.
// ready accepts a held command; writes_drained certifies all accepted writes
// have reached the ordered DDR backend. At most one read is outstanding.
// reset is an abort request, NOT a transport reset. Keep clock/DDR alive until
// busy falls. Memory ownership must remain exclusive for this whole interval.
module v3_private_publisher(
 input wire clk, reset, start, cancel,
 input wire [6:0] slot,
 input wire [31:0] rom, generation,
 input wire [15:0] config_id,
 input wire [17:0] journal_record_count,
 output reg busy=0, done=0, failed=0,
 output reg cmd_valid=0, cmd_write=0,
 output reg [28:0] cmd_address=0,
 output reg [63:0] cmd_data=0,
 output reg [7:0] cmd_byteenable=0,
 input wire cmd_ready, read_valid,
 input wire [63:0] read_data,
 input wire writes_drained
);
 localparam [28:0] JOURNAL=29'h07a80000, IMAGE=29'h07c00000;
 localparam integer PAYLOAD=11115;
 localparam [63:0] MAGIC=64'h5447525744000001,
  SCHEMA=64'h7b4a4831e0d369a8 ^ 64'h524557494e440001;
 localparam [5:0] IDLE=0, INVALIDATE=1, PAD=2, READ_RECORD=3,
  FEED=4, SETTLE=5, CANONICAL=6, NEXT_RECORD=7, END_INPUT=8,
  END_WAIT=9, VALIDATE=10, READ_CRC=11, CRC_STEP=12, HEADERS=13,
  COMMIT=14, SUCCESS=15, ABORT=16, ABORT_DONE=17,
  ISSUE=18, WAIT_READ=19, WAIT_WRITE=20;
 reg [5:0] state=IDLE, resume_state=IDLE;
 reg aborting=0;
 reg [28:0] base=0;
 reg [31:0] held_rom=0, held_generation=0;
 reg [15:0] held_config=0;
 reg [17:0] count=0, cursor=0;
 reg [13:0] crc_index=0;
 reg [2:0] header_index=0;
 reg [63:0] response=0;
 reg [31:0] crc=32'hffffffff;
 wire decoder_reset_n=busy && state!=INVALIDATE && state!=PAD;
 wire decoder_record_valid=(state==FEED) && !aborting && !cancel && !reset;
 wire decoder_end_input=(state==END_INPUT) && !aborting && !cancel && !reset;
 wire cv, dfault, dend, descriptor;
 wire [15:0] ca, cd;
 v3_decoder decoder(.clk(clk),.reset_n(decoder_reset_n),.stream_fault(1'b0),
  .record_valid(decoder_record_valid),.end_input(decoder_end_input),
  .generation(held_generation[7:0]),.record_address(cursor[16:0]),.record_data(response),
  .canonical_valid(cv),.canonical_address(ca),.canonical_data(cd),
  .fault(dfault),.end_ok(dend),.descriptor_valid(descriptor));
 reg saved_cv=0, saved_end=0;
 reg [15:0] saved_ca=0, saved_cd=0;
 function automatic [31:0] crc64(input [31:0] initial_crc,input [63:0] data);
  reg [31:0] c; integer b; begin c=initial_crc;
   for(b=0;b<64;b=b+1) c=(c>>1)^((c[0]^data[b])?32'hedb88320:0);
   crc64=c;
  end
 endfunction
 task issue_write(input [28:0] address,input [63:0] data,input [7:0] enables,input [5:0] next_state);
 begin cmd_valid<=1;cmd_write<=1;cmd_address<=address;cmd_data<=data;
 cmd_byteenable<=enables;resume_state<=next_state;state<=ISSUE;end endtask
 task issue_read(input [28:0] address,input [5:0] next_state);
 begin cmd_valid<=1;cmd_write<=0;cmd_address<=address;cmd_data<=0;
 cmd_byteenable<=8'hff;resume_state<=next_state;state<=ISSUE;end endtask
 always @(posedge clk) begin
  done<=0; failed<=0;
  if(busy && (cancel || reset)) aborting<=1;
  if(cv) begin saved_cv<=1;saved_ca<=ca;saved_cd<=cd;end
  if(dend) saved_end<=1;
  // Outstanding transport is always serviced first, including after reset.
  if(state==ISSUE) begin
   if(cmd_ready) begin
    cmd_valid<=0;
    if(cmd_write) state<=WAIT_WRITE;
    else if(read_valid) begin response<=read_data;state<=resume_state;end
    else state<=WAIT_READ;
   end
  end else if(state==WAIT_READ) begin
   if(read_valid) begin response<=read_data;state<=resume_state;end
  end else if(state==WAIT_WRITE) begin
   if(writes_drained) state<=resume_state;
  end else if(busy && (aborting || cancel || reset || dfault) && state!=ABORT && state!=ABORT_DONE) begin
   aborting<=1;state<=ABORT;
  end else case(state)
   IDLE: if(start && !reset && !cancel) begin
    busy<=1;aborting<=0;held_rom<=rom;held_config<=config_id;held_generation<=generation;
    base<=IMAGE+({22'd0,slot}<<14);count<=journal_record_count;cursor<=0;
    crc<=32'hffffffff;crc_index<=0;header_index<=1;saved_cv<=0;saved_end<=0;
    state<=INVALIDATE;
   end
   INVALIDATE: issue_write(base,0,8'hff,PAD);
   PAD: if(count==0 || count>131072) begin aborting<=1;state<=ABORT;end
    else issue_write(base+5+PAYLOAD-1,0,8'hff,READ_RECORD);
   READ_RECORD: begin saved_cv<=0;issue_read(JOURNAL+cursor,FEED);end
   FEED: state<=SETTLE;
   SETTLE: state<=CANONICAL;
   CANONICAL: if(saved_cv) begin
    if(saved_ca>=44458) begin aborting<=1;state<=ABORT;end
    else issue_write(base+5+(saved_ca>>2),{48'd0,saved_cd} << (saved_ca[1:0]*16),8'h03 << (saved_ca[1:0]*2),NEXT_RECORD);
   end else state<=NEXT_RECORD;
   NEXT_RECORD: if(cursor+1==count) state<=END_INPUT;
    else begin cursor<=cursor+1;state<=READ_RECORD;end
   END_INPUT: state<=END_WAIT;
   END_WAIT: state<=VALIDATE;
   VALIDATE: if(saved_end && descriptor && !dfault) state<=READ_CRC;
    else begin aborting<=1;state<=ABORT;end
   READ_CRC: issue_read(base+5+crc_index,CRC_STEP);
   CRC_STEP: begin crc<=crc64(crc,response);
    if(crc_index==PAYLOAD-1) state<=HEADERS;
    else begin crc_index<=crc_index+1;state<=READ_CRC;end
   end
   HEADERS: begin
    case(header_index)
     1: issue_write(base+1,MAGIC,8'hff,HEADERS);
     2: issue_write(base+2,SCHEMA,8'hff,HEADERS);
     3: issue_write(base+3,{16'd0,held_config,held_rom},8'hff,HEADERS);
     4: issue_write(base+4,{32'd11115,~crc},8'hff,COMMIT);
    endcase
    header_index<=header_index+1;
   end
   COMMIT: issue_write(base,{32'd22238,held_generation},8'hff,SUCCESS);
   SUCCESS: begin busy<=0;done<=1;state<=IDLE;end
   // If cancellation races an already presented commit, wait for that command
   // then invalidate and drain it. History is never notified for this attempt.
   ABORT: issue_write(base,0,8'hff,ABORT_DONE);
   ABORT_DONE: begin busy<=0;failed<=1;state<=IDLE;end
   default: state<=IDLE;
  endcase
 end
endmodule
