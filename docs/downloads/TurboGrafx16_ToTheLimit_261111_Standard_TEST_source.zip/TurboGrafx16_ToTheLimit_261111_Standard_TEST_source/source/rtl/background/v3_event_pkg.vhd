library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package v3_event_pkg is
  function power_of_two(n : positive) return boolean;
  constant FORMAT_VERSION : natural := 3;
  constant SELECTED_WORDS : natural := 3498;
  constant SELECTED_BASE : natural := 40960;
  constant IMAGE_WORDS : natural := 44458;
  function domain_size(domain, wram_words, vram_words : natural) return natural;
  subtype word_t is std_logic_vector(63 downto 0);
  subtype address_t is std_logic_vector(14 downto 0);
  subtype value_t is std_logic_vector(15 downto 0);
  type addresses_t is array (0 to 1) of address_t;
  type values_t is array (0 to 1) of value_t;
  type bundle_t is array (0 to 5) of word_t;
  function selected_payload_ok(index : natural; value : value_t) return boolean;
  function selected_word(gen, epoch : std_logic_vector(7 downto 0); index : natural; data : value_t) return word_t;
  function is_strong(value : std_logic_vector) return boolean;
  function memory_word(kind, domain : natural; gen : std_logic_vector(7 downto 0);
    paired : std_logic; addr : address_t; data : value_t) return word_t;
end package;

package body v3_event_pkg is
  function power_of_two(n : positive) return boolean is
    variable k : positive := n;
  begin
    while k > 1 loop
      if k mod 2 /= 0 then return false; end if;
      k := k / 2;
    end loop;
    return true;
  end;
  function domain_size(domain, wram_words, vram_words : natural) return natural is
  begin
    if domain = 0 then return wram_words; else return vram_words; end if;
  end;
  function selected_payload_ok(index : natural; value : value_t) return boolean is
  begin
    if index >= 256 and index < 1792 then return value(15 downto 9) = "0000000";
    elsif index = 2816 then return value(15 downto 8) = x"00";
    else return true; end if;
  end;
  function selected_word(gen, epoch : std_logic_vector(7 downto 0); index : natural; data : value_t) return word_t is
    variable result_word : word_t := (others => '0');
  begin
    result_word(63 downto 60) := x"6";
    result_word(59 downto 52) := gen;
    result_word(51 downto 49) := "010";
    result_word(47 downto 40) := epoch;
    result_word(39 downto 28) := std_logic_vector(to_unsigned(index,12));
    result_word(15 downto 0) := data;
    return result_word;
  end;
  function is_strong(value : std_logic_vector) return boolean is
  begin
    for i in value'range loop
      if value(i) /= '0' and value(i) /= '1' then return false; end if;
    end loop;
    return true;
  end;

  function memory_word(kind, domain : natural; gen : std_logic_vector(7 downto 0);
    paired : std_logic; addr : address_t; data : value_t) return word_t is
    variable result_word : word_t := (others => '0');
  begin
    result_word(63 downto 60) := std_logic_vector(to_unsigned(kind, 4));
    result_word(59 downto 52) := gen;
    result_word(51 downto 49) := std_logic_vector(to_unsigned(domain, 3));
    result_word(48) := paired;
    result_word(47 downto 33) := addr;
    result_word(32 downto 17) := data;
    return result_word;
  end;
end package body;
