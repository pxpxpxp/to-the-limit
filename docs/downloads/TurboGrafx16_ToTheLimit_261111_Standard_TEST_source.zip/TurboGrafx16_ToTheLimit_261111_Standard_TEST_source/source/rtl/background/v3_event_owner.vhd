library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.v3_event_pkg.all;

entity v3_event_owner is
  generic (DEPTH : positive := 8; LIMIT : positive := 131072; WRAM_WORDS : positive := 8192; VRAM_WORDS : positive := 32768);
  port (
    clk, reset_n, abort_request, source_fault : in std_logic;
    generation : in std_logic_vector(7 downto 0);
    sample_valid, base_valid, write_valid : in std_logic_vector(1 downto 0);
    sample_address, write_address : in addresses_t;
    sample_value, write_value : in values_t;
    common_request, common_eligible : in std_logic;
    epoch : in std_logic_vector(7 downto 0);
    wram_q : in std_logic_vector(15 downto 0);
    vram_q : in std_logic_vector(31 downto 0);
    line_q : in std_logic_vector(35 downto 0);
    selected_valid : in std_logic;
    selected_word : in word_t;
    complete_request : in std_logic;
    complete_epoch : in std_logic_vector(7 downto 0);
    complete_ready, complete_accept : out std_logic;
    append_ready : in std_logic;
    append_valid : out std_logic;
    append_address : out unsigned(16 downto 0);
    append_data : out word_t;
    tracking_closed : out std_logic;
    common_grant, selected_accept, native_bundle_recorded : out std_logic;
    fault : out std_logic;
    queued : out natural range 0 to DEPTH;
    reserved, committed : out natural range 0 to LIMIT
  );
end entity;

architecture rtl of v3_event_owner is
  type fifo_t is array (0 to DEPTH - 1) of word_t;
  type bank_outputs_t is array (0 to 3) of word_t;
  signal bank_outputs : bank_outputs_t;
  signal head_word : word_t;
  signal rd, wr : natural range 0 to DEPTH - 1 := 0;
  signal q_count : natural range 0 to DEPTH := 0;
  signal a_count, c_count : natural range 0 to LIMIT := 0;
  signal bad : std_logic := '0';
  type lifecycle_t is (COLD, EXPORTING, SELECTED_DONE, COMPLETE_QUEUED);
  signal lifecycle : lifecycle_t := COLD;
  signal held_epoch : std_logic_vector(7 downto 0) := (others => '0');
  signal selected_cursor : natural range 0 to 3498 := 0;
  signal held_generation : std_logic_vector(7 downto 0) := (others => '0');
  signal new_words : bundle_t;
  signal new_count : natural range 0 to 6;
  signal pop_head, edge_fault : boolean;
begin
  assert power_of_two(WRAM_WORDS) and power_of_two(VRAM_WORDS) and WRAM_WORDS <= 8192 and VRAM_WORDS <= 32768 report "canonical geometry" severity failure;
  assert LIMIT <= 131072 and DEPTH >= 6 report "v2 owner geometry" severity failure;
  tracking_closed <= '0' when lifecycle = COLD else '1';
  append_valid <= '1' when q_count > 0 and c_count < LIMIT else '0';
  append_address <= to_unsigned(c_count, 17) when c_count < LIMIT else (others => '0');
  append_data <= head_word when q_count > 0 else (others => '0');

  -- Consecutive enqueue lanes rotate across four independent single-write
  -- banks. Each bank selects its input once, not once per FIFO storage word.
  -- All reachable transactions contain at most four words. Non-multiple-of-4
  -- generic depths retain the original storage implementation.
  banked : if DEPTH mod 4 = 0 generate
    head_word <= bank_outputs(rd mod 4);
    banks : for b in 0 to 3 generate
      type bank_t is array (0 to DEPTH / 4 - 1) of word_t;
      signal memory : bank_t;
      attribute ramstyle : string;
      attribute ramstyle of memory : signal is "MLAB";
      signal lane : natural range 0 to 3;
      signal location : natural range 0 to DEPTH / 4 - 1;
    begin
      lane <= (b + 4 - (wr mod 4)) mod 4;
      location <= ((wr + lane) mod DEPTH) / 4;
      bank_outputs(b) <= memory(rd / 4);
      process(clk)
      begin
        if rising_edge(clk) then
          if reset_n = '1' and bad = '0' and not edge_fault then
            assert new_count <= 4 report "owner bank enqueue bound" severity failure;
            if lane < new_count then memory(location) <= new_words(lane); end if;
          end if;
        end if;
      end process;
    end generate;
  end generate;
  unbanked : if DEPTH mod 4 /= 0 generate
    signal fifo : fifo_t;
  begin
    head_word <= fifo(rd);
    process(clk)
    begin
      if rising_edge(clk) then
        if reset_n = '1' and bad = '0' and not edge_fault then
          for i in 0 to 5 loop
            if i < new_count then fifo((wr + i) mod DEPTH) <= new_words(i); end if;
          end loop;
        end if;
      end if;
    end process;
  end generate;
  queued <= q_count;
  reserved <= a_count;
  committed <= c_count;
  fault <= bad;

  process(all)
    variable valid_inputs, has_native, marker_candidate : boolean;
    variable normal, marker_words : bundle_t;
    variable n, k, free_slots, remaining, pop_value : natural;
    variable tmp : word_t;
    variable domain_number, expected_domain, expected_index : natural;
  begin
    new_words <= (others => (others => '0'));
    new_count <= 0;
    common_grant <= '0';
    selected_accept <= '0';
    complete_ready <= '0';
    complete_accept <= '0';
    native_bundle_recorded <= '0';
    pop_head <= q_count > 0 and c_count < LIMIT and append_ready = '1';
    edge_fault <= false;
    normal := (others => (others => '0'));
    marker_words := (others => (others => '0'));
    n := 0;
    k := 4;
    pop_value := 0;
    if q_count > 0 and c_count < LIMIT and append_ready = '1' then pop_value := 1; end if;
    free_slots := DEPTH - q_count + pop_value;
    remaining := LIMIT - a_count;
    valid_inputs := is_strong(reset_n & abort_request & source_fault & generation &
      sample_valid & base_valid & write_valid & common_request & common_eligible &
      selected_valid & complete_request & append_ready);
    if a_count > 0 and generation /= held_generation then valid_inputs := false; end if;
    if lifecycle = COLD then
    for d in 0 to 1 loop
      if sample_valid(d) = '1' then
        if not is_strong(sample_address(d) & sample_value(d)) then valid_inputs := false;
        elsif to_integer(unsigned(sample_address(d))) >= domain_size(d, WRAM_WORDS, VRAM_WORDS) then valid_inputs := false; end if;
        if d = 0 and sample_value(d)(15 downto 8) /= x"00" then valid_inputs := false; end if;
      end if;
      if write_valid(d) = '1' then
        if not is_strong(write_address(d) & write_value(d)) then valid_inputs := false;
        elsif to_integer(unsigned(write_address(d))) >= domain_size(d, WRAM_WORDS, VRAM_WORDS) then valid_inputs := false; end if;
        if d = 0 and write_value(d)(15 downto 8) /= x"00" then valid_inputs := false; end if;
      end if;
      if sample_valid(d) = '1' and base_valid(d) = '1' then valid_inputs := false; end if;
    end loop;
    end if;
    if common_request = '1' and not is_strong(epoch & wram_q & vram_q & line_q) then
      valid_inputs := false;
    end if;
    if (common_request = '1' and (selected_valid = '1' or complete_request = '1')) or
      (selected_valid = '1' and complete_request = '1') then valid_inputs := false; end if;
    if common_request = '1' and lifecycle /= COLD then valid_inputs := false; end if;
    if complete_request = '1' then
      if not is_strong(complete_epoch) or complete_epoch /= held_epoch or lifecycle /= SELECTED_DONE then
        valid_inputs := false;
      end if;
    end if;
    if selected_valid = '1' then
      if not is_strong(selected_word) then
        valid_inputs := false;
      else
        domain_number := to_integer(unsigned(selected_word(51 downto 49)));
        if not selected_payload_ok(selected_cursor, selected_word(15 downto 0)) or
          lifecycle /= EXPORTING or domain_number /= 2 or
          to_integer(unsigned(selected_word(39 downto 28))) /= selected_cursor or
          selected_word(47 downto 40) /= held_epoch or
          selected_word(63 downto 60) /= x"6" or
          selected_word(59 downto 52) /= generation or selected_word(48) /= '0' or
          selected_word(27 downto 16) /= x"000" then valid_inputs := false; end if;
      end if;
    end if;
    has_native := sample_valid /= "00" or base_valid /= "00" or write_valid /= "00";
    if reset_n = '0' then
      null;
    elsif bad = '1' then
      null;
    elsif not valid_inputs or abort_request = '1' or source_fault = '1' then
      edge_fault <= true;
    else
      if lifecycle = COLD then
      for d in 0 to 1 loop
        if sample_valid(d) = '1' then
          normal(n) := memory_word(1, d, generation, write_valid(d), sample_address(d), sample_value(d));
          n := n + 1;
        elsif base_valid(d) = '1' then
          tmp := memory_word(3, d, generation, write_valid(d), (others => '0'), (others => '0'));
          tmp(47 downto 32) := std_logic_vector(to_unsigned(domain_size(d, WRAM_WORDS, VRAM_WORDS),16));
          tmp(7 downto 0) := x"03";
          normal(n) := tmp;
          n := n + 1;
        end if;
        if write_valid(d) = '1' then
          if sample_valid(d) = '1' or base_valid(d) = '1' then
            normal(n) := memory_word(8, d, generation, '0', write_address(d), write_value(d));
          else
            normal(n) := memory_word(2, d, generation, '0', write_address(d), write_value(d));
          end if;
          n := n + 1;
        end if;
      end loop;
      end if;
      marker_candidate := common_request = '1' and common_eligible = '1' and sample_valid = "00" and base_valid = "00";
      -- Pre-edge cut: same-edge native writes are outside the captured image.
      if marker_candidate and free_slots >= k and remaining >= k then
        tmp := (others => '0');
        tmp(63 downto 60) := x"4";
        tmp(59 downto 52) := generation;
        tmp(51 downto 49) := "111";
        tmp(48) := '1';
        tmp(47 downto 40) := epoch;
        tmp(39 downto 32) := std_logic_vector(to_unsigned(k - 1, 8));
        tmp(31 downto 30) := "00";
        tmp(7 downto 0) := x"03";
        marker_words(0) := tmp;
        for r in 0 to 2 loop
          tmp := (others => '0');
          tmp(63 downto 60) := x"5";
          tmp(59 downto 52) := generation;
          if r = 0 then tmp(51 downto 49) := "000"; tmp(19 downto 4) := wram_q;
          elsif r = 1 then tmp(51 downto 49) := "001"; tmp(35 downto 4) := vram_q;
          else tmp(51 downto 49) := "100"; tmp(39 downto 4) := line_q; end if;
          tmp(47 downto 40) := epoch;
          tmp(3 downto 0) := x"3";
          marker_words(r + 1) := tmp;
        end loop;
        new_words <= marker_words;
        new_count <= k;
        common_grant <= '1';
        if has_native then native_bundle_recorded <= '1'; end if;
      elsif n > free_slots or n > remaining or
        (remaining = 0 and (selected_valid = '1' or lifecycle = SELECTED_DONE)) then
        edge_fault <= true;
      else
        if has_native then native_bundle_recorded <= '1'; end if;
        if selected_valid = '1' and free_slots - n >= 1 and remaining - n >= 1 then
          normal(n) := selected_word;
          n := n + 1;
          selected_accept <= '1';
        elsif lifecycle = SELECTED_DONE and common_request = '0' and selected_valid = '0' and
          free_slots - n >= 1 and remaining - n >= 1 then
          complete_ready <= '1';
          if complete_request = '1' then
            tmp := (others => '0');
            tmp(63 downto 60) := x"7";
            tmp(59 downto 52) := generation;
            tmp(51 downto 49) := "111";
            tmp(47 downto 40) := held_epoch;
            tmp(39 downto 28) := std_logic_vector(to_unsigned(SELECTED_WORDS, 12));
            tmp(7 downto 0) := x"03";
            normal(n) := tmp;
            n := n + 1;
            complete_accept <= '1';
          end if;
        end if;
        new_words <= normal;
        new_count <= n;
      end if;
    end if;
  end process;

  process(clk)
    variable p : natural range 0 to 1;
  begin
    if rising_edge(clk) then
      if reset_n = '0' then
        assert q_count = 0 report "cold reset requires empty owner" severity failure;
        rd <= 0; wr <= 0; q_count <= 0; a_count <= 0; c_count <= 0; bad <= '0';
        held_generation <= (others => '0');
        held_epoch <= (others => '0'); lifecycle <= COLD; selected_cursor <= 0;
      else
        p := 0;
        if pop_head then p := 1; rd <= (rd + 1) mod DEPTH; c_count <= c_count + 1; end if;
        if bad = '1' or edge_fault then
          bad <= '1';
          if q_count > 0 and p = 0 then q_count <= 1; else q_count <= 0; end if;
        else
          assert a_count = c_count + q_count report "healthy owner count identity" severity failure;
          wr <= (wr + new_count) mod DEPTH;
          q_count <= q_count - p + new_count;
          a_count <= a_count + new_count;
          if new_count > 0 then held_generation <= generation; end if;
          if common_grant = '1' then
            lifecycle <= EXPORTING; held_epoch <= epoch; selected_cursor <= 0;
          elsif selected_accept = '1' then
            selected_cursor <= selected_cursor + 1;
            if selected_cursor = 3497 then lifecycle <= SELECTED_DONE; end if;
          elsif complete_accept = '1' then lifecycle <= COMPLETE_QUEUED; end if;
        end if;
      end if;
    end if;
  end process;
end architecture;
