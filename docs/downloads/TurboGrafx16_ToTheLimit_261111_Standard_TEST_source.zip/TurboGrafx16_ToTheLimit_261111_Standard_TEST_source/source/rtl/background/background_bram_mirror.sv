// Observe the TWO existing physical battery-RAM banks independently. Inactive
// restore writes must not corrupt the active bank's snapshot on a failed load.
// Each mixed 8/16-bit RAM is split into even/odd byte mirrors; host B writes
// update both, while a CPU A write touches its selected byte only.
module background_bram_mirror(
 input wire clk,reset,abort_capture,release_capture,cut,active_bank,
 input wire [10:0] a_addr,input wire [7:0] a_data,
 input wire [1:0] a_we,
 input wire [9:0] b_addr,input wire [15:0] b_data,
 input wire [1:0] b_we,
 output wire cut_ready,fault,
 input wire read_valid,input wire [9:0] read_addr,
 output wire read_ready,out_valid,output wire[15:0]out_data,input wire out_ready
);
 wire[3:0] ready,broken,frozen,rr,ov;
 wire[7:0] byte_data[0:3];
 reg captured_bank=0;
 wire common_cut=cut && cut_ready;
 always @(posedge clk) if(common_cut)captured_bank<=active_bank;
 assign cut_ready=active_bank ? (&ready[3:2]) : (&ready[1:0]);
 assign fault=active_bank ? (|broken[3:2]) : (|broken[1:0]);
 assign read_ready=captured_bank ? (&rr[3:2]) : (&rr[1:0]);
 assign out_valid=captured_bank ? (&ov[3:2]) : (&ov[1:0]);
 assign out_data=captured_bank ? {byte_data[3],byte_data[2]} : {byte_data[1],byte_data[0]};
 genvar i;
 generate for(i=0;i<4;i=i+1)begin:g
  localparam integer BANK=i/2, BYTE=i%2, OTHER=(i%2==0)?i+1:i-1;
  snapshot_mirror #(.AW(10),.DW(8)) mirror(
   .clk(clk),.reset(reset),.abort_capture(abort_capture),.release_capture(release_capture),
   .a_we(a_we[BANK] && a_addr[0]==BYTE),.a_addr(a_addr[10:1]),.a_data(a_data),
   .b_we(b_we[BANK]),.b_addr(b_addr),.b_data(b_data[BYTE*8+:8]),
   .cut(common_cut && active_bank==BANK),.cut_ready(ready[i]),.cut_accepted(),
   .frozen(frozen[i]),.fault(broken[i]),
   .read_valid(read_valid && captured_bank==BANK && rr[OTHER]),.read_addr(read_addr),.read_ready(rr[i]),
   .out_valid(ov[i]),.out_data(byte_data[i]),.out_ready(out_ready && captured_bank==BANK && ov[OTHER]));
 end endgenerate
endmodule
