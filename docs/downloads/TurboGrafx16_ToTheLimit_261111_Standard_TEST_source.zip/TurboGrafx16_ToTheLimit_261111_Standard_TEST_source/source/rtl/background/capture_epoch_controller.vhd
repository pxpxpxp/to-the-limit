library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.v3_event_pkg.all;

-- All control and tap inputs belong to clk_sys. No console reset on metadata.
entity capture_epoch_controller is
 port (
 clk_sys, power_reset, console_reset, cancel_request : in std_logic;
 enabled, safe, mirror_all_ready, start_request : in std_logic;
 request_slot : in std_logic_vector(7 downto 0);
 request_rom, request_config : in std_logic_vector(31 downto 0);
 start_ready, start_accept, busy, history_done, capture_failed : out std_logic;
 common_cut, mirror_release, sample_start_out, track_out : out std_logic;
 w_a_address,w_b_address,v_a_address,v_b_address : in std_logic_vector(14 downto 0);
 w_a_data,w_b_raw,v_a_data,v_b_raw : in std_logic_vector(15 downto 0);
 w_a_enable,w_a_cs,w_a_write,w_b_enable,w_b_cs,w_b_write : in std_logic;
 v_a_enable,v_a_cs,v_a_write,v_b_enable,v_b_cs,v_b_write : in std_logic;
 freeze_mode,load_mode,scan_mode,clear_mode : in std_logic;
 wram_q : in std_logic_vector(15 downto 0);
 vram_q : in std_logic_vector(31 downto 0);
 line_q : in std_logic_vector(35 downto 0);
 selected_request_valid : out std_logic;
 selected_request_ready : in std_logic;
 selected_index : out std_logic_vector(11 downto 0);
 selected_response_valid : in std_logic;
 selected_response_data : in std_logic_vector(15 downto 0);
 selected_response_ready, selected_cancel : out std_logic;
 selected_idle : in std_logic;
 append_start,append_finish,append_cancel : out std_logic;
 append_start_accept,append_ready,append_busy,append_done,append_failed : in std_logic;
 append_valid : out std_logic;
 append_address : out unsigned(16 downto 0);
 append_data : out word_t;
 publisher_start,publisher_cancel : out std_logic;
 publisher_ready,publisher_busy,publisher_done,publisher_failed : in std_logic;
 record_count : out unsigned(17 downto 0);
 active_slot : out std_logic_vector(7 downto 0);
 active_rom,active_config,full_generation : out std_logic_vector(31 downto 0);
 stream_generation,active_epoch : out std_logic_vector(7 downto 0)
 );
end;
architecture rtl of capture_epoch_controller is
 type state_t is (IDLE,REARM,BRIDGE_START,BRIDGE_READY,TRACK_FIRST,TRACK,
 CUT_WAIT,SELECT_REQUEST,SELECT_RESPONSE,SELECT_HOLD,COMPLETE,OWNER_DRAIN,
 BRIDGE_FINISH,BRIDGE_DRAIN,PUBLISH_START,PUBLISH_WAIT,
 ABORT_OWNER,ABORT_BRIDGE,ABORT_PUBLISH,ABORT_SOURCE);
 signal state : state_t := IDLE;
 signal gen : unsigned(31 downto 0) := (others=>'0');
 signal epoch : std_logic_vector(7 downto 0) := (others=>'0');
 signal slot : std_logic_vector(7 downto 0) := (others=>'0');
 signal rom_id,config_id : std_logic_vector(31 downto 0) := (others=>'0');
 signal arm_reset_n,tracking,sample_start,abort_signal,owner_fault,grant,closed : std_logic;
 signal sample_valid,base_valid,write_valid,source_fault : std_logic_vector(1 downto 0);
 signal sample_address,write_address : addresses_t;
 signal sample_value,write_value : values_t;
 signal wc : natural range 0 to 8192;
 signal vc : natural range 0 to 32768;
 signal queued : natural range 0 to 32;
 signal reserved,committed : natural range 0 to 131072;
 signal common_request,selected_valid,selected_accept,complete_request,complete_accept : std_logic;
 signal selected_record : word_t;
 signal held_data : std_logic_vector(15 downto 0) := (others=>'0');
 signal cursor : natural range 0 to 3497 := 0;
 signal settle : natural range 0 to 3 := 0;
 signal stop_now : std_logic;
 signal count_latch : unsigned(17 downto 0) := (others=>'0');
 function aborting(s:state_t) return boolean is
 begin return s=ABORT_OWNER or s=ABORT_BRIDGE or s=ABORT_PUBLISH or s=ABORT_SOURCE; end;
begin
 full_generation<=std_logic_vector(gen); stream_generation<=std_logic_vector(gen(7 downto 0));
 active_epoch<=epoch;active_slot<=slot;active_rom<=rom_id;active_config<=config_id;record_count<=count_latch;
 busy<='0' when state=IDLE else '1';
 start_ready<='1' when state=IDLE and enabled='1' and safe='1' and console_reset='0' and cancel_request='0' and append_busy='0' and publisher_busy='0' and selected_idle='1' else '0';
 stop_now<=console_reset or cancel_request or not enabled or owner_fault or source_fault(0) or source_fault(1);
 arm_reset_n<='0' when power_reset='1' or state=REARM or state=IDLE else '1';
 tracking<='1' when state=TRACK_FIRST or state=TRACK else '0';
 sample_start<='1' when state=TRACK_FIRST else '0';
 track_out<=tracking;sample_start_out<=sample_start;
 abort_signal<='1' when aborting(state) or ((console_reset='1' or cancel_request='1' or enabled='0') and state/=IDLE and state/=REARM) else '0';
 common_request<='1' when state=TRACK and wc=8192 and vc=32768 and mirror_all_ready='1' and stop_now='0' else '0';
 common_cut<=grant;
 selected_request_valid<='1' when state=SELECT_REQUEST and stop_now='0' else '0';
 selected_index<=std_logic_vector(to_unsigned(cursor,12));
 selected_response_ready<='1' when state=SELECT_RESPONSE and stop_now='0' else '0';
 selected_cancel<='1' when aborting(state) else '0';
 selected_valid<='1' when state=SELECT_HOLD else '0';
 selected_record<=selected_word(std_logic_vector(gen(7 downto 0)),epoch,cursor,held_data);
 complete_request<='1' when state=COMPLETE else '0';
 append_start<='1' when state=BRIDGE_START and stop_now='0' else '0';
 append_finish<='1' when state=BRIDGE_FINISH else '0';
 append_cancel<='1' when state=ABORT_BRIDGE else '0';
 publisher_start<='1' when state=PUBLISH_START and stop_now='0' else '0';
 publisher_cancel<='1' when state=ABORT_PUBLISH else '0';
 arms: for d in 0 to 1 generate
  signal aa,ba : std_logic_vector(14 downto 0);
  signal ad,bd : std_logic_vector(15 downto 0);
  signal ae,ac,aw,be,bc,bw : std_logic;
  constant width_c:positive:=8+8*d;
  constant words_c:positive:=8192+24576*d;
  signal coverage:natural range 0 to words_c;
 begin
  aa<=w_a_address when d=0 else v_a_address;ba<=w_b_address when d=0 else v_b_address;
  ad<=w_a_data when d=0 else v_a_data;bd<=w_b_raw when d=0 else v_b_raw;
  ae<=w_a_enable when d=0 else v_a_enable;ac<=w_a_cs when d=0 else v_a_cs;aw<=w_a_write when d=0 else v_a_write;
  be<=w_b_enable when d=0 else v_b_enable;bc<=w_b_cs when d=0 else v_b_cs;bw<=w_b_write when d=0 else v_b_write;
  a:entity work.v3_passive_sample_arm generic map(WIDTH=>width_c,WORDS=>words_c,SAMPLE_STRIDE=>15)
  port map(clk=>clk_sys,cold_reset_n=>arm_reset_n,track_active=>tracking,close_tracking=>grant,sample_start=>sample_start,
   abort_request=>abort_signal,owner_fault=>owner_fault,generation=>std_logic_vector(gen(7 downto 0)),
   a_address=>aa,b_address=>ba,a_data=>ad,b_raw=>bd,a_enable=>ae,a_cs=>ac,a_write=>aw,b_enable=>be,b_cs=>bc,b_write=>bw,
   freeze_mode=>freeze_mode,load_mode=>load_mode,scan_mode=>scan_mode,clear_mode=>clear_mode,
   sample_valid=>sample_valid(d),base_valid=>base_valid(d),write_valid=>write_valid(d),source_fault=>source_fault(d),
   sample_address=>sample_address(d),write_address=>write_address(d),sample_value=>sample_value(d),write_value=>write_value(d),
   forwarded=>open,primed_out=>open,started_out=>open,coverage_count=>coverage);
  w:if d=0 generate wc<=coverage; end generate;
  v:if d=1 generate vc<=coverage; end generate;
 end generate;
 owner:entity work.v3_event_owner generic map(DEPTH=>32)
 port map(clk=>clk_sys,reset_n=>arm_reset_n,abort_request=>abort_signal,source_fault=>source_fault(0) or source_fault(1),
 generation=>std_logic_vector(gen(7 downto 0)),sample_valid=>sample_valid,base_valid=>base_valid,write_valid=>write_valid,
 sample_address=>sample_address,write_address=>write_address,sample_value=>sample_value,write_value=>write_value,
 common_request=>common_request,common_eligible=>safe and mirror_all_ready,epoch=>epoch,wram_q=>wram_q,vram_q=>vram_q,line_q=>line_q,
 selected_valid=>selected_valid,selected_word=>selected_record,complete_request=>complete_request,complete_epoch=>epoch,
 complete_ready=>open,complete_accept=>complete_accept,append_ready=>append_ready,append_valid=>append_valid,
 append_address=>append_address,append_data=>append_data,tracking_closed=>closed,common_grant=>grant,selected_accept=>selected_accept,
 native_bundle_recorded=>open,fault=>owner_fault,queued=>queued,reserved=>reserved,committed=>committed);
 process(clk_sys)
 begin
 if rising_edge(clk_sys) then
  start_accept<='0';history_done<='0';capture_failed<='0';mirror_release<='0';
  if power_reset='1' then
   state<=IDLE;gen<=(others=>'0');epoch<=(others=>'0');cursor<=0;settle<=0;count_latch<=(others=>'0');
  elsif state/=IDLE and not aborting(state) and stop_now='1' then
   mirror_release<='1';
   if state=PUBLISH_WAIT then state<=ABORT_PUBLISH; else state<=ABORT_OWNER; end if;
  else
   case state is
    when IDLE=>if start_request='1' and start_ready='1' then
     gen<=gen+1;epoch<=std_logic_vector(gen(7 downto 0)+1);slot<=request_slot;rom_id<=request_rom;config_id<=request_config;
     start_accept<='1';state<=REARM;cursor<=0;count_latch<=(others=>'0');end if;
    when REARM=>state<=BRIDGE_START;
    when BRIDGE_START=>if append_start_accept='1' then state<=BRIDGE_READY;end if;
    when BRIDGE_READY=>if append_ready='1' then state<=TRACK_FIRST;end if;
    when TRACK_FIRST=>state<=TRACK;
    when TRACK=>if grant='1' then state<=CUT_WAIT;settle<=0;end if;
    when CUT_WAIT=>if settle=2 then state<=SELECT_REQUEST;else settle<=settle+1;end if;
    when SELECT_REQUEST=>if selected_request_ready='1' then state<=SELECT_RESPONSE;end if;
    when SELECT_RESPONSE=>if selected_response_valid='1' then held_data<=selected_response_data;state<=SELECT_HOLD;end if;
    when SELECT_HOLD=>if selected_accept='1' then
      if cursor=3497 then state<=COMPLETE;else cursor<=cursor+1;state<=SELECT_REQUEST;end if;end if;
    when COMPLETE=>if complete_accept='1' then mirror_release<='1';state<=OWNER_DRAIN;end if;
    when OWNER_DRAIN=>if queued=0 then count_latch<=to_unsigned(committed,18);state<=BRIDGE_FINISH;end if;
    when BRIDGE_FINISH=>state<=BRIDGE_DRAIN;
    when BRIDGE_DRAIN=>if append_failed='1' then state<=ABORT_SOURCE;
      elsif append_done='1' then state<=PUBLISH_START;end if;
    when PUBLISH_START=>if publisher_ready='1' then state<=PUBLISH_WAIT;end if;
    when PUBLISH_WAIT=>if publisher_done='1' then history_done<='1';state<=IDLE;
      elsif publisher_failed='1' then state<=ABORT_SOURCE;end if;
    when ABORT_OWNER=>if queued=0 then state<=ABORT_BRIDGE;end if;
    when ABORT_BRIDGE=>if append_busy='0' then state<=ABORT_SOURCE;end if;
    when ABORT_PUBLISH=>if publisher_busy='0' then state<=ABORT_SOURCE;end if;
    when ABORT_SOURCE=>if selected_idle='1' then capture_failed<='1';state<=IDLE;end if;
   end case;
  end if;
 end if;
 end process;
end;
