// Passive two-bank observer. No gameplay enable, address or data output exists.
// Single clock only; a_we/b_we MUST be actual committed native write strobes.
module snapshot_mirror #(
    parameter integer AW=8, DW=8,
    parameter INIT_FILE="", parameter QUARTUS_INIT_FILE="UNUSED"
)(
    input wire clk, reset, abort_capture,
    input wire a_we, input wire [AW-1:0] a_addr, input wire [DW-1:0] a_data,
    input wire b_we, input wire [AW-1:0] b_addr, input wire [DW-1:0] b_data,
    input wire cut, release_capture,
    output wire cut_ready, output reg cut_accepted,
    output reg frozen, output reg fault,
    input wire read_valid, input wire [AW-1:0] read_addr,
    output wire read_ready,
    output reg out_valid, output wire [DW-1:0] out_data,
    input wire out_ready
);
    localparam integer N=1<<AW;
    reg coherent, pending;
    reg [AW-1:0] cursor;
    wire [DW-1:0] live_q;
    reg bypass, saved_valid;
    reg [DW-1:0] saved_data;
    reg [DW-1:0] bypass_data;
    wire [DW-1:0] copy_data = bypass ? bypass_data : saved_valid ? saved_data : live_q;
    wire collision = a_we && b_we && (a_addr == b_addr);
    wire invalidate = reset || abort_capture || release_capture;
    assign cut_ready = coherent && !frozen && !fault && !invalidate && !collision;
    wire take_cut = cut && cut_ready;
    wire track_snap = (!frozen || invalidate) && !take_cut;
    wire rebuilding = !coherent && !frozen && !invalidate && !fault;
    wire same_a = a_we && a_addr == cursor;
    wire same_b = b_we && b_addr == cursor;
    wire commit_copy = rebuilding && pending && (!a_we || !b_we || same_a || same_b);
    // A same-edge native write supersedes the older copy and itself repairs word.
    wire copy_write = commit_copy && !same_a && !same_b;
    wire issue_copy = rebuilding && !pending && !a_we;
    assign read_ready = frozen && !fault && !invalidate && (!out_valid || out_ready);
    initial begin
        coherent=0; pending=0; cursor=0; bypass=0; bypass_data=0; saved_valid=0; saved_data=0;
        frozen=0; fault=0; cut_accepted=0; out_valid=0;
    end
    always @(posedge clk) begin
        if (issue_copy || invalidate || commit_copy) saved_valid <= 0;
        else if (pending && !saved_valid) begin
            saved_valid <= 1;
            saved_data <= live_q;
        end
    end
    // Registered read output is kept inside canonical RAM inference template.
    // Forward the B collision separately; do not put a data mux before RAM q.
    always @(posedge clk) if (issue_copy) begin
        bypass <= b_we && b_addr == cursor;
        bypass_data <= b_data;
    end
    snapshot_mirror_tdp #(.AW(AW),.DW(DW),.INIT_FILE(INIT_FILE),.QUARTUS_INIT_FILE(QUARTUS_INIT_FILE)) live_ram (
        .clk(clk), .a_en(a_we || issue_copy), .a_we(a_we),
        .a_addr(a_we ? a_addr : cursor), .a_data(a_data), .a_q(live_q),
        .b_en(b_we && !collision), .b_we(b_we && !collision),
        .b_addr(b_addr), .b_data(b_data), .b_q()
    );
    wire snap_a_native = track_snap && a_we;
    wire snap_b_native = track_snap && b_we && !collision;
    wire snap_a_copy = copy_write && !a_we;
    wire snap_b_copy = copy_write && a_we && !b_we;
    snapshot_mirror_tdp #(.AW(AW),.DW(DW),.INIT_FILE(INIT_FILE),.QUARTUS_INIT_FILE(QUARTUS_INIT_FILE)) snap_ram (
        .clk(clk),
        .a_en(snap_a_native || snap_a_copy || (read_valid && read_ready)),
        .a_we(snap_a_native || snap_a_copy),
        .a_addr(snap_a_native ? a_addr : snap_a_copy ? cursor : read_addr),
        .a_data(snap_a_native ? a_data : copy_data), .a_q(out_data),
        .b_en(snap_b_native || snap_b_copy), .b_we(snap_b_native || snap_b_copy),
        .b_addr(snap_b_native ? b_addr : cursor),
        .b_data(snap_b_native ? b_data : copy_data), .b_q()
    );
    always @(posedge clk) begin
        cut_accepted <= 0;
        // Unknown native dual-write behavior cannot be reconstructed. Sticky
        // until FPGA reinitialization, not reset: never certify corrupted data.
        if (collision) fault <= 1;
        if (invalidate) begin
            coherent <= 0; pending <= 0; cursor <= 0;
            frozen <= 0; out_valid <= 0;
        end else if (fault || collision) begin
            coherent <= 0; pending <= 0; frozen <= 0; out_valid <= 0;
        end else if (take_cut) begin
            frozen <= 1; coherent <= 0; pending <= 0;
            cut_accepted <= 1; out_valid <= 0;
        end else begin
            if (out_valid && out_ready) out_valid <= 0;
            if (read_valid && read_ready) out_valid <= 1;
            if (issue_copy) pending <= 1;
            if (commit_copy) begin
                pending <= 0;
                if (&cursor) begin coherent <= 1; cursor <= 0; end
                else cursor <= cursor + 1'b1;
            end
        end
    end
endmodule

// Canonical same-clock true dual-port block RAM, synchronous registered reads.
// Same-address mixed-port read values are unspecified and never consumed by
// controller without bypass. Controller prevents dual writes to one address.
module snapshot_mirror_tdp #(
    parameter integer AW=8, DW=8, parameter INIT_FILE="", parameter QUARTUS_INIT_FILE="UNUSED"
)(
    input wire clk,
    input wire a_en, a_we, input wire [AW-1:0] a_addr,
    input wire [DW-1:0] a_data, output reg [DW-1:0] a_q,
    input wire b_en, b_we, input wire [AW-1:0] b_addr,
    input wire [DW-1:0] b_data, output reg [DW-1:0] b_q
);
`ifndef MIRROR_BEHAVIORAL_RAM
    altsyncram #(
        .intended_device_family("Cyclone V"), .operation_mode("BIDIR_DUAL_PORT"),
        .ram_block_type("M10K"), .lpm_type("altsyncram"),
        .width_a(DW), .widthad_a(AW), .numwords_a(1<<AW),
        .width_b(DW), .widthad_b(AW), .numwords_b(1<<AW),
        .width_byteena_a(1), .width_byteena_b(1),
        .address_reg_b("CLOCK1"), .indata_reg_b("CLOCK1"),
        .wrcontrol_wraddress_reg_b("CLOCK1"),
        .clock_enable_input_a("NORMAL"), .clock_enable_input_b("NORMAL"),
        .clock_enable_output_a("BYPASS"), .clock_enable_output_b("BYPASS"),
        .outdata_reg_a("UNREGISTERED"), .outdata_reg_b("UNREGISTERED"),
        .outdata_aclr_a("NONE"), .outdata_aclr_b("NONE"),
        .read_during_write_mode_port_a("NEW_DATA_NO_NBE_READ"),
        .read_during_write_mode_port_b("NEW_DATA_NO_NBE_READ"),
        .read_during_write_mode_mixed_ports("DONT_CARE"),
        .power_up_uninitialized("FALSE"), .init_file(QUARTUS_INIT_FILE)
    ) ram (
        .clock0(clk), .clock1(clk), .clocken0(a_en), .clocken1(b_en),
        .clocken2(1'b1), .clocken3(1'b1),
        .address_a(a_addr), .address_b(b_addr), .data_a(a_data), .data_b(b_data),
        .wren_a(a_we && a_en), .wren_b(b_we && b_en),
        .rden_a(1'b1), .rden_b(1'b1), .q_a(a_q), .q_b(b_q),
        .aclr0(1'b0), .aclr1(1'b0), .byteena_a(1'b1), .byteena_b(1'b1),
        .addressstall_a(1'b0), .addressstall_b(1'b0), .eccstatus()
    );
`else
    (* ramstyle = "M10K, no_rw_check" *) reg [DW-1:0] mem [0:(1<<AW)-1];
    integer i;
    initial begin
        for(i=0;i<(1<<AW);i=i+1) mem[i]=0;
        if(INIT_FILE != "") $readmemh(INIT_FILE, mem);
    end
    always @(posedge clk) if(a_en) begin
        if(a_we) mem[a_addr] <= a_data;
        a_q <= mem[a_addr];
    end
    always @(posedge clk) if(b_en) begin
        if(b_we) mem[b_addr] <= b_data;
        b_q <= mem[b_addr];
    end
`endif
endmodule
