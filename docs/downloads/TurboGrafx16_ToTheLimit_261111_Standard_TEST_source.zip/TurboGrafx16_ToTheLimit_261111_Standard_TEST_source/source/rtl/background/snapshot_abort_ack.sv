// Completion adapter for the production synchronous mirrors, NOT an arbitrary
// asynchronous/variable-latency transport. Connect mirror_abort to every mirror
// abort_capture and BG_ABORT. Their abort priority clears every pending output
// on the rising edge. Acknowledge only after that edge and both aggregate valids
// are low. Use the same clk/reset as the selected exporter and all mirrors.
module snapshot_abort_ack (
    input wire clk_sys, power_reset,
    input wire native_abort,
    input wire pce_out_valid, bram_out_valid,
    output wire mirror_abort,
    output wire native_abort_done
);
    reg abort_seen = 0;
    always @(posedge clk_sys)
        if (power_reset) abort_seen <= 0;
        else abort_seen <= native_abort;
    assign mirror_abort = native_abort;
    assign native_abort_done = native_abort && abort_seen &&
        !pce_out_valid && !bram_out_valid;
endmodule
