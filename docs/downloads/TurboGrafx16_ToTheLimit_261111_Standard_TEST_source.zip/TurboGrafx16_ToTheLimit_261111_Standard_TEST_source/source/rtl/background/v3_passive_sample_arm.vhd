library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity v3_passive_sample_arm is
 generic (WIDTH : positive := 16; WORDS : positive := 32768; SAMPLE_STRIDE : positive := 15);
 port (
  clk, cold_reset_n, track_active, close_tracking, sample_start, abort_request, owner_fault : in std_logic;
  generation : in std_logic_vector(7 downto 0);
  a_address, b_address : in std_logic_vector(14 downto 0);
  a_data, b_raw : in std_logic_vector(15 downto 0);
  a_enable, a_cs, a_write, b_enable, b_cs, b_write : in std_logic;
  freeze_mode, load_mode, scan_mode, clear_mode : in std_logic;
  sample_valid, base_valid, write_valid, source_fault : out std_logic;
  sample_address, write_address : out std_logic_vector(14 downto 0);
  sample_value, write_value : out std_logic_vector(15 downto 0);
  forwarded, primed_out, started_out : out std_logic;
  coverage_count : out natural range 0 to WORDS
 );
end entity;

architecture passive of v3_passive_sample_arm is
 signal closed : std_logic := '0';
 signal primed, started, ended, broken, previous_write : std_logic := '0';
 signal previous_b, previous_a, expected_tag : unsigned(14 downto 0) := (others => '0');
 signal previous_data : std_logic_vector(15 downto 0) := (others => '0');
 signal held_generation : std_logic_vector(7 downto 0) := (others => '0');
 signal count : natural range 0 to WORDS := 0;
 signal phase : natural range 0 to SAMPLE_STRIDE-1 := 0;
 signal invalid_now, take_sample, take_base, take_write, use_forward : std_logic;
 signal observed : std_logic_vector(15 downto 0);
 function is_strong(v : std_logic_vector) return boolean is
 begin
  for i in v'range loop
   if v(i) /= '0' and v(i) /= '1' then return false; end if;
  end loop;
  return true;
 end function;
 function payload_ok(v : std_logic_vector(15 downto 0)) return boolean is
 begin
  return is_strong(v) and (WIDTH = 16 or v(15 downto 8) = x"00");
 end function;
begin
 assert WORDS <= 32768 and (WORDS = 8192 or WORDS = 32768) and SAMPLE_STRIDE mod 2 = 1 report "adapter geometry/stride" severity failure;
 assert WIDTH = 8 or WIDTH = 16 report "adapter width must be 8 or 16" severity failure;
 coverage_count <= count;
 primed_out <= primed;
 started_out <= started;
 sample_address <= std_logic_vector(previous_b);
 write_address <= a_address;
 sample_value <= observed;
 write_value <= a_data;
 sample_valid <= take_sample;
 base_valid <= take_base;
 write_valid <= take_write;
 forwarded <= use_forward and take_sample;
 source_fault <= invalid_now;

 process(all)
  variable bad_input, wants_sample, collision, accepted_write : boolean;
  variable value : std_logic_vector(15 downto 0);
 begin
  take_sample <= '0'; take_base <= '0'; take_write <= '0'; use_forward <= '0';
  invalid_now <= '0'; observed <= (others => '0');
  bad_input := broken = '1';
  wants_sample := started = '1' and count < WORDS and phase = 0;
  collision := previous_write = '1' and previous_a = previous_b;
  accepted_write := a_enable = '1' and a_cs = '1' and a_write = '1';
  value := b_raw;
  if collision then value := previous_data; end if;
  if cold_reset_n /= '0' and closed = '0' then
   bad_input := bad_input or not is_strong(cold_reset_n & track_active & sample_start & abort_request & owner_fault &
    a_enable & a_cs & a_write & b_enable & b_cs & b_write & freeze_mode & load_mode & scan_mode & clear_mode);
   bad_input := bad_input or abort_request /= '0' or owner_fault /= '0';
   -- The owner grants the cut while tracking is still active. Do not feed
   -- its combinational grant back into fault qualification. The registered
   -- closed flag masks this arm before tracking drops on the following edge.
   if primed = '1' and track_active /= '1' then bad_input := true; end if;
   if sample_start = '1' and (track_active /= '1' or started = '1') then bad_input := true; end if;
   if track_active = '1' then
    bad_input := bad_input or not is_strong(generation & b_address) or b_enable /= '1' or b_cs /= '1' or b_write /= '0';
    bad_input := bad_input or freeze_mode /= '0' or load_mode /= '0' or scan_mode /= '0' or clear_mode /= '0';
    if a_enable = '1' then bad_input := bad_input or not is_strong(a_address); end if;
    if accepted_write then bad_input := bad_input or not payload_ok(a_data); end if;
    if primed = '1' then
     bad_input := bad_input or generation /= held_generation;
     if is_strong(b_address) then bad_input := bad_input or to_integer(unsigned(b_address)) /= (to_integer(previous_b) + 1) mod WORDS; end if;
    end if;
    if wants_sample then
     bad_input := bad_input or not payload_ok(value);
     if count > 0 then bad_input := bad_input or previous_b /= expected_tag; end if;
    end if;
   end if;
   if bad_input then
    invalid_now <= '1';
   elsif track_active = '1' then
    if accepted_write then take_write <= '1'; end if;
    if wants_sample then
     take_sample <= '1'; observed <= value;
     if collision then use_forward <= '1'; end if;
    elsif count = WORDS and ended = '0' then
     take_base <= '1';
    end if;
   end if;
  end if;
 end process;

 process(clk)
 begin
  if rising_edge(clk) then
   -- synthesis translate_off
   if cold_reset_n='1' and closed='0' then
    assert close_tracking='0' or close_tracking='1' report "unknown close grant" severity failure;
    assert close_tracking/='1' or track_active='1' report "cut requires active tracking on its edge" severity failure;
   end if;
   -- synthesis translate_on
   if cold_reset_n = '0' then
    closed <= '0';
    primed <= '0'; started <= '0'; ended <= '0'; broken <= '0'; previous_write <= '0';
    previous_b <= (others => '0'); previous_a <= (others => '0'); previous_data <= (others => '0');
    held_generation <= (others => '0'); expected_tag <= (others => '0'); count <= 0; phase <= 0;
   elsif close_tracking = '1' then
    closed <= '1';
   elsif closed = '1' then null;
   elsif invalid_now = '1' then
    broken <= '1';
   elsif track_active = '1' then
    primed <= '1'; previous_b <= unsigned(b_address); held_generation <= generation;
    previous_write <= take_write;
    if take_write = '1' then previous_a <= unsigned(a_address); previous_data <= a_data; end if;
    if sample_start = '1' then started <= '1'; phase <= 0; end if;
    if take_sample = '1' then
     count <= count + 1; expected_tag <= to_unsigned((to_integer(previous_b) + SAMPLE_STRIDE) mod WORDS,15); phase <= SAMPLE_STRIDE-1;
    elsif started = '1' and count < WORDS and phase > 0 then
     phase <= phase - 1;
    end if;
    if take_base = '1' then ended <= '1'; end if;
   end if;
  end if;
 end process;
end architecture;
