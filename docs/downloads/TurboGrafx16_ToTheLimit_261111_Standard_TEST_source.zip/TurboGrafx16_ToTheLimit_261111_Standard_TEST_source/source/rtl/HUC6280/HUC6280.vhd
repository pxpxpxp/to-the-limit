library IEEE;
use IEEE.std_logic_1164.all;
use ieee.numeric_std.all;
library work;
use work.HUC6280_PKG.all;

entity HUC6280 is
	port(
        SS_SAFE : out std_logic;
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LIVE_CUT : in std_logic := '0'; -- private live capture; never a freeze
        SS_LOAD : in std_logic := '0';
 
		CLK		: in std_logic;
		RST_N		: in std_logic;
		WAIT_N	: in std_logic;
		CPU_TURBO : in std_logic_vector(1 downto 0) := "00";
		  
		A			: buffer std_logic_vector(20 downto 0);
		DI			: in std_logic_vector(7 downto 0);
		DO			: buffer std_logic_vector(7 downto 0);
		WR_N  	: buffer std_logic;
		RD_N  	: buffer std_logic;
		RDY		: in std_logic;
		NMI_N		: in std_logic;  
		IRQ1_N	: in std_logic;
		IRQ2_N	: in std_logic;
		
		CE			: buffer std_logic;
		CEK_N		: buffer std_logic;
		CE7_N		: buffer std_logic;
		CER_N		: buffer std_logic;
		PRE_RD	: buffer std_logic; -- for MiSTer sdram/ddram read
		PRE_WR	: buffer std_logic;
		
		HSM		: buffer std_logic;
		
		O			: buffer std_logic_vector(7 downto 0);
		K			: in std_logic_vector(7 downto 0);
		
		VDCNUM	: in std_logic;
		
		AUD_LDATA: buffer std_logic_vector(23 downto 0);
		AUD_RDATA: buffer std_logic_vector(23 downto 0)
	);
end HUC6280;

architecture rtl of HUC6280 is

	signal CPU_CE 			: std_logic;
	signal CPU_CER 		: std_logic;
	signal IO_CE 			: std_logic;
	signal EN 				: std_logic;
	
	signal CPU_DI 			: std_logic_vector(7 downto 0);
	signal CPU_DO 			: std_logic_vector(7 downto 0);
	signal CPU_A 			: std_logic_vector(20 downto 0);
	signal CPU_WE_N 		: std_logic;
	signal CPU_CS 			: std_logic;
	signal CPU_MCYCLE		: std_logic;
	signal CPU_IRQ1_N 	: std_logic;
	signal CPU_IRQ2_N 	: std_logic;
	signal CPU_IRQT_N 	: std_logic;
	signal CPU_RDY 		: std_logic;
	
	signal CPU_CLK_CNT 	: unsigned(4 downto 0);
	-- Latched after the CPU address and CSH/CSL outputs settle.
	signal CPU_CYCLE_LAST : unsigned(4 downto 0);
	signal IO_CLK_CNT 	: unsigned(2 downto 0);
	signal VDC_SEL_OLD	: std_logic;
	
	--IO
	signal IO_BUF 			: std_logic_vector(7 downto 0);
	signal RAM_SEL 		: std_logic;
	signal VDC_SEL 		: std_logic;
	signal VCE_SEL 		: std_logic;
	signal IOP_SEL 		: std_logic;
	signal PSG_SEL 		: std_logic;
	signal TMR_SEL 		: std_logic;
	signal INT_SEL 		: std_logic;
	signal IO_SEL 			: std_logic;
	
	signal INT_MASK_PRE	: std_logic_vector(2 downto 0);
	signal INT_MASK 		: std_logic_vector(2 downto 0);
	signal TMR_PRE_CNT 	: unsigned(9 downto 0);
	signal TMR_VALUE 		: std_logic_vector(6 downto 0); 
	signal TMR_LATCH 		: std_logic_vector(6 downto 0);
	signal TMR_EN 			: std_logic;
	signal TMR_RELOAD		: std_logic; 
	signal TMR_IRQ 		: std_logic;
	signal TMR_IRQ_ACK 	: std_logic;

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_CPU_CE : std_logic;
signal SS_SH_CPU_CER : std_logic;
signal SS_SH_CPU_CLK_CNT : unsigned(4 downto 0);
signal SS_SH_CPU_CYCLE_LAST : unsigned(4 downto 0);
signal SS_SH_CPU_DI : std_logic_vector(7 downto 0);
signal SS_SH_CPU_RDY : std_logic;
signal SS_SH_INT_MASK : std_logic_vector(2 downto 0);
signal SS_SH_INT_MASK_PRE : std_logic_vector(2 downto 0);
signal SS_SH_IO_BUF : std_logic_vector(7 downto 0);
signal SS_SH_IO_CE : std_logic;
signal SS_SH_IO_CLK_CNT : unsigned(2 downto 0);
signal SS_SH_O : std_logic_vector(7 downto 0);
signal SS_SH_RD_N : std_logic;
signal SS_SH_TMR_EN : std_logic;
signal SS_SH_TMR_IRQ : std_logic;
signal SS_SH_TMR_IRQ_ACK : std_logic;
signal SS_SH_TMR_LATCH : std_logic_vector(6 downto 0);
signal SS_SH_TMR_PRE_CNT : unsigned(9 downto 0);
signal SS_SH_TMR_RELOAD : std_logic;
signal SS_SH_TMR_VALUE : std_logic_vector(6 downto 0);
signal SS_SH_VDC_SEL_OLD : std_logic;
signal SS_SH_WR_N : std_logic;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_CHILD_HUC6280_CPU : std_logic_vector(15 downto 0);
signal SS_CHILD_PSG : std_logic_vector(15 downto 0);
signal SS_CHAIN : std_logic_vector(79 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(79 downto 0);
signal SS_LIVE_PENDING : std_logic_vector(1 downto 0) := "00";
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin

	


	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			CPU_CLK_CNT <= (others=>'0');
			CPU_CYCLE_LAST <= to_unsigned(23, CPU_CYCLE_LAST'length);
			CPU_CE <= '0';
			CPU_CER <= '0';
			IO_CLK_CNT <= (others=>'0');
			IO_CE <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CPU_CE <= SS_SH_CPU_CE;
CPU_CER <= SS_SH_CPU_CER;
CPU_CLK_CNT <= SS_SH_CPU_CLK_CNT;
CPU_CYCLE_LAST <= SS_SH_CPU_CYCLE_LAST;
IO_CE <= SS_SH_IO_CE;
IO_CLK_CNT <= SS_SH_IO_CLK_CNT;
elsif SS_FREEZE = '0' then

			CPU_CE <= '0';
			if CPU_CLK_CNT = CPU_CYCLE_LAST then
				if WAIT_N = '1' then
					CPU_CLK_CNT <= (others=>'0');
					CPU_CE <= '1';
				end if; 
			else
				CPU_CLK_CNT <= CPU_CLK_CNT + 1;
			end if; 
			
			CPU_CER <= '0';
			if CPU_CLK_CNT = 1 then
				CPU_CER <= '1';
				-- Only accelerate high-speed ROM/RAM/internal cycles. Keep
				-- low-speed mode and the entire $FF I/O page at stock speed.
				-- Four master clocks is the minimum: preserve the bus setup
				-- pipeline and allow eight clocks for the 2x SDRAM controller.
				CPU_CYCLE_LAST <= to_unsigned(23, CPU_CYCLE_LAST'length);
				if CPU_CS = '1' then
					CPU_CYCLE_LAST <= to_unsigned(5, CPU_CYCLE_LAST'length);
					if CPU_A(20 downto 13) /= x"FF" then
						case CPU_TURBO is
							when "01" => CPU_CYCLE_LAST <= to_unsigned(4, CPU_CYCLE_LAST'length);
							when "10" => CPU_CYCLE_LAST <= to_unsigned(3, CPU_CYCLE_LAST'length);
							when others => null; -- Off, including reserved value 11
						end case;
					end if;
				end if;
			end if; 
			
			IO_CE <= '0';
			IO_CLK_CNT <= IO_CLK_CNT + 1;
			if IO_CLK_CNT = 5 then
				IO_CLK_CNT <= (others=>'0');
				IO_CE <= '1';
			end if; 
		
end if;
end if;
	end process;
	
	CE <= CPU_CE and CPU_RDY;
	
	EN <= CPU_CE and CPU_RDY;
	
	
	CORE : entity work.HUC6280_CPU
	port map (
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_CHILD_HUC6280_CPU,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD => SS_LOAD,

		CLK 		=> CLK,
		RST_N 	=> RST_N,
		CE 		=> CPU_CE,
		
		A_OUT 	=> CPU_A,
		DI 		=> CPU_DI,
		DO 		=> CPU_DO,
		WE_N 		=> CPU_WE_N,
		RDY 		=> CPU_RDY,
		IRQ1_N 	=> CPU_IRQ1_N,
		IRQ2_N 	=> CPU_IRQ2_N,
		IRQT_N 	=> CPU_IRQT_N,
		NMI_N 	=> NMI_N,
		MCYCLE	=> CPU_MCYCLE,
		CS 		=> CPU_CS,
		VDCNUM   => VDCNUM
	);
	
	CPU_IRQ1_N <= IRQ1_N or INT_MASK(1);
	CPU_IRQ2_N <= IRQ2_N or INT_MASK(0);
	CPU_IRQT_N <= not TMR_IRQ or INT_MASK(2);
	
	RAM_SEL <= '1' when CPU_A(20 downto 15) = "111110" else '0'; -- RAM : Page $F8 - $FB
	VDC_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "000" else '0'; -- VDC : $0000 - $03FF
	VCE_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "001" else '0'; -- VCE : $0400 - $07FF
	
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			WR_N <= '1';
			RD_N <= '1';
			CPU_RDY <= '1';
			VDC_SEL_OLD <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CPU_RDY <= SS_SH_CPU_RDY;
RD_N <= SS_SH_RD_N;
VDC_SEL_OLD <= SS_SH_VDC_SEL_OLD;
WR_N <= SS_SH_WR_N;
elsif SS_FREEZE = '0' then

			if CPU_CER = '1' then
				if CPU_MCYCLE = '1' then
					WR_N <= CPU_WE_N;
					RD_N <= not CPU_WE_N;
				end if; 
				
				VDC_SEL_OLD <= VDC_SEL or VCE_SEL;
				if (VDC_SEL = '1' or VCE_SEL = '1') and VDC_SEL_OLD = '0' then
					CPU_RDY <= '0';
				end if;
			elsif CPU_CE = '1' then
				if CPU_RDY = '1' then
					WR_N <= '1';
					RD_N <= '1';
				end if; 
				CPU_RDY <= RDY;
			end if; 
		
end if;
end if;
	end process;
	
	PRE_RD <= CPU_WE_N and CPU_MCYCLE and RST_N;
	PRE_WR <= not CPU_WE_N and CPU_MCYCLE and RST_N;
	
	A <= CPU_A;
	DO <= CPU_DO;
	CER_N <= not RAM_SEL;
	CE7_N <= not VDC_SEL;
	CEK_N <= not VCE_SEL;
	HSM <= CPU_CS;
	
	
	
	--KO port
	IOP_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "100" else '0'; -- IOP : $1000 - $13FF
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			O <= (others=>'0');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
O <= SS_SH_O;
elsif SS_FREEZE = '0' then

			if EN = '1' then
				if IOP_SEL = '1' and CPU_WE_N = '0' then
					O <= CPU_DO;
				end if; 
			end if; 
		
end if;
end if;
	end process;
	
	--Interrupts register
	INT_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "101" else '0'; -- INT : $1400 - $17FF
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			INT_MASK_PRE <= (others=>'0');
			TMR_IRQ_ACK <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
INT_MASK <= SS_SH_INT_MASK;
INT_MASK_PRE <= SS_SH_INT_MASK_PRE;
TMR_IRQ_ACK <= SS_SH_TMR_IRQ_ACK;
elsif SS_FREEZE = '0' then

			TMR_IRQ_ACK <= '0';
			
			if CPU_CE = '1' then
				INT_MASK <= INT_MASK_PRE;	-- Delay interrupt mask usage until 1 cycle after it is updated
			end if;

			if INT_SEL = '1' and CPU_CER = '1' then 
				if CPU_WE_N = '0' then
					case CPU_A(1 downto 0) is
						when "10" =>
							INT_MASK_PRE <= CPU_DO(2 downto 0);
						when "11" =>
							TMR_IRQ_ACK <= '1';
						when others => null;
					end case;
				end if; 
			end if; 
		
end if;
end if;
	end process;


	-- Timer
	TMR_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "011" else '0'; -- TMR : $0C00 - $0FFF
	process( CLK, RST_N )
	begin
		if RST_N = '0' then
			TMR_VALUE <= (others => '0');			
			TMR_PRE_CNT <= (others => '1'); 
			TMR_LATCH <= (others => '0');
			TMR_EN <= '0';
			TMR_RELOAD <= '0'; 
			TMR_IRQ <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
TMR_EN <= SS_SH_TMR_EN;
TMR_IRQ <= SS_SH_TMR_IRQ;
TMR_LATCH <= SS_SH_TMR_LATCH;
TMR_PRE_CNT <= SS_SH_TMR_PRE_CNT;
TMR_RELOAD <= SS_SH_TMR_RELOAD;
TMR_VALUE <= SS_SH_TMR_VALUE;
elsif SS_FREEZE = '0' then

			if TMR_SEL = '1' and CPU_WE_N = '0' and CPU_CER = '1' then
				if CPU_A(0) = '0' then
					-- Timer latch
					TMR_LATCH <= CPU_DO(6 downto 0);
				else
					-- Timer enable
					TMR_EN <= CPU_DO(0);
					if TMR_EN = '0' and CPU_DO(0) = '1' then
						TMR_VALUE <= TMR_LATCH;
						TMR_PRE_CNT <= (others => '1'); 
					end if;
				end if;	
			end if; 
			
			if TMR_IRQ_ACK = '1' then
				TMR_IRQ <= '0';
			end if;
			
			if IO_CE = '1' then
				TMR_RELOAD <= '0';
				if TMR_EN = '1' then
					TMR_PRE_CNT <= TMR_PRE_CNT - 1;
					if TMR_PRE_CNT = 0 then
						TMR_VALUE <= std_logic_vector( unsigned(TMR_VALUE) - 1 );
						if TMR_VALUE = "0000000" then
							TMR_RELOAD <= '1';
							TMR_IRQ <= '1';
						end if;
					end if;
				end if; 
				
				if TMR_RELOAD = '1' then
					TMR_VALUE <= TMR_LATCH;
				end if; 
			end if;
		
end if;
end if;
	end process;
	
	-- PSG
	PSG_SEL <= '1' when CPU_A(20 downto 13) = x"FF" and CPU_A(12 downto 10) = "010" else '0'; -- PSG : $0800 - $0BFF
	PSG : entity work.psg port map (
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_CHILD_PSG,

SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD => SS_LOAD,

		CLK		=> CLK,
		CLKEN		=> IO_CE,	-- 7.16 Mhz clock
		RESET_N	=> RST_N,
		
		DI			=> CPU_DO,
		A			=> CPU_A(3 downto 0),
		WE			=> not CPU_WE_N and EN and PSG_SEL,
		
		DAC_LATCH=> '1',
		LDATA		=> AUD_LDATA,
		RDATA		=> AUD_RDATA
	);
		
	IO_SEL <= IOP_SEL or INT_SEL or TMR_SEL or PSG_SEL;
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			IO_BUF <= (others=>'1');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
IO_BUF <= SS_SH_IO_BUF;
elsif SS_FREEZE = '0' then

			if EN = '1' then
				if IO_SEL = '1' then 
					if CPU_WE_N = '0' then
						IO_BUF <= CPU_DO;
					else
						IO_BUF <= CPU_DI;
					end if; 
				end if; 
			end if; 
		
end if;
end if;
	end process;
	
	process(CLK)
	begin
		if rising_edge(CLK) then
if SS_LOAD = '1' then
CPU_DI <= SS_SH_CPU_DI;
elsif SS_FREEZE = '0' then

			if IO_SEL = '0' then
				CPU_DI <= DI;
			elsif PSG_SEL = '1' then
				CPU_DI <= x"00";
			elsif IOP_SEL = '1' then
				CPU_DI <= K;
			elsif INT_SEL = '1' then
				case CPU_A(1 downto 0) is
					when "10" =>
						CPU_DI <= IO_BUF(7 downto 3) & INT_MASK;
					when "11" =>
						CPU_DI <= IO_BUF(7 downto 3) & TMR_IRQ & not IRQ1_N & not IRQ2_N;
					when others =>
						CPU_DI <= IO_BUF;
				end case;
			elsif TMR_SEL = '1' then
				CPU_DI <= IO_BUF(7) & TMR_VALUE;
			else
				CPU_DI <= IO_BUF;
			end if;
		
end if;
end if;
	end process;

SS_SAFE <= '1' when CPU_CLK_CNT = CPU_CYCLE_LAST and CPU_CE = '0' and WAIT_N = '1' else '0';

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 401 and to_integer(unsigned(SS_RADDR)) <= 405 else (others => '0');
SS_CAPTURE_DATA(0) <= CPU_CE;
SS_CAPTURE_DATA(1) <= CPU_CER;
SS_CAPTURE_DATA(6 downto 2) <= std_logic_vector(CPU_CLK_CNT(4 downto 0));
SS_CAPTURE_DATA(11 downto 7) <= std_logic_vector(CPU_CYCLE_LAST(4 downto 0));
SS_CAPTURE_DATA(15 downto 12) <= std_logic_vector(CPU_DI(3 downto 0));
SS_CAPTURE_DATA(19 downto 16) <= std_logic_vector(CPU_DI(7 downto 4));
SS_CAPTURE_DATA(20) <= CPU_RDY;
SS_CAPTURE_DATA(23 downto 21) <= std_logic_vector(INT_MASK(2 downto 0));
SS_CAPTURE_DATA(26 downto 24) <= std_logic_vector(INT_MASK_PRE(2 downto 0));
SS_CAPTURE_DATA(31 downto 27) <= std_logic_vector(IO_BUF(4 downto 0));
SS_CAPTURE_DATA(34 downto 32) <= std_logic_vector(IO_BUF(7 downto 5));
SS_CAPTURE_DATA(35) <= IO_CE;
SS_CAPTURE_DATA(38 downto 36) <= std_logic_vector(IO_CLK_CNT(2 downto 0));
SS_CAPTURE_DATA(46 downto 39) <= std_logic_vector(O(7 downto 0));
SS_CAPTURE_DATA(47) <= RD_N;
SS_CAPTURE_DATA(48) <= TMR_EN;
SS_CAPTURE_DATA(49) <= TMR_IRQ;
SS_CAPTURE_DATA(50) <= TMR_IRQ_ACK;
SS_CAPTURE_DATA(57 downto 51) <= std_logic_vector(TMR_LATCH(6 downto 0));
SS_CAPTURE_DATA(63 downto 58) <= std_logic_vector(TMR_PRE_CNT(5 downto 0));
SS_CAPTURE_DATA(67 downto 64) <= std_logic_vector(TMR_PRE_CNT(9 downto 6));
SS_CAPTURE_DATA(68) <= TMR_RELOAD;
SS_CAPTURE_DATA(75 downto 69) <= std_logic_vector(TMR_VALUE(6 downto 0));
SS_CAPTURE_DATA(76) <= VDC_SEL_OLD;
SS_CAPTURE_DATA(77) <= WR_N;
SS_CAPTURE_DATA(79 downto 78) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
-- T captures ordinary fields; T+2 patches only the settled variable proxies.
-- Native state machines continue unchanged throughout this operation.
SS_LIVE_PENDING <= SS_LIVE_PENDING(0) & SS_LIVE_CUT;
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
-- synthesis translate_off
assert not (SS_LIVE_CUT = '1' and (SS_SAVE = '1' or SS_LOAD = '1' or SS_FREEZE = '1' or SS_CHAIN_CAPTURE /= "00" or SS_LIVE_PENDING /= "00"))
 report "live cut overlaps another snapshot operation" severity failure;
assert not ((SS_LIVE_CUT = '1' or SS_LIVE_PENDING /= "00") and (SS_RROTATE = '1' or SS_RWE = '1' or SS_LOAD = '1' or SS_SAVE = '1'))
 report "snapshot chain used before live proxy settling completes" severity failure;
-- synthesis translate_on
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA; -- unchanged legacy frozen-save behavior
elsif SS_LIVE_CUT = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_LIVE_PENDING(1) = '1' then
null; -- no delayed process-variable fields in this chain
elsif SS_LIVE_PENDING /= "00" then
null; -- hold the captured scalar fields during proxy settling
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 401 and to_integer(unsigned(SS_RADDR)) <= 405) then
SS_CHAIN <= SS_RDI & SS_CHAIN(79 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 401 and to_integer(unsigned(SS_RADDR)) <= 405) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(79 downto 16);
end if;
end if;
end process;
SS_SH_CPU_CE <= SS_CHAIN(0);
SS_SH_CPU_CER <= SS_CHAIN(1);
SS_SH_CPU_CLK_CNT(4 downto 0) <= unsigned(SS_CHAIN(6 downto 2));
SS_SH_CPU_CYCLE_LAST(4 downto 0) <= unsigned(SS_CHAIN(11 downto 7));
SS_SH_CPU_DI(3 downto 0) <= SS_CHAIN(15 downto 12);
SS_SH_CPU_DI(7 downto 4) <= SS_CHAIN(19 downto 16);
SS_SH_CPU_RDY <= SS_CHAIN(20);
SS_SH_INT_MASK(2 downto 0) <= SS_CHAIN(23 downto 21);
SS_SH_INT_MASK_PRE(2 downto 0) <= SS_CHAIN(26 downto 24);
SS_SH_IO_BUF(4 downto 0) <= SS_CHAIN(31 downto 27);
SS_SH_IO_BUF(7 downto 5) <= SS_CHAIN(34 downto 32);
SS_SH_IO_CE <= SS_CHAIN(35);
SS_SH_IO_CLK_CNT(2 downto 0) <= unsigned(SS_CHAIN(38 downto 36));
SS_SH_O(7 downto 0) <= SS_CHAIN(46 downto 39);
SS_SH_RD_N <= SS_CHAIN(47);
SS_SH_TMR_EN <= SS_CHAIN(48);
SS_SH_TMR_IRQ <= SS_CHAIN(49);
SS_SH_TMR_IRQ_ACK <= SS_CHAIN(50);
SS_SH_TMR_LATCH(6 downto 0) <= SS_CHAIN(57 downto 51);
SS_SH_TMR_PRE_CNT(5 downto 0) <= unsigned(SS_CHAIN(63 downto 58));
SS_SH_TMR_PRE_CNT(9 downto 6) <= unsigned(SS_CHAIN(67 downto 64));
SS_SH_TMR_RELOAD <= SS_CHAIN(68);
SS_SH_TMR_VALUE(6 downto 0) <= SS_CHAIN(75 downto 69);
SS_SH_VDC_SEL_OLD <= SS_CHAIN(76);
SS_SH_WR_N <= SS_CHAIN(77);


SS_RDO <= SS_CHILD_HUC6280_CPU or SS_CHILD_PSG or SS_LOCAL_RDO;
end rtl;
	