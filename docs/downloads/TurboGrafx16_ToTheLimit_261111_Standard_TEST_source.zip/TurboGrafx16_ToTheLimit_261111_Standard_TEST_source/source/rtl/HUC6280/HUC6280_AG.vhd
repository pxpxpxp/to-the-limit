library IEEE;
use IEEE.std_logic_1164.all;
use ieee.numeric_std.all;
library work;

entity HUC6280_AG is
    port(
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LIVE_CUT : in std_logic := '0'; -- private live capture; never a freeze
        SS_LOAD : in std_logic := '0';
 
        CLK 			: in std_logic;
		  RST_N 			: in std_logic;
		  CE 				: in std_logic;
		  PC_CTRL		: in std_logic_vector(2 downto 0); 
        ADDR_CTRL		: in std_logic_vector(5 downto 0); 
		  GOT_INT		: in std_logic;  
        DI   			: in std_logic_vector(7 downto 0);
		  X   			: in std_logic_vector(7 downto 0);
		  Y   			: in std_logic_vector(7 downto 0);
		  DR   			: in std_logic_vector(7 downto 0);

		  PC				: buffer std_logic_vector(15 downto 0);
        AA     		: buffer std_logic_vector(15 downto 0)
    );
end HUC6280_AG;

architecture rtl of HUC6280_AG is

	signal AAL, AAH : std_logic_vector(7 downto 0);
	signal SavedCarry : std_logic;
	
	signal NewAAL : std_logic_vector(8 downto 0);
	signal NewAAH : std_logic_vector(7 downto 0);
	
	signal PCr: std_logic_vector(15 downto 0);
	signal NextPC, NewPCWithOffset: std_logic_vector(15 downto 0);

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_AAH : std_logic_vector(7 downto 0);
signal SS_SH_AAL : std_logic_vector(7 downto 0);
signal SS_SH_PCR : std_logic_vector(15 downto 0);
signal SS_SH_SAVEDCARRY : std_logic;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_CHAIN : std_logic_vector(47 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(47 downto 0);
signal SS_LIVE_PENDING : std_logic_vector(1 downto 0) := "00";
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin



	NewPCWithOffset <= std_logic_vector(unsigned(PCr) + unsigned((7 downto 0 => AAL(7)) & AAL)); 
	
	process(CLK, RST_N, PC_CTRL, PCr, DI, DR, GOT_INT, NewPCWithOffset, AAH, AAL )
	begin
		case PC_CTRL is
			when "000" => 
				NextPC <= PCr;
			when "001" => 
				if GOT_INT = '0' then
					NextPC <= std_logic_vector(unsigned(PCr) + 1); 
				else
					NextPC <= PCr;
				end if;
			when "010"=> 
				NextPC <= PCr(15 downto 8) & DI;
			when "011" => 
				NextPC <= DI & PCr(7 downto 0); 
			when "100" => 
				NextPC <= NewPCWithOffset; 
			when "110" => 
				NextPC <= AAH & AAL; 
			when others => 
				NextPC <= PCr;
		end case;
		
		if RST_N = '0' then
			PCr <= (others=>'0');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
PCR <= SS_SH_PCR;
elsif SS_FREEZE = '0' then

			if CE = '1' then
				PCr <= NextPC;
			end if;
		
end if;
end if;
	end process;
	
	process(ADDR_CTRL, AAL, AAH, X, Y, DI, DR, SavedCarry)
	begin
		case ADDR_CTRL(5 downto 3) is
			when "000"=> 
				NewAAL <= "0" & AAL;
			when "001"=> 
				NewAAL <= "0" & DI;
			when "010" => 
				NewAAL <= std_logic_vector(unsigned("0" & AAL) + 1);
			when "011" => 
				NewAAL <= std_logic_vector(unsigned("0" & AAL) + unsigned("0" & X));
			when "100" => 
				NewAAL <= std_logic_vector(unsigned("0" & AAL) + unsigned("0" & Y));
			when "101" => 
				NewAAL <= "0" & DR;
			when "110" => 
				NewAAL <= std_logic_vector(unsigned("0" & DR) + unsigned("0" & Y));
			when others =>
				NewAAL <= "0" & X;
		end case;
		
		case ADDR_CTRL(2 downto 0) is
			when "000"=> 
				NewAAH <= AAH;
			when "001"=> 
				NewAAH <= DI;
			when "010" => 
				NewAAH <= std_logic_vector(unsigned(AAH) + 1);
			when "011" => 
				NewAAH <= std_logic_vector(unsigned(AAH) + ("0000000"&SavedCarry));
			when others =>
				NewAAH <= AAH;
		end case;
	end process;

	
	process(CLK, RST_N)
	begin
		if RST_N = '0' then
			AAL <= (others=>'0');
			AAH <= (others=>'0');
			SavedCarry <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
AAH <= SS_SH_AAH;
AAL <= SS_SH_AAL;
SAVEDCARRY <= SS_SH_SAVEDCARRY;
elsif SS_FREEZE = '0' then

			if CE = '1' then
				AAL <= NewAAL(7 downto 0); 
				SavedCarry <= NewAAL(8); 
				AAH <= NewAAH(7 downto 0); 
			end if;
		
end if;
end if;
	end process;

	AA <= AAH & AAL; 
	PC <= PCr;
	

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 417 and to_integer(unsigned(SS_RADDR)) <= 419 else (others => '0');
SS_CAPTURE_DATA(7 downto 0) <= std_logic_vector(AAH(7 downto 0));
SS_CAPTURE_DATA(15 downto 8) <= std_logic_vector(AAL(7 downto 0));
SS_CAPTURE_DATA(31 downto 16) <= std_logic_vector(PCR(15 downto 0));
SS_CAPTURE_DATA(32) <= SAVEDCARRY;
SS_CAPTURE_DATA(47 downto 33) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
-- T captures ordinary fields; T+2 patches only the settled variable proxies.
-- Native state machines continue unchanged throughout this operation.
SS_LIVE_PENDING <= SS_LIVE_PENDING(0) & SS_LIVE_CUT;
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
-- synthesis translate_off
assert not (SS_LIVE_CUT = '1' and (SS_SAVE = '1' or SS_LOAD = '1' or SS_FREEZE = '1' or SS_CHAIN_CAPTURE /= "00" or SS_LIVE_PENDING /= "00"))
 report "live cut overlaps another snapshot operation" severity failure;
assert not ((SS_LIVE_CUT = '1' or SS_LIVE_PENDING /= "00") and (SS_RROTATE = '1' or SS_RWE = '1' or SS_LOAD = '1' or SS_SAVE = '1'))
 report "snapshot chain used before live proxy settling completes" severity failure;
-- synthesis translate_on
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA; -- unchanged legacy frozen-save behavior
elsif SS_LIVE_CUT = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_LIVE_PENDING(1) = '1' then
null; -- no delayed process-variable fields in this chain
elsif SS_LIVE_PENDING /= "00" then
null; -- hold the captured scalar fields during proxy settling
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 417 and to_integer(unsigned(SS_RADDR)) <= 419) then
SS_CHAIN <= SS_RDI & SS_CHAIN(47 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 417 and to_integer(unsigned(SS_RADDR)) <= 419) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(47 downto 16);
end if;
end if;
end process;
SS_SH_AAH(7 downto 0) <= SS_CHAIN(7 downto 0);
SS_SH_AAL(7 downto 0) <= SS_CHAIN(15 downto 8);
SS_SH_PCR(15 downto 0) <= SS_CHAIN(31 downto 16);
SS_SH_SAVEDCARRY <= SS_CHAIN(32);


SS_RDO <= SS_LOCAL_RDO;
end rtl;