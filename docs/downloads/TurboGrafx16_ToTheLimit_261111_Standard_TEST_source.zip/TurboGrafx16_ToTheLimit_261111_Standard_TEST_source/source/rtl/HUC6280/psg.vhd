library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;

entity psg is
	port (
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LIVE_CUT : in std_logic := '0'; -- private live capture; never a freeze
        SS_LOAD : in std_logic := '0';

		CLK 	: in std_logic;
		CLKEN	: in std_logic;
		RESET_N	: in std_logic;

		-- CPU Interface
		DI		: in std_logic_vector(7 downto 0);
		A 		: in std_logic_vector(3 downto 0);
		WE		: in std_logic;

		-- DAC Interface
		DAC_LATCH	: in std_logic;
		LDATA		: buffer std_logic_vector(23 downto 0);
		RDATA		: buffer std_logic_vector(23 downto 0)
	);
end psg;

architecture rtl of psg is

-- R0 - Channel Selection
signal CHSEL	: integer range 0 to 7;
-- R1 - Main Volume Adjustement
signal LMAL		: std_logic_vector(3 downto 0);
signal RMAL		: std_logic_vector(3 downto 0);

-- R2-R7 - Channel specific registers
type wavedata_t is array(0 to 31) of std_logic_vector(4 downto 0);
type chan_t is
	record
		-- Registers
		FREQ		: std_logic_vector(11 downto 0);
		DDA		: std_logic;
		CHON		: std_logic;
		AL			: std_logic_vector(4 downto 0);
		LAL		: std_logic_vector(3 downto 0);
		RAL		: std_logic_vector(3 downto 0);

		NG_FREQ	: std_logic_vector(4 downto 0);
		NE			: std_logic;

		-- Waveform generator
		WF_DATA	: wavedata_t;
		WF_ADDR	: std_logic_vector(4 downto 0);
		WF_CNT	: std_logic_vector(12 downto 0);

		WF_RES	: std_logic;
		WF_INC	: std_logic;

		-- Noise generator
		LFSR		: std_logic_vector(17 downto 0);
		NG_CNT	: std_logic_vector(11 downto 0);

		-- Outputs
		DA_OUT	: std_logic_vector(4 downto 0);
		WF_OUT	: std_logic_vector(4 downto 0);
		NG_OUT	: std_logic_vector(4 downto 0);
		-- Global output
		GL_OUT	: std_logic_vector(4 downto 0);

		-- LFO
		LFO_FREQ	: std_logic_vector(7 downto 0);
		LFCTL		: std_logic_vector(1 downto 0);
		LFTRG		: std_logic;
		LFO_CNT	: std_logic_vector(7 downto 0);
		LFO_ADD 	: std_logic_vector(11 downto 0);
	end record;
type chanarray_t is array(0 to 5) of chan_t;
signal CH		: chanarray_t;

-- Channels mixing
signal LACC		: std_logic_vector(23 downto 0);
signal RACC		: std_logic_vector(23 downto 0);

signal VT_ADDR	: std_logic_vector(11 downto 0);
signal VT_DATA	: std_logic_vector(23 downto 0);

type mix_t is ( MIX_WAIT, MIX_NEXT, MIX_LREAD, MIX_LNEXT, MIX_RREAD, MIX_RNEXT, MIX_END );
signal MIX		: mix_t;
signal MIX_CNT	: std_logic_vector(2 downto 0);

signal LDATA_FF	: std_logic_vector(23 downto 0);
signal RDATA_FF	: std_logic_vector(23 downto 0);

-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_CH : chanarray_t;
signal SS_SH_CHSEL : integer range 0 to 7;
signal SS_SH_LACC : std_logic_vector(23 downto 0);
signal SS_SH_LDATA_FF : std_logic_vector(23 downto 0);
signal SS_SH_LMAL : std_logic_vector(3 downto 0);
signal SS_SH_MIX : mix_t;
signal SS_SH_MIX_CNT : std_logic_vector(2 downto 0);
signal SS_SH_RACC : std_logic_vector(23 downto 0);
signal SS_SH_RDATA_FF : std_logic_vector(23 downto 0);
signal SS_SH_RMAL : std_logic_vector(3 downto 0);
signal SS_SH_VT_ADDR : std_logic_vector(11 downto 0);
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_R_VT : std_logic_vector(15 downto 0);
signal SS_CHAIN : std_logic_vector(1919 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(1919 downto 0);
signal SS_LIVE_PENDING : std_logic_vector(1 downto 0) := "00";
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);
signal SS_PROXY_0 : std_logic_vector(4 downto 0);

begin



-- CPU Interface
process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
for ss_i in 0 to 5 loop
CH(ss_i).AL <= SS_SH_CH(ss_i).AL;
CH(ss_i).CHON <= SS_SH_CH(ss_i).CHON;
CH(ss_i).DA_OUT <= SS_SH_CH(ss_i).DA_OUT;
CH(ss_i).DDA <= SS_SH_CH(ss_i).DDA;
CH(ss_i).FREQ <= SS_SH_CH(ss_i).FREQ;
CH(ss_i).LAL <= SS_SH_CH(ss_i).LAL;
CH(ss_i).LFCTL <= SS_SH_CH(ss_i).LFCTL;
CH(ss_i).LFO_FREQ <= SS_SH_CH(ss_i).LFO_FREQ;
CH(ss_i).LFTRG <= SS_SH_CH(ss_i).LFTRG;
CH(ss_i).NE <= SS_SH_CH(ss_i).NE;
CH(ss_i).NG_FREQ <= SS_SH_CH(ss_i).NG_FREQ;
CH(ss_i).RAL <= SS_SH_CH(ss_i).RAL;
CH(ss_i).WF_DATA <= SS_SH_CH(ss_i).WF_DATA;
CH(ss_i).WF_INC <= SS_SH_CH(ss_i).WF_INC;
CH(ss_i).WF_RES <= SS_SH_CH(ss_i).WF_RES;
end loop;
CHSEL <= SS_SH_CHSEL;
LMAL <= SS_SH_LMAL;
RMAL <= SS_SH_RMAL;
elsif SS_FREEZE = '0' then


		for i in 0 to 5 loop
			CH(i).WF_RES <= '0';
			CH(i).WF_INC <= '0';
		end loop;

		if RESET_N = '0' then

			CHSEL <= 0;
			LMAL <= (others => '0');
			RMAL <= (others => '0');

			for i in 0 to 5 loop
				CH(i).FREQ <= (others => '0');
				CH(i).DDA <= '0';
				CH(i).CHON <= '0';
				CH(i).LAL <= (others => '0');
				CH(i).RAL <= (others => '0');
				CH(i).NG_FREQ <= (others => '0');
				CH(i).NE <= '0';
				CH(i).DA_OUT <= (others => '0');
				CH(i).LFO_FREQ <= (others => '0');
				CH(i).LFCTL <= "00";
				CH(i).LFTRG <= '0';
			end loop;
		else
			if WE = '1' then
				case A is
				when "0000" =>
					CHSEL <= conv_integer(DI(2 downto 0));

				when "0001" =>
					LMAL <= DI(7 downto 4);
					RMAL <= DI(3 downto 0);

				when "0010" =>
					CH(CHSEL).FREQ(7 downto 0) <= DI;

				when "0011" =>
					CH(CHSEL).FREQ(11 downto 8) <= DI(3 downto 0);

				when "0100" =>
					CH(CHSEL).CHON <= DI(7);
					CH(CHSEL).DDA <= DI(6);
					CH(CHSEL).AL <= DI(4 downto 0);
					if CH(CHSEL).DDA = '1' and DI(6) = '0' then
						CH(CHSEL).WF_RES <= '1';
					end if;

				when "0101" =>
					CH(CHSEL).LAL <= DI(7 downto 4);
					CH(CHSEL).RAL <= DI(3 downto 0);

				when "0110" =>
					if CH(CHSEL).DDA = '0' then
						CH(CHSEL).WF_DATA(conv_integer(CH(CHSEL).WF_ADDR)) <= DI(4 downto 0);
					end if;
					if CH(CHSEL).CHON = '1' then
						CH(CHSEL).DA_OUT <= DI(4 downto 0);
					end if;
					if CH(CHSEL).DDA = '0' and CH(CHSEL).CHON = '0' then
						CH(CHSEL).WF_INC <= '1';
					end if;

				when "0111" =>
					if CHSEL = 4 or CHSEL =5 then
						CH(CHSEL).NE <= DI(7);
						CH(CHSEL).NG_FREQ <= DI(4 downto 0);
					end if;

				when "1000" =>
					CH(1).LFO_FREQ <= DI;

				when "1001" =>
					CH(1).LFCTL <= DI(1 downto 0);
					CH(1).LFTRG <= DI(7);

				when others => null;
				end case;
			end if;
		end if;
	
end if;
end if;
end process;


process( CLK ) begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
for ss_i in 0 to 5 loop
CH(ss_i).GL_OUT <= SS_SH_CH(ss_i).GL_OUT;
CH(ss_i).LFO_CNT <= SS_SH_CH(ss_i).LFO_CNT;
CH(ss_i).LFSR <= SS_SH_CH(ss_i).LFSR;
CH(ss_i).NG_CNT <= SS_SH_CH(ss_i).NG_CNT;
CH(ss_i).NG_OUT <= SS_SH_CH(ss_i).NG_OUT;
CH(ss_i).WF_ADDR <= SS_SH_CH(ss_i).WF_ADDR;
CH(ss_i).WF_CNT <= SS_SH_CH(ss_i).WF_CNT;
CH(ss_i).WF_OUT <= SS_SH_CH(ss_i).WF_OUT;
end loop;
elsif SS_FREEZE = '0' then

		for i in 0 to 5 loop
			if RESET_N = '0' then
				CH(i).GL_OUT <= (others => '0');
				CH(i).WF_CNT <= (others => '0');
				CH(i).LFSR <= (others => '0');
				CH(i).NG_CNT <= (others => '0');
				CH(i).LFO_CNT <= (others => '0');
			else
				if CH(i).WF_RES = '1' then
					CH(i).WF_ADDR <= (others => '0');
				end if;
				if CH(i).WF_INC = '1' then
					CH(i).WF_ADDR <= CH(i).WF_ADDR + 1;
				end if;

				if CH(i).LFCTL /= "00" then
					CH(i).WF_OUT <= CH(i).WF_DATA(conv_integer(CH(i).WF_ADDR));

					if CH(i).LFTRG = '1' then
						CH(i).WF_ADDR <= (others => '0');
						CH(i).WF_CNT <= (CH(i).FREQ - 1) & "1";
						CH(i).LFO_CNT <= CH(i).LFO_FREQ - 1;
					else
						if CLKEN = '1' then
							CH(i).LFO_CNT <= CH(i).LFO_CNT - 1;
							if CH(i).LFO_CNT = 0 then
								CH(i).LFO_CNT <= CH(i).LFO_FREQ - 1;
								CH(i).WF_CNT <= CH(i).WF_CNT - 1;
								if CH(i).WF_CNT = 0 then
									CH(i).WF_CNT <= (CH(i).FREQ - 1) & "1";
									CH(i).WF_ADDR <= CH(i).WF_ADDR + 1;
								end if;
							end if;
						end if;
					end if;
				elsif CH(i).CHON = '0' then
					CH(i).WF_CNT <= (CH(i).FREQ - 1 + CH(i).LFO_ADD) & "1";
				elsif CH(i).DDA = '0' then
					CH(i).WF_OUT <= CH(i).WF_DATA(conv_integer(CH(i).WF_ADDR));

					if CLKEN = '1' then
						CH(i).WF_CNT <= CH(i).WF_CNT - 1;
						if CH(i).WF_CNT = 0 then
							CH(i).WF_CNT <= (CH(i).FREQ - 1 + CH(i).LFO_ADD) & "1";
							CH(i).WF_ADDR <= CH(i).WF_ADDR + 1;
						end if;
					end if;
				end if;

				if CH(i).NE = '0' then
				if CH(i).NG_FREQ = "11111" then
						CH(i).NG_CNT <= "000000111111";
					else
						CH(i).NG_CNT <= ( not(CH(i).NG_FREQ) - 1) & "1111111";
					end if;
				else
					if CH(i).LFSR(0) = '0' then
						CH(i).NG_OUT <= "00000";
					else
						CH(i).NG_OUT <= "11111";
					end if;

					if CLKEN = '1' then
						CH(i).NG_CNT <= CH(i).NG_CNT - 1;
						if CH(i).NG_CNT = 0 then
							if CH(i).NG_FREQ = "11111" then
								CH(i).NG_CNT <= "000000111111";
							else
								CH(i).NG_CNT <= ( not(CH(i).NG_FREQ) - 1) & "1111111";
							end if;
							if CH(i).LFSR = 0 then
								CH(i).LFSR(0) <= '1';
							else
								CH(i).LFSR <= (CH(i).LFSR(0) xor CH(i).LFSR(1) xor CH(i).LFSR(11) xor CH(i).LFSR(12) xor CH(i).LFSR(17)) & CH(i).LFSR(17 downto 1);
							end if;
						end if;
					end if;
				end if;

				if CH(i).CHON = '0' then
					CH(i).GL_OUT <= "10000";		-- Not zero; this should be midpoint in the range to reduce 'pop' sound
				elsif CH(i).DDA = '1' then
					CH(i).GL_OUT <= CH(i).DA_OUT;
				elsif CH(i).NE = '1' then
					CH(i).GL_OUT <= CH(i).NG_OUT;
				else
					CH(i).GL_OUT <= CH(i).WF_OUT;
				end if;
			end if;
		end loop;
	
end if;
end if;
end process;

process( CLK )
	variable DATA: std_logic_vector(4 downto 0);
variable SS_SH_VAR_DATA : std_logic_vector(4 downto 0);
begin
if rising_edge(CLK) then


SS_PROXY_0 <= SS_SH_VAR_DATA;
end if;

if rising_edge(CLK) and (SS_SAVE = '1' or SS_LIVE_CUT = '1') then
SS_SH_VAR_DATA := DATA;
end if;

	if rising_edge( CLK ) then
if SS_LOAD = '1' then
DATA := std_logic_vector(SS_CHAIN(1908 downto 1904));
for ss_i in 0 to 5 loop
CH(ss_i).LFO_ADD <= SS_SH_CH(ss_i).LFO_ADD;
end loop;
elsif SS_FREEZE = '0' then

		if RESET_N = '0' then
			for i in 0 to 5 loop
				CH(i).LFO_ADD <= (others => '0');
			end loop;
		else
			DATA := CH(1).WF_DATA(conv_integer(CH(1).WF_ADDR)) xor "1000";
			CH(0).LFO_ADD(11 downto 8) <= DATA(4) & DATA(4) & DATA(4) & DATA(4);
			case CH(1).LFCTL is
			when "01" =>   CH(0).LFO_ADD(7 downto 0) <= DATA(4) & DATA(4) & DATA(4) & DATA;
			when "10" =>   CH(0).LFO_ADD(7 downto 0) <= DATA(4) & DATA & "00";
			when "11" =>   CH(0).LFO_ADD(7 downto 0) <= DATA(3 downto 0) & "0000";
			when others => CH(0).LFO_ADD <= (others => '0');
			end case;
		end if;
	
end if;
end if;
end process;

-- Channels mixing
VT : entity work.dpram generic map (12,24,"HUC6280/voltab.mif", SS_REG_BASE => 557)
port map (
SS_RROTATE => SS_RROTATE, SS_RADDR => SS_RADDR, SS_RDI => SS_RDI, SS_RWE => SS_RWE, SS_RDO => SS_R_VT,
SS_FREEZE => SS_FREEZE, SS_SAVE => SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT,

	clock		=> CLK,
	address_a=> VT_ADDR,
	q_a		=> VT_DATA
);

process( CLK )
begin
	if rising_edge( CLK ) then
if SS_LOAD = '1' then
LACC <= SS_SH_LACC;
LDATA_FF <= SS_SH_LDATA_FF;
MIX <= SS_SH_MIX;
MIX_CNT <= SS_SH_MIX_CNT;
RACC <= SS_SH_RACC;
RDATA_FF <= SS_SH_RDATA_FF;
VT_ADDR <= SS_SH_VT_ADDR;
elsif SS_FREEZE = '0' then

		if RESET_N = '0' then
			LDATA_FF <= (others => '0');
			RDATA_FF <= (others => '0');
			MIX <= MIX_WAIT;
		else
			case MIX is
			when MIX_WAIT =>
				LACC <= (others => '0');
				RACC <= (others => '0');
				MIX_CNT <= (others => '0');
				VT_ADDR <= (others => '1');
				if DAC_LATCH = '1' then
					MIX <= MIX_NEXT;
				end if;

			when MIX_NEXT =>
				VT_ADDR <= CH(conv_integer(MIX_CNT)).GL_OUT
					& ( "1011101" - CH(conv_integer(MIX_CNT)).AL - (CH(conv_integer(MIX_CNT)).LAL & "1") - (LMAL & "1") );
				MIX <= MIX_LREAD;

			when MIX_LREAD =>
				MIX <= MIX_LNEXT;

			when MIX_LNEXT =>
				LACC <= LACC + VT_DATA;
				VT_ADDR <= CH(conv_integer(MIX_CNT)).GL_OUT
					& ( "1011101" - CH(conv_integer(MIX_CNT)).AL - (CH(conv_integer(MIX_CNT)).RAL & "1") - (RMAL & "1") );
				MIX <= MIX_RREAD;

			when MIX_RREAD =>
				MIX <= MIX_RNEXT;

			when MIX_RNEXT =>
				RACC <= RACC + VT_DATA;
				if MIX_CNT = "101" then
					MIX <= MIX_END;
				else
					MIX_CNT <= MIX_CNT + 1;
					MIX <= MIX_NEXT;
				end if;

			when MIX_END =>
				LDATA_FF <= LACC;
				RDATA_FF <= RACC;
				MIX <= MIX_WAIT;

			when others => null;
			end case;
		end if;
	
end if;
end if;
end process;

LDATA <= LDATA_FF;
RDATA <= RDATA_FF;


SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 425 and to_integer(unsigned(SS_RADDR)) <= 544 else (others => '0');
SS_CAPTURE_DATA(11 downto 0) <= std_logic_vector(CH(0).FREQ(11 downto 0));
SS_CAPTURE_DATA(12) <= CH(0).DDA;
SS_CAPTURE_DATA(13) <= CH(0).CHON;
SS_CAPTURE_DATA(15 downto 14) <= std_logic_vector(CH(0).AL(1 downto 0));
SS_CAPTURE_DATA(18 downto 16) <= std_logic_vector(CH(0).AL(4 downto 2));
SS_CAPTURE_DATA(22 downto 19) <= std_logic_vector(CH(0).LAL(3 downto 0));
SS_CAPTURE_DATA(26 downto 23) <= std_logic_vector(CH(0).RAL(3 downto 0));
SS_CAPTURE_DATA(31 downto 27) <= std_logic_vector(CH(0).NG_FREQ(4 downto 0));
SS_CAPTURE_DATA(32) <= CH(0).NE;
SS_CAPTURE_DATA(37 downto 33) <= std_logic_vector(CH(0).WF_DATA(0)(4 downto 0));
SS_CAPTURE_DATA(42 downto 38) <= std_logic_vector(CH(0).WF_DATA(1)(4 downto 0));
SS_CAPTURE_DATA(47 downto 43) <= std_logic_vector(CH(0).WF_DATA(2)(4 downto 0));
SS_CAPTURE_DATA(52 downto 48) <= std_logic_vector(CH(0).WF_DATA(3)(4 downto 0));
SS_CAPTURE_DATA(57 downto 53) <= std_logic_vector(CH(0).WF_DATA(4)(4 downto 0));
SS_CAPTURE_DATA(62 downto 58) <= std_logic_vector(CH(0).WF_DATA(5)(4 downto 0));
SS_CAPTURE_DATA(63 downto 63) <= std_logic_vector(CH(0).WF_DATA(6)(0 downto 0));
SS_CAPTURE_DATA(67 downto 64) <= std_logic_vector(CH(0).WF_DATA(6)(4 downto 1));
SS_CAPTURE_DATA(72 downto 68) <= std_logic_vector(CH(0).WF_DATA(7)(4 downto 0));
SS_CAPTURE_DATA(77 downto 73) <= std_logic_vector(CH(0).WF_DATA(8)(4 downto 0));
SS_CAPTURE_DATA(79 downto 78) <= std_logic_vector(CH(0).WF_DATA(9)(1 downto 0));
SS_CAPTURE_DATA(82 downto 80) <= std_logic_vector(CH(0).WF_DATA(9)(4 downto 2));
SS_CAPTURE_DATA(87 downto 83) <= std_logic_vector(CH(0).WF_DATA(10)(4 downto 0));
SS_CAPTURE_DATA(92 downto 88) <= std_logic_vector(CH(0).WF_DATA(11)(4 downto 0));
SS_CAPTURE_DATA(95 downto 93) <= std_logic_vector(CH(0).WF_DATA(12)(2 downto 0));
SS_CAPTURE_DATA(97 downto 96) <= std_logic_vector(CH(0).WF_DATA(12)(4 downto 3));
SS_CAPTURE_DATA(102 downto 98) <= std_logic_vector(CH(0).WF_DATA(13)(4 downto 0));
SS_CAPTURE_DATA(107 downto 103) <= std_logic_vector(CH(0).WF_DATA(14)(4 downto 0));
SS_CAPTURE_DATA(111 downto 108) <= std_logic_vector(CH(0).WF_DATA(15)(3 downto 0));
SS_CAPTURE_DATA(112 downto 112) <= std_logic_vector(CH(0).WF_DATA(15)(4 downto 4));
SS_CAPTURE_DATA(117 downto 113) <= std_logic_vector(CH(0).WF_DATA(16)(4 downto 0));
SS_CAPTURE_DATA(122 downto 118) <= std_logic_vector(CH(0).WF_DATA(17)(4 downto 0));
SS_CAPTURE_DATA(127 downto 123) <= std_logic_vector(CH(0).WF_DATA(18)(4 downto 0));
SS_CAPTURE_DATA(132 downto 128) <= std_logic_vector(CH(0).WF_DATA(19)(4 downto 0));
SS_CAPTURE_DATA(137 downto 133) <= std_logic_vector(CH(0).WF_DATA(20)(4 downto 0));
SS_CAPTURE_DATA(142 downto 138) <= std_logic_vector(CH(0).WF_DATA(21)(4 downto 0));
SS_CAPTURE_DATA(143 downto 143) <= std_logic_vector(CH(0).WF_DATA(22)(0 downto 0));
SS_CAPTURE_DATA(147 downto 144) <= std_logic_vector(CH(0).WF_DATA(22)(4 downto 1));
SS_CAPTURE_DATA(152 downto 148) <= std_logic_vector(CH(0).WF_DATA(23)(4 downto 0));
SS_CAPTURE_DATA(157 downto 153) <= std_logic_vector(CH(0).WF_DATA(24)(4 downto 0));
SS_CAPTURE_DATA(159 downto 158) <= std_logic_vector(CH(0).WF_DATA(25)(1 downto 0));
SS_CAPTURE_DATA(162 downto 160) <= std_logic_vector(CH(0).WF_DATA(25)(4 downto 2));
SS_CAPTURE_DATA(167 downto 163) <= std_logic_vector(CH(0).WF_DATA(26)(4 downto 0));
SS_CAPTURE_DATA(172 downto 168) <= std_logic_vector(CH(0).WF_DATA(27)(4 downto 0));
SS_CAPTURE_DATA(175 downto 173) <= std_logic_vector(CH(0).WF_DATA(28)(2 downto 0));
SS_CAPTURE_DATA(177 downto 176) <= std_logic_vector(CH(0).WF_DATA(28)(4 downto 3));
SS_CAPTURE_DATA(182 downto 178) <= std_logic_vector(CH(0).WF_DATA(29)(4 downto 0));
SS_CAPTURE_DATA(187 downto 183) <= std_logic_vector(CH(0).WF_DATA(30)(4 downto 0));
SS_CAPTURE_DATA(191 downto 188) <= std_logic_vector(CH(0).WF_DATA(31)(3 downto 0));
SS_CAPTURE_DATA(192 downto 192) <= std_logic_vector(CH(0).WF_DATA(31)(4 downto 4));
SS_CAPTURE_DATA(197 downto 193) <= std_logic_vector(CH(0).WF_ADDR(4 downto 0));
SS_CAPTURE_DATA(207 downto 198) <= std_logic_vector(CH(0).WF_CNT(9 downto 0));
SS_CAPTURE_DATA(210 downto 208) <= std_logic_vector(CH(0).WF_CNT(12 downto 10));
SS_CAPTURE_DATA(211) <= CH(0).WF_RES;
SS_CAPTURE_DATA(212) <= CH(0).WF_INC;
SS_CAPTURE_DATA(223 downto 213) <= std_logic_vector(CH(0).LFSR(10 downto 0));
SS_CAPTURE_DATA(230 downto 224) <= std_logic_vector(CH(0).LFSR(17 downto 11));
SS_CAPTURE_DATA(239 downto 231) <= std_logic_vector(CH(0).NG_CNT(8 downto 0));
SS_CAPTURE_DATA(242 downto 240) <= std_logic_vector(CH(0).NG_CNT(11 downto 9));
SS_CAPTURE_DATA(247 downto 243) <= std_logic_vector(CH(0).DA_OUT(4 downto 0));
SS_CAPTURE_DATA(252 downto 248) <= std_logic_vector(CH(0).WF_OUT(4 downto 0));
SS_CAPTURE_DATA(255 downto 253) <= std_logic_vector(CH(0).NG_OUT(2 downto 0));
SS_CAPTURE_DATA(257 downto 256) <= std_logic_vector(CH(0).NG_OUT(4 downto 3));
SS_CAPTURE_DATA(262 downto 258) <= std_logic_vector(CH(0).GL_OUT(4 downto 0));
SS_CAPTURE_DATA(270 downto 263) <= std_logic_vector(CH(0).LFO_FREQ(7 downto 0));
SS_CAPTURE_DATA(271 downto 271) <= std_logic_vector(CH(0).LFCTL(0 downto 0));
SS_CAPTURE_DATA(272 downto 272) <= std_logic_vector(CH(0).LFCTL(1 downto 1));
SS_CAPTURE_DATA(273) <= CH(0).LFTRG;
SS_CAPTURE_DATA(281 downto 274) <= std_logic_vector(CH(0).LFO_CNT(7 downto 0));
SS_CAPTURE_DATA(287 downto 282) <= std_logic_vector(CH(0).LFO_ADD(5 downto 0));
SS_CAPTURE_DATA(293 downto 288) <= std_logic_vector(CH(0).LFO_ADD(11 downto 6));
SS_CAPTURE_DATA(303 downto 294) <= std_logic_vector(CH(1).FREQ(9 downto 0));
SS_CAPTURE_DATA(305 downto 304) <= std_logic_vector(CH(1).FREQ(11 downto 10));
SS_CAPTURE_DATA(306) <= CH(1).DDA;
SS_CAPTURE_DATA(307) <= CH(1).CHON;
SS_CAPTURE_DATA(312 downto 308) <= std_logic_vector(CH(1).AL(4 downto 0));
SS_CAPTURE_DATA(316 downto 313) <= std_logic_vector(CH(1).LAL(3 downto 0));
SS_CAPTURE_DATA(319 downto 317) <= std_logic_vector(CH(1).RAL(2 downto 0));
SS_CAPTURE_DATA(320 downto 320) <= std_logic_vector(CH(1).RAL(3 downto 3));
SS_CAPTURE_DATA(325 downto 321) <= std_logic_vector(CH(1).NG_FREQ(4 downto 0));
SS_CAPTURE_DATA(326) <= CH(1).NE;
SS_CAPTURE_DATA(331 downto 327) <= std_logic_vector(CH(1).WF_DATA(0)(4 downto 0));
SS_CAPTURE_DATA(335 downto 332) <= std_logic_vector(CH(1).WF_DATA(1)(3 downto 0));
SS_CAPTURE_DATA(336 downto 336) <= std_logic_vector(CH(1).WF_DATA(1)(4 downto 4));
SS_CAPTURE_DATA(341 downto 337) <= std_logic_vector(CH(1).WF_DATA(2)(4 downto 0));
SS_CAPTURE_DATA(346 downto 342) <= std_logic_vector(CH(1).WF_DATA(3)(4 downto 0));
SS_CAPTURE_DATA(351 downto 347) <= std_logic_vector(CH(1).WF_DATA(4)(4 downto 0));
SS_CAPTURE_DATA(356 downto 352) <= std_logic_vector(CH(1).WF_DATA(5)(4 downto 0));
SS_CAPTURE_DATA(361 downto 357) <= std_logic_vector(CH(1).WF_DATA(6)(4 downto 0));
SS_CAPTURE_DATA(366 downto 362) <= std_logic_vector(CH(1).WF_DATA(7)(4 downto 0));
SS_CAPTURE_DATA(367 downto 367) <= std_logic_vector(CH(1).WF_DATA(8)(0 downto 0));
SS_CAPTURE_DATA(371 downto 368) <= std_logic_vector(CH(1).WF_DATA(8)(4 downto 1));
SS_CAPTURE_DATA(376 downto 372) <= std_logic_vector(CH(1).WF_DATA(9)(4 downto 0));
SS_CAPTURE_DATA(381 downto 377) <= std_logic_vector(CH(1).WF_DATA(10)(4 downto 0));
SS_CAPTURE_DATA(383 downto 382) <= std_logic_vector(CH(1).WF_DATA(11)(1 downto 0));
SS_CAPTURE_DATA(386 downto 384) <= std_logic_vector(CH(1).WF_DATA(11)(4 downto 2));
SS_CAPTURE_DATA(391 downto 387) <= std_logic_vector(CH(1).WF_DATA(12)(4 downto 0));
SS_CAPTURE_DATA(396 downto 392) <= std_logic_vector(CH(1).WF_DATA(13)(4 downto 0));
SS_CAPTURE_DATA(399 downto 397) <= std_logic_vector(CH(1).WF_DATA(14)(2 downto 0));
SS_CAPTURE_DATA(401 downto 400) <= std_logic_vector(CH(1).WF_DATA(14)(4 downto 3));
SS_CAPTURE_DATA(406 downto 402) <= std_logic_vector(CH(1).WF_DATA(15)(4 downto 0));
SS_CAPTURE_DATA(411 downto 407) <= std_logic_vector(CH(1).WF_DATA(16)(4 downto 0));
SS_CAPTURE_DATA(415 downto 412) <= std_logic_vector(CH(1).WF_DATA(17)(3 downto 0));
SS_CAPTURE_DATA(416 downto 416) <= std_logic_vector(CH(1).WF_DATA(17)(4 downto 4));
SS_CAPTURE_DATA(421 downto 417) <= std_logic_vector(CH(1).WF_DATA(18)(4 downto 0));
SS_CAPTURE_DATA(426 downto 422) <= std_logic_vector(CH(1).WF_DATA(19)(4 downto 0));
SS_CAPTURE_DATA(431 downto 427) <= std_logic_vector(CH(1).WF_DATA(20)(4 downto 0));
SS_CAPTURE_DATA(436 downto 432) <= std_logic_vector(CH(1).WF_DATA(21)(4 downto 0));
SS_CAPTURE_DATA(441 downto 437) <= std_logic_vector(CH(1).WF_DATA(22)(4 downto 0));
SS_CAPTURE_DATA(446 downto 442) <= std_logic_vector(CH(1).WF_DATA(23)(4 downto 0));
SS_CAPTURE_DATA(447 downto 447) <= std_logic_vector(CH(1).WF_DATA(24)(0 downto 0));
SS_CAPTURE_DATA(451 downto 448) <= std_logic_vector(CH(1).WF_DATA(24)(4 downto 1));
SS_CAPTURE_DATA(456 downto 452) <= std_logic_vector(CH(1).WF_DATA(25)(4 downto 0));
SS_CAPTURE_DATA(461 downto 457) <= std_logic_vector(CH(1).WF_DATA(26)(4 downto 0));
SS_CAPTURE_DATA(463 downto 462) <= std_logic_vector(CH(1).WF_DATA(27)(1 downto 0));
SS_CAPTURE_DATA(466 downto 464) <= std_logic_vector(CH(1).WF_DATA(27)(4 downto 2));
SS_CAPTURE_DATA(471 downto 467) <= std_logic_vector(CH(1).WF_DATA(28)(4 downto 0));
SS_CAPTURE_DATA(476 downto 472) <= std_logic_vector(CH(1).WF_DATA(29)(4 downto 0));
SS_CAPTURE_DATA(479 downto 477) <= std_logic_vector(CH(1).WF_DATA(30)(2 downto 0));
SS_CAPTURE_DATA(481 downto 480) <= std_logic_vector(CH(1).WF_DATA(30)(4 downto 3));
SS_CAPTURE_DATA(486 downto 482) <= std_logic_vector(CH(1).WF_DATA(31)(4 downto 0));
SS_CAPTURE_DATA(491 downto 487) <= std_logic_vector(CH(1).WF_ADDR(4 downto 0));
SS_CAPTURE_DATA(495 downto 492) <= std_logic_vector(CH(1).WF_CNT(3 downto 0));
SS_CAPTURE_DATA(504 downto 496) <= std_logic_vector(CH(1).WF_CNT(12 downto 4));
SS_CAPTURE_DATA(505) <= CH(1).WF_RES;
SS_CAPTURE_DATA(506) <= CH(1).WF_INC;
SS_CAPTURE_DATA(511 downto 507) <= std_logic_vector(CH(1).LFSR(4 downto 0));
SS_CAPTURE_DATA(524 downto 512) <= std_logic_vector(CH(1).LFSR(17 downto 5));
SS_CAPTURE_DATA(527 downto 525) <= std_logic_vector(CH(1).NG_CNT(2 downto 0));
SS_CAPTURE_DATA(536 downto 528) <= std_logic_vector(CH(1).NG_CNT(11 downto 3));
SS_CAPTURE_DATA(541 downto 537) <= std_logic_vector(CH(1).DA_OUT(4 downto 0));
SS_CAPTURE_DATA(543 downto 542) <= std_logic_vector(CH(1).WF_OUT(1 downto 0));
SS_CAPTURE_DATA(546 downto 544) <= std_logic_vector(CH(1).WF_OUT(4 downto 2));
SS_CAPTURE_DATA(551 downto 547) <= std_logic_vector(CH(1).NG_OUT(4 downto 0));
SS_CAPTURE_DATA(556 downto 552) <= std_logic_vector(CH(1).GL_OUT(4 downto 0));
SS_CAPTURE_DATA(559 downto 557) <= std_logic_vector(CH(1).LFO_FREQ(2 downto 0));
SS_CAPTURE_DATA(564 downto 560) <= std_logic_vector(CH(1).LFO_FREQ(7 downto 3));
SS_CAPTURE_DATA(566 downto 565) <= std_logic_vector(CH(1).LFCTL(1 downto 0));
SS_CAPTURE_DATA(567) <= CH(1).LFTRG;
SS_CAPTURE_DATA(575 downto 568) <= std_logic_vector(CH(1).LFO_CNT(7 downto 0));
SS_CAPTURE_DATA(587 downto 576) <= std_logic_vector(CH(1).LFO_ADD(11 downto 0));
SS_CAPTURE_DATA(591 downto 588) <= std_logic_vector(CH(2).FREQ(3 downto 0));
SS_CAPTURE_DATA(599 downto 592) <= std_logic_vector(CH(2).FREQ(11 downto 4));
SS_CAPTURE_DATA(600) <= CH(2).DDA;
SS_CAPTURE_DATA(601) <= CH(2).CHON;
SS_CAPTURE_DATA(606 downto 602) <= std_logic_vector(CH(2).AL(4 downto 0));
SS_CAPTURE_DATA(607 downto 607) <= std_logic_vector(CH(2).LAL(0 downto 0));
SS_CAPTURE_DATA(610 downto 608) <= std_logic_vector(CH(2).LAL(3 downto 1));
SS_CAPTURE_DATA(614 downto 611) <= std_logic_vector(CH(2).RAL(3 downto 0));
SS_CAPTURE_DATA(619 downto 615) <= std_logic_vector(CH(2).NG_FREQ(4 downto 0));
SS_CAPTURE_DATA(620) <= CH(2).NE;
SS_CAPTURE_DATA(623 downto 621) <= std_logic_vector(CH(2).WF_DATA(0)(2 downto 0));
SS_CAPTURE_DATA(625 downto 624) <= std_logic_vector(CH(2).WF_DATA(0)(4 downto 3));
SS_CAPTURE_DATA(630 downto 626) <= std_logic_vector(CH(2).WF_DATA(1)(4 downto 0));
SS_CAPTURE_DATA(635 downto 631) <= std_logic_vector(CH(2).WF_DATA(2)(4 downto 0));
SS_CAPTURE_DATA(639 downto 636) <= std_logic_vector(CH(2).WF_DATA(3)(3 downto 0));
SS_CAPTURE_DATA(640 downto 640) <= std_logic_vector(CH(2).WF_DATA(3)(4 downto 4));
SS_CAPTURE_DATA(645 downto 641) <= std_logic_vector(CH(2).WF_DATA(4)(4 downto 0));
SS_CAPTURE_DATA(650 downto 646) <= std_logic_vector(CH(2).WF_DATA(5)(4 downto 0));
SS_CAPTURE_DATA(655 downto 651) <= std_logic_vector(CH(2).WF_DATA(6)(4 downto 0));
SS_CAPTURE_DATA(660 downto 656) <= std_logic_vector(CH(2).WF_DATA(7)(4 downto 0));
SS_CAPTURE_DATA(665 downto 661) <= std_logic_vector(CH(2).WF_DATA(8)(4 downto 0));
SS_CAPTURE_DATA(670 downto 666) <= std_logic_vector(CH(2).WF_DATA(9)(4 downto 0));
SS_CAPTURE_DATA(671 downto 671) <= std_logic_vector(CH(2).WF_DATA(10)(0 downto 0));
SS_CAPTURE_DATA(675 downto 672) <= std_logic_vector(CH(2).WF_DATA(10)(4 downto 1));
SS_CAPTURE_DATA(680 downto 676) <= std_logic_vector(CH(2).WF_DATA(11)(4 downto 0));
SS_CAPTURE_DATA(685 downto 681) <= std_logic_vector(CH(2).WF_DATA(12)(4 downto 0));
SS_CAPTURE_DATA(687 downto 686) <= std_logic_vector(CH(2).WF_DATA(13)(1 downto 0));
SS_CAPTURE_DATA(690 downto 688) <= std_logic_vector(CH(2).WF_DATA(13)(4 downto 2));
SS_CAPTURE_DATA(695 downto 691) <= std_logic_vector(CH(2).WF_DATA(14)(4 downto 0));
SS_CAPTURE_DATA(700 downto 696) <= std_logic_vector(CH(2).WF_DATA(15)(4 downto 0));
SS_CAPTURE_DATA(703 downto 701) <= std_logic_vector(CH(2).WF_DATA(16)(2 downto 0));
SS_CAPTURE_DATA(705 downto 704) <= std_logic_vector(CH(2).WF_DATA(16)(4 downto 3));
SS_CAPTURE_DATA(710 downto 706) <= std_logic_vector(CH(2).WF_DATA(17)(4 downto 0));
SS_CAPTURE_DATA(715 downto 711) <= std_logic_vector(CH(2).WF_DATA(18)(4 downto 0));
SS_CAPTURE_DATA(719 downto 716) <= std_logic_vector(CH(2).WF_DATA(19)(3 downto 0));
SS_CAPTURE_DATA(720 downto 720) <= std_logic_vector(CH(2).WF_DATA(19)(4 downto 4));
SS_CAPTURE_DATA(725 downto 721) <= std_logic_vector(CH(2).WF_DATA(20)(4 downto 0));
SS_CAPTURE_DATA(730 downto 726) <= std_logic_vector(CH(2).WF_DATA(21)(4 downto 0));
SS_CAPTURE_DATA(735 downto 731) <= std_logic_vector(CH(2).WF_DATA(22)(4 downto 0));
SS_CAPTURE_DATA(740 downto 736) <= std_logic_vector(CH(2).WF_DATA(23)(4 downto 0));
SS_CAPTURE_DATA(745 downto 741) <= std_logic_vector(CH(2).WF_DATA(24)(4 downto 0));
SS_CAPTURE_DATA(750 downto 746) <= std_logic_vector(CH(2).WF_DATA(25)(4 downto 0));
SS_CAPTURE_DATA(751 downto 751) <= std_logic_vector(CH(2).WF_DATA(26)(0 downto 0));
SS_CAPTURE_DATA(755 downto 752) <= std_logic_vector(CH(2).WF_DATA(26)(4 downto 1));
SS_CAPTURE_DATA(760 downto 756) <= std_logic_vector(CH(2).WF_DATA(27)(4 downto 0));
SS_CAPTURE_DATA(765 downto 761) <= std_logic_vector(CH(2).WF_DATA(28)(4 downto 0));
SS_CAPTURE_DATA(767 downto 766) <= std_logic_vector(CH(2).WF_DATA(29)(1 downto 0));
SS_CAPTURE_DATA(770 downto 768) <= std_logic_vector(CH(2).WF_DATA(29)(4 downto 2));
SS_CAPTURE_DATA(775 downto 771) <= std_logic_vector(CH(2).WF_DATA(30)(4 downto 0));
SS_CAPTURE_DATA(780 downto 776) <= std_logic_vector(CH(2).WF_DATA(31)(4 downto 0));
SS_CAPTURE_DATA(783 downto 781) <= std_logic_vector(CH(2).WF_ADDR(2 downto 0));
SS_CAPTURE_DATA(785 downto 784) <= std_logic_vector(CH(2).WF_ADDR(4 downto 3));
SS_CAPTURE_DATA(798 downto 786) <= std_logic_vector(CH(2).WF_CNT(12 downto 0));
SS_CAPTURE_DATA(799) <= CH(2).WF_RES;
SS_CAPTURE_DATA(800) <= CH(2).WF_INC;
SS_CAPTURE_DATA(815 downto 801) <= std_logic_vector(CH(2).LFSR(14 downto 0));
SS_CAPTURE_DATA(818 downto 816) <= std_logic_vector(CH(2).LFSR(17 downto 15));
SS_CAPTURE_DATA(830 downto 819) <= std_logic_vector(CH(2).NG_CNT(11 downto 0));
SS_CAPTURE_DATA(831 downto 831) <= std_logic_vector(CH(2).DA_OUT(0 downto 0));
SS_CAPTURE_DATA(835 downto 832) <= std_logic_vector(CH(2).DA_OUT(4 downto 1));
SS_CAPTURE_DATA(840 downto 836) <= std_logic_vector(CH(2).WF_OUT(4 downto 0));
SS_CAPTURE_DATA(845 downto 841) <= std_logic_vector(CH(2).NG_OUT(4 downto 0));
SS_CAPTURE_DATA(847 downto 846) <= std_logic_vector(CH(2).GL_OUT(1 downto 0));
SS_CAPTURE_DATA(850 downto 848) <= std_logic_vector(CH(2).GL_OUT(4 downto 2));
SS_CAPTURE_DATA(858 downto 851) <= std_logic_vector(CH(2).LFO_FREQ(7 downto 0));
SS_CAPTURE_DATA(860 downto 859) <= std_logic_vector(CH(2).LFCTL(1 downto 0));
SS_CAPTURE_DATA(861) <= CH(2).LFTRG;
SS_CAPTURE_DATA(863 downto 862) <= std_logic_vector(CH(2).LFO_CNT(1 downto 0));
SS_CAPTURE_DATA(869 downto 864) <= std_logic_vector(CH(2).LFO_CNT(7 downto 2));
SS_CAPTURE_DATA(879 downto 870) <= std_logic_vector(CH(2).LFO_ADD(9 downto 0));
SS_CAPTURE_DATA(881 downto 880) <= std_logic_vector(CH(2).LFO_ADD(11 downto 10));
SS_CAPTURE_DATA(893 downto 882) <= std_logic_vector(CH(3).FREQ(11 downto 0));
SS_CAPTURE_DATA(894) <= CH(3).DDA;
SS_CAPTURE_DATA(895) <= CH(3).CHON;
SS_CAPTURE_DATA(900 downto 896) <= std_logic_vector(CH(3).AL(4 downto 0));
SS_CAPTURE_DATA(904 downto 901) <= std_logic_vector(CH(3).LAL(3 downto 0));
SS_CAPTURE_DATA(908 downto 905) <= std_logic_vector(CH(3).RAL(3 downto 0));
SS_CAPTURE_DATA(911 downto 909) <= std_logic_vector(CH(3).NG_FREQ(2 downto 0));
SS_CAPTURE_DATA(913 downto 912) <= std_logic_vector(CH(3).NG_FREQ(4 downto 3));
SS_CAPTURE_DATA(914) <= CH(3).NE;
SS_CAPTURE_DATA(919 downto 915) <= std_logic_vector(CH(3).WF_DATA(0)(4 downto 0));
SS_CAPTURE_DATA(924 downto 920) <= std_logic_vector(CH(3).WF_DATA(1)(4 downto 0));
SS_CAPTURE_DATA(927 downto 925) <= std_logic_vector(CH(3).WF_DATA(2)(2 downto 0));
SS_CAPTURE_DATA(929 downto 928) <= std_logic_vector(CH(3).WF_DATA(2)(4 downto 3));
SS_CAPTURE_DATA(934 downto 930) <= std_logic_vector(CH(3).WF_DATA(3)(4 downto 0));
SS_CAPTURE_DATA(939 downto 935) <= std_logic_vector(CH(3).WF_DATA(4)(4 downto 0));
SS_CAPTURE_DATA(943 downto 940) <= std_logic_vector(CH(3).WF_DATA(5)(3 downto 0));
SS_CAPTURE_DATA(944 downto 944) <= std_logic_vector(CH(3).WF_DATA(5)(4 downto 4));
SS_CAPTURE_DATA(949 downto 945) <= std_logic_vector(CH(3).WF_DATA(6)(4 downto 0));
SS_CAPTURE_DATA(954 downto 950) <= std_logic_vector(CH(3).WF_DATA(7)(4 downto 0));
SS_CAPTURE_DATA(959 downto 955) <= std_logic_vector(CH(3).WF_DATA(8)(4 downto 0));
SS_CAPTURE_DATA(964 downto 960) <= std_logic_vector(CH(3).WF_DATA(9)(4 downto 0));
SS_CAPTURE_DATA(969 downto 965) <= std_logic_vector(CH(3).WF_DATA(10)(4 downto 0));
SS_CAPTURE_DATA(974 downto 970) <= std_logic_vector(CH(3).WF_DATA(11)(4 downto 0));
SS_CAPTURE_DATA(975 downto 975) <= std_logic_vector(CH(3).WF_DATA(12)(0 downto 0));
SS_CAPTURE_DATA(979 downto 976) <= std_logic_vector(CH(3).WF_DATA(12)(4 downto 1));
SS_CAPTURE_DATA(984 downto 980) <= std_logic_vector(CH(3).WF_DATA(13)(4 downto 0));
SS_CAPTURE_DATA(989 downto 985) <= std_logic_vector(CH(3).WF_DATA(14)(4 downto 0));
SS_CAPTURE_DATA(991 downto 990) <= std_logic_vector(CH(3).WF_DATA(15)(1 downto 0));
SS_CAPTURE_DATA(994 downto 992) <= std_logic_vector(CH(3).WF_DATA(15)(4 downto 2));
SS_CAPTURE_DATA(999 downto 995) <= std_logic_vector(CH(3).WF_DATA(16)(4 downto 0));
SS_CAPTURE_DATA(1004 downto 1000) <= std_logic_vector(CH(3).WF_DATA(17)(4 downto 0));
SS_CAPTURE_DATA(1007 downto 1005) <= std_logic_vector(CH(3).WF_DATA(18)(2 downto 0));
SS_CAPTURE_DATA(1009 downto 1008) <= std_logic_vector(CH(3).WF_DATA(18)(4 downto 3));
SS_CAPTURE_DATA(1014 downto 1010) <= std_logic_vector(CH(3).WF_DATA(19)(4 downto 0));
SS_CAPTURE_DATA(1019 downto 1015) <= std_logic_vector(CH(3).WF_DATA(20)(4 downto 0));
SS_CAPTURE_DATA(1023 downto 1020) <= std_logic_vector(CH(3).WF_DATA(21)(3 downto 0));
SS_CAPTURE_DATA(1024 downto 1024) <= std_logic_vector(CH(3).WF_DATA(21)(4 downto 4));
SS_CAPTURE_DATA(1029 downto 1025) <= std_logic_vector(CH(3).WF_DATA(22)(4 downto 0));
SS_CAPTURE_DATA(1034 downto 1030) <= std_logic_vector(CH(3).WF_DATA(23)(4 downto 0));
SS_CAPTURE_DATA(1039 downto 1035) <= std_logic_vector(CH(3).WF_DATA(24)(4 downto 0));
SS_CAPTURE_DATA(1044 downto 1040) <= std_logic_vector(CH(3).WF_DATA(25)(4 downto 0));
SS_CAPTURE_DATA(1049 downto 1045) <= std_logic_vector(CH(3).WF_DATA(26)(4 downto 0));
SS_CAPTURE_DATA(1054 downto 1050) <= std_logic_vector(CH(3).WF_DATA(27)(4 downto 0));
SS_CAPTURE_DATA(1055 downto 1055) <= std_logic_vector(CH(3).WF_DATA(28)(0 downto 0));
SS_CAPTURE_DATA(1059 downto 1056) <= std_logic_vector(CH(3).WF_DATA(28)(4 downto 1));
SS_CAPTURE_DATA(1064 downto 1060) <= std_logic_vector(CH(3).WF_DATA(29)(4 downto 0));
SS_CAPTURE_DATA(1069 downto 1065) <= std_logic_vector(CH(3).WF_DATA(30)(4 downto 0));
SS_CAPTURE_DATA(1071 downto 1070) <= std_logic_vector(CH(3).WF_DATA(31)(1 downto 0));
SS_CAPTURE_DATA(1074 downto 1072) <= std_logic_vector(CH(3).WF_DATA(31)(4 downto 2));
SS_CAPTURE_DATA(1079 downto 1075) <= std_logic_vector(CH(3).WF_ADDR(4 downto 0));
SS_CAPTURE_DATA(1087 downto 1080) <= std_logic_vector(CH(3).WF_CNT(7 downto 0));
SS_CAPTURE_DATA(1092 downto 1088) <= std_logic_vector(CH(3).WF_CNT(12 downto 8));
SS_CAPTURE_DATA(1093) <= CH(3).WF_RES;
SS_CAPTURE_DATA(1094) <= CH(3).WF_INC;
SS_CAPTURE_DATA(1103 downto 1095) <= std_logic_vector(CH(3).LFSR(8 downto 0));
SS_CAPTURE_DATA(1112 downto 1104) <= std_logic_vector(CH(3).LFSR(17 downto 9));
SS_CAPTURE_DATA(1119 downto 1113) <= std_logic_vector(CH(3).NG_CNT(6 downto 0));
SS_CAPTURE_DATA(1124 downto 1120) <= std_logic_vector(CH(3).NG_CNT(11 downto 7));
SS_CAPTURE_DATA(1129 downto 1125) <= std_logic_vector(CH(3).DA_OUT(4 downto 0));
SS_CAPTURE_DATA(1134 downto 1130) <= std_logic_vector(CH(3).WF_OUT(4 downto 0));
SS_CAPTURE_DATA(1135 downto 1135) <= std_logic_vector(CH(3).NG_OUT(0 downto 0));
SS_CAPTURE_DATA(1139 downto 1136) <= std_logic_vector(CH(3).NG_OUT(4 downto 1));
SS_CAPTURE_DATA(1144 downto 1140) <= std_logic_vector(CH(3).GL_OUT(4 downto 0));
SS_CAPTURE_DATA(1151 downto 1145) <= std_logic_vector(CH(3).LFO_FREQ(6 downto 0));
SS_CAPTURE_DATA(1152 downto 1152) <= std_logic_vector(CH(3).LFO_FREQ(7 downto 7));
SS_CAPTURE_DATA(1154 downto 1153) <= std_logic_vector(CH(3).LFCTL(1 downto 0));
SS_CAPTURE_DATA(1155) <= CH(3).LFTRG;
SS_CAPTURE_DATA(1163 downto 1156) <= std_logic_vector(CH(3).LFO_CNT(7 downto 0));
SS_CAPTURE_DATA(1167 downto 1164) <= std_logic_vector(CH(3).LFO_ADD(3 downto 0));
SS_CAPTURE_DATA(1175 downto 1168) <= std_logic_vector(CH(3).LFO_ADD(11 downto 4));
SS_CAPTURE_DATA(1183 downto 1176) <= std_logic_vector(CH(4).FREQ(7 downto 0));
SS_CAPTURE_DATA(1187 downto 1184) <= std_logic_vector(CH(4).FREQ(11 downto 8));
SS_CAPTURE_DATA(1188) <= CH(4).DDA;
SS_CAPTURE_DATA(1189) <= CH(4).CHON;
SS_CAPTURE_DATA(1194 downto 1190) <= std_logic_vector(CH(4).AL(4 downto 0));
SS_CAPTURE_DATA(1198 downto 1195) <= std_logic_vector(CH(4).LAL(3 downto 0));
SS_CAPTURE_DATA(1199 downto 1199) <= std_logic_vector(CH(4).RAL(0 downto 0));
SS_CAPTURE_DATA(1202 downto 1200) <= std_logic_vector(CH(4).RAL(3 downto 1));
SS_CAPTURE_DATA(1207 downto 1203) <= std_logic_vector(CH(4).NG_FREQ(4 downto 0));
SS_CAPTURE_DATA(1208) <= CH(4).NE;
SS_CAPTURE_DATA(1213 downto 1209) <= std_logic_vector(CH(4).WF_DATA(0)(4 downto 0));
SS_CAPTURE_DATA(1215 downto 1214) <= std_logic_vector(CH(4).WF_DATA(1)(1 downto 0));
SS_CAPTURE_DATA(1218 downto 1216) <= std_logic_vector(CH(4).WF_DATA(1)(4 downto 2));
SS_CAPTURE_DATA(1223 downto 1219) <= std_logic_vector(CH(4).WF_DATA(2)(4 downto 0));
SS_CAPTURE_DATA(1228 downto 1224) <= std_logic_vector(CH(4).WF_DATA(3)(4 downto 0));
SS_CAPTURE_DATA(1231 downto 1229) <= std_logic_vector(CH(4).WF_DATA(4)(2 downto 0));
SS_CAPTURE_DATA(1233 downto 1232) <= std_logic_vector(CH(4).WF_DATA(4)(4 downto 3));
SS_CAPTURE_DATA(1238 downto 1234) <= std_logic_vector(CH(4).WF_DATA(5)(4 downto 0));
SS_CAPTURE_DATA(1243 downto 1239) <= std_logic_vector(CH(4).WF_DATA(6)(4 downto 0));
SS_CAPTURE_DATA(1247 downto 1244) <= std_logic_vector(CH(4).WF_DATA(7)(3 downto 0));
SS_CAPTURE_DATA(1248 downto 1248) <= std_logic_vector(CH(4).WF_DATA(7)(4 downto 4));
SS_CAPTURE_DATA(1253 downto 1249) <= std_logic_vector(CH(4).WF_DATA(8)(4 downto 0));
SS_CAPTURE_DATA(1258 downto 1254) <= std_logic_vector(CH(4).WF_DATA(9)(4 downto 0));
SS_CAPTURE_DATA(1263 downto 1259) <= std_logic_vector(CH(4).WF_DATA(10)(4 downto 0));
SS_CAPTURE_DATA(1268 downto 1264) <= std_logic_vector(CH(4).WF_DATA(11)(4 downto 0));
SS_CAPTURE_DATA(1273 downto 1269) <= std_logic_vector(CH(4).WF_DATA(12)(4 downto 0));
SS_CAPTURE_DATA(1278 downto 1274) <= std_logic_vector(CH(4).WF_DATA(13)(4 downto 0));
SS_CAPTURE_DATA(1279 downto 1279) <= std_logic_vector(CH(4).WF_DATA(14)(0 downto 0));
SS_CAPTURE_DATA(1283 downto 1280) <= std_logic_vector(CH(4).WF_DATA(14)(4 downto 1));
SS_CAPTURE_DATA(1288 downto 1284) <= std_logic_vector(CH(4).WF_DATA(15)(4 downto 0));
SS_CAPTURE_DATA(1293 downto 1289) <= std_logic_vector(CH(4).WF_DATA(16)(4 downto 0));
SS_CAPTURE_DATA(1295 downto 1294) <= std_logic_vector(CH(4).WF_DATA(17)(1 downto 0));
SS_CAPTURE_DATA(1298 downto 1296) <= std_logic_vector(CH(4).WF_DATA(17)(4 downto 2));
SS_CAPTURE_DATA(1303 downto 1299) <= std_logic_vector(CH(4).WF_DATA(18)(4 downto 0));
SS_CAPTURE_DATA(1308 downto 1304) <= std_logic_vector(CH(4).WF_DATA(19)(4 downto 0));
SS_CAPTURE_DATA(1311 downto 1309) <= std_logic_vector(CH(4).WF_DATA(20)(2 downto 0));
SS_CAPTURE_DATA(1313 downto 1312) <= std_logic_vector(CH(4).WF_DATA(20)(4 downto 3));
SS_CAPTURE_DATA(1318 downto 1314) <= std_logic_vector(CH(4).WF_DATA(21)(4 downto 0));
SS_CAPTURE_DATA(1323 downto 1319) <= std_logic_vector(CH(4).WF_DATA(22)(4 downto 0));
SS_CAPTURE_DATA(1327 downto 1324) <= std_logic_vector(CH(4).WF_DATA(23)(3 downto 0));
SS_CAPTURE_DATA(1328 downto 1328) <= std_logic_vector(CH(4).WF_DATA(23)(4 downto 4));
SS_CAPTURE_DATA(1333 downto 1329) <= std_logic_vector(CH(4).WF_DATA(24)(4 downto 0));
SS_CAPTURE_DATA(1338 downto 1334) <= std_logic_vector(CH(4).WF_DATA(25)(4 downto 0));
SS_CAPTURE_DATA(1343 downto 1339) <= std_logic_vector(CH(4).WF_DATA(26)(4 downto 0));
SS_CAPTURE_DATA(1348 downto 1344) <= std_logic_vector(CH(4).WF_DATA(27)(4 downto 0));
SS_CAPTURE_DATA(1353 downto 1349) <= std_logic_vector(CH(4).WF_DATA(28)(4 downto 0));
SS_CAPTURE_DATA(1358 downto 1354) <= std_logic_vector(CH(4).WF_DATA(29)(4 downto 0));
SS_CAPTURE_DATA(1359 downto 1359) <= std_logic_vector(CH(4).WF_DATA(30)(0 downto 0));
SS_CAPTURE_DATA(1363 downto 1360) <= std_logic_vector(CH(4).WF_DATA(30)(4 downto 1));
SS_CAPTURE_DATA(1368 downto 1364) <= std_logic_vector(CH(4).WF_DATA(31)(4 downto 0));
SS_CAPTURE_DATA(1373 downto 1369) <= std_logic_vector(CH(4).WF_ADDR(4 downto 0));
SS_CAPTURE_DATA(1375 downto 1374) <= std_logic_vector(CH(4).WF_CNT(1 downto 0));
SS_CAPTURE_DATA(1386 downto 1376) <= std_logic_vector(CH(4).WF_CNT(12 downto 2));
SS_CAPTURE_DATA(1387) <= CH(4).WF_RES;
SS_CAPTURE_DATA(1388) <= CH(4).WF_INC;
SS_CAPTURE_DATA(1391 downto 1389) <= std_logic_vector(CH(4).LFSR(2 downto 0));
SS_CAPTURE_DATA(1406 downto 1392) <= std_logic_vector(CH(4).LFSR(17 downto 3));
SS_CAPTURE_DATA(1407 downto 1407) <= std_logic_vector(CH(4).NG_CNT(0 downto 0));
SS_CAPTURE_DATA(1418 downto 1408) <= std_logic_vector(CH(4).NG_CNT(11 downto 1));
SS_CAPTURE_DATA(1423 downto 1419) <= std_logic_vector(CH(4).DA_OUT(4 downto 0));
SS_CAPTURE_DATA(1428 downto 1424) <= std_logic_vector(CH(4).WF_OUT(4 downto 0));
SS_CAPTURE_DATA(1433 downto 1429) <= std_logic_vector(CH(4).NG_OUT(4 downto 0));
SS_CAPTURE_DATA(1438 downto 1434) <= std_logic_vector(CH(4).GL_OUT(4 downto 0));
SS_CAPTURE_DATA(1439 downto 1439) <= std_logic_vector(CH(4).LFO_FREQ(0 downto 0));
SS_CAPTURE_DATA(1446 downto 1440) <= std_logic_vector(CH(4).LFO_FREQ(7 downto 1));
SS_CAPTURE_DATA(1448 downto 1447) <= std_logic_vector(CH(4).LFCTL(1 downto 0));
SS_CAPTURE_DATA(1449) <= CH(4).LFTRG;
SS_CAPTURE_DATA(1455 downto 1450) <= std_logic_vector(CH(4).LFO_CNT(5 downto 0));
SS_CAPTURE_DATA(1457 downto 1456) <= std_logic_vector(CH(4).LFO_CNT(7 downto 6));
SS_CAPTURE_DATA(1469 downto 1458) <= std_logic_vector(CH(4).LFO_ADD(11 downto 0));
SS_CAPTURE_DATA(1471 downto 1470) <= std_logic_vector(CH(5).FREQ(1 downto 0));
SS_CAPTURE_DATA(1481 downto 1472) <= std_logic_vector(CH(5).FREQ(11 downto 2));
SS_CAPTURE_DATA(1482) <= CH(5).DDA;
SS_CAPTURE_DATA(1483) <= CH(5).CHON;
SS_CAPTURE_DATA(1487 downto 1484) <= std_logic_vector(CH(5).AL(3 downto 0));
SS_CAPTURE_DATA(1488 downto 1488) <= std_logic_vector(CH(5).AL(4 downto 4));
SS_CAPTURE_DATA(1492 downto 1489) <= std_logic_vector(CH(5).LAL(3 downto 0));
SS_CAPTURE_DATA(1496 downto 1493) <= std_logic_vector(CH(5).RAL(3 downto 0));
SS_CAPTURE_DATA(1501 downto 1497) <= std_logic_vector(CH(5).NG_FREQ(4 downto 0));
SS_CAPTURE_DATA(1502) <= CH(5).NE;
SS_CAPTURE_DATA(1503 downto 1503) <= std_logic_vector(CH(5).WF_DATA(0)(0 downto 0));
SS_CAPTURE_DATA(1507 downto 1504) <= std_logic_vector(CH(5).WF_DATA(0)(4 downto 1));
SS_CAPTURE_DATA(1512 downto 1508) <= std_logic_vector(CH(5).WF_DATA(1)(4 downto 0));
SS_CAPTURE_DATA(1517 downto 1513) <= std_logic_vector(CH(5).WF_DATA(2)(4 downto 0));
SS_CAPTURE_DATA(1519 downto 1518) <= std_logic_vector(CH(5).WF_DATA(3)(1 downto 0));
SS_CAPTURE_DATA(1522 downto 1520) <= std_logic_vector(CH(5).WF_DATA(3)(4 downto 2));
SS_CAPTURE_DATA(1527 downto 1523) <= std_logic_vector(CH(5).WF_DATA(4)(4 downto 0));
SS_CAPTURE_DATA(1532 downto 1528) <= std_logic_vector(CH(5).WF_DATA(5)(4 downto 0));
SS_CAPTURE_DATA(1535 downto 1533) <= std_logic_vector(CH(5).WF_DATA(6)(2 downto 0));
SS_CAPTURE_DATA(1537 downto 1536) <= std_logic_vector(CH(5).WF_DATA(6)(4 downto 3));
SS_CAPTURE_DATA(1542 downto 1538) <= std_logic_vector(CH(5).WF_DATA(7)(4 downto 0));
SS_CAPTURE_DATA(1547 downto 1543) <= std_logic_vector(CH(5).WF_DATA(8)(4 downto 0));
SS_CAPTURE_DATA(1551 downto 1548) <= std_logic_vector(CH(5).WF_DATA(9)(3 downto 0));
SS_CAPTURE_DATA(1552 downto 1552) <= std_logic_vector(CH(5).WF_DATA(9)(4 downto 4));
SS_CAPTURE_DATA(1557 downto 1553) <= std_logic_vector(CH(5).WF_DATA(10)(4 downto 0));
SS_CAPTURE_DATA(1562 downto 1558) <= std_logic_vector(CH(5).WF_DATA(11)(4 downto 0));
SS_CAPTURE_DATA(1567 downto 1563) <= std_logic_vector(CH(5).WF_DATA(12)(4 downto 0));
SS_CAPTURE_DATA(1572 downto 1568) <= std_logic_vector(CH(5).WF_DATA(13)(4 downto 0));
SS_CAPTURE_DATA(1577 downto 1573) <= std_logic_vector(CH(5).WF_DATA(14)(4 downto 0));
SS_CAPTURE_DATA(1582 downto 1578) <= std_logic_vector(CH(5).WF_DATA(15)(4 downto 0));
SS_CAPTURE_DATA(1583 downto 1583) <= std_logic_vector(CH(5).WF_DATA(16)(0 downto 0));
SS_CAPTURE_DATA(1587 downto 1584) <= std_logic_vector(CH(5).WF_DATA(16)(4 downto 1));
SS_CAPTURE_DATA(1592 downto 1588) <= std_logic_vector(CH(5).WF_DATA(17)(4 downto 0));
SS_CAPTURE_DATA(1597 downto 1593) <= std_logic_vector(CH(5).WF_DATA(18)(4 downto 0));
SS_CAPTURE_DATA(1599 downto 1598) <= std_logic_vector(CH(5).WF_DATA(19)(1 downto 0));
SS_CAPTURE_DATA(1602 downto 1600) <= std_logic_vector(CH(5).WF_DATA(19)(4 downto 2));
SS_CAPTURE_DATA(1607 downto 1603) <= std_logic_vector(CH(5).WF_DATA(20)(4 downto 0));
SS_CAPTURE_DATA(1612 downto 1608) <= std_logic_vector(CH(5).WF_DATA(21)(4 downto 0));
SS_CAPTURE_DATA(1615 downto 1613) <= std_logic_vector(CH(5).WF_DATA(22)(2 downto 0));
SS_CAPTURE_DATA(1617 downto 1616) <= std_logic_vector(CH(5).WF_DATA(22)(4 downto 3));
SS_CAPTURE_DATA(1622 downto 1618) <= std_logic_vector(CH(5).WF_DATA(23)(4 downto 0));
SS_CAPTURE_DATA(1627 downto 1623) <= std_logic_vector(CH(5).WF_DATA(24)(4 downto 0));
SS_CAPTURE_DATA(1631 downto 1628) <= std_logic_vector(CH(5).WF_DATA(25)(3 downto 0));
SS_CAPTURE_DATA(1632 downto 1632) <= std_logic_vector(CH(5).WF_DATA(25)(4 downto 4));
SS_CAPTURE_DATA(1637 downto 1633) <= std_logic_vector(CH(5).WF_DATA(26)(4 downto 0));
SS_CAPTURE_DATA(1642 downto 1638) <= std_logic_vector(CH(5).WF_DATA(27)(4 downto 0));
SS_CAPTURE_DATA(1647 downto 1643) <= std_logic_vector(CH(5).WF_DATA(28)(4 downto 0));
SS_CAPTURE_DATA(1652 downto 1648) <= std_logic_vector(CH(5).WF_DATA(29)(4 downto 0));
SS_CAPTURE_DATA(1657 downto 1653) <= std_logic_vector(CH(5).WF_DATA(30)(4 downto 0));
SS_CAPTURE_DATA(1662 downto 1658) <= std_logic_vector(CH(5).WF_DATA(31)(4 downto 0));
SS_CAPTURE_DATA(1663 downto 1663) <= std_logic_vector(CH(5).WF_ADDR(0 downto 0));
SS_CAPTURE_DATA(1667 downto 1664) <= std_logic_vector(CH(5).WF_ADDR(4 downto 1));
SS_CAPTURE_DATA(1679 downto 1668) <= std_logic_vector(CH(5).WF_CNT(11 downto 0));
SS_CAPTURE_DATA(1680 downto 1680) <= std_logic_vector(CH(5).WF_CNT(12 downto 12));
SS_CAPTURE_DATA(1681) <= CH(5).WF_RES;
SS_CAPTURE_DATA(1682) <= CH(5).WF_INC;
SS_CAPTURE_DATA(1695 downto 1683) <= std_logic_vector(CH(5).LFSR(12 downto 0));
SS_CAPTURE_DATA(1700 downto 1696) <= std_logic_vector(CH(5).LFSR(17 downto 13));
SS_CAPTURE_DATA(1711 downto 1701) <= std_logic_vector(CH(5).NG_CNT(10 downto 0));
SS_CAPTURE_DATA(1712 downto 1712) <= std_logic_vector(CH(5).NG_CNT(11 downto 11));
SS_CAPTURE_DATA(1717 downto 1713) <= std_logic_vector(CH(5).DA_OUT(4 downto 0));
SS_CAPTURE_DATA(1722 downto 1718) <= std_logic_vector(CH(5).WF_OUT(4 downto 0));
SS_CAPTURE_DATA(1727 downto 1723) <= std_logic_vector(CH(5).NG_OUT(4 downto 0));
SS_CAPTURE_DATA(1732 downto 1728) <= std_logic_vector(CH(5).GL_OUT(4 downto 0));
SS_CAPTURE_DATA(1740 downto 1733) <= std_logic_vector(CH(5).LFO_FREQ(7 downto 0));
SS_CAPTURE_DATA(1742 downto 1741) <= std_logic_vector(CH(5).LFCTL(1 downto 0));
SS_CAPTURE_DATA(1743) <= CH(5).LFTRG;
SS_CAPTURE_DATA(1751 downto 1744) <= std_logic_vector(CH(5).LFO_CNT(7 downto 0));
SS_CAPTURE_DATA(1759 downto 1752) <= std_logic_vector(CH(5).LFO_ADD(7 downto 0));
SS_CAPTURE_DATA(1763 downto 1760) <= std_logic_vector(CH(5).LFO_ADD(11 downto 8));
SS_CAPTURE_DATA(1766 downto 1764) <= std_logic_vector(to_unsigned(CHSEL,3));
SS_CAPTURE_DATA(1775 downto 1767) <= std_logic_vector(LACC(8 downto 0));
SS_CAPTURE_DATA(1790 downto 1776) <= std_logic_vector(LACC(23 downto 9));
SS_CAPTURE_DATA(1791 downto 1791) <= std_logic_vector(LDATA_FF(0 downto 0));
SS_CAPTURE_DATA(1807 downto 1792) <= std_logic_vector(LDATA_FF(16 downto 1));
SS_CAPTURE_DATA(1814 downto 1808) <= std_logic_vector(LDATA_FF(23 downto 17));
SS_CAPTURE_DATA(1818 downto 1815) <= std_logic_vector(LMAL(3 downto 0));
SS_CAPTURE_DATA(1821 downto 1819) <= std_logic_vector(to_unsigned(mix_t'pos(MIX),3));
SS_CAPTURE_DATA(1823 downto 1822) <= std_logic_vector(MIX_CNT(1 downto 0));
SS_CAPTURE_DATA(1824 downto 1824) <= std_logic_vector(MIX_CNT(2 downto 2));
SS_CAPTURE_DATA(1839 downto 1825) <= std_logic_vector(RACC(14 downto 0));
SS_CAPTURE_DATA(1848 downto 1840) <= std_logic_vector(RACC(23 downto 15));
SS_CAPTURE_DATA(1855 downto 1849) <= std_logic_vector(RDATA_FF(6 downto 0));
SS_CAPTURE_DATA(1871 downto 1856) <= std_logic_vector(RDATA_FF(22 downto 7));
SS_CAPTURE_DATA(1872 downto 1872) <= std_logic_vector(RDATA_FF(23 downto 23));
SS_CAPTURE_DATA(1876 downto 1873) <= std_logic_vector(RMAL(3 downto 0));
SS_CAPTURE_DATA(1887 downto 1877) <= std_logic_vector(VT_ADDR(10 downto 0));
SS_CAPTURE_DATA(1888 downto 1888) <= std_logic_vector(VT_ADDR(11 downto 11));
SS_CAPTURE_DATA(1908 downto 1904) <= std_logic_vector(SS_PROXY_0(4 downto 0));
SS_CAPTURE_DATA(1903 downto 1889) <= (others => '0');
SS_CAPTURE_DATA(1919 downto 1909) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
-- T captures ordinary fields; T+2 patches only the settled variable proxies.
-- Native state machines continue unchanged throughout this operation.
SS_LIVE_PENDING <= SS_LIVE_PENDING(0) & SS_LIVE_CUT;
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
-- synthesis translate_off
assert not (SS_LIVE_CUT = '1' and (SS_SAVE = '1' or SS_LOAD = '1' or SS_FREEZE = '1' or SS_CHAIN_CAPTURE /= "00" or SS_LIVE_PENDING /= "00"))
 report "live cut overlaps another snapshot operation" severity failure;
assert not ((SS_LIVE_CUT = '1' or SS_LIVE_PENDING /= "00") and (SS_RROTATE = '1' or SS_RWE = '1' or SS_LOAD = '1' or SS_SAVE = '1'))
 report "snapshot chain used before live proxy settling completes" severity failure;
-- synthesis translate_on
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA; -- unchanged legacy frozen-save behavior
elsif SS_LIVE_CUT = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_LIVE_PENDING(1) = '1' then
SS_CHAIN(1908 downto 1904) <= SS_CAPTURE_DATA(1908 downto 1904);
elsif SS_LIVE_PENDING /= "00" then
null; -- hold the captured scalar fields during proxy settling
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= 425 and to_integer(unsigned(SS_RADDR)) <= 544) then
SS_CHAIN <= SS_RDI & SS_CHAIN(1919 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= 425 and to_integer(unsigned(SS_RADDR)) <= 544) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(1919 downto 16);
end if;
end if;
end process;
SS_SH_CH(0).FREQ(11 downto 0) <= SS_CHAIN(11 downto 0);
SS_SH_CH(0).DDA <= SS_CHAIN(12);
SS_SH_CH(0).CHON <= SS_CHAIN(13);
SS_SH_CH(0).AL(1 downto 0) <= SS_CHAIN(15 downto 14);
SS_SH_CH(0).AL(4 downto 2) <= SS_CHAIN(18 downto 16);
SS_SH_CH(0).LAL(3 downto 0) <= SS_CHAIN(22 downto 19);
SS_SH_CH(0).RAL(3 downto 0) <= SS_CHAIN(26 downto 23);
SS_SH_CH(0).NG_FREQ(4 downto 0) <= SS_CHAIN(31 downto 27);
SS_SH_CH(0).NE <= SS_CHAIN(32);
SS_SH_CH(0).WF_DATA(0)(4 downto 0) <= SS_CHAIN(37 downto 33);
SS_SH_CH(0).WF_DATA(1)(4 downto 0) <= SS_CHAIN(42 downto 38);
SS_SH_CH(0).WF_DATA(2)(4 downto 0) <= SS_CHAIN(47 downto 43);
SS_SH_CH(0).WF_DATA(3)(4 downto 0) <= SS_CHAIN(52 downto 48);
SS_SH_CH(0).WF_DATA(4)(4 downto 0) <= SS_CHAIN(57 downto 53);
SS_SH_CH(0).WF_DATA(5)(4 downto 0) <= SS_CHAIN(62 downto 58);
SS_SH_CH(0).WF_DATA(6)(0 downto 0) <= SS_CHAIN(63 downto 63);
SS_SH_CH(0).WF_DATA(6)(4 downto 1) <= SS_CHAIN(67 downto 64);
SS_SH_CH(0).WF_DATA(7)(4 downto 0) <= SS_CHAIN(72 downto 68);
SS_SH_CH(0).WF_DATA(8)(4 downto 0) <= SS_CHAIN(77 downto 73);
SS_SH_CH(0).WF_DATA(9)(1 downto 0) <= SS_CHAIN(79 downto 78);
SS_SH_CH(0).WF_DATA(9)(4 downto 2) <= SS_CHAIN(82 downto 80);
SS_SH_CH(0).WF_DATA(10)(4 downto 0) <= SS_CHAIN(87 downto 83);
SS_SH_CH(0).WF_DATA(11)(4 downto 0) <= SS_CHAIN(92 downto 88);
SS_SH_CH(0).WF_DATA(12)(2 downto 0) <= SS_CHAIN(95 downto 93);
SS_SH_CH(0).WF_DATA(12)(4 downto 3) <= SS_CHAIN(97 downto 96);
SS_SH_CH(0).WF_DATA(13)(4 downto 0) <= SS_CHAIN(102 downto 98);
SS_SH_CH(0).WF_DATA(14)(4 downto 0) <= SS_CHAIN(107 downto 103);
SS_SH_CH(0).WF_DATA(15)(3 downto 0) <= SS_CHAIN(111 downto 108);
SS_SH_CH(0).WF_DATA(15)(4 downto 4) <= SS_CHAIN(112 downto 112);
SS_SH_CH(0).WF_DATA(16)(4 downto 0) <= SS_CHAIN(117 downto 113);
SS_SH_CH(0).WF_DATA(17)(4 downto 0) <= SS_CHAIN(122 downto 118);
SS_SH_CH(0).WF_DATA(18)(4 downto 0) <= SS_CHAIN(127 downto 123);
SS_SH_CH(0).WF_DATA(19)(4 downto 0) <= SS_CHAIN(132 downto 128);
SS_SH_CH(0).WF_DATA(20)(4 downto 0) <= SS_CHAIN(137 downto 133);
SS_SH_CH(0).WF_DATA(21)(4 downto 0) <= SS_CHAIN(142 downto 138);
SS_SH_CH(0).WF_DATA(22)(0 downto 0) <= SS_CHAIN(143 downto 143);
SS_SH_CH(0).WF_DATA(22)(4 downto 1) <= SS_CHAIN(147 downto 144);
SS_SH_CH(0).WF_DATA(23)(4 downto 0) <= SS_CHAIN(152 downto 148);
SS_SH_CH(0).WF_DATA(24)(4 downto 0) <= SS_CHAIN(157 downto 153);
SS_SH_CH(0).WF_DATA(25)(1 downto 0) <= SS_CHAIN(159 downto 158);
SS_SH_CH(0).WF_DATA(25)(4 downto 2) <= SS_CHAIN(162 downto 160);
SS_SH_CH(0).WF_DATA(26)(4 downto 0) <= SS_CHAIN(167 downto 163);
SS_SH_CH(0).WF_DATA(27)(4 downto 0) <= SS_CHAIN(172 downto 168);
SS_SH_CH(0).WF_DATA(28)(2 downto 0) <= SS_CHAIN(175 downto 173);
SS_SH_CH(0).WF_DATA(28)(4 downto 3) <= SS_CHAIN(177 downto 176);
SS_SH_CH(0).WF_DATA(29)(4 downto 0) <= SS_CHAIN(182 downto 178);
SS_SH_CH(0).WF_DATA(30)(4 downto 0) <= SS_CHAIN(187 downto 183);
SS_SH_CH(0).WF_DATA(31)(3 downto 0) <= SS_CHAIN(191 downto 188);
SS_SH_CH(0).WF_DATA(31)(4 downto 4) <= SS_CHAIN(192 downto 192);
SS_SH_CH(0).WF_ADDR(4 downto 0) <= SS_CHAIN(197 downto 193);
SS_SH_CH(0).WF_CNT(9 downto 0) <= SS_CHAIN(207 downto 198);
SS_SH_CH(0).WF_CNT(12 downto 10) <= SS_CHAIN(210 downto 208);
SS_SH_CH(0).WF_RES <= SS_CHAIN(211);
SS_SH_CH(0).WF_INC <= SS_CHAIN(212);
SS_SH_CH(0).LFSR(10 downto 0) <= SS_CHAIN(223 downto 213);
SS_SH_CH(0).LFSR(17 downto 11) <= SS_CHAIN(230 downto 224);
SS_SH_CH(0).NG_CNT(8 downto 0) <= SS_CHAIN(239 downto 231);
SS_SH_CH(0).NG_CNT(11 downto 9) <= SS_CHAIN(242 downto 240);
SS_SH_CH(0).DA_OUT(4 downto 0) <= SS_CHAIN(247 downto 243);
SS_SH_CH(0).WF_OUT(4 downto 0) <= SS_CHAIN(252 downto 248);
SS_SH_CH(0).NG_OUT(2 downto 0) <= SS_CHAIN(255 downto 253);
SS_SH_CH(0).NG_OUT(4 downto 3) <= SS_CHAIN(257 downto 256);
SS_SH_CH(0).GL_OUT(4 downto 0) <= SS_CHAIN(262 downto 258);
SS_SH_CH(0).LFO_FREQ(7 downto 0) <= SS_CHAIN(270 downto 263);
SS_SH_CH(0).LFCTL(0 downto 0) <= SS_CHAIN(271 downto 271);
SS_SH_CH(0).LFCTL(1 downto 1) <= SS_CHAIN(272 downto 272);
SS_SH_CH(0).LFTRG <= SS_CHAIN(273);
SS_SH_CH(0).LFO_CNT(7 downto 0) <= SS_CHAIN(281 downto 274);
SS_SH_CH(0).LFO_ADD(5 downto 0) <= SS_CHAIN(287 downto 282);
SS_SH_CH(0).LFO_ADD(11 downto 6) <= SS_CHAIN(293 downto 288);
SS_SH_CH(1).FREQ(9 downto 0) <= SS_CHAIN(303 downto 294);
SS_SH_CH(1).FREQ(11 downto 10) <= SS_CHAIN(305 downto 304);
SS_SH_CH(1).DDA <= SS_CHAIN(306);
SS_SH_CH(1).CHON <= SS_CHAIN(307);
SS_SH_CH(1).AL(4 downto 0) <= SS_CHAIN(312 downto 308);
SS_SH_CH(1).LAL(3 downto 0) <= SS_CHAIN(316 downto 313);
SS_SH_CH(1).RAL(2 downto 0) <= SS_CHAIN(319 downto 317);
SS_SH_CH(1).RAL(3 downto 3) <= SS_CHAIN(320 downto 320);
SS_SH_CH(1).NG_FREQ(4 downto 0) <= SS_CHAIN(325 downto 321);
SS_SH_CH(1).NE <= SS_CHAIN(326);
SS_SH_CH(1).WF_DATA(0)(4 downto 0) <= SS_CHAIN(331 downto 327);
SS_SH_CH(1).WF_DATA(1)(3 downto 0) <= SS_CHAIN(335 downto 332);
SS_SH_CH(1).WF_DATA(1)(4 downto 4) <= SS_CHAIN(336 downto 336);
SS_SH_CH(1).WF_DATA(2)(4 downto 0) <= SS_CHAIN(341 downto 337);
SS_SH_CH(1).WF_DATA(3)(4 downto 0) <= SS_CHAIN(346 downto 342);
SS_SH_CH(1).WF_DATA(4)(4 downto 0) <= SS_CHAIN(351 downto 347);
SS_SH_CH(1).WF_DATA(5)(4 downto 0) <= SS_CHAIN(356 downto 352);
SS_SH_CH(1).WF_DATA(6)(4 downto 0) <= SS_CHAIN(361 downto 357);
SS_SH_CH(1).WF_DATA(7)(4 downto 0) <= SS_CHAIN(366 downto 362);
SS_SH_CH(1).WF_DATA(8)(0 downto 0) <= SS_CHAIN(367 downto 367);
SS_SH_CH(1).WF_DATA(8)(4 downto 1) <= SS_CHAIN(371 downto 368);
SS_SH_CH(1).WF_DATA(9)(4 downto 0) <= SS_CHAIN(376 downto 372);
SS_SH_CH(1).WF_DATA(10)(4 downto 0) <= SS_CHAIN(381 downto 377);
SS_SH_CH(1).WF_DATA(11)(1 downto 0) <= SS_CHAIN(383 downto 382);
SS_SH_CH(1).WF_DATA(11)(4 downto 2) <= SS_CHAIN(386 downto 384);
SS_SH_CH(1).WF_DATA(12)(4 downto 0) <= SS_CHAIN(391 downto 387);
SS_SH_CH(1).WF_DATA(13)(4 downto 0) <= SS_CHAIN(396 downto 392);
SS_SH_CH(1).WF_DATA(14)(2 downto 0) <= SS_CHAIN(399 downto 397);
SS_SH_CH(1).WF_DATA(14)(4 downto 3) <= SS_CHAIN(401 downto 400);
SS_SH_CH(1).WF_DATA(15)(4 downto 0) <= SS_CHAIN(406 downto 402);
SS_SH_CH(1).WF_DATA(16)(4 downto 0) <= SS_CHAIN(411 downto 407);
SS_SH_CH(1).WF_DATA(17)(3 downto 0) <= SS_CHAIN(415 downto 412);
SS_SH_CH(1).WF_DATA(17)(4 downto 4) <= SS_CHAIN(416 downto 416);
SS_SH_CH(1).WF_DATA(18)(4 downto 0) <= SS_CHAIN(421 downto 417);
SS_SH_CH(1).WF_DATA(19)(4 downto 0) <= SS_CHAIN(426 downto 422);
SS_SH_CH(1).WF_DATA(20)(4 downto 0) <= SS_CHAIN(431 downto 427);
SS_SH_CH(1).WF_DATA(21)(4 downto 0) <= SS_CHAIN(436 downto 432);
SS_SH_CH(1).WF_DATA(22)(4 downto 0) <= SS_CHAIN(441 downto 437);
SS_SH_CH(1).WF_DATA(23)(4 downto 0) <= SS_CHAIN(446 downto 442);
SS_SH_CH(1).WF_DATA(24)(0 downto 0) <= SS_CHAIN(447 downto 447);
SS_SH_CH(1).WF_DATA(24)(4 downto 1) <= SS_CHAIN(451 downto 448);
SS_SH_CH(1).WF_DATA(25)(4 downto 0) <= SS_CHAIN(456 downto 452);
SS_SH_CH(1).WF_DATA(26)(4 downto 0) <= SS_CHAIN(461 downto 457);
SS_SH_CH(1).WF_DATA(27)(1 downto 0) <= SS_CHAIN(463 downto 462);
SS_SH_CH(1).WF_DATA(27)(4 downto 2) <= SS_CHAIN(466 downto 464);
SS_SH_CH(1).WF_DATA(28)(4 downto 0) <= SS_CHAIN(471 downto 467);
SS_SH_CH(1).WF_DATA(29)(4 downto 0) <= SS_CHAIN(476 downto 472);
SS_SH_CH(1).WF_DATA(30)(2 downto 0) <= SS_CHAIN(479 downto 477);
SS_SH_CH(1).WF_DATA(30)(4 downto 3) <= SS_CHAIN(481 downto 480);
SS_SH_CH(1).WF_DATA(31)(4 downto 0) <= SS_CHAIN(486 downto 482);
SS_SH_CH(1).WF_ADDR(4 downto 0) <= SS_CHAIN(491 downto 487);
SS_SH_CH(1).WF_CNT(3 downto 0) <= SS_CHAIN(495 downto 492);
SS_SH_CH(1).WF_CNT(12 downto 4) <= SS_CHAIN(504 downto 496);
SS_SH_CH(1).WF_RES <= SS_CHAIN(505);
SS_SH_CH(1).WF_INC <= SS_CHAIN(506);
SS_SH_CH(1).LFSR(4 downto 0) <= SS_CHAIN(511 downto 507);
SS_SH_CH(1).LFSR(17 downto 5) <= SS_CHAIN(524 downto 512);
SS_SH_CH(1).NG_CNT(2 downto 0) <= SS_CHAIN(527 downto 525);
SS_SH_CH(1).NG_CNT(11 downto 3) <= SS_CHAIN(536 downto 528);
SS_SH_CH(1).DA_OUT(4 downto 0) <= SS_CHAIN(541 downto 537);
SS_SH_CH(1).WF_OUT(1 downto 0) <= SS_CHAIN(543 downto 542);
SS_SH_CH(1).WF_OUT(4 downto 2) <= SS_CHAIN(546 downto 544);
SS_SH_CH(1).NG_OUT(4 downto 0) <= SS_CHAIN(551 downto 547);
SS_SH_CH(1).GL_OUT(4 downto 0) <= SS_CHAIN(556 downto 552);
SS_SH_CH(1).LFO_FREQ(2 downto 0) <= SS_CHAIN(559 downto 557);
SS_SH_CH(1).LFO_FREQ(7 downto 3) <= SS_CHAIN(564 downto 560);
SS_SH_CH(1).LFCTL(1 downto 0) <= SS_CHAIN(566 downto 565);
SS_SH_CH(1).LFTRG <= SS_CHAIN(567);
SS_SH_CH(1).LFO_CNT(7 downto 0) <= SS_CHAIN(575 downto 568);
SS_SH_CH(1).LFO_ADD(11 downto 0) <= SS_CHAIN(587 downto 576);
SS_SH_CH(2).FREQ(3 downto 0) <= SS_CHAIN(591 downto 588);
SS_SH_CH(2).FREQ(11 downto 4) <= SS_CHAIN(599 downto 592);
SS_SH_CH(2).DDA <= SS_CHAIN(600);
SS_SH_CH(2).CHON <= SS_CHAIN(601);
SS_SH_CH(2).AL(4 downto 0) <= SS_CHAIN(606 downto 602);
SS_SH_CH(2).LAL(0 downto 0) <= SS_CHAIN(607 downto 607);
SS_SH_CH(2).LAL(3 downto 1) <= SS_CHAIN(610 downto 608);
SS_SH_CH(2).RAL(3 downto 0) <= SS_CHAIN(614 downto 611);
SS_SH_CH(2).NG_FREQ(4 downto 0) <= SS_CHAIN(619 downto 615);
SS_SH_CH(2).NE <= SS_CHAIN(620);
SS_SH_CH(2).WF_DATA(0)(2 downto 0) <= SS_CHAIN(623 downto 621);
SS_SH_CH(2).WF_DATA(0)(4 downto 3) <= SS_CHAIN(625 downto 624);
SS_SH_CH(2).WF_DATA(1)(4 downto 0) <= SS_CHAIN(630 downto 626);
SS_SH_CH(2).WF_DATA(2)(4 downto 0) <= SS_CHAIN(635 downto 631);
SS_SH_CH(2).WF_DATA(3)(3 downto 0) <= SS_CHAIN(639 downto 636);
SS_SH_CH(2).WF_DATA(3)(4 downto 4) <= SS_CHAIN(640 downto 640);
SS_SH_CH(2).WF_DATA(4)(4 downto 0) <= SS_CHAIN(645 downto 641);
SS_SH_CH(2).WF_DATA(5)(4 downto 0) <= SS_CHAIN(650 downto 646);
SS_SH_CH(2).WF_DATA(6)(4 downto 0) <= SS_CHAIN(655 downto 651);
SS_SH_CH(2).WF_DATA(7)(4 downto 0) <= SS_CHAIN(660 downto 656);
SS_SH_CH(2).WF_DATA(8)(4 downto 0) <= SS_CHAIN(665 downto 661);
SS_SH_CH(2).WF_DATA(9)(4 downto 0) <= SS_CHAIN(670 downto 666);
SS_SH_CH(2).WF_DATA(10)(0 downto 0) <= SS_CHAIN(671 downto 671);
SS_SH_CH(2).WF_DATA(10)(4 downto 1) <= SS_CHAIN(675 downto 672);
SS_SH_CH(2).WF_DATA(11)(4 downto 0) <= SS_CHAIN(680 downto 676);
SS_SH_CH(2).WF_DATA(12)(4 downto 0) <= SS_CHAIN(685 downto 681);
SS_SH_CH(2).WF_DATA(13)(1 downto 0) <= SS_CHAIN(687 downto 686);
SS_SH_CH(2).WF_DATA(13)(4 downto 2) <= SS_CHAIN(690 downto 688);
SS_SH_CH(2).WF_DATA(14)(4 downto 0) <= SS_CHAIN(695 downto 691);
SS_SH_CH(2).WF_DATA(15)(4 downto 0) <= SS_CHAIN(700 downto 696);
SS_SH_CH(2).WF_DATA(16)(2 downto 0) <= SS_CHAIN(703 downto 701);
SS_SH_CH(2).WF_DATA(16)(4 downto 3) <= SS_CHAIN(705 downto 704);
SS_SH_CH(2).WF_DATA(17)(4 downto 0) <= SS_CHAIN(710 downto 706);
SS_SH_CH(2).WF_DATA(18)(4 downto 0) <= SS_CHAIN(715 downto 711);
SS_SH_CH(2).WF_DATA(19)(3 downto 0) <= SS_CHAIN(719 downto 716);
SS_SH_CH(2).WF_DATA(19)(4 downto 4) <= SS_CHAIN(720 downto 720);
SS_SH_CH(2).WF_DATA(20)(4 downto 0) <= SS_CHAIN(725 downto 721);
SS_SH_CH(2).WF_DATA(21)(4 downto 0) <= SS_CHAIN(730 downto 726);
SS_SH_CH(2).WF_DATA(22)(4 downto 0) <= SS_CHAIN(735 downto 731);
SS_SH_CH(2).WF_DATA(23)(4 downto 0) <= SS_CHAIN(740 downto 736);
SS_SH_CH(2).WF_DATA(24)(4 downto 0) <= SS_CHAIN(745 downto 741);
SS_SH_CH(2).WF_DATA(25)(4 downto 0) <= SS_CHAIN(750 downto 746);
SS_SH_CH(2).WF_DATA(26)(0 downto 0) <= SS_CHAIN(751 downto 751);
SS_SH_CH(2).WF_DATA(26)(4 downto 1) <= SS_CHAIN(755 downto 752);
SS_SH_CH(2).WF_DATA(27)(4 downto 0) <= SS_CHAIN(760 downto 756);
SS_SH_CH(2).WF_DATA(28)(4 downto 0) <= SS_CHAIN(765 downto 761);
SS_SH_CH(2).WF_DATA(29)(1 downto 0) <= SS_CHAIN(767 downto 766);
SS_SH_CH(2).WF_DATA(29)(4 downto 2) <= SS_CHAIN(770 downto 768);
SS_SH_CH(2).WF_DATA(30)(4 downto 0) <= SS_CHAIN(775 downto 771);
SS_SH_CH(2).WF_DATA(31)(4 downto 0) <= SS_CHAIN(780 downto 776);
SS_SH_CH(2).WF_ADDR(2 downto 0) <= SS_CHAIN(783 downto 781);
SS_SH_CH(2).WF_ADDR(4 downto 3) <= SS_CHAIN(785 downto 784);
SS_SH_CH(2).WF_CNT(12 downto 0) <= SS_CHAIN(798 downto 786);
SS_SH_CH(2).WF_RES <= SS_CHAIN(799);
SS_SH_CH(2).WF_INC <= SS_CHAIN(800);
SS_SH_CH(2).LFSR(14 downto 0) <= SS_CHAIN(815 downto 801);
SS_SH_CH(2).LFSR(17 downto 15) <= SS_CHAIN(818 downto 816);
SS_SH_CH(2).NG_CNT(11 downto 0) <= SS_CHAIN(830 downto 819);
SS_SH_CH(2).DA_OUT(0 downto 0) <= SS_CHAIN(831 downto 831);
SS_SH_CH(2).DA_OUT(4 downto 1) <= SS_CHAIN(835 downto 832);
SS_SH_CH(2).WF_OUT(4 downto 0) <= SS_CHAIN(840 downto 836);
SS_SH_CH(2).NG_OUT(4 downto 0) <= SS_CHAIN(845 downto 841);
SS_SH_CH(2).GL_OUT(1 downto 0) <= SS_CHAIN(847 downto 846);
SS_SH_CH(2).GL_OUT(4 downto 2) <= SS_CHAIN(850 downto 848);
SS_SH_CH(2).LFO_FREQ(7 downto 0) <= SS_CHAIN(858 downto 851);
SS_SH_CH(2).LFCTL(1 downto 0) <= SS_CHAIN(860 downto 859);
SS_SH_CH(2).LFTRG <= SS_CHAIN(861);
SS_SH_CH(2).LFO_CNT(1 downto 0) <= SS_CHAIN(863 downto 862);
SS_SH_CH(2).LFO_CNT(7 downto 2) <= SS_CHAIN(869 downto 864);
SS_SH_CH(2).LFO_ADD(9 downto 0) <= SS_CHAIN(879 downto 870);
SS_SH_CH(2).LFO_ADD(11 downto 10) <= SS_CHAIN(881 downto 880);
SS_SH_CH(3).FREQ(11 downto 0) <= SS_CHAIN(893 downto 882);
SS_SH_CH(3).DDA <= SS_CHAIN(894);
SS_SH_CH(3).CHON <= SS_CHAIN(895);
SS_SH_CH(3).AL(4 downto 0) <= SS_CHAIN(900 downto 896);
SS_SH_CH(3).LAL(3 downto 0) <= SS_CHAIN(904 downto 901);
SS_SH_CH(3).RAL(3 downto 0) <= SS_CHAIN(908 downto 905);
SS_SH_CH(3).NG_FREQ(2 downto 0) <= SS_CHAIN(911 downto 909);
SS_SH_CH(3).NG_FREQ(4 downto 3) <= SS_CHAIN(913 downto 912);
SS_SH_CH(3).NE <= SS_CHAIN(914);
SS_SH_CH(3).WF_DATA(0)(4 downto 0) <= SS_CHAIN(919 downto 915);
SS_SH_CH(3).WF_DATA(1)(4 downto 0) <= SS_CHAIN(924 downto 920);
SS_SH_CH(3).WF_DATA(2)(2 downto 0) <= SS_CHAIN(927 downto 925);
SS_SH_CH(3).WF_DATA(2)(4 downto 3) <= SS_CHAIN(929 downto 928);
SS_SH_CH(3).WF_DATA(3)(4 downto 0) <= SS_CHAIN(934 downto 930);
SS_SH_CH(3).WF_DATA(4)(4 downto 0) <= SS_CHAIN(939 downto 935);
SS_SH_CH(3).WF_DATA(5)(3 downto 0) <= SS_CHAIN(943 downto 940);
SS_SH_CH(3).WF_DATA(5)(4 downto 4) <= SS_CHAIN(944 downto 944);
SS_SH_CH(3).WF_DATA(6)(4 downto 0) <= SS_CHAIN(949 downto 945);
SS_SH_CH(3).WF_DATA(7)(4 downto 0) <= SS_CHAIN(954 downto 950);
SS_SH_CH(3).WF_DATA(8)(4 downto 0) <= SS_CHAIN(959 downto 955);
SS_SH_CH(3).WF_DATA(9)(4 downto 0) <= SS_CHAIN(964 downto 960);
SS_SH_CH(3).WF_DATA(10)(4 downto 0) <= SS_CHAIN(969 downto 965);
SS_SH_CH(3).WF_DATA(11)(4 downto 0) <= SS_CHAIN(974 downto 970);
SS_SH_CH(3).WF_DATA(12)(0 downto 0) <= SS_CHAIN(975 downto 975);
SS_SH_CH(3).WF_DATA(12)(4 downto 1) <= SS_CHAIN(979 downto 976);
SS_SH_CH(3).WF_DATA(13)(4 downto 0) <= SS_CHAIN(984 downto 980);
SS_SH_CH(3).WF_DATA(14)(4 downto 0) <= SS_CHAIN(989 downto 985);
SS_SH_CH(3).WF_DATA(15)(1 downto 0) <= SS_CHAIN(991 downto 990);
SS_SH_CH(3).WF_DATA(15)(4 downto 2) <= SS_CHAIN(994 downto 992);
SS_SH_CH(3).WF_DATA(16)(4 downto 0) <= SS_CHAIN(999 downto 995);
SS_SH_CH(3).WF_DATA(17)(4 downto 0) <= SS_CHAIN(1004 downto 1000);
SS_SH_CH(3).WF_DATA(18)(2 downto 0) <= SS_CHAIN(1007 downto 1005);
SS_SH_CH(3).WF_DATA(18)(4 downto 3) <= SS_CHAIN(1009 downto 1008);
SS_SH_CH(3).WF_DATA(19)(4 downto 0) <= SS_CHAIN(1014 downto 1010);
SS_SH_CH(3).WF_DATA(20)(4 downto 0) <= SS_CHAIN(1019 downto 1015);
SS_SH_CH(3).WF_DATA(21)(3 downto 0) <= SS_CHAIN(1023 downto 1020);
SS_SH_CH(3).WF_DATA(21)(4 downto 4) <= SS_CHAIN(1024 downto 1024);
SS_SH_CH(3).WF_DATA(22)(4 downto 0) <= SS_CHAIN(1029 downto 1025);
SS_SH_CH(3).WF_DATA(23)(4 downto 0) <= SS_CHAIN(1034 downto 1030);
SS_SH_CH(3).WF_DATA(24)(4 downto 0) <= SS_CHAIN(1039 downto 1035);
SS_SH_CH(3).WF_DATA(25)(4 downto 0) <= SS_CHAIN(1044 downto 1040);
SS_SH_CH(3).WF_DATA(26)(4 downto 0) <= SS_CHAIN(1049 downto 1045);
SS_SH_CH(3).WF_DATA(27)(4 downto 0) <= SS_CHAIN(1054 downto 1050);
SS_SH_CH(3).WF_DATA(28)(0 downto 0) <= SS_CHAIN(1055 downto 1055);
SS_SH_CH(3).WF_DATA(28)(4 downto 1) <= SS_CHAIN(1059 downto 1056);
SS_SH_CH(3).WF_DATA(29)(4 downto 0) <= SS_CHAIN(1064 downto 1060);
SS_SH_CH(3).WF_DATA(30)(4 downto 0) <= SS_CHAIN(1069 downto 1065);
SS_SH_CH(3).WF_DATA(31)(1 downto 0) <= SS_CHAIN(1071 downto 1070);
SS_SH_CH(3).WF_DATA(31)(4 downto 2) <= SS_CHAIN(1074 downto 1072);
SS_SH_CH(3).WF_ADDR(4 downto 0) <= SS_CHAIN(1079 downto 1075);
SS_SH_CH(3).WF_CNT(7 downto 0) <= SS_CHAIN(1087 downto 1080);
SS_SH_CH(3).WF_CNT(12 downto 8) <= SS_CHAIN(1092 downto 1088);
SS_SH_CH(3).WF_RES <= SS_CHAIN(1093);
SS_SH_CH(3).WF_INC <= SS_CHAIN(1094);
SS_SH_CH(3).LFSR(8 downto 0) <= SS_CHAIN(1103 downto 1095);
SS_SH_CH(3).LFSR(17 downto 9) <= SS_CHAIN(1112 downto 1104);
SS_SH_CH(3).NG_CNT(6 downto 0) <= SS_CHAIN(1119 downto 1113);
SS_SH_CH(3).NG_CNT(11 downto 7) <= SS_CHAIN(1124 downto 1120);
SS_SH_CH(3).DA_OUT(4 downto 0) <= SS_CHAIN(1129 downto 1125);
SS_SH_CH(3).WF_OUT(4 downto 0) <= SS_CHAIN(1134 downto 1130);
SS_SH_CH(3).NG_OUT(0 downto 0) <= SS_CHAIN(1135 downto 1135);
SS_SH_CH(3).NG_OUT(4 downto 1) <= SS_CHAIN(1139 downto 1136);
SS_SH_CH(3).GL_OUT(4 downto 0) <= SS_CHAIN(1144 downto 1140);
SS_SH_CH(3).LFO_FREQ(6 downto 0) <= SS_CHAIN(1151 downto 1145);
SS_SH_CH(3).LFO_FREQ(7 downto 7) <= SS_CHAIN(1152 downto 1152);
SS_SH_CH(3).LFCTL(1 downto 0) <= SS_CHAIN(1154 downto 1153);
SS_SH_CH(3).LFTRG <= SS_CHAIN(1155);
SS_SH_CH(3).LFO_CNT(7 downto 0) <= SS_CHAIN(1163 downto 1156);
SS_SH_CH(3).LFO_ADD(3 downto 0) <= SS_CHAIN(1167 downto 1164);
SS_SH_CH(3).LFO_ADD(11 downto 4) <= SS_CHAIN(1175 downto 1168);
SS_SH_CH(4).FREQ(7 downto 0) <= SS_CHAIN(1183 downto 1176);
SS_SH_CH(4).FREQ(11 downto 8) <= SS_CHAIN(1187 downto 1184);
SS_SH_CH(4).DDA <= SS_CHAIN(1188);
SS_SH_CH(4).CHON <= SS_CHAIN(1189);
SS_SH_CH(4).AL(4 downto 0) <= SS_CHAIN(1194 downto 1190);
SS_SH_CH(4).LAL(3 downto 0) <= SS_CHAIN(1198 downto 1195);
SS_SH_CH(4).RAL(0 downto 0) <= SS_CHAIN(1199 downto 1199);
SS_SH_CH(4).RAL(3 downto 1) <= SS_CHAIN(1202 downto 1200);
SS_SH_CH(4).NG_FREQ(4 downto 0) <= SS_CHAIN(1207 downto 1203);
SS_SH_CH(4).NE <= SS_CHAIN(1208);
SS_SH_CH(4).WF_DATA(0)(4 downto 0) <= SS_CHAIN(1213 downto 1209);
SS_SH_CH(4).WF_DATA(1)(1 downto 0) <= SS_CHAIN(1215 downto 1214);
SS_SH_CH(4).WF_DATA(1)(4 downto 2) <= SS_CHAIN(1218 downto 1216);
SS_SH_CH(4).WF_DATA(2)(4 downto 0) <= SS_CHAIN(1223 downto 1219);
SS_SH_CH(4).WF_DATA(3)(4 downto 0) <= SS_CHAIN(1228 downto 1224);
SS_SH_CH(4).WF_DATA(4)(2 downto 0) <= SS_CHAIN(1231 downto 1229);
SS_SH_CH(4).WF_DATA(4)(4 downto 3) <= SS_CHAIN(1233 downto 1232);
SS_SH_CH(4).WF_DATA(5)(4 downto 0) <= SS_CHAIN(1238 downto 1234);
SS_SH_CH(4).WF_DATA(6)(4 downto 0) <= SS_CHAIN(1243 downto 1239);
SS_SH_CH(4).WF_DATA(7)(3 downto 0) <= SS_CHAIN(1247 downto 1244);
SS_SH_CH(4).WF_DATA(7)(4 downto 4) <= SS_CHAIN(1248 downto 1248);
SS_SH_CH(4).WF_DATA(8)(4 downto 0) <= SS_CHAIN(1253 downto 1249);
SS_SH_CH(4).WF_DATA(9)(4 downto 0) <= SS_CHAIN(1258 downto 1254);
SS_SH_CH(4).WF_DATA(10)(4 downto 0) <= SS_CHAIN(1263 downto 1259);
SS_SH_CH(4).WF_DATA(11)(4 downto 0) <= SS_CHAIN(1268 downto 1264);
SS_SH_CH(4).WF_DATA(12)(4 downto 0) <= SS_CHAIN(1273 downto 1269);
SS_SH_CH(4).WF_DATA(13)(4 downto 0) <= SS_CHAIN(1278 downto 1274);
SS_SH_CH(4).WF_DATA(14)(0 downto 0) <= SS_CHAIN(1279 downto 1279);
SS_SH_CH(4).WF_DATA(14)(4 downto 1) <= SS_CHAIN(1283 downto 1280);
SS_SH_CH(4).WF_DATA(15)(4 downto 0) <= SS_CHAIN(1288 downto 1284);
SS_SH_CH(4).WF_DATA(16)(4 downto 0) <= SS_CHAIN(1293 downto 1289);
SS_SH_CH(4).WF_DATA(17)(1 downto 0) <= SS_CHAIN(1295 downto 1294);
SS_SH_CH(4).WF_DATA(17)(4 downto 2) <= SS_CHAIN(1298 downto 1296);
SS_SH_CH(4).WF_DATA(18)(4 downto 0) <= SS_CHAIN(1303 downto 1299);
SS_SH_CH(4).WF_DATA(19)(4 downto 0) <= SS_CHAIN(1308 downto 1304);
SS_SH_CH(4).WF_DATA(20)(2 downto 0) <= SS_CHAIN(1311 downto 1309);
SS_SH_CH(4).WF_DATA(20)(4 downto 3) <= SS_CHAIN(1313 downto 1312);
SS_SH_CH(4).WF_DATA(21)(4 downto 0) <= SS_CHAIN(1318 downto 1314);
SS_SH_CH(4).WF_DATA(22)(4 downto 0) <= SS_CHAIN(1323 downto 1319);
SS_SH_CH(4).WF_DATA(23)(3 downto 0) <= SS_CHAIN(1327 downto 1324);
SS_SH_CH(4).WF_DATA(23)(4 downto 4) <= SS_CHAIN(1328 downto 1328);
SS_SH_CH(4).WF_DATA(24)(4 downto 0) <= SS_CHAIN(1333 downto 1329);
SS_SH_CH(4).WF_DATA(25)(4 downto 0) <= SS_CHAIN(1338 downto 1334);
SS_SH_CH(4).WF_DATA(26)(4 downto 0) <= SS_CHAIN(1343 downto 1339);
SS_SH_CH(4).WF_DATA(27)(4 downto 0) <= SS_CHAIN(1348 downto 1344);
SS_SH_CH(4).WF_DATA(28)(4 downto 0) <= SS_CHAIN(1353 downto 1349);
SS_SH_CH(4).WF_DATA(29)(4 downto 0) <= SS_CHAIN(1358 downto 1354);
SS_SH_CH(4).WF_DATA(30)(0 downto 0) <= SS_CHAIN(1359 downto 1359);
SS_SH_CH(4).WF_DATA(30)(4 downto 1) <= SS_CHAIN(1363 downto 1360);
SS_SH_CH(4).WF_DATA(31)(4 downto 0) <= SS_CHAIN(1368 downto 1364);
SS_SH_CH(4).WF_ADDR(4 downto 0) <= SS_CHAIN(1373 downto 1369);
SS_SH_CH(4).WF_CNT(1 downto 0) <= SS_CHAIN(1375 downto 1374);
SS_SH_CH(4).WF_CNT(12 downto 2) <= SS_CHAIN(1386 downto 1376);
SS_SH_CH(4).WF_RES <= SS_CHAIN(1387);
SS_SH_CH(4).WF_INC <= SS_CHAIN(1388);
SS_SH_CH(4).LFSR(2 downto 0) <= SS_CHAIN(1391 downto 1389);
SS_SH_CH(4).LFSR(17 downto 3) <= SS_CHAIN(1406 downto 1392);
SS_SH_CH(4).NG_CNT(0 downto 0) <= SS_CHAIN(1407 downto 1407);
SS_SH_CH(4).NG_CNT(11 downto 1) <= SS_CHAIN(1418 downto 1408);
SS_SH_CH(4).DA_OUT(4 downto 0) <= SS_CHAIN(1423 downto 1419);
SS_SH_CH(4).WF_OUT(4 downto 0) <= SS_CHAIN(1428 downto 1424);
SS_SH_CH(4).NG_OUT(4 downto 0) <= SS_CHAIN(1433 downto 1429);
SS_SH_CH(4).GL_OUT(4 downto 0) <= SS_CHAIN(1438 downto 1434);
SS_SH_CH(4).LFO_FREQ(0 downto 0) <= SS_CHAIN(1439 downto 1439);
SS_SH_CH(4).LFO_FREQ(7 downto 1) <= SS_CHAIN(1446 downto 1440);
SS_SH_CH(4).LFCTL(1 downto 0) <= SS_CHAIN(1448 downto 1447);
SS_SH_CH(4).LFTRG <= SS_CHAIN(1449);
SS_SH_CH(4).LFO_CNT(5 downto 0) <= SS_CHAIN(1455 downto 1450);
SS_SH_CH(4).LFO_CNT(7 downto 6) <= SS_CHAIN(1457 downto 1456);
SS_SH_CH(4).LFO_ADD(11 downto 0) <= SS_CHAIN(1469 downto 1458);
SS_SH_CH(5).FREQ(1 downto 0) <= SS_CHAIN(1471 downto 1470);
SS_SH_CH(5).FREQ(11 downto 2) <= SS_CHAIN(1481 downto 1472);
SS_SH_CH(5).DDA <= SS_CHAIN(1482);
SS_SH_CH(5).CHON <= SS_CHAIN(1483);
SS_SH_CH(5).AL(3 downto 0) <= SS_CHAIN(1487 downto 1484);
SS_SH_CH(5).AL(4 downto 4) <= SS_CHAIN(1488 downto 1488);
SS_SH_CH(5).LAL(3 downto 0) <= SS_CHAIN(1492 downto 1489);
SS_SH_CH(5).RAL(3 downto 0) <= SS_CHAIN(1496 downto 1493);
SS_SH_CH(5).NG_FREQ(4 downto 0) <= SS_CHAIN(1501 downto 1497);
SS_SH_CH(5).NE <= SS_CHAIN(1502);
SS_SH_CH(5).WF_DATA(0)(0 downto 0) <= SS_CHAIN(1503 downto 1503);
SS_SH_CH(5).WF_DATA(0)(4 downto 1) <= SS_CHAIN(1507 downto 1504);
SS_SH_CH(5).WF_DATA(1)(4 downto 0) <= SS_CHAIN(1512 downto 1508);
SS_SH_CH(5).WF_DATA(2)(4 downto 0) <= SS_CHAIN(1517 downto 1513);
SS_SH_CH(5).WF_DATA(3)(1 downto 0) <= SS_CHAIN(1519 downto 1518);
SS_SH_CH(5).WF_DATA(3)(4 downto 2) <= SS_CHAIN(1522 downto 1520);
SS_SH_CH(5).WF_DATA(4)(4 downto 0) <= SS_CHAIN(1527 downto 1523);
SS_SH_CH(5).WF_DATA(5)(4 downto 0) <= SS_CHAIN(1532 downto 1528);
SS_SH_CH(5).WF_DATA(6)(2 downto 0) <= SS_CHAIN(1535 downto 1533);
SS_SH_CH(5).WF_DATA(6)(4 downto 3) <= SS_CHAIN(1537 downto 1536);
SS_SH_CH(5).WF_DATA(7)(4 downto 0) <= SS_CHAIN(1542 downto 1538);
SS_SH_CH(5).WF_DATA(8)(4 downto 0) <= SS_CHAIN(1547 downto 1543);
SS_SH_CH(5).WF_DATA(9)(3 downto 0) <= SS_CHAIN(1551 downto 1548);
SS_SH_CH(5).WF_DATA(9)(4 downto 4) <= SS_CHAIN(1552 downto 1552);
SS_SH_CH(5).WF_DATA(10)(4 downto 0) <= SS_CHAIN(1557 downto 1553);
SS_SH_CH(5).WF_DATA(11)(4 downto 0) <= SS_CHAIN(1562 downto 1558);
SS_SH_CH(5).WF_DATA(12)(4 downto 0) <= SS_CHAIN(1567 downto 1563);
SS_SH_CH(5).WF_DATA(13)(4 downto 0) <= SS_CHAIN(1572 downto 1568);
SS_SH_CH(5).WF_DATA(14)(4 downto 0) <= SS_CHAIN(1577 downto 1573);
SS_SH_CH(5).WF_DATA(15)(4 downto 0) <= SS_CHAIN(1582 downto 1578);
SS_SH_CH(5).WF_DATA(16)(0 downto 0) <= SS_CHAIN(1583 downto 1583);
SS_SH_CH(5).WF_DATA(16)(4 downto 1) <= SS_CHAIN(1587 downto 1584);
SS_SH_CH(5).WF_DATA(17)(4 downto 0) <= SS_CHAIN(1592 downto 1588);
SS_SH_CH(5).WF_DATA(18)(4 downto 0) <= SS_CHAIN(1597 downto 1593);
SS_SH_CH(5).WF_DATA(19)(1 downto 0) <= SS_CHAIN(1599 downto 1598);
SS_SH_CH(5).WF_DATA(19)(4 downto 2) <= SS_CHAIN(1602 downto 1600);
SS_SH_CH(5).WF_DATA(20)(4 downto 0) <= SS_CHAIN(1607 downto 1603);
SS_SH_CH(5).WF_DATA(21)(4 downto 0) <= SS_CHAIN(1612 downto 1608);
SS_SH_CH(5).WF_DATA(22)(2 downto 0) <= SS_CHAIN(1615 downto 1613);
SS_SH_CH(5).WF_DATA(22)(4 downto 3) <= SS_CHAIN(1617 downto 1616);
SS_SH_CH(5).WF_DATA(23)(4 downto 0) <= SS_CHAIN(1622 downto 1618);
SS_SH_CH(5).WF_DATA(24)(4 downto 0) <= SS_CHAIN(1627 downto 1623);
SS_SH_CH(5).WF_DATA(25)(3 downto 0) <= SS_CHAIN(1631 downto 1628);
SS_SH_CH(5).WF_DATA(25)(4 downto 4) <= SS_CHAIN(1632 downto 1632);
SS_SH_CH(5).WF_DATA(26)(4 downto 0) <= SS_CHAIN(1637 downto 1633);
SS_SH_CH(5).WF_DATA(27)(4 downto 0) <= SS_CHAIN(1642 downto 1638);
SS_SH_CH(5).WF_DATA(28)(4 downto 0) <= SS_CHAIN(1647 downto 1643);
SS_SH_CH(5).WF_DATA(29)(4 downto 0) <= SS_CHAIN(1652 downto 1648);
SS_SH_CH(5).WF_DATA(30)(4 downto 0) <= SS_CHAIN(1657 downto 1653);
SS_SH_CH(5).WF_DATA(31)(4 downto 0) <= SS_CHAIN(1662 downto 1658);
SS_SH_CH(5).WF_ADDR(0 downto 0) <= SS_CHAIN(1663 downto 1663);
SS_SH_CH(5).WF_ADDR(4 downto 1) <= SS_CHAIN(1667 downto 1664);
SS_SH_CH(5).WF_CNT(11 downto 0) <= SS_CHAIN(1679 downto 1668);
SS_SH_CH(5).WF_CNT(12 downto 12) <= SS_CHAIN(1680 downto 1680);
SS_SH_CH(5).WF_RES <= SS_CHAIN(1681);
SS_SH_CH(5).WF_INC <= SS_CHAIN(1682);
SS_SH_CH(5).LFSR(12 downto 0) <= SS_CHAIN(1695 downto 1683);
SS_SH_CH(5).LFSR(17 downto 13) <= SS_CHAIN(1700 downto 1696);
SS_SH_CH(5).NG_CNT(10 downto 0) <= SS_CHAIN(1711 downto 1701);
SS_SH_CH(5).NG_CNT(11 downto 11) <= SS_CHAIN(1712 downto 1712);
SS_SH_CH(5).DA_OUT(4 downto 0) <= SS_CHAIN(1717 downto 1713);
SS_SH_CH(5).WF_OUT(4 downto 0) <= SS_CHAIN(1722 downto 1718);
SS_SH_CH(5).NG_OUT(4 downto 0) <= SS_CHAIN(1727 downto 1723);
SS_SH_CH(5).GL_OUT(4 downto 0) <= SS_CHAIN(1732 downto 1728);
SS_SH_CH(5).LFO_FREQ(7 downto 0) <= SS_CHAIN(1740 downto 1733);
SS_SH_CH(5).LFCTL(1 downto 0) <= SS_CHAIN(1742 downto 1741);
SS_SH_CH(5).LFTRG <= SS_CHAIN(1743);
SS_SH_CH(5).LFO_CNT(7 downto 0) <= SS_CHAIN(1751 downto 1744);
SS_SH_CH(5).LFO_ADD(7 downto 0) <= SS_CHAIN(1759 downto 1752);
SS_SH_CH(5).LFO_ADD(11 downto 8) <= SS_CHAIN(1763 downto 1760);
SS_SH_CHSEL <= to_integer(unsigned(SS_CHAIN(1766 downto 1764)));
SS_SH_LACC(8 downto 0) <= SS_CHAIN(1775 downto 1767);
SS_SH_LACC(23 downto 9) <= SS_CHAIN(1790 downto 1776);
SS_SH_LDATA_FF(0 downto 0) <= SS_CHAIN(1791 downto 1791);
SS_SH_LDATA_FF(16 downto 1) <= SS_CHAIN(1807 downto 1792);
SS_SH_LDATA_FF(23 downto 17) <= SS_CHAIN(1814 downto 1808);
SS_SH_LMAL(3 downto 0) <= SS_CHAIN(1818 downto 1815);
SS_SH_MIX <= mix_t'val(to_integer(unsigned(SS_CHAIN(1821 downto 1819)))) when to_integer(unsigned(SS_CHAIN(1821 downto 1819))) <= 6 else mix_t'val(0);
SS_SH_MIX_CNT(1 downto 0) <= SS_CHAIN(1823 downto 1822);
SS_SH_MIX_CNT(2 downto 2) <= SS_CHAIN(1824 downto 1824);
SS_SH_RACC(14 downto 0) <= SS_CHAIN(1839 downto 1825);
SS_SH_RACC(23 downto 15) <= SS_CHAIN(1848 downto 1840);
SS_SH_RDATA_FF(6 downto 0) <= SS_CHAIN(1855 downto 1849);
SS_SH_RDATA_FF(22 downto 7) <= SS_CHAIN(1871 downto 1856);
SS_SH_RDATA_FF(23 downto 23) <= SS_CHAIN(1872 downto 1872);
SS_SH_RMAL(3 downto 0) <= SS_CHAIN(1876 downto 1873);
SS_SH_VT_ADDR(10 downto 0) <= SS_CHAIN(1887 downto 1877);
SS_SH_VT_ADDR(11 downto 11) <= SS_CHAIN(1888 downto 1888);


SS_RDO <= SS_R_VT or SS_LOCAL_RDO;
end rtl;

