library STD;
use STD.TEXTIO.ALL;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_TEXTIO.all;
use IEEE.NUMERIC_STD.ALL;

entity cd is
	port(
 SS_RROTATE : in std_logic := '0';
 SS_RADDR : in std_logic_vector(14 downto 0) := (others=>'0');
 SS_RDI : in std_logic_vector(15 downto 0) := (others=>'0');
 SS_RWE : in std_logic := '0';
 SS_RDO : out std_logic_vector(15 downto 0);
 SS_UNSAFE : out std_logic;
 -- Qualification only; native CD address decoding is unchanged.
 SS_HUCARD : in std_logic := '0';
 SS_NEW_CART : in std_logic := '0';
 SS_ADPCM_ADDR : in std_logic_vector(16 downto 0) := (others=>'0');
 SS_ADPCM_DI : in std_logic_vector(3 downto 0) := (others=>'0');
 SS_ADPCM_WE : in std_logic := '0';
 SS_ADPCM_DO : out std_logic_vector(3 downto 0);
 SS_FREEZE : in std_logic := '0';
 SS_SAVE : in std_logic := '0';
        SS_LIVE_CUT : in std_logic := '0'; -- private live capture; never a freeze
 SS_LOAD : in std_logic := '0';
 SS_COMPACT : in std_logic := '0';

		RST_N			: in  std_logic;
		CLK 			: in  std_logic;
		EN 			: in  std_logic;

		EXT_A 		: in  std_logic_vector(20 downto 0);
		EXT_DI 		: in  std_logic_vector(7 downto 0);
		EXT_DO 		: buffer std_logic_vector(7 downto 0);
		EXT_WR_N		: in  std_logic;
		EXT_RD_N		: in  std_logic;
		CPU_CE		: in  std_logic;
		
		SEL_N			: buffer std_logic;
		IRQ_N			: buffer std_logic;
		
		RAM_CS_N		: buffer std_logic;
		BRAM_EN		: buffer std_logic;
		
		CD_STAT		: in std_logic_vector(7 downto 0);
		CD_MSG		: in std_logic_vector(7 downto 0);
		CD_STAT_GET	: in std_logic;
		
		CD_COMM		: buffer std_logic_vector(95 downto 0);
		CD_COMM_SEND: buffer std_logic;
		
		CD_DOUT_REQ	: in std_logic;
		CD_DOUT		: buffer std_logic_vector(79 downto 0);
		CD_DOUT_SEND: buffer std_logic;
		
		CD_REGION   : in  std_logic;
		CD_RESET		: buffer std_logic;
		
		CD_DATA		: in std_logic_vector(7 downto 0);
		CD_DATA_WR	: in std_logic;
		CD_AUDIO_WR	: in std_logic;
		CD_SUBCD_WR	: in std_logic;
		CD_DATA_END	: buffer std_logic;
		
		DM				: in std_logic;
		
		CD_SL			: buffer signed(15 downto 0);
		CD_SR			: buffer signed(15 downto 0);
		AD_S			: buffer signed(15 downto 0)
	);
end cd;

architecture rtl of cd is

	signal REG_SEL 			: std_logic;
	signal RAM_SEL 			: std_logic;
	signal CDRAM_DO			: std_logic_vector(7 downto 0);
	
	signal SCSI_DBI			: std_logic_vector(7 downto 0);
	signal SCSI_DBO			: std_logic_vector(7 downto 0);
	signal SCSI_ACK_N			: std_logic;
	signal SCSI_RST_N			: std_logic;
	signal SCSI_SEL_N			: std_logic;
	signal SCSI_BSY_N			: std_logic;
	signal SCSI_REQ_N			: std_logic;
	signal SCSI_MSG_N			: std_logic;
	signal SCSI_CD_N			: std_logic;
	signal SCSI_IO_N			: std_logic;
	signal CD_STOP_CD_SND	: std_logic;
	
	signal CD_DTD				: std_logic;	--CD data transfer done flag
	signal CD_DTR				: std_logic;	--CD data transfer ready flag
	signal CD_SUBCD			: std_logic;	--CD Subcode data ready flag
	signal CD_DTD_EN			: std_logic;
	signal CD_DTR_EN			: std_logic;
--	signal CD_MOTOR			: std_logic;
	signal CD_SUBCD_EN		: std_logic;
	signal ADPCM_END_EN		: std_logic;
	signal ADPCM_HALF_EN		: std_logic;
	signal CH_SEL				: std_logic;
	signal BRAM_LOCK			: std_logic;
	
	signal AUTO_ACK			: std_logic;
	signal TR_DONE_OLD		: std_logic;
	signal TR_RDY_OLD			: std_logic;
	signal SCSI_REQ_N_OLD	: std_logic;
	signal SCSI_BSY_N_OLD	: std_logic;
	signal SCSI_ACK_N_OLD	: std_logic;
	signal CD_DATA_CNT		: unsigned(10 downto 0);
	
	signal R1802_0				: std_logic;
	signal R1802_1				: std_logic;
	signal R180E_7_4			: std_logic_vector(3 downto 0);
	signal R180F_0				: std_logic;
	signal R180F_7_4			: std_logic_vector(3 downto 0);
	
	signal CDDA_VOL			: std_logic_vector(15 downto 0);
	
	--ADPCM controller
	signal ADPCM_OFFS			: std_logic_vector(15 downto 0);
	signal ADPCM_LEN			: std_logic_vector(16 downto 0);
	signal ADPCM_RDADDR		: std_logic_vector(16 downto 0);
	signal ADPCM_WRADDR		: std_logic_vector(16 downto 0);
	signal ADPCM_CTRL			: std_logic_vector(7 downto 0);
	signal ADPCM_DMA_EN		: std_logic;
	signal ADPCM_DMA_RUN		: std_logic;
	signal ADPCM_END			: std_logic;							--ADPCM end reached flag
	signal ADPCM_HALF			: std_logic;							--ADPCM half reached flag
	signal ADPCM_PLAY			: std_logic;
	signal ADPCM_FREQ			: std_logic_vector(3 downto 0);
	signal ADPCM_FADER		: std_logic_vector(2 downto 0);
	signal ADPCM_RDDATA		: std_logic_vector(7 downto 0);
	signal ADPCM_WRDATA		: std_logic_vector(7 downto 0);
	signal ADPCM_WRITE_PEND	: std_logic;
	signal ADPCM_READ_PEND	: std_logic;
	signal PLAY_READ_PEND	: std_logic;
	signal DMA_WRITE_PEND	: std_logic := '0';
	signal ADPCM_WRITE_NIB	: std_logic;
	signal ADPCM_READ_NIB	: std_logic;
	signal WRITE_PEND			: std_logic;
	signal READ_PEND			: std_logic;
	
	--ADPCM DRAM
	signal ADRAM_A				: std_logic_vector(16 downto 0);
	signal ADRAM_DI			: std_logic_vector(3 downto 0);
	signal ADRAM_DO			: std_logic_vector(3 downto 0);
	signal ADRAM_WE			: std_logic;
	
	type DRAMSlot_t is (
		SLOT_REFRESH,
		SLOT_READ,
		SLOT_WRITE
	);
	signal DRAM_SLOT 			: DRAMSlot_t; 
	signal DRAM_CLK_CNT		: unsigned(4 downto 0);
	signal DRAM_CLKEN			: std_logic;
	signal DRAM_SLOT_CNT		: unsigned(1 downto 0);
	
	--ADPCM decoder
	signal M5205_D				: std_logic_vector(3 downto 0);
	signal M5205_CLK			: std_logic;
	signal M5205_VCK_R		: std_logic;
	signal M5205_VCK_F		: std_logic;
	signal M5205_SOUT			: signed(15 downto 0);
	signal M5205_CLK_CNT 	: integer range 0 to 511;
	type M5205ClockTable_t is array (0 to 15) of integer range 0 to 511;
	constant ACT : M5205ClockTable_t :=
	(443,	--96712Hz
	 415,	--103199Hz
	 387,	--110619Hz
	 360,	--119048Hz
	 332,	--129032Hz
	 304,	--140647Hz
	 276,	--154799Hz
	 249,	--171821Hz
	 221,	--193424Hz
	 193,	--221239Hz
	 166,	--257732Hz
	 138,	--309598Hz
	 110,	--386100Hz
	 82,	--515464Hz
	 55,	--769231Hz
	 27	--1538462Hz
	);
	
	--CDDA
	signal CD_WR_OLD 			: std_logic;
	signal CD_BYTE_CNT		: unsigned(1 downto 0);
	signal FIFO_FULL 			: std_logic;
	signal FIFO_EMPTY 		: std_logic;
	signal FIFO_RD_REQ		: std_logic;
	signal FIFO_WR_REQ		: std_logic;
	signal FIFO_D 				: std_logic_vector(31 downto 0);
	signal FIFO_Q 				: std_logic_vector(31 downto 0);
	signal FIFO_SCLR			: std_logic;
	signal CDDA_CE 			: std_logic;
	signal ADPCM_CE         : std_logic;
	signal CDDA_SAMPLE		: std_logic;
	signal CDDA_SAMPLE_OLD	: std_logic;
	signal OUTL 				: signed(15 downto 0);
	signal OUTR 				: signed(15 downto 0);
	
	--CD SUBCODE
	signal SUBCD_WR_OLD 			: std_logic;
	signal SUBCD_FIFO_FULL 		: std_logic;
	signal SUBCD_FIFO_EMPTY 	: std_logic;
	signal SUBCD_FIFO_RD_REQ	: std_logic;
	signal SUBCD_FIFO_WR_REQ	: std_logic;
	signal SUBCD_FIFO_D 			: std_logic_vector(7 downto 0);
	signal SUBCD_FIFO_Q 			: std_logic_vector(7 downto 0);
	signal SUBCD_FIFO_SCLR		: std_logic;
	signal SUBCD_CE			: std_logic;
	signal SUBCD_CE_OLD		: std_logic;
	signal SUBCD_CNT			: unsigned(3 downto 0);
	signal SUBCD_BYTE			: std_logic_vector(7 downto 0);
	signal SUBCD_BYTENUM		: unsigned(7 downto 0);
	
	--Fader
	signal FADE_VOL 			: unsigned(10 downto 0);
	signal FADE_CNT 			: unsigned(7 downto 0);
	signal CDDA_FADE_VOL		: unsigned(10 downto 0);
	signal ADPCM_FADE_VOL	: unsigned(10 downto 0);

signal SS_SH_ADPCM_CTRL : std_logic_vector(7 downto 0);
signal SS_SH_ADPCM_DMA_EN : std_logic;
signal SS_SH_ADPCM_DMA_RUN : std_logic;
signal SS_SH_ADPCM_END : std_logic;
signal SS_SH_ADPCM_END_EN : std_logic;
signal SS_SH_ADPCM_FADER : std_logic_vector(2 downto 0);
signal SS_SH_ADPCM_FREQ : std_logic_vector(3 downto 0);
signal SS_SH_ADPCM_HALF : std_logic;
signal SS_SH_ADPCM_HALF_EN : std_logic;
signal SS_SH_ADPCM_LEN : std_logic_vector(16 downto 0);
signal SS_SH_ADPCM_OFFS : std_logic_vector(15 downto 0);
signal SS_SH_ADPCM_PLAY : std_logic;
signal SS_SH_ADPCM_RDADDR : std_logic_vector(16 downto 0);
signal SS_SH_ADPCM_RDDATA : std_logic_vector(7 downto 0);
signal SS_SH_ADPCM_READ_NIB : std_logic;
signal SS_SH_ADPCM_READ_PEND : std_logic;
signal SS_SH_ADPCM_WRADDR : std_logic_vector(16 downto 0);
signal SS_SH_ADPCM_WRDATA : std_logic_vector(7 downto 0);
signal SS_SH_ADPCM_WRITE_NIB : std_logic;
signal SS_SH_ADPCM_WRITE_PEND : std_logic;
signal SS_SH_AUTO_ACK : std_logic;
signal SS_SH_BRAM_LOCK : std_logic;
signal SS_SH_CDDA_SAMPLE : std_logic;
signal SS_SH_CDDA_SAMPLE_OLD : std_logic;
signal SS_SH_CDDA_VOL : std_logic_vector(15 downto 0);
signal SS_SH_CD_BYTE_CNT : unsigned(1 downto 0);
signal SS_SH_CD_DATA_CNT : unsigned(10 downto 0);
signal SS_SH_CD_DTD : std_logic;
signal SS_SH_CD_DTD_EN : std_logic;
signal SS_SH_CD_DTR : std_logic;
signal SS_SH_CD_DTR_EN : std_logic;
signal SS_SH_CD_SUBCD : std_logic;
signal SS_SH_CD_SUBCD_EN : std_logic;
signal SS_SH_CD_WR_OLD : std_logic;
signal SS_SH_CH_SEL : std_logic;
signal SS_SH_DMA_WRITE_PEND : std_logic;
signal SS_SH_DRAM_CLKEN : std_logic;
signal SS_SH_DRAM_CLK_CNT : unsigned(4 downto 0);
signal SS_SH_DRAM_SLOT_CNT : unsigned(1 downto 0);
signal SS_SH_FADE_CNT : unsigned(7 downto 0);
signal SS_SH_FADE_VOL : unsigned(10 downto 0);
signal SS_SH_FIFO_D : std_logic_vector(31 downto 0);
signal SS_SH_FIFO_RD_REQ : std_logic;
signal SS_SH_FIFO_SCLR : std_logic;
signal SS_SH_FIFO_WR_REQ : std_logic;
signal SS_SH_M5205_CLK : std_logic;
signal SS_SH_M5205_CLK_CNT : integer range 0 to 511;
signal SS_SH_M5205_D : std_logic_vector(3 downto 0);
signal SS_SH_OUTL : signed(15 downto 0);
signal SS_SH_OUTR : signed(15 downto 0);
signal SS_SH_PLAY_READ_PEND : std_logic;
signal SS_SH_R1802_0 : std_logic;
signal SS_SH_R1802_1 : std_logic;
signal SS_SH_R180E_7_4 : std_logic_vector(3 downto 0);
signal SS_SH_R180F_0 : std_logic;
signal SS_SH_R180F_7_4 : std_logic_vector(3 downto 0);
signal SS_SH_SCSI_ACK_N : std_logic;
signal SS_SH_SCSI_ACK_N_OLD : std_logic;
signal SS_SH_SCSI_BSY_N_OLD : std_logic;
signal SS_SH_SCSI_DBI : std_logic_vector(7 downto 0);
signal SS_SH_SCSI_REQ_N_OLD : std_logic;
signal SS_SH_SCSI_RST_N : std_logic;
signal SS_SH_SCSI_SEL_N : std_logic;
signal SS_SH_SUBCD_BYTE : std_logic_vector(7 downto 0);
signal SS_SH_SUBCD_BYTENUM : unsigned(7 downto 0);
signal SS_SH_SUBCD_CE : std_logic;
signal SS_SH_SUBCD_CE_OLD : std_logic;
signal SS_SH_SUBCD_CNT : unsigned(3 downto 0);
signal SS_SH_SUBCD_FIFO_D : std_logic_vector(7 downto 0);
signal SS_SH_SUBCD_FIFO_RD_REQ : std_logic;
signal SS_SH_SUBCD_FIFO_SCLR : std_logic;
signal SS_SH_SUBCD_FIFO_WR_REQ : std_logic;
signal SS_SH_SUBCD_WR_OLD : std_logic;
signal SS_CHAIN, SS_CAPTURE_DATA : std_logic_vector(319 downto 0);
signal SS_LIVE_PENDING : std_logic_vector(1 downto 0) := "00";
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_CHILD_SCSI, SS_CHILD_MSM, SS_CHILD_CE_A, SS_CHILD_CE_B, SS_CHILD_RAM : std_logic_vector(15 downto 0);
signal SS_UNSAFE_LATCH : std_logic := '0';
signal SS_SCSI_IDLE, SS_SCSI_FIFO_WRITE, SS_CD_EVENT : std_logic;
signal SS_REG_READ_SIDE_EFFECT : std_logic;
signal SS_REG_WRITE_UNCAPTURED : std_logic;
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);

begin

	
-- Only reads 03/07/08/0A have sequential effects. Captured BRAM control is
-- the sole HuCard register exception; other writes stay guarded.
-- HuCard 0x0D0000..0x0FFFFF reads return ROM, not CD RAM. Do not poison
-- that cartridge's snapshot eligibility merely because both decoders match.
-- Reads above the ROM window and every read in CD mode remain guarded.
-- HuCard backup-RAM control is already captured in both snapshot profiles:
-- BRAM_LOCK is chain bit 110 (word 585 bit 14), and the 2 KiB BRAM plus its read
-- latch are in the core image. Do not classify those two accesses as omitted
-- CD state. All other register, RAM, host, ADPCM and FIFO guards stay intact.
SS_REG_WRITE_UNCAPTURED <= '0' when SS_HUCARD='1' and EXT_A(7 downto 0)=x"07" else '1';
SS_REG_READ_SIDE_EFFECT <= '1' when (EXT_A(7 downto 0)=x"03" and SS_HUCARD/='1') or EXT_A(7 downto 0)=x"07" or EXT_A(7 downto 0)=x"08" or EXT_A(7 downto 0)=x"0A" else '0';
SS_CD_EVENT <= (REG_SEL and CPU_CE and ((not EXT_WR_N and SS_REG_WRITE_UNCAPTURED) or (not EXT_RD_N and SS_REG_READ_SIDE_EFFECT))) or (RAM_SEL and CPU_CE and (not EXT_WR_N or (not EXT_RD_N and (not SS_HUCARD or EXT_A(20))))) or CD_STAT_GET or CD_DOUT_REQ or CD_DATA_WR or CD_AUDIO_WR or CD_SUBCD_WR or ADRAM_WE or FIFO_WR_REQ or SUBCD_FIFO_WR_REQ or SS_SCSI_FIFO_WRITE;
SS_UNSAFE <= SS_UNSAFE_LATCH or SS_CD_EVENT or not (FIFO_EMPTY and SUBCD_FIFO_EMPTY and SS_SCSI_IDLE) or FIFO_WR_REQ or FIFO_RD_REQ or FIFO_SCLR or SUBCD_FIFO_WR_REQ or SUBCD_FIFO_RD_REQ or SUBCD_FIFO_SCLR;
process(CLK) begin if rising_edge(CLK) then
 -- A real cartridge change starts a new observation epoch only after
 -- the machine has consumed reset. Soft reset retains unsafe history.
 -- Any later CD access/write immediately blocks again before its edge.
 if SS_NEW_CART='1' and RST_N='0' then
   SS_UNSAFE_LATCH <= '0';
 elsif SS_CD_EVENT='1' then
   SS_UNSAFE_LATCH <= '1';
 end if;
end if; end process;

REG_SEL <= '1' when EXT_A(20 downto 13) = x"FF" and EXT_A(12 downto 8) = "11000" else '0';

	process( CLK, RST_N ) 
	variable NEW_ADPCM_LEN : std_logic_vector(16 downto 0);
	begin
		if RST_N = '0' then
			SCSI_DBI <= (others => '0');
			SCSI_ACK_N <= '1';
			SCSI_RST_N <= '1';
			SCSI_SEL_N <= '1';
			CD_DTD <= '0';
			CD_DTR <= '0';
			CD_SUBCD <= '0';
			CH_SEL <= '0';
			BRAM_LOCK <= '1';
			CD_DTD_EN <= '0';
			CD_DTR_EN <= '0';

			CD_SUBCD_EN <= '0';
			ADPCM_END_EN <= '0';
			ADPCM_HALF_EN <= '0';
			AUTO_ACK <= '0';
			
			CDDA_VOL <= (others => '0');
			
			SUBCD_CE_OLD <= '0';
			ADPCM_OFFS <= (others => '0');
			ADPCM_LEN <= (others => '0');
			ADPCM_RDADDR <= (others => '0');
			ADPCM_WRADDR <= (others => '0');
			ADPCM_CTRL <= (others => '0');
			ADPCM_DMA_EN <= '0';
			ADPCM_DMA_RUN <= '0';
			ADPCM_END <= '0';
			ADPCM_HALF <= '0';
			ADPCM_PLAY <= '0';
			ADPCM_FREQ <= (others => '0');
			ADPCM_WRDATA <= (others => '0');
			ADPCM_RDDATA <= (others => '0');
			ADPCM_WRITE_PEND <= '0';
			ADPCM_READ_PEND <= '0';
			PLAY_READ_PEND <= '0';
			ADPCM_WRITE_NIB <= '0';
			ADPCM_READ_NIB <= '0';
			M5205_D <= (others => '0');
		elsif rising_edge( CLK ) then
if SS_LOAD = '1' then
ADPCM_CTRL <= SS_SH_ADPCM_CTRL;
ADPCM_DMA_EN <= SS_SH_ADPCM_DMA_EN;
ADPCM_DMA_RUN <= SS_SH_ADPCM_DMA_RUN;
ADPCM_END <= SS_SH_ADPCM_END;
ADPCM_END_EN <= SS_SH_ADPCM_END_EN;
ADPCM_FADER <= SS_SH_ADPCM_FADER;
ADPCM_FREQ <= SS_SH_ADPCM_FREQ;
ADPCM_HALF <= SS_SH_ADPCM_HALF;
ADPCM_HALF_EN <= SS_SH_ADPCM_HALF_EN;
ADPCM_LEN <= SS_SH_ADPCM_LEN;
ADPCM_OFFS <= SS_SH_ADPCM_OFFS;
ADPCM_PLAY <= SS_SH_ADPCM_PLAY;
ADPCM_RDADDR <= SS_SH_ADPCM_RDADDR;
ADPCM_RDDATA <= SS_SH_ADPCM_RDDATA;
ADPCM_READ_NIB <= SS_SH_ADPCM_READ_NIB;
ADPCM_READ_PEND <= SS_SH_ADPCM_READ_PEND;
ADPCM_WRADDR <= SS_SH_ADPCM_WRADDR;
ADPCM_WRDATA <= SS_SH_ADPCM_WRDATA;
ADPCM_WRITE_NIB <= SS_SH_ADPCM_WRITE_NIB;
ADPCM_WRITE_PEND <= SS_SH_ADPCM_WRITE_PEND;
AUTO_ACK <= SS_SH_AUTO_ACK;
BRAM_LOCK <= SS_SH_BRAM_LOCK;
CDDA_SAMPLE_OLD <= SS_SH_CDDA_SAMPLE_OLD;
CDDA_VOL <= SS_SH_CDDA_VOL;
CD_DATA_CNT <= SS_SH_CD_DATA_CNT;
CD_DTD <= SS_SH_CD_DTD;
CD_DTD_EN <= SS_SH_CD_DTD_EN;
CD_DTR <= SS_SH_CD_DTR;
CD_DTR_EN <= SS_SH_CD_DTR_EN;
CD_SUBCD <= SS_SH_CD_SUBCD;
CD_SUBCD_EN <= SS_SH_CD_SUBCD_EN;
CH_SEL <= SS_SH_CH_SEL;
DMA_WRITE_PEND <= SS_SH_DMA_WRITE_PEND;
M5205_D <= SS_SH_M5205_D;
PLAY_READ_PEND <= SS_SH_PLAY_READ_PEND;
R1802_0 <= SS_SH_R1802_0;
R1802_1 <= SS_SH_R1802_1;
R180E_7_4 <= SS_SH_R180E_7_4;
R180F_0 <= SS_SH_R180F_0;
R180F_7_4 <= SS_SH_R180F_7_4;
SCSI_ACK_N <= SS_SH_SCSI_ACK_N;
SCSI_ACK_N_OLD <= SS_SH_SCSI_ACK_N_OLD;
SCSI_BSY_N_OLD <= SS_SH_SCSI_BSY_N_OLD;
SCSI_DBI <= SS_SH_SCSI_DBI;
SCSI_REQ_N_OLD <= SS_SH_SCSI_REQ_N_OLD;
SCSI_RST_N <= SS_SH_SCSI_RST_N;
SCSI_SEL_N <= SS_SH_SCSI_SEL_N;
SUBCD_CE_OLD <= SS_SH_SUBCD_CE_OLD;
elsif SS_FREEZE = '0' then

			if EN = '1' then
			if CPU_CE = '1' then
				SCSI_SEL_N <= '1';
				if REG_SEL = '1' and EXT_WR_N = '0' then
					case EXT_A(7 downto 0) is
						when x"00" =>
							SCSI_SEL_N <= '0';
							CD_DTD <= '0';
							CD_DTR <= '0';



						when x"01" =>
							SCSI_DBI <= EXT_DI;
						when x"02" =>
							SCSI_ACK_N <= not EXT_DI(7);
							CD_DTR_EN <= EXT_DI(6);
							CD_DTD_EN <= EXT_DI(5);
							CD_SUBCD_EN <= EXT_DI(4);
							ADPCM_END_EN <= EXT_DI(3);
							ADPCM_HALF_EN <= EXT_DI(2);
							R1802_1 <= EXT_DI(1);
							R1802_0 <= EXT_DI(0);
						when x"04" =>
							SCSI_RST_N <= not EXT_DI(1);
							if EXT_DI(1) = '1' then
								CD_DTD <= '0';
								CD_DTR <= '0';
							end if;
						when x"05" =>
							if CDDA_SAMPLE = '1' and CDDA_SAMPLE_OLD = '0' then
								if CH_SEL = '0' then
									CDDA_VOL <= std_logic_vector(OUTL);   
								else
									CDDA_VOL <= std_logic_vector(OUTR);
								end if;
								CH_SEL <= not CH_SEL;
							end if;
							CDDA_SAMPLE_OLD <= CDDA_SAMPLE;
							
						when x"07" =>
							BRAM_LOCK <= not EXT_DI(7);  
						when x"08" =>
							ADPCM_OFFS(7 downto 0) <= EXT_DI;
						when x"09" =>
							ADPCM_OFFS(15 downto 8) <= EXT_DI;
						when x"0A" =>
							ADPCM_WRDATA <= EXT_DI;
							ADPCM_WRITE_NIB <= '0';
							ADPCM_WRITE_PEND <= '1';
						when x"0B" =>
							ADPCM_DMA_EN <= EXT_DI(1);
							ADPCM_DMA_RUN <= EXT_DI(0);
						when x"0D" =>
							ADPCM_CTRL <= EXT_DI;
							if EXT_DI(5) = '1' and ADPCM_CTRL(5) = '0' then
								ADPCM_PLAY <= '1';
								ADPCM_HALF <= '0';
							elsif EXT_DI(5) = '0' and ADPCM_CTRL(5) = '1' then
								ADPCM_PLAY <= '0';
							end if;
						when x"0E" =>
							R180E_7_4 <= EXT_DI(7 downto 4);
							ADPCM_FREQ <= EXT_DI(3 downto 0);
						when x"0F" =>
							R180F_7_4 <= EXT_DI(7 downto 4);
							ADPCM_FADER <= EXT_DI(3 downto 1);
							R180F_0 <= EXT_DI(0);
						when others => null;
					end case;
				elsif REG_SEL = '1' and EXT_RD_N = '0' then
					case EXT_A(7 downto 0) is
						when x"03" =>
							BRAM_LOCK <= '1';
						when x"07" =>
							CD_SUBCD <= '0';
						when x"08" =>
							if SCSI_REQ_N = '0' and SCSI_IO_N = '0' and SCSI_CD_N = '1' and SCSI_ACK_N = '1' then 
								SCSI_ACK_N <= '0';
								AUTO_ACK <= '1';
							end if;
						when x"0A" =>
							ADPCM_READ_NIB <= '0';
							ADPCM_READ_PEND <= '1';
						when others => null;
					end case;
				end if;
			end if;
			
			if AUTO_ACK = '1' and SCSI_REQ_N = '1' then
				SCSI_ACK_N <= '1';
				AUTO_ACK <= '0';
			end if;
			
			if (ADPCM_DMA_EN = '1' or ADPCM_DMA_RUN = '1') and DMA_WRITE_PEND = '0' then
				if SCSI_REQ_N = '0' and SCSI_IO_N = '0' and SCSI_CD_N = '1' and SCSI_ACK_N = '1' then
					ADPCM_WRDATA <= SCSI_DBO;
					DMA_WRITE_PEND <= '1';
				end if;
			end if;
			
			SCSI_REQ_N_OLD <= SCSI_REQ_N;
			SCSI_BSY_N_OLD <= SCSI_BSY_N;
			if CD_DTD = '0' and SCSI_REQ_N = '0' and SCSI_REQ_N_OLD = '1' and SCSI_BSY_N = '0' and SCSI_IO_N = '0' and SCSI_CD_N = '0' then
				CD_DTD <= '1';
			elsif CD_DTD = '1' and ((SCSI_REQ_N = '1' and SCSI_REQ_N_OLD = '0' and SCSI_MSG_N = '0') or (SCSI_BSY_N = '1' and SCSI_BSY_N_OLD = '0')) then
				CD_DTD <= '0';
			end if;
			
			SCSI_ACK_N_OLD <= SCSI_ACK_N;
			if CD_DTR = '0' and SCSI_REQ_N = '0' and SCSI_BSY_N = '0' and SCSI_CD_N = '1' and SCSI_MSG_N = '1' and SCSI_IO_N = '0' then
				CD_DTR <= '1';
				CD_DATA_CNT <= (others => '0');
			elsif CD_DTR = '1' and SCSI_ACK_N = '1' and SCSI_ACK_N_OLD = '0' and SCSI_BSY_N = '0' and SCSI_CD_N = '1' and SCSI_MSG_N = '1' and SCSI_IO_N = '0' then
				CD_DATA_CNT <= CD_DATA_CNT + 1;
				if CD_DATA_CNT = 2047 then
					CD_DTR <= '0';
					ADPCM_DMA_RUN <= '0';
				end if;
			elsif CD_DTR = '1' and (SCSI_BSY_N = '1' and SCSI_BSY_N_OLD = '0') then
				CD_DTR <= '0';
			end if;

			SUBCD_CE_OLD <= SUBCD_CE;
			if CD_SUBCD = '0' and SUBCD_CE = '1' and SUBCD_CE_OLD = '0' then
				CD_SUBCD <= '1';
			end if;
			
			if M5205_VCK_R = '1' and ADPCM_PLAY = '1' then
				PLAY_READ_PEND <= '1';
			end if;
			
			if DRAM_CLKEN = '1' and ADPCM_CTRL(7) = '0' then
				case DRAM_SLOT is
					when SLOT_READ =>
						NEW_ADPCM_LEN := std_logic_vector(unsigned(ADPCM_LEN) - 1);
						if ADPCM_READ_PEND = '1' or PLAY_READ_PEND = '1' then
							M5205_D <= ADRAM_DO;
							if PLAY_READ_PEND = '1' then
								PLAY_READ_PEND <= '0';
							end if;
							
							ADPCM_READ_NIB <= not ADPCM_READ_NIB;
							if ADPCM_READ_NIB = '0' then
								ADPCM_RDDATA(7 downto 4) <= ADRAM_DO;
							else
								ADPCM_RDDATA(3 downto 0) <= ADRAM_DO;
							end if;
							if ADPCM_READ_NIB = '1' then
								if ADPCM_LEN /= "0"&x"0000" then
									ADPCM_LEN <= NEW_ADPCM_LEN;
								end if;
								if ADPCM_READ_PEND = '1' then
									ADPCM_READ_PEND <= '0';
								end if;
							end if;
							if ADPCM_LEN < "0"&x"8000" then
								ADPCM_HALF <= '1';
							elsif ADPCM_LEN = "0"&x"8000" and ADPCM_CTRL(4) = '0' then
								ADPCM_HALF <= '1';
							else
								ADPCM_HALF <= '0';
							end if;
							if ADPCM_LEN = "0"&x"0000" then
								ADPCM_END <= '1';
								if ADPCM_READ_PEND = '1' and ADPCM_CTRL(4) = '0' then
									ADPCM_HALF <= '0';
								end if;
								if ADPCM_CTRL(6) = '1' and ADPCM_PLAY = '1' then
									ADPCM_PLAY <= '0';
									M5205_D <= (others => '0');
									ADPCM_CTRL(5) <= '0';
								end if;
							end if;
						end if;
						
					when SLOT_WRITE =>
						NEW_ADPCM_LEN := std_logic_vector(unsigned(ADPCM_LEN) + 1);
						if ADPCM_WRITE_PEND = '1' or DMA_WRITE_PEND = '1' then
							ADPCM_WRITE_NIB <= not ADPCM_WRITE_NIB;
							if ADPCM_WRITE_NIB = '1' then
								ADPCM_LEN <= NEW_ADPCM_LEN;
								if ADPCM_WRITE_PEND = '1' then
									ADPCM_WRITE_PEND <= '0';
								end if;
								if DMA_WRITE_PEND = '1' then
									DMA_WRITE_PEND <= '0';
									SCSI_ACK_N <= '0';
									AUTO_ACK <= '1';
								end if;
							end if;
							ADPCM_HALF <= not ADPCM_LEN(15) and not ADPCM_LEN(16);
							if ADPCM_LEN = "0"&x"0000" then
								ADPCM_END <= '1';
							end if;
						end if;
						
					when others => null;
				end case;
			end if;
			
			if ADPCM_CTRL(4) = '1' then
				ADPCM_LEN <= "0"&ADPCM_OFFS;
				ADPCM_END <= '0';
			end if;
			
			if ADPCM_CTRL(7) = '1' then
				ADPCM_OFFS <= (others => '0');
				ADPCM_LEN <= (others => '0');
				ADPCM_WRADDR <= (others => '0');
				ADPCM_RDADDR <= (others => '0');
				ADPCM_END <= '0';
				ADPCM_HALF <= '0';
			end if;
			
			if DRAM_CLKEN = '1' and DRAM_SLOT = SLOT_WRITE and (ADPCM_WRITE_PEND = '1' or DMA_WRITE_PEND = '1') then
				if ADPCM_CTRL(1) = '1' then
					ADPCM_WRADDR <= ADPCM_OFFS & "0";
				else
					ADPCM_WRADDR <= std_logic_vector(unsigned(ADPCM_WRADDR) + 1);
				end if;
			elsif CPU_CE = '1' and REG_SEL = '1' and EXT_WR_N = '0' and EXT_A(7 downto 0) = x"0D" and EXT_DI(0) = '0' and ADPCM_CTRL(0) = '1' then
				if ADPCM_CTRL(1) = '1' then
					ADPCM_WRADDR <= ADPCM_OFFS & "0";
				else
					ADPCM_WRADDR <= std_logic_vector(unsigned(ADPCM_WRADDR) + 1);
				end if;
			end if;
			
			if DRAM_CLKEN = '1' and DRAM_SLOT = SLOT_READ and (ADPCM_READ_PEND = '1' or PLAY_READ_PEND = '1') then
				if ADPCM_CTRL(3) = '1' then
					ADPCM_RDADDR <= ADPCM_OFFS & "0";
				else
					ADPCM_RDADDR <= std_logic_vector(unsigned(ADPCM_RDADDR) + 1);
				end if;
			elsif CPU_CE = '1' and REG_SEL = '1' and EXT_WR_N = '0' and EXT_A(7 downto 0) = x"0D" and EXT_DI(2) = '0' and ADPCM_CTRL(2) = '1' then
				if ADPCM_CTRL(3) = '1' then
					ADPCM_RDADDR <= ADPCM_OFFS & "0";
				else
					ADPCM_RDADDR <= std_logic_vector(unsigned(ADPCM_RDADDR) + 1);
				end if;
			end if;
			end if;
		
end if;
end if;
	end process;

	WRITE_PEND <= ADPCM_WRITE_PEND or DMA_WRITE_PEND;
	READ_PEND <= ADPCM_READ_PEND or PLAY_READ_PEND;
	process( REG_SEL, EXT_A, SCSI_DBO, SCSI_DBI, SCSI_BSY_N, SCSI_REQ_N, SCSI_MSG_N, SCSI_CD_N, SCSI_IO_N, SCSI_ACK_N, SCSI_RST_N, 
				CD_DTR, CD_DTD, CD_SUBCD, SUBCD_BYTE, CD_DTR_EN, CD_DTD_EN, CD_SUBCD_EN, R1802_0, R1802_1, CH_SEL, ADPCM_RDDATA, ADPCM_DMA_EN, ADPCM_DMA_RUN, ADPCM_END, ADPCM_HALF, ADPCM_END_EN, ADPCM_HALF_EN, 
				ADPCM_CTRL, ADPCM_FREQ, R180E_7_4, ADPCM_PLAY, ADPCM_FADER, R180F_0, R180F_7_4, READ_PEND, WRITE_PEND, CDDA_VOL, CD_REGION) 
	begin
		EXT_DO <= x"00";
		if REG_SEL = '1' then
			case EXT_A(7 downto 0) is
				when x"00" =>
					EXT_DO <= not SCSI_BSY_N & not SCSI_REQ_N & not SCSI_MSG_N & not SCSI_CD_N & not SCSI_IO_N & "000";
				when x"01" =>
					if SCSI_BSY_N = '0' then
						EXT_DO <= SCSI_DBO;
					else
						EXT_DO <= SCSI_DBI;
					end if;
				when x"02" =>
					EXT_DO <= not SCSI_ACK_N & CD_DTR_EN & CD_DTD_EN & CD_SUBCD_EN & ADPCM_END_EN & ADPCM_HALF_EN & R1802_1 & R1802_0;
				when x"03" =>
					EXT_DO <= "0" & CD_DTR & CD_DTD & CD_SUBCD & ADPCM_END & ADPCM_HALF & CH_SEL & "0";--TODO	
				when x"04" =>
					EXT_DO <= "000000" & not SCSI_RST_N & "0";
				when x"05" =>
					EXT_DO <= CDDA_VOL(7 downto 0);
				when x"06" =>
					EXT_DO <= CDDA_VOL(15 downto 8);
				when x"07" =>
					EXT_DO <= SUBCD_BYTE;
				when x"08" =>
					if SCSI_BSY_N = '0' then
						EXT_DO <= SCSI_DBO;
					else
						EXT_DO <= SCSI_DBI;
					end if;
					
				when x"0A" =>
					EXT_DO <= ADPCM_RDDATA;
				when x"0B" =>
					EXT_DO <= "000000" & ADPCM_DMA_EN & ADPCM_DMA_RUN;
				when x"0C" =>
					EXT_DO <= READ_PEND & "000" & ADPCM_PLAY & WRITE_PEND & "0" & ADPCM_END;
				when x"0D" =>
					EXT_DO <= ADPCM_CTRL;
				when x"0E" =>
					EXT_DO <= R180E_7_4 & ADPCM_FREQ;
				when x"0F" =>
					EXT_DO <= R180F_7_4 & ADPCM_FADER & R180F_0;
					
				when x"C1" =>
					EXT_DO <= x"AA";
				when x"C2" =>
					EXT_DO <= x"55";
				when x"C3" =>
					EXT_DO <= x"00";

				when x"C5" =>
					if CD_REGION = '1' then
						EXT_DO <= x"55";
					else
						EXT_DO <= x"AA";
					end if;
				when x"C6" =>
					if CD_REGION = '1' then
						EXT_DO <= x"AA";
					else
						EXT_DO <= x"55";
					end if;
				when x"C7" =>
					if CD_REGION = '1' then
						EXT_DO <= x"C0";
					else
						EXT_DO <= x"03";
					end if;
				when others => null;
			end case;
		end if;
	end process;
	
	SEL_N <= not (REG_SEL and EN);
	IRQ_N <= not ((CD_DTR_EN and CD_DTR) or (CD_DTD_EN and CD_DTD) or (CD_SUBCD_EN and CD_SUBCD) or (ADPCM_END_EN and ADPCM_END) or (ADPCM_HALF_EN and ADPCM_HALF));
	
	RAM_SEL <= '1' when EXT_A(20 downto 13) >= x"68" and EXT_A(20 downto 13) <= x"87" else '0';
	RAM_CS_N <= not (RAM_SEL and EN);
	
	BRAM_EN <= not BRAM_LOCK or not EN;
	CD_RESET <= not SCSI_RST_N;
	
	SCSI : entity work.SCSI
	port map (
SS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CHILD_SCSI, SS_FIFO_IDLE=>SS_SCSI_IDLE, SS_FIFO_WRITE=>SS_SCSI_FIFO_WRITE, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD=>SS_LOAD,

		RESET_N		=> RST_N and SCSI_RST_N,-- and EN
		CLK			=> CLK,
		
		DBI			=> SCSI_DBI,
		DBO			=> SCSI_DBO,
		SEL_N			=> SCSI_SEL_N,
		ACK_N			=> SCSI_ACK_N,
		RST_N			=> '1', --SCSI_RST_N,
		BSY_N			=> SCSI_BSY_N,
		REQ_N			=> SCSI_REQ_N,
		MSG_N			=> SCSI_MSG_N,
		CD_N			=> SCSI_CD_N,
		IO_N			=> SCSI_IO_N,
		
		STATUS		=> CD_STAT,
		MESSAGE		=> CD_MSG,
		STAT_GET		=> CD_STAT_GET,
		
		COMMAND		=> CD_COMM,
		COMM_SEND	=> CD_COMM_SEND,
		
		DOUT_REQ		=> CD_DOUT_REQ,
		DOUT			=> CD_DOUT,
		DOUT_SEND	=> CD_DOUT_SEND,
		STOP_CD_SND	=> CD_STOP_CD_SND,
		
		CD_DATA		=> CD_DATA,
		CD_WR			=> CD_DATA_WR,
		CD_DATA_END	=> CD_DATA_END
	);


	--ADPCM DRAM
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			DRAM_CLK_CNT <= (others => '0');
			DRAM_CLKEN <= '0';
			DRAM_SLOT_CNT <= (others => '0');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
DRAM_CLKEN <= SS_SH_DRAM_CLKEN;
DRAM_CLK_CNT <= SS_SH_DRAM_CLK_CNT;
DRAM_SLOT_CNT <= SS_SH_DRAM_SLOT_CNT;
elsif SS_FREEZE = '0' then

			if EN = '1' then
				DRAM_CLKEN <= '0';
				DRAM_CLK_CNT <= DRAM_CLK_CNT + 1;
				if DRAM_CLK_CNT = 18-1 then
					DRAM_CLK_CNT <= (others => '0');
					DRAM_CLKEN <= '1';
				end if;
				
				if DRAM_CLKEN = '1' then
					DRAM_SLOT_CNT <= DRAM_SLOT_CNT + 1;
				end if;
			end if;
		
end if;
end if;
	end process;
	
	process( DRAM_SLOT_CNT )
	begin
		case DRAM_SLOT_CNT is
			when "00" => DRAM_SLOT <= SLOT_REFRESH;
			when "01" => DRAM_SLOT <= SLOT_WRITE;
			when "10" => DRAM_SLOT <= SLOT_WRITE;
			when others => DRAM_SLOT <= SLOT_READ;
		end case;
	end process;
	
	ADPCM_DRAM : entity work.adpcm_snapshot_ram generic map (SS_REG_BASE => 625)
 port map(CLK=>CLK,ADDRESS_A=>ADRAM_A,DATA_A=>ADRAM_DI,WREN_A=>ADRAM_WE,Q_A=>ADRAM_DO,
  SS_FREEZE=>SS_FREEZE,SS_SAVE=>SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT,SS_LOAD=>(SS_LOAD and not SS_COMPACT),
  SS_RADDR=>SS_RADDR,SS_RDI=>SS_RDI,SS_RWE=>SS_RWE,SS_RDO=>SS_CHILD_RAM,
  SS_ADDR=>SS_ADPCM_ADDR,SS_DI=>SS_ADPCM_DI,SS_WE=>SS_ADPCM_WE,SS_DO=>SS_ADPCM_DO);
	ADRAM_A <= ADPCM_WRADDR when DRAM_SLOT = SLOT_WRITE else ADPCM_RDADDR;
	ADRAM_DI <= ADPCM_WRDATA(3 downto 0) when ADPCM_WRITE_NIB = '1' else ADPCM_WRDATA(7 downto 4);
	ADRAM_WE <= DRAM_CLKEN when DRAM_SLOT = SLOT_WRITE and (ADPCM_WRITE_PEND = '1' or DMA_WRITE_PEND = '1') else '0';

	
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			M5205_CLK_CNT <= 0;
			M5205_CLK <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
M5205_CLK <= SS_SH_M5205_CLK;
M5205_CLK_CNT <= SS_SH_M5205_CLK_CNT;
elsif SS_FREEZE = '0' then

			M5205_CLK <= '0';
			if EN = '1' then
				if ADPCM_CE = '1' then
					
					M5205_CLK_CNT <= M5205_CLK_CNT + 1;
					if M5205_CLK_CNT >= 15 - unsigned(ADPCM_FREQ) then
						M5205_CLK_CNT <= 0;
						M5205_CLK <= '1';
					end if;
				end if;
			end if;
		
end if;
end if;
	end process;
	
	MSM5205 : entity work.MSM5205
	port map (
SS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CHILD_MSM, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD=>SS_LOAD,

		RST_N		=> not ADPCM_CTRL(7) and ADPCM_PLAY and EN,
		CLK		=> CLK,
		
		XTI		=> M5205_CLK,
		D			=> M5205_D,
		VCK_R		=> M5205_VCK_R,
		--VCK_F		=> M5205_VCK_F,
		
		SOUT		=> M5205_SOUT
	);

	
	--CDDA
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			CD_BYTE_CNT <= (others => '0');
			FIFO_D <= (others => '0');
			FIFO_WR_REQ <= '0';
			CD_WR_OLD <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CD_BYTE_CNT <= SS_SH_CD_BYTE_CNT;
CD_WR_OLD <= SS_SH_CD_WR_OLD;
FIFO_D <= SS_SH_FIFO_D;
FIFO_WR_REQ <= SS_SH_FIFO_WR_REQ;
elsif SS_FREEZE = '0' then

			FIFO_WR_REQ <= '0';
			if EN = '1' then
				CD_WR_OLD <= CD_AUDIO_WR;
				if DM = '1' then
					CD_BYTE_CNT <= (others => '0');
				elsif CD_AUDIO_WR = '1' and CD_WR_OLD = '0' then
					CD_BYTE_CNT <= CD_BYTE_CNT + 1;
					case CD_BYTE_CNT is
						when "00" => FIFO_D(7 downto 0) <= CD_DATA;
						when "01" => FIFO_D(15 downto 8) <= CD_DATA;
						when "10" => FIFO_D(23 downto 16) <= CD_DATA;
						when others => 
							FIFO_D(31 downto 24) <= CD_DATA;
							if FIFO_FULL = '0' and DM = '0' then
								FIFO_WR_REQ <= '1';
							end if;
					end case;
				end if;
			end if;
		
end if;
end if;
	end process;
	
	FIFO : entity work.CDDA_FIFO 
	port map(
		clock		=> CLK,
		data		=> FIFO_D,
		wrreq		=> FIFO_WR_REQ,
		full		=> FIFO_FULL,
		sclr		=> FIFO_SCLR,
		rdreq		=> FIFO_RD_REQ,
		empty		=> FIFO_EMPTY,
		q			=> FIFO_Q
	);
	
	CDDA_CLK_GEN : entity work.CEGen_CD generic map(SS_REG_BASE => 619) 
	port map(
SS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CHILD_CE_A, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD=>SS_LOAD,

		CLK   		=> CLK,
		RST_N       => RST_N,		
		IN_CLK   	=> 429545,
		OUT_CLK   	=> 441,
		CE   			=> CDDA_CE
	);

	ADPCM_CLK_GEN : entity work.CEGen_CD generic map(SS_REG_BASE => 622) 
	port map(
SS_RROTATE=>SS_RROTATE, SS_RADDR=>SS_RADDR, SS_RDI=>SS_RDI, SS_RWE=>SS_RWE, SS_RDO=>SS_CHILD_CE_B, SS_FREEZE=>SS_FREEZE, SS_SAVE=>SS_SAVE, SS_LIVE_CUT => SS_LIVE_CUT, SS_LOAD=>SS_LOAD,

		CLK         => CLK,
		RST_N       => RST_N,
		IN_CLK      => 42954545,
		OUT_CLK     => 1540200,
		CE          => ADPCM_CE
	);
	
	--CD SUBCODE
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			SUBCD_FIFO_D <= (others => '0');
			SUBCD_FIFO_WR_REQ <= '0';
			SUBCD_WR_OLD <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
SUBCD_FIFO_D <= SS_SH_SUBCD_FIFO_D;
SUBCD_FIFO_WR_REQ <= SS_SH_SUBCD_FIFO_WR_REQ;
SUBCD_WR_OLD <= SS_SH_SUBCD_WR_OLD;
elsif SS_FREEZE = '0' then

			SUBCD_FIFO_WR_REQ <= '0';
			if EN = '1' then
				SUBCD_WR_OLD <= CD_SUBCD_WR;
				if CD_SUBCD_WR = '1' and SUBCD_WR_OLD = '0' then
					SUBCD_FIFO_D(7 downto 0) <= CD_DATA;
					if SUBCD_FIFO_FULL = '0' and DM = '0' then
						SUBCD_FIFO_WR_REQ <= '1';
					end if;
				end if;
			end if;
		
end if;
end if;
	end process;
	
	CDSUBC_FIFO : entity work.CDSUBC_FIFO 
	port map(
		clock		=> CLK,
		data		=> SUBCD_FIFO_D,
		wrreq		=> SUBCD_FIFO_WR_REQ,
		full		=> SUBCD_FIFO_FULL,
		sclr		=> SUBCD_FIFO_SCLR,
		rdreq		=> SUBCD_FIFO_RD_REQ,
		empty		=> SUBCD_FIFO_EMPTY,
		q			=> SUBCD_FIFO_Q
	);
	
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			FIFO_SCLR <= '1';
			FIFO_RD_REQ <= '0';
			OUTL <= (others => '0');
			OUTR <= (others => '0');
			SUBCD_CE <= '0';
			SUBCD_CNT <= (others => '0');
			SUBCD_BYTE <= (others => '0');
			SUBCD_BYTENUM <= (others => '0');
			SUBCD_FIFO_SCLR <= '1';
			SUBCD_FIFO_RD_REQ <= '0';

		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CDDA_SAMPLE <= SS_SH_CDDA_SAMPLE;
FIFO_RD_REQ <= SS_SH_FIFO_RD_REQ;
FIFO_SCLR <= SS_SH_FIFO_SCLR;
OUTL <= SS_SH_OUTL;
OUTR <= SS_SH_OUTR;
SUBCD_BYTE <= SS_SH_SUBCD_BYTE;
SUBCD_BYTENUM <= SS_SH_SUBCD_BYTENUM;
SUBCD_CE <= SS_SH_SUBCD_CE;
SUBCD_CNT <= SS_SH_SUBCD_CNT;
SUBCD_FIFO_RD_REQ <= SS_SH_SUBCD_FIFO_RD_REQ;
SUBCD_FIFO_SCLR <= SS_SH_SUBCD_FIFO_SCLR;
elsif SS_FREEZE = '0' then

			FIFO_RD_REQ <= '0';
			FIFO_SCLR <= '0';
			SUBCD_FIFO_RD_REQ <= '0';
			SUBCD_FIFO_SCLR <= '0';
			
			if CDDA_CE = '1' and EN = '1' then	
				CDDA_SAMPLE <= not CDDA_SAMPLE;
				if FIFO_EMPTY = '0' then
					FIFO_RD_REQ <= '1';
					if (CD_STOP_CD_SND = '0') then
						OUTL <= resize(shift_right(signed(FIFO_Q(15 downto 0)) * signed(CDDA_FADE_VOL), 10), OUTL'length);
						OUTR <= resize(shift_right(signed(FIFO_Q(31 downto 16)) * signed(CDDA_FADE_VOL), 10), OUTR'length);
					else
						OUTL <= (others => '0');
						OUTR <= (others => '0');
						FIFO_SCLR <= '1';
						SUBCD_FIFO_SCLR <= '1';
					end if;
				end if;


				if SUBCD_CNT = 0 then
					SUBCD_CE <= '1';									
					
					if SUBCD_FIFO_EMPTY = '0' then
						SUBCD_FIFO_RD_REQ <= '1';
						SUBCD_BYTE <= SUBCD_FIFO_Q(7 downto 0);
					end if;

					
					
						
					
						

					if (SUBCD_BYTENUM = 97) then
						SUBCD_BYTENUM <= (others => '0');		
					else
						SUBCD_BYTENUM <= SUBCD_BYTENUM + 1;
					end if;
				else
					SUBCD_CE <= '0';									
				end if;

				if SUBCD_CNT = 5 then
					SUBCD_CNT <= (others => '0');
				else
					SUBCD_CNT <= SUBCD_CNT + 1;
				end if;

			end if;
		
end if;
end if;
	end process;

			
	--Fader
	process( RST_N, CLK )
	begin
		if RST_N = '0' then
			FADE_VOL <= "01111111111";
			FADE_CNT <= (others => '0');
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
FADE_CNT <= SS_SH_FADE_CNT;
FADE_VOL <= SS_SH_FADE_VOL;
elsif SS_FREEZE = '0' then

			if CDDA_CE = '1' and EN = '1' then
				if FADE_VOL(9 downto 0) > 0 and ADPCM_FADER(2) = '1' then
					FADE_CNT <= FADE_CNT + 1;
					if (FADE_CNT = 107 and ADPCM_FADER(1) = '1') or 	
						(FADE_CNT = 255 and ADPCM_FADER(1) = '0') then	
						FADE_CNT <= (others => '0');
						FADE_VOL <= "0" & (FADE_VOL(9 downto 0) - 1);
					end if;
				elsif ADPCM_FADER(2) = '0' then
					FADE_VOL <= "01111111111";
				end if;
			end if;
		
end if;
end if;
	end process;
	
	CDDA_FADE_VOL <= FADE_VOL when ADPCM_FADER(0) = '0' else "01111111111";
	ADPCM_FADE_VOL <= FADE_VOL when ADPCM_FADER(0) = '1' else "01111111111";
	
	CD_SL <= OUTL;
	CD_SR <= OUTR;

	AD_S <= x"0000" when ADPCM_PLAY = '0' else resize(shift_right(M5205_SOUT * signed(ADPCM_FADE_VOL), 10), AD_S'length);


SS_CAPTURE_DATA(7 downto 0) <= std_logic_vector(ADPCM_CTRL(7 downto 0));
SS_CAPTURE_DATA(8) <= ADPCM_DMA_EN;
SS_CAPTURE_DATA(9) <= ADPCM_DMA_RUN;
SS_CAPTURE_DATA(10) <= ADPCM_END;
SS_CAPTURE_DATA(11) <= ADPCM_END_EN;
SS_CAPTURE_DATA(14 downto 12) <= std_logic_vector(ADPCM_FADER(2 downto 0));
SS_CAPTURE_DATA(15 downto 15) <= std_logic_vector(ADPCM_FREQ(0 downto 0));
SS_CAPTURE_DATA(18 downto 16) <= std_logic_vector(ADPCM_FREQ(3 downto 1));
SS_CAPTURE_DATA(19) <= ADPCM_HALF;
SS_CAPTURE_DATA(20) <= ADPCM_HALF_EN;
SS_CAPTURE_DATA(31 downto 21) <= std_logic_vector(ADPCM_LEN(10 downto 0));
SS_CAPTURE_DATA(37 downto 32) <= std_logic_vector(ADPCM_LEN(16 downto 11));
SS_CAPTURE_DATA(47 downto 38) <= std_logic_vector(ADPCM_OFFS(9 downto 0));
SS_CAPTURE_DATA(53 downto 48) <= std_logic_vector(ADPCM_OFFS(15 downto 10));
SS_CAPTURE_DATA(54) <= ADPCM_PLAY;
SS_CAPTURE_DATA(63 downto 55) <= std_logic_vector(ADPCM_RDADDR(8 downto 0));
SS_CAPTURE_DATA(71 downto 64) <= std_logic_vector(ADPCM_RDADDR(16 downto 9));
SS_CAPTURE_DATA(79 downto 72) <= std_logic_vector(ADPCM_RDDATA(7 downto 0));
SS_CAPTURE_DATA(80) <= ADPCM_READ_NIB;
SS_CAPTURE_DATA(81) <= ADPCM_READ_PEND;
SS_CAPTURE_DATA(95 downto 82) <= std_logic_vector(ADPCM_WRADDR(13 downto 0));
SS_CAPTURE_DATA(98 downto 96) <= std_logic_vector(ADPCM_WRADDR(16 downto 14));
SS_CAPTURE_DATA(106 downto 99) <= std_logic_vector(ADPCM_WRDATA(7 downto 0));
SS_CAPTURE_DATA(107) <= ADPCM_WRITE_NIB;
SS_CAPTURE_DATA(108) <= ADPCM_WRITE_PEND;
SS_CAPTURE_DATA(109) <= AUTO_ACK;
SS_CAPTURE_DATA(110) <= BRAM_LOCK;
SS_CAPTURE_DATA(111) <= CDDA_SAMPLE;
SS_CAPTURE_DATA(112) <= CDDA_SAMPLE_OLD;
SS_CAPTURE_DATA(127 downto 113) <= std_logic_vector(CDDA_VOL(14 downto 0));
SS_CAPTURE_DATA(128 downto 128) <= std_logic_vector(CDDA_VOL(15 downto 15));
SS_CAPTURE_DATA(130 downto 129) <= std_logic_vector(CD_BYTE_CNT(1 downto 0));
SS_CAPTURE_DATA(141 downto 131) <= std_logic_vector(CD_DATA_CNT(10 downto 0));
SS_CAPTURE_DATA(142) <= CD_DTD;
SS_CAPTURE_DATA(143) <= CD_DTD_EN;
SS_CAPTURE_DATA(144) <= CD_DTR;
SS_CAPTURE_DATA(145) <= CD_DTR_EN;
SS_CAPTURE_DATA(146) <= CD_SUBCD;
SS_CAPTURE_DATA(147) <= CD_SUBCD_EN;
SS_CAPTURE_DATA(148) <= CD_WR_OLD;
SS_CAPTURE_DATA(149) <= CH_SEL;
SS_CAPTURE_DATA(150) <= DMA_WRITE_PEND;
SS_CAPTURE_DATA(151) <= DRAM_CLKEN;
SS_CAPTURE_DATA(156 downto 152) <= std_logic_vector(DRAM_CLK_CNT(4 downto 0));
SS_CAPTURE_DATA(158 downto 157) <= std_logic_vector(DRAM_SLOT_CNT(1 downto 0));
SS_CAPTURE_DATA(159 downto 159) <= std_logic_vector(FADE_CNT(0 downto 0));
SS_CAPTURE_DATA(166 downto 160) <= std_logic_vector(FADE_CNT(7 downto 1));
SS_CAPTURE_DATA(175 downto 167) <= std_logic_vector(FADE_VOL(8 downto 0));
SS_CAPTURE_DATA(177 downto 176) <= std_logic_vector(FADE_VOL(10 downto 9));
SS_CAPTURE_DATA(191 downto 178) <= std_logic_vector(FIFO_D(13 downto 0));
SS_CAPTURE_DATA(207 downto 192) <= std_logic_vector(FIFO_D(29 downto 14));
SS_CAPTURE_DATA(209 downto 208) <= std_logic_vector(FIFO_D(31 downto 30));
SS_CAPTURE_DATA(210) <= FIFO_RD_REQ;
SS_CAPTURE_DATA(211) <= FIFO_SCLR;
SS_CAPTURE_DATA(212) <= FIFO_WR_REQ;
SS_CAPTURE_DATA(213) <= M5205_CLK;
SS_CAPTURE_DATA(222 downto 214) <= std_logic_vector(to_unsigned(M5205_CLK_CNT,9));
SS_CAPTURE_DATA(223 downto 223) <= std_logic_vector(M5205_D(0 downto 0));
SS_CAPTURE_DATA(226 downto 224) <= std_logic_vector(M5205_D(3 downto 1));
SS_CAPTURE_DATA(239 downto 227) <= std_logic_vector(OUTL(12 downto 0));
SS_CAPTURE_DATA(242 downto 240) <= std_logic_vector(OUTL(15 downto 13));
SS_CAPTURE_DATA(255 downto 243) <= std_logic_vector(OUTR(12 downto 0));
SS_CAPTURE_DATA(258 downto 256) <= std_logic_vector(OUTR(15 downto 13));
SS_CAPTURE_DATA(259) <= PLAY_READ_PEND;
SS_CAPTURE_DATA(260) <= R1802_0;
SS_CAPTURE_DATA(261) <= R1802_1;
SS_CAPTURE_DATA(265 downto 262) <= std_logic_vector(R180E_7_4(3 downto 0));
SS_CAPTURE_DATA(266) <= R180F_0;
SS_CAPTURE_DATA(270 downto 267) <= std_logic_vector(R180F_7_4(3 downto 0));
SS_CAPTURE_DATA(271) <= SCSI_ACK_N;
SS_CAPTURE_DATA(272) <= SCSI_ACK_N_OLD;
SS_CAPTURE_DATA(273) <= SCSI_BSY_N_OLD;
SS_CAPTURE_DATA(281 downto 274) <= std_logic_vector(SCSI_DBI(7 downto 0));
SS_CAPTURE_DATA(282) <= SCSI_REQ_N_OLD;
SS_CAPTURE_DATA(283) <= SCSI_RST_N;
SS_CAPTURE_DATA(284) <= SCSI_SEL_N;
SS_CAPTURE_DATA(287 downto 285) <= std_logic_vector(SUBCD_BYTE(2 downto 0));
SS_CAPTURE_DATA(292 downto 288) <= std_logic_vector(SUBCD_BYTE(7 downto 3));
SS_CAPTURE_DATA(300 downto 293) <= std_logic_vector(SUBCD_BYTENUM(7 downto 0));
SS_CAPTURE_DATA(301) <= SUBCD_CE;
SS_CAPTURE_DATA(302) <= SUBCD_CE_OLD;
SS_CAPTURE_DATA(303 downto 303) <= std_logic_vector(SUBCD_CNT(0 downto 0));
SS_CAPTURE_DATA(306 downto 304) <= std_logic_vector(SUBCD_CNT(3 downto 1));
SS_CAPTURE_DATA(314 downto 307) <= std_logic_vector(SUBCD_FIFO_D(7 downto 0));
SS_CAPTURE_DATA(315) <= SUBCD_FIFO_RD_REQ;
SS_CAPTURE_DATA(316) <= SUBCD_FIFO_SCLR;
SS_CAPTURE_DATA(317) <= SUBCD_FIFO_WR_REQ;
SS_CAPTURE_DATA(318) <= SUBCD_WR_OLD;
SS_CAPTURE_DATA(319) <= '0';
SS_SH_ADPCM_CTRL(7 downto 0) <= SS_CHAIN(7 downto 0);
SS_SH_ADPCM_DMA_EN <= SS_CHAIN(8);
SS_SH_ADPCM_DMA_RUN <= SS_CHAIN(9);
SS_SH_ADPCM_END <= SS_CHAIN(10);
SS_SH_ADPCM_END_EN <= SS_CHAIN(11);
SS_SH_ADPCM_FADER(2 downto 0) <= SS_CHAIN(14 downto 12);
SS_SH_ADPCM_FREQ(0 downto 0) <= SS_CHAIN(15 downto 15);
SS_SH_ADPCM_FREQ(3 downto 1) <= SS_CHAIN(18 downto 16);
SS_SH_ADPCM_HALF <= SS_CHAIN(19);
SS_SH_ADPCM_HALF_EN <= SS_CHAIN(20);
SS_SH_ADPCM_LEN(10 downto 0) <= SS_CHAIN(31 downto 21);
SS_SH_ADPCM_LEN(16 downto 11) <= SS_CHAIN(37 downto 32);
SS_SH_ADPCM_OFFS(9 downto 0) <= SS_CHAIN(47 downto 38);
SS_SH_ADPCM_OFFS(15 downto 10) <= SS_CHAIN(53 downto 48);
SS_SH_ADPCM_PLAY <= SS_CHAIN(54);
SS_SH_ADPCM_RDADDR(8 downto 0) <= SS_CHAIN(63 downto 55);
SS_SH_ADPCM_RDADDR(16 downto 9) <= SS_CHAIN(71 downto 64);
SS_SH_ADPCM_RDDATA(7 downto 0) <= SS_CHAIN(79 downto 72);
SS_SH_ADPCM_READ_NIB <= SS_CHAIN(80);
SS_SH_ADPCM_READ_PEND <= SS_CHAIN(81);
SS_SH_ADPCM_WRADDR(13 downto 0) <= SS_CHAIN(95 downto 82);
SS_SH_ADPCM_WRADDR(16 downto 14) <= SS_CHAIN(98 downto 96);
SS_SH_ADPCM_WRDATA(7 downto 0) <= SS_CHAIN(106 downto 99);
SS_SH_ADPCM_WRITE_NIB <= SS_CHAIN(107);
SS_SH_ADPCM_WRITE_PEND <= SS_CHAIN(108);
SS_SH_AUTO_ACK <= SS_CHAIN(109);
SS_SH_BRAM_LOCK <= SS_CHAIN(110);
SS_SH_CDDA_SAMPLE <= SS_CHAIN(111);
SS_SH_CDDA_SAMPLE_OLD <= SS_CHAIN(112);
SS_SH_CDDA_VOL(14 downto 0) <= SS_CHAIN(127 downto 113);
SS_SH_CDDA_VOL(15 downto 15) <= SS_CHAIN(128 downto 128);
SS_SH_CD_BYTE_CNT(1 downto 0) <= unsigned(SS_CHAIN(130 downto 129));
SS_SH_CD_DATA_CNT(10 downto 0) <= unsigned(SS_CHAIN(141 downto 131));
SS_SH_CD_DTD <= SS_CHAIN(142);
SS_SH_CD_DTD_EN <= SS_CHAIN(143);
SS_SH_CD_DTR <= SS_CHAIN(144);
SS_SH_CD_DTR_EN <= SS_CHAIN(145);
SS_SH_CD_SUBCD <= SS_CHAIN(146);
SS_SH_CD_SUBCD_EN <= SS_CHAIN(147);
SS_SH_CD_WR_OLD <= SS_CHAIN(148);
SS_SH_CH_SEL <= SS_CHAIN(149);
SS_SH_DMA_WRITE_PEND <= SS_CHAIN(150);
SS_SH_DRAM_CLKEN <= SS_CHAIN(151);
SS_SH_DRAM_CLK_CNT(4 downto 0) <= unsigned(SS_CHAIN(156 downto 152));
SS_SH_DRAM_SLOT_CNT(1 downto 0) <= unsigned(SS_CHAIN(158 downto 157));
SS_SH_FADE_CNT(0 downto 0) <= unsigned(SS_CHAIN(159 downto 159));
SS_SH_FADE_CNT(7 downto 1) <= unsigned(SS_CHAIN(166 downto 160));
SS_SH_FADE_VOL(8 downto 0) <= unsigned(SS_CHAIN(175 downto 167));
SS_SH_FADE_VOL(10 downto 9) <= unsigned(SS_CHAIN(177 downto 176));
SS_SH_FIFO_D(13 downto 0) <= SS_CHAIN(191 downto 178);
SS_SH_FIFO_D(29 downto 14) <= SS_CHAIN(207 downto 192);
SS_SH_FIFO_D(31 downto 30) <= SS_CHAIN(209 downto 208);
SS_SH_FIFO_RD_REQ <= SS_CHAIN(210);
SS_SH_FIFO_SCLR <= SS_CHAIN(211);
SS_SH_FIFO_WR_REQ <= SS_CHAIN(212);
SS_SH_M5205_CLK <= SS_CHAIN(213);
SS_SH_M5205_CLK_CNT <= to_integer(unsigned(SS_CHAIN(222 downto 214))) when to_integer(unsigned(SS_CHAIN(222 downto 214))) <= 511 else 0;
SS_SH_M5205_D(0 downto 0) <= SS_CHAIN(223 downto 223);
SS_SH_M5205_D(3 downto 1) <= SS_CHAIN(226 downto 224);
SS_SH_OUTL(12 downto 0) <= signed(SS_CHAIN(239 downto 227));
SS_SH_OUTL(15 downto 13) <= signed(SS_CHAIN(242 downto 240));
SS_SH_OUTR(12 downto 0) <= signed(SS_CHAIN(255 downto 243));
SS_SH_OUTR(15 downto 13) <= signed(SS_CHAIN(258 downto 256));
SS_SH_PLAY_READ_PEND <= SS_CHAIN(259);
SS_SH_R1802_0 <= SS_CHAIN(260);
SS_SH_R1802_1 <= SS_CHAIN(261);
SS_SH_R180E_7_4(3 downto 0) <= SS_CHAIN(265 downto 262);
SS_SH_R180F_0 <= SS_CHAIN(266);
SS_SH_R180F_7_4(3 downto 0) <= SS_CHAIN(270 downto 267);
SS_SH_SCSI_ACK_N <= SS_CHAIN(271);
SS_SH_SCSI_ACK_N_OLD <= SS_CHAIN(272);
SS_SH_SCSI_BSY_N_OLD <= SS_CHAIN(273);
SS_SH_SCSI_DBI(7 downto 0) <= SS_CHAIN(281 downto 274);
SS_SH_SCSI_REQ_N_OLD <= SS_CHAIN(282);
SS_SH_SCSI_RST_N <= SS_CHAIN(283);
SS_SH_SCSI_SEL_N <= SS_CHAIN(284);
SS_SH_SUBCD_BYTE(2 downto 0) <= SS_CHAIN(287 downto 285);
SS_SH_SUBCD_BYTE(7 downto 3) <= SS_CHAIN(292 downto 288);
SS_SH_SUBCD_BYTENUM(7 downto 0) <= unsigned(SS_CHAIN(300 downto 293));
SS_SH_SUBCD_CE <= SS_CHAIN(301);
SS_SH_SUBCD_CE_OLD <= SS_CHAIN(302);
SS_SH_SUBCD_CNT(0 downto 0) <= unsigned(SS_CHAIN(303 downto 303));
SS_SH_SUBCD_CNT(3 downto 1) <= unsigned(SS_CHAIN(306 downto 304));
SS_SH_SUBCD_FIFO_D(7 downto 0) <= SS_CHAIN(314 downto 307);
SS_SH_SUBCD_FIFO_RD_REQ <= SS_CHAIN(315);
SS_SH_SUBCD_FIFO_SCLR <= SS_CHAIN(316);
SS_SH_SUBCD_FIFO_WR_REQ <= SS_CHAIN(317);
SS_SH_SUBCD_WR_OLD <= SS_CHAIN(318);
SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= 579 and to_integer(unsigned(SS_RADDR)) < 599 else (others=>'0');
process(CLK) begin if rising_edge(CLK) then
 -- T captures ordinary fields; T+2 patches only the settled variable proxies.
-- Native state machines continue unchanged throughout this operation.
SS_LIVE_PENDING <= SS_LIVE_PENDING(0) & SS_LIVE_CUT;
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
-- synthesis translate_off
assert not (SS_LIVE_CUT = '1' and (SS_SAVE = '1' or SS_LOAD = '1' or SS_FREEZE = '1' or SS_CHAIN_CAPTURE /= "00" or SS_LIVE_PENDING /= "00"))
 report "live cut overlaps another snapshot operation" severity failure;
assert not ((SS_LIVE_CUT = '1' or SS_LIVE_PENDING /= "00") and (SS_RROTATE = '1' or SS_RWE = '1' or SS_LOAD = '1' or SS_SAVE = '1'))
 report "snapshot chain used before live proxy settling completes" severity failure;
-- synthesis translate_on
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA; -- unchanged legacy frozen-save behavior
elsif SS_LIVE_CUT = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_LIVE_PENDING(1) = '1' then
null; -- no delayed process-variable fields in this chain
elsif SS_LIVE_PENDING /= "00" then
null; -- hold the captured scalar fields during proxy settling
 elsif SS_RWE='1' and (to_integer(unsigned(SS_RADDR)) >= 579 and to_integer(unsigned(SS_RADDR)) < 599) then SS_CHAIN <= SS_RDI & SS_CHAIN(319 downto 16);
 elsif SS_RROTATE='1' and (to_integer(unsigned(SS_RADDR)) >= 579 and to_integer(unsigned(SS_RADDR)) < 599) then SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(319 downto 16);
 end if;
end if; end process;
SS_RDO <= SS_LOCAL_RDO or SS_CHILD_SCSI or SS_CHILD_MSM or SS_CHILD_CE_A or SS_CHILD_CE_B or SS_CHILD_RAM;
end rtl;
