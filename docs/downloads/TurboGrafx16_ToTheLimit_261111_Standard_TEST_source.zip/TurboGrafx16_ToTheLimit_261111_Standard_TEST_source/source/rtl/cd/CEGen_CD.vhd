LIBRARY ieee;
USE ieee.std_logic_1164.all;
use ieee.numeric_std.all;

ENTITY CEGen_CD IS
    generic (SS_REG_BASE : integer := 0);
	PORT
	(
        
        SS_RROTATE : in std_logic := '0';
        SS_RADDR : in std_logic_vector(14 downto 0) := (others => '0');
        SS_RDI : in std_logic_vector(15 downto 0) := (others => '0');
        SS_RWE : in std_logic := '0';
        SS_RDO : out std_logic_vector(15 downto 0);
        SS_FREEZE : in std_logic := '0';
        SS_SAVE : in std_logic := '0';
        SS_LIVE_CUT : in std_logic := '0'; -- private live capture; never a freeze
        SS_LOAD : in std_logic := '0';

		CLK       : in  STD_LOGIC;
		RST_N     : in  STD_LOGIC;

		IN_CLK    : in  integer;
		OUT_CLK   : in  integer;

		CE        : buffer STD_LOGIC
	);
END CEGen_CD;

ARCHITECTURE SYN OF CEGen_CD IS
-- Volatile register snapshot; independent of CPU reset.
signal SS_SH_CE : STD_LOGIC;
function ss_integer_read(v:integer; off:natural) return std_logic_vector is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); return std_logic_vector(bits(off+15 downto off)); end;
function ss_integer_write(v:integer; di:std_logic_vector(15 downto 0); off:natural) return integer is
 variable bits:signed(31 downto 0); begin bits:=to_signed(v,32); bits(off+15 downto off):=signed(di); return to_integer(bits); end;
signal SS_CHAIN : std_logic_vector(47 downto 0);
signal SS_CAPTURE_DATA : std_logic_vector(47 downto 0);
signal SS_LIVE_PENDING : std_logic_vector(1 downto 0) := "00";
signal SS_CHAIN_CAPTURE : std_logic_vector(1 downto 0) := "00";
signal SS_LOCAL_RDO : std_logic_vector(15 downto 0);
signal SS_PROXY_0 : integer;

BEGIN


	process( RST_N, CLK )
	variable CLK_SUM : integer;
	variable SS_SH_VAR_CLK_SUM : integer;
begin
if rising_edge(CLK) then


SS_PROXY_0 <= SS_SH_VAR_CLK_SUM;
end if;

if rising_edge(CLK) and (SS_SAVE = '1' or SS_LIVE_CUT = '1') then
SS_SH_VAR_CLK_SUM := CLK_SUM;
end if;

		if RST_N = '0' then
			CLK_SUM := 0;
			CE <= '0';
		elsif rising_edge(CLK) then
if SS_LOAD = '1' then
CLK_SUM := to_integer(signed(SS_CHAIN(47 downto 32) & SS_CHAIN(31 downto 16)));
CE <= SS_SH_CE;
elsif SS_FREEZE = '0' then

			CE <= '0';
			CLK_SUM := CLK_SUM + OUT_CLK;
			if CLK_SUM >= IN_CLK then
				CLK_SUM := CLK_SUM - IN_CLK;
				CE <= '1';
			end if;
		
end if;
end if;
	end process;

SS_LOCAL_RDO <= SS_CHAIN(15 downto 0) when to_integer(unsigned(SS_RADDR)) >= SS_REG_BASE and to_integer(unsigned(SS_RADDR)) <= SS_REG_BASE+2 else (others => '0');
SS_CAPTURE_DATA(0) <= CE;
SS_CAPTURE_DATA(31 downto 16) <= ss_integer_read(SS_PROXY_0,0);
SS_CAPTURE_DATA(47 downto 32) <= ss_integer_read(SS_PROXY_0,16);
SS_CAPTURE_DATA(15 downto 1) <= (others => '0');

process(CLK) begin
if rising_edge(CLK) then
-- T captures ordinary fields; T+2 patches only the settled variable proxies.
-- Native state machines continue unchanged throughout this operation.
SS_LIVE_PENDING <= SS_LIVE_PENDING(0) & SS_LIVE_CUT;
SS_CHAIN_CAPTURE <= SS_CHAIN_CAPTURE(0) & SS_SAVE;
-- synthesis translate_off
assert not (SS_LIVE_CUT = '1' and (SS_SAVE = '1' or SS_LOAD = '1' or SS_FREEZE = '1' or SS_CHAIN_CAPTURE /= "00" or SS_LIVE_PENDING /= "00"))
 report "live cut overlaps another snapshot operation" severity failure;
assert not ((SS_LIVE_CUT = '1' or SS_LIVE_PENDING /= "00") and (SS_RROTATE = '1' or SS_RWE = '1' or SS_LOAD = '1' or SS_SAVE = '1'))
 report "snapshot chain used before live proxy settling completes" severity failure;
-- synthesis translate_on
if SS_CHAIN_CAPTURE(1) = '1' then
SS_CHAIN <= SS_CAPTURE_DATA; -- unchanged legacy frozen-save behavior
elsif SS_LIVE_CUT = '1' then
SS_CHAIN <= SS_CAPTURE_DATA;
elsif SS_LIVE_PENDING(1) = '1' then
SS_CHAIN(31 downto 16) <= SS_CAPTURE_DATA(31 downto 16);
SS_CHAIN(47 downto 32) <= SS_CAPTURE_DATA(47 downto 32);
elsif SS_LIVE_PENDING /= "00" then
null; -- hold the captured scalar fields during proxy settling
elsif SS_RWE = '1' and (to_integer(unsigned(SS_RADDR)) >= SS_REG_BASE and to_integer(unsigned(SS_RADDR)) <= SS_REG_BASE+2) then
SS_CHAIN <= SS_RDI & SS_CHAIN(47 downto 16);
elsif SS_RROTATE = '1' and (to_integer(unsigned(SS_RADDR)) >= SS_REG_BASE and to_integer(unsigned(SS_RADDR)) <= SS_REG_BASE+2) then
SS_CHAIN <= SS_CHAIN(15 downto 0) & SS_CHAIN(47 downto 16);
end if;
end if;
end process;
SS_SH_CE <= SS_CHAIN(0);


SS_RDO <= SS_LOCAL_RDO;
END SYN;
