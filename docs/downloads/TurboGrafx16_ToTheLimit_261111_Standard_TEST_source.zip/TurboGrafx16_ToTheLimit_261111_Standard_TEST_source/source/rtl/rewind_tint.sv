// Stronger 50% desaturation only while the rewind control is actively stepping.
// Pure combinational color transform: no pixel or sync latency is introduced.
module rewind_tint(input wire active, input wire [23:0] rgb_in,
                   output wire [23:0] rgb_out);
    wire [7:0] r=rgb_in[23:16], g=rgb_in[15:8], b=rgb_in[7:0];
    wire [9:0] luma_sum={2'b0,r}+{1'b0,g,1'b0}+{2'b0,b};
    wire [7:0] y=luma_sum[9:2];
    wire [8:0] red_sum={1'b0,r}+{1'b0,y};
    wire [8:0] green_sum={1'b0,g}+{1'b0,y};
    wire [8:0] blue_sum={1'b0,b}+{1'b0,y};
    assign rgb_out=active ? {red_sum[8:1],green_sum[8:1],blue_sum[8:1]} : rgb_in;
endmodule
