// Stock MiSTer UIO_INFO_GET mailbox. IDs index the CONF_STR I entry (one based).
// Best-effort notifications: hps_io provides no acknowledgement or durable-save status.
module state_feedback(
 input clk, reset, available,
 input [1:0] selected_slot,
 input manual_edge,
 input request_accept, operation_private, accepted_loading,
 input [1:0] accepted_slot,
 input backend_done, backend_failed,
 input [3:0] backend_error,
 output reg info_req=0,
 output reg [7:0] info=0
);
 reg [1:0] last_slot=0, active_slot=0;
 reg active=0, loading=0;
 reg [7:0] pending=0;
 // 1..4 selected, 5..8 captured, 9..12 loaded, 13 incompatible,
 // 14 CRC, 15 unavailable, 16 timeout, 17 failed.
 function automatic [7:0] failure_message(input [3:0] code);
  case(code)
   1,2,3,4,5,8: failure_message=13;
   6: failure_message=14;
   7: failure_message=16;
   default: failure_message=17;
  endcase
 endfunction
 always @(posedge clk) begin
  info_req<=0;
  last_slot<=selected_slot;
  if(reset) begin
   active<=0;pending<=0;info<=0;
  end else begin
   // A full low cycle separates requests, including adjacent events.
   if(!info_req && pending!=0) begin
    info<=pending;info_req<=1;pending<=0;
   end
   if(selected_slot!=last_slot) pending<=8'd1+{6'd0,selected_slot};
   if(manual_edge && !available) pending<=15;
   if(request_accept) begin
    active<=!operation_private;
    loading<=accepted_loading;
    active_slot<=accepted_slot;
   end
   // Only accepted manual operations can report completion. Capture completion
   // means DDR publication and drain, not host SD write completion.
   if(active && backend_done && available && !backend_failed) begin
    pending<=(loading ? 8'd9 : 8'd5)+{6'd0,active_slot};active<=0;
   end
   if(active && backend_failed) begin
    pending<=backend_error==7 ? 8'd16 : (!available ? 8'd15 : failure_message(backend_error));active<=0;
   end
  end
 end
endmodule
