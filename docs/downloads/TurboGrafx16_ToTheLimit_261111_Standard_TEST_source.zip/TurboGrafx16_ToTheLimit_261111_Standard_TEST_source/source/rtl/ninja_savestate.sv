// Complete four-slot snapshots. Header word zero is MiSTer's commit/change word.
// The payload contains RAM AND every mapped register, including RAM read latches.
module ninja_savestate #(
 parameter integer REGISTER_WORDS=681, RAM_WORDS=43777, ADPCM_WORDS=8192, CDRAM_WORDS=32768,
 parameter [63:0] SCHEMA=64'h7b4a4831e0d369a8,
 // Prototype opt-in: caller must invalidate and lend rewind slots 0..3.
 parameter bit MANUAL_LOAD_STAGING=0,
 // Default off preserves existing manual/private backend admission.
 parameter bit PRIVATE_SAVE_WINDOW_ENABLE=0
)(
 input clk,ram_clk,reset,enabled,safe,
 input private_save_window,
 input save_button,load_button,start_block,
 input [1:0] slot,
 // Unconnected optional inputs retain the legacy four-slot profile.
 input private_mode,
 input manual_stage_allowed,
 input [6:0] private_slot,
 output wire busy,
 output reg done=0,failed=0,request_accept=0,operation_private=0,
 input [31:0] rom_id,
 input [15:0] config_id,
 output reg freeze=0,save_pulse=0,load_pulse=0,
 output reg valid=0,fault_reset=0,
 output reg [3:0] error=0,
 output wire [17:0] scan_addr,
 input [15:0] scan_dout,
 output [16:0] adpcm_addr,
 output [3:0] adpcm_din,
 output adpcm_we,
 input [3:0] adpcm_dout,
 output [17:0] cd_ram_addr,
 output [7:0] cd_ram_din,
 output cd_ram_write,cd_ram_req,cd_ram_hold,
 input cd_ram_ack,
 input [7:0] cd_ram_dout,
 output [15:0] scan_din,
 output scan_we,
 output reg_rotate,
 input normal_idle,ram_busy,ram_ready,
 input [63:0] ram_dout,
 output take_ddr,
 output [28:0] ram_addr,
 output [63:0] ram_din,
 output ram_rd,ram_we
);
 localparam integer CORE_WORDS=RAM_WORDS+REGISTER_WORDS, CORE_GROUPS=(CORE_WORDS+3)/4,
                    CDRAM_BASE=CORE_GROUPS+ADPCM_WORDS, WORDS=CDRAM_BASE+CDRAM_WORDS, IMAGE_WORDS=WORDS+5;
 localparam integer STAGE_CAPACITY_WORDS=65536; // Four contiguous 128 KiB rewind slots.
 localparam [63:0] MAGIC=64'h54474c5353000003; // TGLSS, SD publication protocol 3
 localparam [63:0] PRIVATE_MAGIC=64'h5447525744000001;
 localparam [63:0] PRIVATE_SCHEMA=SCHEMA ^ 64'h524557494e440001;
 wire [31:0] operation_words=operation_private ? CORE_GROUPS : WORDS;
 wire [31:0] operation_size=(operation_words+4)*2;
 wire [63:0] operation_magic=operation_private ? PRIVATE_MAGIC : MAGIC;
 wire [63:0] operation_schema=operation_private ? PRIVATE_SCHEMA : SCHEMA;
 reg [6:0] active_private_slot=0;
 reg success_pending=0;
 (* async_reg="true" *) reg owned_meta=0,owned_sync=0;
 // Include the physical owner as well as its synchronized copy: release must
 // never be advertised while an aborted DDR read is still draining.
 assign busy=(state!=IDLE)||freeze||(req!=ack_sync)||owned||owned_sync||cd_ram_hold||success_pending;
 localparam IDLE=0,WAIT_SAFE=1,SETTLE=2,PREP=3,ISSUE=4,RESPONSE=5,
            NEXT=6,CORE_READ_WAIT=7,CORE_WRITE_WAIT=8,RESTORE=9,WARM=10,REJECT=11,
            ADPCM_READ_WAIT=12,ADPCM_WRITE_WAIT=13,CDRAM_READ_WAIT=14,CDRAM_WRITE_WAIT=15;
 reg [3:0] state=IDLE,after_response=NEXT;
 reg loading=0,applying=0,old_save=0,old_load=0;
 // Latched transaction grant; the caller cannot reuse borrowed history memory
 // until busy falls, including all accepted DDR responses after cancellation.
 reg staged_manual_load=0,rechecking_header=0;
 reg mailbox_stage=0;
 reg [1:0] active_slot=0;
 reg [5:0] delay_count=0;
 reg [27:0] watchdog=0;
 reg [15:0] index=0;
 reg [2:0] phase=0; // 0=control,1=magic,2=schema,3=identity,4=CRC,5=payload,6=commit,7=invalidate
 reg [31:0] crc=32'hffffffff,expected_crc=0,generation=0;
 reg [31:0] active_rom=0;
 reg [15:0] active_config=0;
 reg req=0;
 reg [63:0] payload=0,response=0;
 reg [15:0] mailbox_addr=0;
 reg mailbox_write=0;
 reg adpcm_read_start=0,adpcm_write_start=0;
 wire adpcm_busy,adpcm_done,adpcm_aborted;
 wire [63:0] adpcm_word;
 wire cdram_selected=(index>=CDRAM_BASE);
 wire adpcm_selected=(index>=CORE_GROUPS && index<CDRAM_BASE);
 reg cdram_read_start=0,cdram_write_start=0;
 wire cdram_busy,cdram_done,cdram_aborted;
 wire [63:0] cdram_word;
 cd_ram_pack_engine cdram_pack(.clk(clk),.reset(reset),.freeze(freeze),.cancel(!enabled),
  .start_read(cdram_read_start),.start_write(cdram_write_start),
  .group_addr(15'(index-CDRAM_BASE)),.word_in(response),
  .cell_addr(cd_ram_addr),.cell_din(cd_ram_din),.cell_write(cd_ram_write),.cell_req(cd_ram_req),
  .cell_ack(cd_ram_ack),.cell_dout(cd_ram_dout),.word_out(cdram_word),
  .hold_req(cd_ram_hold),.busy(cdram_busy),.done(cdram_done),.aborted(cdram_aborted));
 reg core_read_start=0,core_write_start=0;
 wire core_busy,core_done,core_aborted,core_scan_we,core_rotate;
 wire [15:0] core_scan_index,core_scan_din;
 wire [63:0] core_word;
 word_scan_pack_engine #(.RAM_WORDS(RAM_WORDS),.REGISTER_WORDS(REGISTER_WORDS)) core_pack(
  .clk(clk),.reset(reset || !enabled),.freeze(freeze),.start_read(core_read_start),.start_write(core_write_start),
  .group_addr(index),.word_in(response),.scan_index(core_scan_index),.scan_dout(scan_dout),
  .scan_din(core_scan_din),.scan_we(core_scan_we),.scan_rotate(core_rotate),
  .word_out(core_word),.busy(core_busy),.done(core_done),.aborted(core_aborted),.rejected());
 adpcm_pack_engine adpcm_pack(.clk(clk),.reset(reset || !enabled),.freeze(freeze),
  .start_read(adpcm_read_start),.start_write(adpcm_write_start),
  .group_addr(13'(index-CORE_GROUPS)),.word_in(response),
  .cell_addr(adpcm_addr),.cell_din(adpcm_din),.cell_we(adpcm_we),.cell_dout(adpcm_dout),
  .word_out(adpcm_word),.busy(adpcm_busy),.done(adpcm_done),.aborted(adpcm_aborted));
 reg ack=0;
 (* async_reg="true" *) reg ack_meta=0,ack_sync=0;
 assign scan_din=core_scan_din;
 assign scan_we=core_scan_we;
 assign reg_rotate=core_rotate;
 assign scan_addr=scan_location(core_scan_index);
 function automatic [31:0] crc16(input [31:0] initial_crc,input [15:0] data);
   reg [31:0] c;integer b;begin c=initial_crc;
   for(b=0;b<16;b=b+1) c=(c>>1)^(((c[0]^data[b])!=0)?32'hedb88320:0);
   crc16=c;end
 endfunction
 function automatic [31:0] crc64(input [31:0] initial_crc,input [63:0] data);
   reg [31:0] c; integer j; begin c=initial_crc;
   for(j=0;j<4;j=j+1) c=crc16(c,data[j*16+:16]);
   crc64=c;end
 endfunction
 function automatic [17:0] scan_location(input [15:0] n);
   if(n>=RAM_WORDS) scan_location=18'h30000+18'(n-RAM_WORDS);
   else if(n<8192) scan_location={3'd0,n[14:0]};
   else if(n<40960) scan_location=18'h08000+18'(n-8192);
   else if(n<41216) scan_location=18'h10000+18'(n-40960);
   else if(n<41728) scan_location=18'h18000+18'(n-41216);
   else if(n<42240) scan_location=18'h20000+18'(n-41728);
   else if(n<42752) scan_location=18'h28000+18'(n-42240);
   else scan_location=18'h38000+18'(n-42752);
 endfunction
 always @(posedge clk) begin
   ack_meta<=ack;ack_sync<=ack_meta;owned_meta<=owned;owned_sync<=owned_meta;
   done<=0;failed<=0;request_accept<=0;
   if(success_pending && !owned_sync && !owned && req==ack_sync && !cd_ram_hold) begin
     success_pending<=0;done<=1;
   end
   old_save<=save_button;old_load<=load_button;
   save_pulse<=0;load_pulse<=0;fault_reset<=0;adpcm_read_start<=0;adpcm_write_start<=0;core_read_start<=0;core_write_start<=0;cdram_read_start<=0;cdram_write_start<=0;
   if(reset || !enabled) begin
     if(freeze && applying) fault_reset<=1;
     if(state!=IDLE || success_pending) failed<=1;
     success_pending<=0;done<=0;
     state<=IDLE;freeze<=0;valid<=0;watchdog<=0;
   end else begin
     if(state==IDLE) watchdog<=0;else watchdog<=watchdog+1'd1;
     if(&watchdog) begin
       state<=IDLE;freeze<=0;valid<=0;fault_reset<=applying;error<=4'd7;failed<=1;success_pending<=0;
     end else case(state)
       IDLE: if(!busy && !start_block && ((save_button&&!old_save)||(load_button&&!old_load))) begin
         loading<=!(save_button&&!old_save);applying<=0;rechecking_header<=0;
         active_slot<=slot;active_rom<=rom_id;active_config<=config_id;
         operation_private<=(private_mode===1'b1);active_private_slot<=private_slot;
         request_accept<=1;
         staged_manual_load<=MANUAL_LOAD_STAGING && !(private_mode===1'b1) &&
                             !(save_button&&!old_save) && (manual_stage_allowed===1'b1);
         error<=0;state<=WAIT_SAFE;
         if(MANUAL_LOAD_STAGING && !(private_mode===1'b1) &&
            (IMAGE_WORDS>STAGE_CAPACITY_WORDS ||
             (!(save_button&&!old_save) && !(manual_stage_allowed===1'b1)))) begin error<=4'd9;state<=REJECT;end
       end
       WAIT_SAFE: if(safe && (!PRIVATE_SAVE_WINDOW_ENABLE || !operation_private || loading || (private_save_window === 1'b1))) begin
         freeze<=1;save_pulse<=1; // preserve live read latches even if validation rejects
         delay_count<=0;state<=SETTLE;
       end
       SETTLE: begin
         delay_count<=delay_count+1'd1;
         if(delay_count==31) begin phase<=0;index<=0;crc<=32'hffffffff;state<=PREP;end
       end
       PREP: begin
         mailbox_write<=!loading;mailbox_stage<=staged_manual_load && applying;
         after_response<=NEXT;state<=ISSUE;
         case(phase)
           0: begin mailbox_addr<=0;payload<=0;mailbox_write<=0;end // read generation; publish only at commit
           1: begin mailbox_addr<=1;payload<=operation_magic;end
           2: begin mailbox_addr<=2;payload<=operation_schema;end
           3: begin mailbox_addr<=3;payload<={16'd0,active_config,active_rom};end
           4: begin mailbox_addr<=4;payload<={operation_words,~crc};end
           5: begin
             mailbox_addr<=index+16'd5;
             if(loading) begin after_response<=NEXT;state<=ISSUE;end
             else if(cdram_selected) begin cdram_read_start<=1;state<=CDRAM_READ_WAIT;end
             else if(adpcm_selected) begin adpcm_read_start<=1;state<=ADPCM_READ_WAIT;end
             else begin core_read_start<=1;state<=CORE_READ_WAIT;end
           end
           6: begin mailbox_addr<=0;payload<={operation_size,generation+32'd1};end
           // Unpublish before changing any image bytes. Hosts must recheck
           // this header after copying to detect concurrent replacement.
           // Core completion does not confirm durable SD publication.
           7: begin mailbox_addr<=0;payload<={32'd0,generation};end
         endcase
       end
       CORE_READ_WAIT: if(core_done) begin
         payload<=core_word;crc<=crc64(crc,core_word);after_response<=NEXT;state<=ISSUE;
       end
       CORE_WRITE_WAIT: if(core_done) state<=NEXT;
       ADPCM_READ_WAIT: if(adpcm_done) begin
         payload<=adpcm_word;crc<=crc64(crc,adpcm_word);after_response<=NEXT;state<=ISSUE;
       end
       ADPCM_WRITE_WAIT: if(adpcm_done) state<=NEXT;
       CDRAM_READ_WAIT: if(cdram_done) begin
         payload<=cdram_word;crc<=crc64(crc,cdram_word);after_response<=NEXT;state<=ISSUE;
       end
       CDRAM_WRITE_WAIT: if(cdram_done) state<=NEXT;
       ISSUE: begin req<=!req;state<=RESPONSE;end
       RESPONSE: if(ack_sync==req) begin
         state<=after_response;
         if(phase==0 && !rechecking_header) generation<=response[31:0];
         // A staging write acknowledges the already validated read; it must not
         // feed the CRC twice or be mistaken for another load response.
         if(loading && !(mailbox_stage && mailbox_write)) case(phase)
           0: begin
             if(response[63:32] != operation_size) begin error<=1;state<=REJECT;end
             else if(rechecking_header && response[31:0]!=generation) begin error<=9;state<=REJECT;end
           end
           1: if(response!=operation_magic) begin error<=2;state<=REJECT;end
           2: if(response!=operation_schema) begin error<=3;state<=REJECT;end
           3: if(response!={16'd0,active_config,active_rom}) begin error<=4;state<=REJECT;end
           4: begin
             if(!rechecking_header) expected_crc<=response[31:0];
             else if(response[31:0]!=expected_crc) begin error<=9;state<=REJECT;end
             if(response[63:32]!=operation_words) begin error<=5;state<=REJECT;end
           end
           5: begin
             if(!adpcm_selected && !cdram_selected && index==CORE_GROUPS-1 && (CORE_WORDS%4)!=0 &&
                (response >> (16*(CORE_WORDS%4)))!=0) begin error<=4'd8;state<=REJECT;end
             else begin
               crc<=crc64(crc,response);
               if(staged_manual_load && !applying) begin
                 // Copy the exact word used by the validation CRC. Only after
                 // the final copy is acknowledged and the CRC matches may the
                 // apply pass read this private, exclusively owned image.
                 payload<=response;mailbox_write<=1;mailbox_stage<=1;state<=ISSUE;
               end else if(applying) begin
                 if(cdram_selected) begin cdram_write_start<=1;state<=CDRAM_WRITE_WAIT;end
                 else if(adpcm_selected) begin adpcm_write_start<=1;state<=ADPCM_WRITE_WAIT;end
                 else begin core_write_start<=1;state<=CORE_WRITE_WAIT;end
               end
             end
           end
         endcase
       end
       NEXT: begin
         if(phase==5) begin
           if(index==operation_words-1) begin
             if(loading) begin
               if((~crc)!=expected_crc) begin error<=6;state<=REJECT;end
               else if(!applying) begin
                 index<=0;crc<=32'hffffffff;state<=PREP;
                 if(staged_manual_load) begin rechecking_header<=1;phase<=0;end
                 else applying<=1;
               end else state<=RESTORE;
             end else begin phase<=4;state<=PREP;end
           end else begin index<=index+1'd1;state<=PREP;end
         end else if(phase==6) begin generation<=generation+1'd1;valid<=1;state<=WARM;delay_count<=0;end
         else if(phase==0 && !loading) begin phase<=7;state<=PREP;end
         else if(phase==7) begin phase<=1;state<=PREP;end
         else if(phase==4) begin
           phase<=loading?3'd5:3'd6;state<=PREP;
           if(rechecking_header) begin rechecking_header<=0;applying<=1;index<=0;crc<=32'hffffffff;end
         end
         else if(phase==3 && !loading) begin phase<=5;state<=PREP;end
         else begin phase<=phase+1'd1;state<=PREP;end
       end
       RESTORE: begin load_pulse<=1;valid<=1;state<=WARM;delay_count<=0;end
       WARM: begin delay_count<=delay_count+1'd1;if(delay_count==7) begin freeze<=0;state<=IDLE;success_pending<=1;end end
       REJECT: begin freeze<=0;valid<=0;fault_reset<=applying;state<=IDLE;failed<=1;end
       default:begin state<=IDLE;freeze<=0;valid<=0;failed<=1;end
     endcase
   end
 end
 // DDR ownership stays with snapshots until all accepted reads have been
 // drained. A stuck response deliberately holds ownership rather than routing
 // its eventual completion to the normal cache. Reset/retry requires external
 // intervention if the DDR controller never responds.
 (* async_reg="true" *) reg req_meta=0,req_sync=0,freeze_meta=0,freeze_sync=0;
 reg [1:0] dstate=0;
 reg [28:0] daddr=0;
 reg [63:0] ddata=0;
 reg dwrite=0,dread=0,owned=0;
 reg [2:0] release_guard=0;
 assign take_ddr=owned;
 assign ram_addr=daddr;assign ram_din=ddata;assign ram_rd=dread;assign ram_we=dwrite;
 always @(posedge ram_clk) begin
   req_meta<=req;req_sync<=req_meta;freeze_meta<=freeze;freeze_sync<=freeze_meta;
   if(!owned) begin
     // If an operation was aborted before arbitration granted ownership, its
     // request was never presented to DDR and can be acknowledged as canceled.
     if(!freeze_sync && req_sync!=ack) ack<=req_sync;
     if(freeze_sync && normal_idle && !ram_busy && !ram_ready) begin
       owned<=1;release_guard<=0;
     end
   end else begin
     case(dstate)
       0: if(req_sync!=ack) begin
         if(!freeze_sync) ack<=req_sync; // request not yet issued: cancel
         else if(!ram_busy) begin
           // Staging is wholly inside the first four already-reserved rewind
           // slots (byte 0x3E000000..0x3E07FFFF), never in a public manual slot.
           daddr<=mailbox_stage ? (29'h07c00000+mailbox_addr) : operation_private ?
             (29'h07c00000+{8'd0,active_private_slot,14'd0}+mailbox_addr) :
             (29'h07e00000+{11'd0,active_slot,16'd0}+mailbox_addr);
           ddata<=payload;dwrite<=mailbox_write;dread<=!mailbox_write;dstate<=1;
         end
       end
       1: begin
         // Ready acceptance must take priority over abort: if !busy at this
         // edge the DDR command was accepted even if freeze just fell.
         if(!ram_busy) begin
           dwrite<=0;dread<=0;
           if(dwrite) begin ack<=req_sync;dstate<=0;end
           else if(ram_ready) begin response<=ram_dout;ack<=req_sync;dstate<=0;end
           else dstate<=2;
         end else if(!freeze_sync) begin
           dwrite<=0;dread<=0;ack<=req_sync;dstate<=0;
         end
       end
       2: if(ram_ready) begin response<=ram_dout;ack<=req_sync;dstate<=0;end
     endcase
     // The quiet guard lets synchronized request/freeze signals settle before
     // handing the bus back, and keeps late completion pulses out of cache.
     if(!freeze_sync && dstate==0 && req_sync==ack && !dread && !dwrite && !ram_ready) begin
       if(release_guard==3) begin owned<=0;release_guard<=0;end
       else release_guard<=release_guard+1'b1;
     end else release_guard<=0;
   end
 end
endmodule
