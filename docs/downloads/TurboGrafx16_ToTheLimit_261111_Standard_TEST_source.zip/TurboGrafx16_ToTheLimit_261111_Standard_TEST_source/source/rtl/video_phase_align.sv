// Preserve external scan phase across save-state and rewind pauses.
// The packed phase is an observation of the VCE, not additional saved state.
// Core and reference run on clk_sys; CLK_VIDEO is the related 2x clock.
module video_phase_align #(
    parameter integer LINE_CLOCKS = 2730,
    parameter integer FLUSH_CLOCKS = 2 * LINE_CLOCKS,
    parameter integer TIMEOUT_CLOCKS = 3 * LINE_CLOCKS * 263
)(
    input wire clk,
    input wire freeze_request,
    input wire cancel,
    input wire [51:0] core_phase,
    output reg machine_hold = 0,
    output wire video_freeze,
    output wire busy,
    output wire reference_ce,
    output wire reference_hs, reference_vs, reference_hbl, reference_vbl,
    output wire [51:0] presentation_phase,
    output reg fault = 0
);
    // [11:0] H_CNT, [21:12] V_CNT, [31:22] END_LINE,
    // [33:32] DOTCLOCK, [34] MULTIRES, [37:35] CLKEN_FS_CNT,
    // [38] CLKEN_FS; [41:39] CLKEN_CNT, [42] CLKEN_FF;
    // [43] HBL_FF, [44] VBL_FF, [45] HBL_FF2, [46] VBL_FF2;
    // [47] HBL, [48] VBL, [49] HS_N, [50] VS_N, [51] RVBL.
    reg [51:0] reference_phase = 0;
    wire [51:0] phase = machine_hold ? reference_phase : core_phase;
    reg [51:0] next_phase;
    wire [11:0] h = phase[11:0];
    wire [9:0] v = phase[21:12];
    wire [9:0] lines = phase[31:22];
    wire [1:0] dotclock = phase[33:32];
    wire multires = phase[34];
    wire [2:0] count = phase[37:35];
    wire [2:0] base_count = phase[41:39];
    always @* begin
        next_phase = phase;
        next_phase[11:0] = h + 1'b1;
        next_phase[37:35] = count + 1'b1;
        next_phase[38] = 0;
        // Exact VCE fixed-sampling pixel-enable recurrence. The short final
        // interval of a line must not become a free-running repeated period.
        if ((multires || dotclock[1]) && count == 3 && h < LINE_CLOCKS-3) begin
            next_phase[37:35] = 0;
            next_phase[38] = 1;
        end else if (dotclock == 0 && count == 7 && h < LINE_CLOCKS-3) begin
            next_phase[37:35] = 0;
            next_phase[38] = 1;
        end else if (dotclock == 1 && count == 5) begin
            next_phase[37:35] = 0;
            next_phase[38] = 1;
        end
        next_phase[41:39] = base_count + 1'b1;
        next_phase[42] = 0;
        if ((dotclock == 0 && base_count == 7 && h < LINE_CLOCKS-3) ||
            (dotclock == 1 && base_count == 5) ||
            (dotclock[1] && base_count == 3 && h < LINE_CLOCKS-3)) begin
            next_phase[41:39] = 0;
            next_phase[42] = 1;
        end
        if (h == 46) next_phase[49] = 0;
        if (h == 238) next_phase[49] = 1;
        if (v == 0) next_phase[50] = 0;
        if (v == 3) next_phase[50] = 1;
        if (h == 456) next_phase[43] = 0;
        if (h == 2616) next_phase[43] = 1;
        if (v == (phase[51] ? 19 : 23)) next_phase[44] = 0;
        if (v == (phase[51] ? 261 : 254)) next_phase[44] = 1;
        if (phase[42]) begin
            next_phase[45] = phase[43];
            next_phase[46] = phase[44];
            next_phase[47] = phase[45];
            next_phase[48] = phase[46];
        end
        if (h == LINE_CLOCKS-1) begin
            next_phase[11:0] = 0;
            next_phase[21:12] = v + 1'b1;
            next_phase[37:35] = 0;
            next_phase[38] = 1;
            next_phase[41:39] = 0;
            next_phase[42] = 1;
            if (machine_hold) next_phase[34:32] = core_phase[34:32];
            if (v >= lines-1'b1) begin
                next_phase[21:12] = 0;
                // Never truncate the running field when a loaded state uses
                // the other legal 262/263-line VCE geometry.
                if (machine_hold && (core_phase[31:22] == 262 || core_phase[31:22] == 263))
                    next_phase[31:22] = core_phase[31:22];
            end
        end
    end

    wire valid_phase = core_phase[11:0] < LINE_CLOCKS &&
                       (core_phase[31:22] == 262 || core_phase[31:22] == 263) &&
                       core_phase[21:12] < core_phase[31:22];
    reg [$clog2(TIMEOUT_CLOCKS+1)-1:0] wait_count = 0;
    reg fault_wait = 0;
    // Reset/config/eligibility cancellation may be a pulse while the backend
    // is still draining. Remember it until ownership actually permits resume.
    reg cancel_pending = 0;
    reg video_hold = 0;
    reg [$clog2(FLUSH_CLOCKS+1)-1:0] flush_count = 0;
    assign presentation_phase = reference_phase;
    assign reference_ce = reference_phase[38];
    assign reference_hs = ~reference_phase[49];
    assign reference_vs = ~reference_phase[50];
    assign reference_hbl = reference_phase[47];
    assign reference_vbl = reference_phase[48];
    assign video_freeze = freeze_request || video_hold;
    assign busy = machine_hold || video_hold;

    always @(posedge clk) begin
        reference_phase <= next_phase;
        fault <= 0;
        if (cancel && (freeze_request || machine_hold)) cancel_pending <= 1;
        if (!freeze_request && !machine_hold) cancel_pending <= 0;
        if (freeze_request) begin
            machine_hold <= 1;
            wait_count <= 0;
            fault_wait <= 0;
        end else if (machine_hold) begin
            if (cancel || cancel_pending) begin
                cancel_pending <= 0;
                machine_hold <= 0;
                fault_wait <= 0;
            end else if (!fault_wait) begin
                // On this edge the core is still frozen. After the edge the
                // reference must equal the held core, so both advance from
                // the same phase on the first resumed core edge.
                if (valid_phase && next_phase == core_phase) begin
                    machine_hold <= 0;
                    wait_count <= 0;
                end else if (wait_count == TIMEOUT_CLOCKS-1) begin
                    fault <= 1;
                    fault_wait <= 1; // retain hold until the fault reset is armed
                end else wait_count <= wait_count + 1'b1;
            end
        end
        // Keep RGB black and the HDMI framebuffer held while live color
        // pipelines refill. The independent sync reference never stops.
        if (freeze_request || machine_hold) begin
            video_hold <= 1;
            flush_count <= FLUSH_CLOCKS;
        end else if (video_hold) begin
            if (flush_count == 1) begin
                flush_count <= 0;
                video_hold <= 0;
            end else flush_count <= flush_count - 1'b1;
        end
    end
endmodule
