//============================================================================
//  TurboGrafx16 / PC Engine
//
//  Port to MiSTer
//  Copyright (C) 2017-2019 Sorgelig
//
//  This program is free software; you can redistribute it and/or modify it
//  under the terms of the GNU General Public License as published by the Free
//  Software Foundation; either version 2 of the License, or (at your option)
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
//  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
//  more details.
//
//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//============================================================================

module emu
(
	`include "sys/emu_ports.vh"
    , output SNAPSHOT_AUDIO_FREEZE
);


//`define DEBUG_BUILD
//`define DEBUG_PALETTES

`ifdef DEBUG_BUILD
	localparam LITE = 1;
`else
	localparam LITE = 1;
`endif

assign ADC_BUS  = 'Z;
assign VGA_F1 = 0;
assign {UART_RTS, UART_TXD, UART_DTR} = 0;
assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;

// Preserve original shared LED/VGA-clock output-enable behavior.
assign LED_USER = cart_download | bk_state | bk_pending;
assign LED_DISK  = 0;
assign LED_POWER = 0;
assign BUTTONS   = osd_btn;
assign VGA_SCALER  = 0;
assign VGA_DISABLE = 0;
// A valid native picture replay keeps the scaler fed during a pause, so
// rewind tint is visible on both outputs. Before a complete picture exists,
// preserve the old HDMI framebuffer rather than displaying fallback black.
assign HDMI_FREEZE = ss_video_freeze && !ss_frame_valid;
// Platform audio snapshot muting must not depend on the scaler's picture hold.
assign SNAPSHOT_AUDIO_FREEZE = ss_video_freeze;
assign HDMI_BLACKOUT = 0;
assign HDMI_BOB_DEINT = 0;

wire [1:0] ar       = status[25:24];
wire       vcrop_en = status[32];
wire [3:0] vcopt    = status[36:33];
reg        en216p;
reg  [4:0] voff;
always @(posedge CLK_VIDEO) begin
	en216p <= ((HDMI_WIDTH == 1920) && (HDMI_HEIGHT == 1080) && !forced_scandoubler && !scale);
	voff <= (vcopt < 6) ? {vcopt,1'b0} : ({vcopt,1'b0} - 5'd24);
end

wire vga_de;
video_freak video_freak
(
	.*,
	.VGA_DE_IN(vga_de),
	.ARX((!ar) ? (overscan ? 8'd4 : 8'd47) : (ar - 1'd1)),
	.ARY((!ar) ? (overscan ? 8'd3 : 8'd37) : 12'd0),
	.CROP_SIZE((en216p & vcrop_en) ? 10'd216 : 10'd0),
	.CROP_OFF(voff),
	.SCALE(status[38:37])
);

// Status Bit Map:
// 0         1         2         3          4         5         6
// 01234567890123456789012345678901 23456789012345678901234567890123
// 0123456789ABCDEFGHIJKLMNOPQRSTUV 0123456789ABCDEFGHIJKLMNOPQRSTUV
// XXXX XXXXXXXXXXXXXXXXXXXXXXXXXX  XXXXXXXXXX
// Bit 11 reserved for legacy sprite option; bit 41: 0=Extra (default), 1=Normal.

`include "build_id.v"
parameter CONF_STR = {
	"TGFX16;SS3F000000:80000;",
	"-,TurboGrafx-16: To the Limit;",
	"FS0,PCEBIN,Load TurboGrafx;",
`ifndef DEBUG_BUILD
	
`endif
	"-;",
`ifdef DEBUG_PALETTES
	"F3,TGP,Load Palette;",
	"-;",
`endif
	"S0,CUECHD,Insert CD;",
	"-;",
	"C,Cheats;",
	"H1O5,Cheats enabled,ON,OFF;",
	"-;",
	"D0RG,Load Backup RAM;",
	"D0R7,Save Backup RAM;",
	"D0ON,Autosave,OFF,ON;",
	"-;",
	"P1,Audio & Video;",
	"P1-;",
	"P1OOP,Aspect ratio,Original,Full Screen,[ARC1],[ARC2];",
	"P1O8A,Scandoubler Fx,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
	"P1-;",
	"d6P1o0,Vertical Crop,Disabled,216p(5x);",
	"d6P1o14,Crop Offset,0,2,4,8,10,12,-12,-10,-8,-6,-4,-2;",
	"P1o56,Scale,Normal,V-Integer,Narrower HV-Integer,Wider HV-Integer;",
	"P1-;",
	"P1OS,Colors,Original,Raw RGB;",
	"P1OH,Overscan,Hidden,Visible;",
	"P1OF,Border Color,Original,Black;",
	"P1o9,Sprites per line,Extra,Normal;",
	"P1-;",
	"P1OK,CD Audio Boost,No,2x;",
	"P1OM,ADPCM Audio Boost,No,Yes;",
	"P1OIJ,Master Audio Boost,No,2x,4x;",
	"P3,Save States (HuCard);",
    "P3-;",
    "D8P3rA,Save State (F5);",
    "D7P3rB,Load State (F8);",
    "P3oCD,Save State Slot,1,2,3,4;",
    "D9P3oE,Rewind,Off,On;",
    "D9P3oFG,Rewind History,128 Slots,64 Slots,32 Slots,16 Slots;",
    "D9P3oHI,Capture Pace,~1 sec,~0.5 sec,~2 sec,~4 sec;",
    "P3-,Hold Backspace or Rewind;",
    "P3-,Changing these clears history;",
    "P3-,Analog video may flash;",
    "P2,Hardware;",
	"P2-;",
	"P2o78,CPU Turbo,Off,+20%,+50%;",
	"P2-;",
	"P2O3,ROM Data Swap,No,Yes;",
`ifdef DEBUG_BUILD
	"P2O6,ROM Storage,SDRAM,DDR3;",
`else
	"D4H2P2O6,ROM Storage,SDRAM,SDRAM;",
	"D4H3P2O6,ROM Storage,DDR3,DDR3;",
`endif
	"P2-;",
	"P2OE,Arcade Card,Disabled,Enabled;",
	"P2O1,CD Seek,Normal,Fast;",
	"P2-;",
	"P2OD,USER I/O,Off,SNAC;",
	"H5P2OL,MB128,Disabled,Enabled;",
	"P2-;",
	"D0P2RC,Format Backup RAM;",
	"-;",
	"H5O2,Turbo Tap,Disabled,Enabled;",
	"H5OTU,Controller,2 Buttons,2 Turbo,6 Buttons;",
	"H5OQR,Special,None,Mouse,Pachinko,XE-1AP;",
	"H5-;",
	"R0,Reset;",
    "I,Slot 1,Slot 2,Slot 3,Slot 4,Captured - slot 1,Captured - slot 2,Captured - slot 3,Captured - slot 4,Loaded - slot 1,Loaded - slot 2,Loaded - slot 3,Loaded - slot 4,State incompatible - ROM or settings,State CRC check failed,States unavailable,State operation timed out,State operation failed;",
	"J1,Button I,Button II,Select,Run,Button III,Button IV,Button V,Button VI,Rewind;",
	"jn,A,B,Select,Start,X,Y,L,R,Rewind;",
	"jp,A,B,Select,Start,L,R,Y,X,Rewind;",
	"V,v",`BUILD_DATE," Standard"
};


reg osd_btn = 0;
always @(posedge clk_sys) begin
	integer timeout = 0;
	reg	has_bootrom = 0;
	reg	last_rst = 0;

	if (reset) last_rst = 0;
	if (status[0]) last_rst = 1;

	if (cart_download & ioctl_wr & status[0]) has_bootrom <= 1;

	if (last_rst & ~status[0]) begin
		osd_btn <= 0;
		if (timeout < 24000000) begin
			timeout <= timeout + 1;
			osd_btn <= ~has_bootrom;
		end
	end
end

////////////////////   CLOCKS   ///////////////////

wire clk_sys, clk_ram;
wire pll_locked;

pll pll
(
	.refclk(CLK_50M),
	.rst(0),
	.outclk_0(clk_ram),
	.outclk_1(clk_sys),
	.locked(pll_locked)
);

///////////////////////////////////////////////////

wire [63:0] status;
wire  [1:0] buttons;

wire [12:0] joy_0;
wire [11:0] joy_1, joy_2, joy_3, joy_4;
wire [15:0] joy_a, joy_b;
wire  [7:0] pd_0;

wire        ioctl_download;
wire  [7:0] ioctl_index;
wire        ioctl_wr;
wire [24:0] ioctl_addr;
wire [15:0] ioctl_dout;
reg         ioctl_wait;
wire        forced_scandoubler;

reg  [31:0] sd_lba;
reg         sd_rd = 0;
reg         sd_wr = 0;
wire        sd_ack;
wire  [7:0] sd_buff_addr;
wire [15:0] sd_buff_dout;
wire [15:0] sd_buff_din;
wire        sd_buff_wr;
wire        img_mounted;
wire        img_readonly;
wire [63:0] img_size;

wire [21:0] gamma_bus;
wire [15:0] sdram_sz;

wire [10:0] ps2_key;
wire [24:0] ps2_mouse;
wire [15:0] ps2_mouse_ext;

hps_io #(.CONF_STR(CONF_STR), .WIDE(1)) hps_io
(
	.clk_sys(clk_sys),
	.HPS_BUS(HPS_BUS),

	.info_req(ss_info_req),
	.info(ss_info),
	.buttons(buttons),
	.status(status),
	.status_menumask({!ss_available, !ss_available | ss_machine_freeze | ss_fault_pending, !ss_available | ss_machine_freeze | ss_fault_pending, en216p, snac, 1'd1, use_sdr, ~use_sdr, ~gg_avail,~bk_ena}),
	.forced_scandoubler(forced_scandoubler),

	.sdram_sz(sdram_sz),

	.new_vmode(0),
	.gamma_bus(gamma_bus),

	.ioctl_download(ioctl_download),
	.ioctl_index(ioctl_index),
	.ioctl_wr(ioctl_wr),
	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.ioctl_wait(ioctl_wait),

	.sd_lba('{sd_lba}),
	.sd_rd(sd_rd),
	.sd_wr(sd_wr),
	.sd_ack(sd_ack),
	.sd_buff_addr(sd_buff_addr),
	.sd_buff_dout(sd_buff_dout),
	.sd_buff_din('{sd_buff_din}),
	.sd_buff_wr(sd_buff_wr),
	.img_mounted(img_mounted),
	.img_readonly(img_readonly),
	.img_size(img_size),

	.joystick_0(joy_0),
	.joystick_1(joy_1),
	.joystick_2(joy_2),
	.joystick_3(joy_3),
	.joystick_4(joy_4),
	.joystick_l_analog_0(joy_a),
	.joystick_r_analog_0(joy_b),
	.paddle_0(pd_0),

	.ps2_key(ps2_key),
	.ps2_mouse(ps2_mouse),
	.ps2_mouse_ext(ps2_mouse_ext),

	.EXT_BUS(EXT_BUS)
);

wire reset_sys_request;
reset_request_sync reset_conditioner(.clk_sys(clk_sys), .async_request(RESET), .sync_request(reset_sys_request));
wire reset = (reset_sys_request | status[0] | buttons[1] | bk_loading);

`ifdef DEBUG_PALETTES
wire palette_download = ioctl_download & (ioctl_index[5:0] == 6'h03 || (ioctl_index[7:6] == 1 && ~|ioctl_index));
`endif

wire code_index      = &ioctl_index;
wire code_download   = ioctl_download & code_index;
wire cart_download   = ioctl_download & (ioctl_index[5:0] <= 6'h01);
wire cd_data_download = ioctl_download & (ioctl_index[5:0] == 6'h02);
wire cd_audio_download = ioctl_download & (ioctl_index[5:0] == 6'h03);
wire cd_subcode_download = ioctl_download & (ioctl_index[5:0] == 6'h04);

wire overscan = ~status[17];

wire [95:0] cd_comm;
wire        cd_comm_send;
reg  [15:0] cd_stat;
reg         cd_stat_rec;
reg         cd_int_req;
reg         cd_dataout_req;
wire [79:0] cd_dataout;
wire        cd_dataout_send;
wire        cd_reset_req;
reg         cd_region;

wire [21:0] cd_ram_a;
wire        cd_ram_rd, cd_ram_wr;
wire  [7:0] cd_ram_do;

wire        ce_rom;

wire [15:0] cdda_sl, cdda_sr, adpcm_s, psg_sl, psg_sr;

pce_top #(.LITE(LITE), .HUCARD_WRAM_8K(1), .BG_CAPTURE_ENABLE(1)) pce_top
(
	.RESET(reset|cart_download|ss_fault_reset|ss_fault_pending),
	.COLD_RESET(cart_download|ss_cold_pending),

	.CLK(clk_sys),
    .SS_RROTATE(ss_reg_rotate), .SS_RADDR(ss_addr[14:0]), .SS_RDI(ss_din), .SS_RWE(ss_we && ss_addr[17:15]==6), .SS_RDO(ss_reg_dout),
    .SS_FREEZE(ss_machine_freeze), .SS_SAVE(ss_save), .SS_LIVE_CUT(bg_cut), .SS_LOAD(ss_load_commit),
    .BG_RESET(bg_power_reset), .BG_ABORT(bg_native_abort), .BG_CUT(bg_cut), .BG_RELEASE(bg_mirror_release),
    .BG_READY(bg_pce_ready), .BG_FAULT(bg_pce_fault),
    .BG_READ_VALID(bg_pce_read_valid), .BG_READ_ADDR(bg_pce_read_addr), .BG_READ_BANK(bg_pce_read_bank),
    .BG_READ_READY(bg_pce_read_ready), .BG_OUT_VALID(bg_pce_out_valid), .BG_OUT_DATA(bg_pce_out_data), .BG_OUT_READY(bg_pce_out_ready),
    .BG_WRAM_A_ADDR(bg_w_a_addr), .BG_WRAM_B_ADDR(bg_w_b_addr),
    .BG_WRAM_A_DATA(bg_w_a_data), .BG_WRAM_B_DATA(), .BG_WRAM_RAW_A(), .BG_WRAM_RAW_B(bg_w_b_raw),
    .BG_WRAM_A_WE(bg_w_a_we), .BG_WRAM_B_WE(bg_w_b_we), .BG_WRAM_A_ENABLE(bg_w_a_enable), .BG_WRAM_B_ENABLE(bg_w_b_enable),
    .BG_WRAM_A_CS(bg_w_a_cs), .BG_WRAM_B_CS(bg_w_b_cs), .BG_WRAM_RECEIPTS(bg_w_q),
    .BG_VRAM_A_ADDR(bg_v_a_addr), .BG_VRAM_B_ADDR(bg_v_b_addr),
    .BG_VRAM_A_DATA(bg_v_a_data), .BG_VRAM_B_DATA(), .BG_VRAM_RAW_A(), .BG_VRAM_RAW_B(bg_v_b_raw),
    .BG_VRAM_A_WE(bg_v_a_we), .BG_VRAM_B_WE(bg_v_b_we), .BG_VRAM_A_ENABLE(bg_v_a_enable), .BG_VRAM_B_ENABLE(bg_v_b_enable),
    .BG_VRAM_A_CS(bg_v_a_cs), .BG_VRAM_B_CS(bg_v_b_cs), .BG_VRAM_RECEIPTS(bg_v_q),
    .BG_NATIVE_CLEAR(bg_native_clear), .BG_NATIVE_FREEZE(bg_native_freeze),
    .BG_LINE_RECEIPTS(bg_line_q), .BG_SAT_RECEIPTS(), .BG_PALETTE_RECEIPTS(),
    .SS_VIDEO_PHASE(ss_video_phase),
    .SS_COMPACT(ss_operation_private),
    .SS_SAFE(ss_safe), .SS_CD_UNSAFE(ss_cd_unsafe),
    .SS_ADPCM_ADDR(ss_adpcm_addr), .SS_ADPCM_DI(ss_adpcm_din), .SS_ADPCM_WE(ss_adpcm_we), .SS_ADPCM_DO(ss_adpcm_dout), .SS_ADDR(ss_addr), .SS_DI(ss_din),
    .SS_DO(ss_ram_dout), .SS_WE(ss_we && ss_addr[17:15]!=6),
    .CPU_TURBO(status[40:39]),

	.ROM_RD(rom_rd),
	.ROM_RDY(rom_sdrdy & rom_ddrdy & ram_ddrdy),
	.ROM_A(rom_rdaddr),
	.ROM_DO(use_sdr ? rom_sdata : rom_ddata),
	.ROM_SZ(romwr_a[23:12]),
	.ROM_POP(populous[romwr_a[9]]),
	.ROM_CLKEN(ce_rom),

	.BRM_A(bram_addr),
	.BRM_DO(bram_q),
	.BRM_DI(bram_data),
	.BRM_WE(bram_wr),

	.GG_EN(status[5]),
	.GG_CODE(gg_code),
	.GG_RESET((cart_download | code_download) & ioctl_wr & !ioctl_addr),
	.GG_AVAIL(gg_avail),

	.SP64(~status[41]),
	.SGX(sgx && !LITE),

	.JOY_OUT(joy_out),
	.JOY_IN(joy_in),

	.CD_EN(cd_en),
	.AC_EN(status[14]),

	.CD_RAM_A(cd_ram_a),
	.CD_RAM_DO(cd_ram_do),
	.CD_RAM_DI(use_sdr ? rom_sdata : rom_ddata),
	.CD_RAM_RD(cd_ram_rd),
	.CD_RAM_WR(cd_ram_wr),

	.CD_STAT(cd_stat[7:0]),
	.CD_MSG(cd_stat[15:8]),
	.CD_STAT_GET(cd_stat_rec),

	.CD_COMM(cd_comm),
	.CD_COMM_SEND(cd_comm_send),

	.CD_DOUT_REQ(cd_dataout_req),
	.CD_DOUT(cd_dataout),
	.CD_DOUT_SEND(cd_dataout_send),

	.CD_REGION(cd_region),
	.CD_RESET(cd_reset_req),

	.CD_DATA(!cd_dat_byte ? cd_dat[7:0] : cd_dat[15:8]),
	.CD_DATA_WR(cd_data_wr),
	.CD_AUDIO_WR(cd_audio_wr),
	.CD_SUBCD_WR(cd_subcode_wr),
	.CD_DATA_END(cd_dat_req),
	.CD_DM(cd_dm),

	.CDDA_SL(cdda_sl),
	.CDDA_SR(cdda_sr),
	.ADPCM_S(adpcm_s),
	.PSG_SL(psg_sl),
	.PSG_SR(psg_sr),

	.BG_EN(VDC_BG_EN),
	.SPR_EN(VDC_SPR_EN),
	.GRID_EN(VDC_GRID_EN),
	.CPU_PAUSE_EN(CPU_PAUSE_EN),

	.ReducedVBL(~overscan),
	.BORDER_EN(~status[15]),
	.VIDEO_R(r),
	.VIDEO_G(g),
	.VIDEO_B(b),
	.VIDEO_BW(bw),
	//.VIDEO_CE(ce_vid),
	.VIDEO_CE_FS(ce_vid),
	.VIDEO_VS(vs),
	.VIDEO_HS(hs),
	.VIDEO_HBL(hbl),
	.VIDEO_VBL(vbl)
);


//CD communication

wire  [35:0] EXT_BUS;
reg  [112:0] cd_in = 0;
wire [112:0] cd_out;
hps_ext hps_ext
(
	.clk_sys(clk_sys),
	.EXT_BUS(EXT_BUS),
	.cd_in(cd_in),
	.cd_out(cd_out)
);

reg cd_en = 0;
always @(posedge clk_sys) begin
	if(img_mounted && img_size) cd_en <= 1;
	if(cart_download) cd_en <= 0;
end

// A host poll can return a response left over from the previous core/session.
// No-disc guest commands are still legitimate: arm their replies after the
// guest sends an actual command or outgoing data. A reset does not end that
// session, but loading a new cartridge does. Never clear the CD safety latch.
reg cd_guest_session = 0;
always @(posedge clk_sys) begin
	if(cart_download) cd_guest_session <= 0;
	else if(!reset && (cd_comm_send || cd_dataout_send)) cd_guest_session <= 1;
end
wire cd_host_reply_admit = cd_en || (img_mounted && (|img_size)) ||
                          cd_guest_session || cd_comm_send || cd_dataout_send;

reg         cd_dat_req;
always @(posedge clk_sys) begin
	reg cd_out112_last = 1;
	reg cd_comm_send_old = 0, cd_dataout_send_old = 0, cd_dat_req_old = 0, cd_reset_req_old = 0;

	cd_stat_rec <= 0;
	cd_dataout_req <= 0;
	if (reset || cart_download) begin
		cd_region <= 0;
	end
	else begin
		if (cd_out[112] != cd_out112_last) begin
			// Consume rejected toggles too, so an old reply cannot replay when
			// a guest later starts CD activity. Reject its payload and region
			// as well as its pulse: inert HuCard state must not change.
			cd_out112_last <= cd_out[112];
			if(cd_host_reply_admit) begin
			cd_stat <= cd_out[15:0];
			cd_stat_rec <= ~cd_out[16];
			cd_dataout_req <= cd_out[16];
			cd_region <= cd_out[17];
			end
		end

		cd_comm_send_old <= cd_comm_send;
		cd_dataout_send_old <= cd_dataout_send;
		cd_dat_req_old <= cd_dat_req;
		cd_reset_req_old <= cd_reset_req;
		if (cd_comm_send && !cd_comm_send_old) begin
			cd_in[95:0] <= cd_comm;
			cd_in[111:96] <= {status[1],15'd0};
			cd_in[112] <= ~cd_in[112];
		end
		else if (cd_dataout_send && !cd_dataout_send_old) begin
			cd_in[79:0] <= cd_dataout;
			cd_in[111:96] <= 16'h0001;
			cd_in[112] <= ~cd_in[112];
		end
		else if (cd_dat_req && !cd_dat_req_old) begin
			cd_in[111:96] <= 16'h0002;
			cd_in[112] <= ~cd_in[112];
		end
		else if (cd_reset_req && !cd_reset_req_old) begin
			cd_in[111:96] <= 16'h00FF;
			cd_in[112] <= ~cd_in[112];
		end
	end
end

reg [15:0] cd_dat;
reg        cd_data_wr,cd_audio_wr,cd_subcode_wr;
reg        cd_dat_byte;
reg        cd_dm;
always @(posedge clk_sys) begin
	reg old_download;
	reg head_pos, cd_dat_write;
	reg [14:0] cd_dat_len, cd_dat_cnt;

	old_download <= cd_data_download | cd_audio_download | cd_subcode_download;
	if ((~old_download && (cd_data_download || cd_audio_download || cd_subcode_download)) || reset) begin
		head_pos <= 0;
		cd_dat_len <= 0;
		cd_dat_cnt <= 0;
	end
	else if (ioctl_wr && (cd_data_download || cd_audio_download || cd_subcode_download)) begin
		if (!head_pos) begin
			{cd_dm,cd_dat_len} <= ioctl_dout;
			cd_dat_cnt <= 0;
			head_pos <= 1;
		end
		else if (cd_dat_cnt < cd_dat_len) begin
			cd_dat_write <= 1;
			cd_dat_byte <= 0;
			cd_dat <= ioctl_dout;
		end
	end

	if (cd_dat_write) begin
		if (!cd_data_wr && !cd_audio_wr && !cd_subcode_wr) begin
			cd_data_wr <= cd_data_download;
			cd_audio_wr <= cd_audio_download;
			cd_subcode_wr <= cd_subcode_download;
		end
		else begin
			cd_data_wr <= 0;
			cd_audio_wr <= 0;
			cd_subcode_wr <= 0;
			cd_dat_byte <= ~cd_dat_byte;
			cd_dat_cnt <= cd_dat_cnt + 15'd1;
			if (cd_dat_byte || cd_dat_cnt >= cd_dat_len-1) begin
				cd_dat_write <= 0;
			end
		end
	end
end


////////////////////////////  VIDEO  ///////////////////////////////////

wire [2:0] r,g,b;
wire hs,vs;
wire hbl,vbl;
wire bw;

wire ce_vid;
assign CLK_VIDEO = clk_ram;

// Independent presentation timing keeps analog sync and pixel phase running
// while the emulated VCE is frozen. It also drives the normal live path, so
// there is no output-sync mux edge when a snapshot resumes.
wire [51:0] ss_video_phase, ss_reference_phase;
wire ss_video_ce, ss_video_hs, ss_video_vs, ss_video_hbl, ss_video_vbl;
wire ss_frame_valid, ss_replay_valid, ss_replay_underflow, ss_capture_fault;
wire [9:0] ss_display_pixel;
wire [2:0] display_r=ss_display_pixel[5:3];
wire [2:0] display_g=ss_display_pixel[8:6];
wire [2:0] display_b=ss_display_pixel[2:0];
wire display_bw=ss_display_pixel[9];
wire [28:0] video_ddr_addr;
wire [63:0] video_ddr_din, video_ddr_dout;
wire [7:0] video_ddr_burst;
wire video_ddr_rd, video_ddr_we, video_ddr_busy, video_ddr_ready;
video_frame_replay video_frame_replay(
 .clk(CLK_VIDEO), .reset(reset | cart_download | ss_config_changed | ss_fault_pending),
 .enabled(ss_replay_enabled), .freeze(ss_video_freeze),
 .source_phase(ss_video_phase), .reference_phase(ss_reference_phase),
 .pixel_in({bw,g,r,b}), .pixel_out(ss_display_pixel),
 .reference_ce(ss_video_ce), .reference_hs(ss_video_hs), .reference_vs(ss_video_vs),
 .reference_hbl(ss_video_hbl), .reference_vbl(ss_video_vbl),
 .frame_valid(ss_frame_valid), .replay_valid(ss_replay_valid),
 .underflow(ss_replay_underflow), .capture_fault(ss_capture_fault),
 .ram_addr(video_ddr_addr), .ram_din(video_ddr_din), .ram_burst(video_ddr_burst),
 .ram_rd(video_ddr_rd), .ram_we(video_ddr_we),
 .ram_busy(video_ddr_busy), .ram_ready(video_ddr_ready), .ram_dout(video_ddr_dout)
);
wire ss_video_hold, ss_video_busy, ss_video_freeze, ss_video_fault;
reg ce_pix;
always @(posedge CLK_VIDEO) begin
    reg old_ce;
    old_ce <= ss_video_ce;
    ce_pix <= ~old_ce & ss_video_ce;
end

`ifdef DEBUG_PALETTES
logic [23:0] read_color;
logic [8:0] ioctl_addr_1;
logic [1:0] pal_cnt;

always @(posedge clk_sys) begin
	if (ioctl_wr & palette_download) begin
		pal_cnt <= pal_cnt + 2'd1;
		if (pal_cnt == 2) begin
			pal_cnt <= 0;
			ioctl_addr_1 <= ioctl_addr_1 + 1'd1;
		end
	end

	if (palette_download)
		read_color[{2'd2 - pal_cnt, 3'b000}+:8] <= ioctl_dout[7:0];
	else begin
		pal_cnt <= 0;
		ioctl_addr_1 <= 0;
	end
end
`endif

logic [23:0] pal_color;

dpram #(
	.addr_width(9),
	.data_width(24),
	.mem_init_file("palette.mif")
) palette_ram (
	.clock(CLK_VIDEO),

	.address_a({display_g,display_r,display_b}),
	.q_a(pal_color)

`ifdef DEBUG_PALETTES
	,
	.address_b(ioctl_addr_1),
	.enable_b(palette_download),
	.data_b({read_color[23:8], ioctl_dout[7:0]}),
	.wren_b(ioctl_wr)
`endif
);

logic [7:0] r1, b1, g1;

assign {r1, g1, b1} = status[28] ? {{display_r,display_r,display_r[2:1]}, {display_g,display_g,display_g[2:1]}, {display_b,display_b,display_b[2:1]}} : pal_color;

color_mix color_mix
(
	.clk_vid(CLK_VIDEO),
	.ce_pix(ce_pix),
	.mix(display_bw ? 3'd5 : 0),

	.R_in(r1),
	.G_in(g1),
	.B_in(b1),
	.HSync_in(ss_video_hs),
	.VSync_in(ss_video_vs),
	.HBlank_in(ss_video_hbl),
	.VBlank_in(ss_video_vbl),

	.R_out(color_R),
	.G_out(color_G),
	.B_out(color_B),
	.HSync_out(HS),
	.VSync_out(VS),
	.HBlank_out(HBlank),
	.VBlank_out(VBlank)
);

wire [7:0] R,G,B, color_R,color_G,color_B;
// Half-strength desaturation is presentation-only and never stored in
// retained pixels. No extra pixel latency or timing-signal change is added.
rewind_tint rewind_tint(.active(ss_rewind_tint_active),
 .rgb_in({color_R,color_G,color_B}), .rgb_out({R,G,B}));
wire HS,VS;
wire HBlank,VBlank;

wire [2:0] scale = status[10:8];
wire [2:0] sl = scale ? scale - 1'd1 : 3'd0;

assign VGA_SL = sl[1:0];

reg VSync, HSync;
always @(posedge CLK_VIDEO) begin
	HSync <= HS;
	if(~HSync & HS) VSync <= VS;
end

video_mixer #(.LINE_LENGTH(560), .GAMMA(1)) video_mixer
(
	.*,
	.VGA_DE(vga_de),
	// Presentation timing already runs continuously; do not select the
	// old learned-sync freezer at an unrelated phase.
	.HDMI_FREEZE(1'b0),
	.freeze_sync(),
	.scandoubler(scale || forced_scandoubler),
	.hq2x(scale==1)
);


////////////////////////////  AUDIO  ///////////////////////////////////

localparam [3:0] comp_f1 = 4;
localparam [3:0] comp_a1 = 2;
localparam       comp_x1 = ((32767 * (comp_f1 - 1)) / ((comp_f1 * comp_a1) - 1)) + 1; // +1 to make sure it won't overflow
localparam       comp_b1 = comp_x1 * comp_a1;

localparam [3:0] comp_f2 = 8;
localparam [3:0] comp_a2 = 4;
localparam       comp_x2 = ((32767 * (comp_f2 - 1)) / ((comp_f2 * comp_a2) - 1)) + 1; // +1 to make sure it won't overflow
localparam       comp_b2 = comp_x2 * comp_a2;

function [15:0] compr; input [15:0] inp;
	reg [15:0] v, v1, v2;
	begin
		v  = inp[15] ? (~inp) + 1'd1 : inp;
		v1 = (v < comp_x1[15:0]) ? (v * comp_a1) : (((v - comp_x1[15:0])/comp_f1) + comp_b1[15:0]);
		v2 = (v < comp_x2[15:0]) ? (v * comp_a2) : (((v - comp_x2[15:0])/comp_f2) + comp_b2[15:0]);
		v  = status[19] ? v2 : v1;
		compr = inp[15] ? ~(v-1'd1) : v;
	end
endfunction

reg [17:0] audio_l = 0, audio_r = 0;
reg [15:0] cmp_l = 0, cmp_r = 0;

logic [4:0] div_audio = 0;
logic adpcm_ce = 0, psg_ce = 0;

logic [15:0] adpcm_filt, psg_l_filt, psg_r_filt;
reg [17:0] pre_l = 0, pre_r = 0;
reg signed [16:0] adpcm_boost = 0;
wire [352:0] ss_psg_filter_live, ss_adpcm_filter_live;
localparam integer SS_AUDIO_BASE = 627;
localparam integer SS_AUDIO_WORDS = 54;
reg [863:0] ss_audio_shadow = 0;
wire [863:0] ss_audio_live = {15'd0, ss_adpcm_filter_live, 15'd0, ss_psg_filter_live,
    div_audio, adpcm_ce, psg_ce, audio_l, audio_r, cmp_l, cmp_r, pre_l, pre_r, adpcm_boost};
wire ss_audio_sel = ss_addr[17:15] == 6 && ss_addr[14:0] >= SS_AUDIO_BASE &&
                    ss_addr[14:0] < SS_AUDIO_BASE + SS_AUDIO_WORDS;
wire [15:0] ss_audio_dout = ss_audio_sel ? ss_audio_shadow[15:0] : 16'd0;
always @(posedge clk_sys) begin
    if (ss_save || bg_cut) ss_audio_shadow <= ss_audio_live;
    else if (ss_we && ss_audio_sel)
        ss_audio_shadow <= {ss_din, ss_audio_shadow[863:16]};
    else if (ss_reg_rotate && ss_audio_sel)
        ss_audio_shadow <= {ss_audio_shadow[15:0], ss_audio_shadow[863:16]};
end

always @(posedge clk_sys) begin
    if (ss_load_commit) {div_audio,adpcm_ce,psg_ce} <= ss_audio_shadow[127:121];
    else if (!ss_machine_freeze) begin
	// 2684650 and 1342323
	div_audio <= div_audio + 1'd1;

	adpcm_ce <= &div_audio[4:0];
	psg_ce <= &div_audio[3:0];
    end
end

tgfx_IIR_filter #(
	.coeff_x   (0.00200339512841342642),
	.coeff_x0  (2),
	.coeff_x1  (1),
	.coeff_x2  (0),
	.coeff_y0  (-1.95511712863912712201),
	.coeff_y1  (0.95667938324280066276),
	.coeff_y2  (0),
	.stereo    (1)
) psg_filter (
    .ss_freeze(ss_machine_freeze), .ss_load(ss_load_commit), .ss_d(ss_audio_shadow[128 +: 353]), .ss_q(ss_psg_filter_live),
	.clk       (clk_sys),
	.ce        (psg_ce), // (1342323 * 2)
	.sample_ce (1),
	.input_l   (psg_sl),
	.input_r   (psg_sr),
	.output_l  (psg_l_filt),
	.output_r  (psg_r_filt)
);

tgfx_IIR_filter #(
	.coeff_x   (0.00002488367092441635),
	.coeff_x0  (3),
	.coeff_x1  (3),
	.coeff_x2  (1),
	.coeff_y0  (-2.94383188882174362533),
	.coeff_y1  (2.88923013608993572987),
	.coeff_y2  (-0.94537670406128904155),
	.stereo    (0)
) adpcm_filter (
    .ss_freeze(ss_machine_freeze), .ss_load(ss_load_commit), .ss_d(ss_audio_shadow[496 +: 353]), .ss_q(ss_adpcm_filter_live),
	.clk       (clk_sys),
	.ce        (adpcm_ce), // 1342323
	.sample_ce (1),
	.input_l   (adpcm_s),
	.output_l  (adpcm_filt)
);

always @(posedge clk_sys) begin
    if (ss_load_commit) {audio_l,audio_r,cmp_l,cmp_r,pre_l,pre_r,adpcm_boost} <= ss_audio_shadow[120:0];
    else if (!ss_machine_freeze) begin
	adpcm_boost <= $signed({adpcm_filt[15], adpcm_filt}) + $signed((status[22] ? {{3{adpcm_filt[15]}}, adpcm_filt[15:2]} : 17'd0));

	pre_l <= ( CDDA_EN                  ? {{2{cdda_sl[15]}},         cdda_sl} : 18'd0)
			 + ((CDDA_EN && status[20]) ? {{2{cdda_sl[15]}},         cdda_sl} : 18'd0)
			 + ( PSG_EN                 ? {{2{psg_l_filt[15]}},   psg_l_filt} : 18'd0)
			 + ( ADPCM_EN               ? {adpcm_boost[16],   adpcm_boost} : 18'd0);

	pre_r <= ( CDDA_EN                  ? {{2{cdda_sr[15]}},         cdda_sr} : 18'd0)
			 + ((CDDA_EN && status[20]) ? {{2{cdda_sr[15]}},         cdda_sr} : 18'd0)
			 + ( PSG_EN                 ? {{2{psg_r_filt[15]}},   psg_r_filt} : 18'd0)
			 + ( ADPCM_EN               ? {adpcm_boost[16],   adpcm_boost} : 18'd0);

	if(~status[20]) begin
		// 3/4 + 1/4 to cover the whole range.
		audio_l <= $signed(pre_l) + ($signed(pre_l)>>>2);
		audio_r <= $signed(pre_r) + ($signed(pre_r)>>>2);
	end
	else begin
		audio_l <= pre_l;
		audio_r <= pre_r;
	end

	cmp_l <= compr(audio_l[17:2]);
	cmp_r <= compr(audio_r[17:2]);
    end
end

assign AUDIO_L = rw_held_active ? 16'd0 : (status[19:18] ? cmp_l : audio_l[17:2]);
assign AUDIO_R = rw_held_active ? 16'd0 : (status[19:18] ? cmp_r : audio_r[17:2]);
assign AUDIO_S = 1;
assign AUDIO_MIX = 0;


////////////////////////////  MEMORY  //////////////////////////////////

reg use_sdr = 0;
always @(posedge clk_ram) if(~rom_rd) use_sdr <= |sdram_sz[14:0];

wire [21:0] rom_rdaddr;
wire  [7:0] rom_ddata, rom_sdata;
wire        rom_rd, rom_sdrdy, rom_ddrdy, ram_ddrdy;

assign DDRAM_CLK = clk_ram;
ddram ddram
(
    .DDRAM_CLK(DDRAM_CLK), .DDRAM_BUSY(primary_ddr_busy | ss_take_ddr),
    .DDRAM_BURSTCNT(normal_burst), .DDRAM_ADDR(normal_addr),
    .DDRAM_DOUT(primary_ddr_dout), .DDRAM_DOUT_READY(primary_ddr_ready & !ss_take_ddr),
    .DDRAM_RD(normal_rd), .DDRAM_DIN(normal_din), .DDRAM_BE(normal_be),
    .DDRAM_WE(normal_we),
	.clkref(ce_rom),

	.wraddr(cart_download ? romwr_a : {3'b001,cd_ram_a}),
	.din(cart_download ? romwr_d : {cd_ram_do,cd_ram_do}),
	.we(~cart_download & ~use_sdr & cd_ram_wr & ce_rom),
	.we_req(rom_wr),
	.we_ack(dd_wrack),
	.we_rdy(ram_ddrdy),

	.rdaddr(rom_rd ? {3'b000,(rom_rdaddr + (romwr_a[9] ? 22'h200 : 22'h0))} : {3'b001,cd_ram_a}),
	.rd(~use_sdr & (rom_rd | cd_ram_rd) & ce_rom),
	.rd_rdy(rom_ddrdy),
    .idle(normal_ddr_idle),
	.dout(rom_ddata)
);

sdram sdram
(
    .*,
    .ss_save(ss_save), .ss_load(ss_sdram_load),
    .ss_live_clk(clk_sys), .ss_live_cut(bg_cut), .ss_live_reg_dout(bg_sdram_dout),
    .ss_scan_freeze(ss_machine_freeze),.ss_scan_req(ss_cdram_req),.ss_scan_wr(ss_cdram_write),
    .ss_scan_addr(ss_cdram_scan_addr),.ss_scan_din(ss_cdram_din),.ss_scan_ack(ss_cdram_ack),.ss_scan_dout(ss_cdram_dout),
    .ss_reg_addr(ss_addr[14:0]), .ss_reg_din(ss_din),
    .ss_reg_we(ss_we && ss_addr[17:15]==6), .ss_reg_dout(ss_sdram_dout),

	.init(~pll_locked),
	.clk(clk_ram),
	.clkref(ce_rom),

	.waddr(cart_download ? romwr_a : ss_cdram_normal_addr),
	.din(cart_download ? romwr_d : {cd_ram_do,cd_ram_do}),
	.we(~cart_download & use_sdr & cd_ram_wr & ce_rom),
	.we_req(rom_wr),
	.we_ack(sd_wrack),

	.raddr(rom_rd ? {3'b000,(rom_rdaddr + (romwr_a[9] ? 22'h200 : 22'h0))} : ss_cdram_normal_addr),
	.rd(use_sdr & (rom_rd | cd_ram_rd) & ce_rom),
	.rd_rdy(rom_sdrdy),
	.dout(rom_sdata)
);


wire        romwr_ack;
reg  [23:0] romwr_a;
reg  rom_wr = 0;
wire sd_wrack, dd_wrack;
// DDR runs at twice clk_sys. Capture its stable toggle acknowledgment in
// clk_sys before the loader's equality/address-enable logic; the request and
// data remain held until both captured DDR and SDRAM acknowledgments match.
(* altera_attribute = "-name PRESERVE_REGISTER ON" *) reg dd_wrack_sys = 0;
always @(posedge clk_sys) dd_wrack_sys <= dd_wrack;

// Snapshot CD staging occupies SDRAM 0x640000..0x67ffff. Do not allow
// snapshots for oversized/unknown cartridges: a wrapping 24-bit download
// counter must not make a large image look small again. This guard does not
// change normal cartridge loading or CD operation.
reg ss_cart_old = 0;
reg ss_rom_oversize = 1;
// Snapshot identity must describe the setting that actually loaded this cart.
// Tracking is observational only: normal loader/game behavior is unchanged.
reg ss_cart_swap = 0, ss_cart_swap_changed = 1, ss_cart_word_seen = 0;
reg ss_cart_tail = 0, ss_reset_old = 0;
always @(posedge clk_sys) begin
    ss_cart_old <= cart_download;
    ss_cart_tail <= ss_cart_old;
    ss_reset_old <= reset;
    if (!ss_cart_old && cart_download) begin
        ss_rom_oversize <= 0;
        ss_cart_swap <= status[3];
        // Loader discards a same-edge start/data strobe: never snapshot it.
        // Do not call this a clean epoch while an older toggle can still
        // advance the newly reset loader address. Unknown/X values also take
        // the conservative else branch in simulation.
        ss_cart_swap_changed <= 1;
        if (!ioctl_wr && !ioctl_wait && (rom_wr == sd_wrack) && (rom_wr == dd_wrack_sys))
            ss_cart_swap_changed <= 0;
        ss_cart_word_seen <= 0;
    end else begin
        if (cart_download && ioctl_wr && romwr_a >= 24'h400000)
            ss_rom_oversize <= 1;
        if ((cart_download || ss_cart_old || ss_cart_tail) && status[3] != ss_cart_swap)
            ss_cart_swap_changed <= 1;
        // A second strobe while the preceding request waits can overwrite
        // the loader toggle/address; refuse snapshots until a clean reload.
        if (cart_download && ioctl_wr && ioctl_wait)
            ss_cart_swap_changed <= 1;
        // After download falls the loader write mux selects CD, not the ROM.
        // A late strobe or outstanding wait cannot safely be certified by a
        // later ACK; reset may also clear wait before a pending write drains.
        if (((ss_cart_old || ss_cart_tail) && !cart_download && (ioctl_wr || ioctl_wait)) ||
            (!cart_download && !ioctl_download && ioctl_wr) ||
            (reset && !ss_reset_old && ioctl_wait))
            ss_cart_swap_changed <= 1;
        if (cart_download && ioctl_wr) ss_cart_word_seen <= 1;
    end
end
wire ss_cart_swap_ok = ss_cart_word_seen && !ss_cart_swap_changed && !ss_cart_old && !ss_cart_tail && !ioctl_wait && !ioctl_wr && (status[3] == ss_cart_swap);
wire [15:0] romwr_d = status[3] ?
		{ ioctl_dout[8], ioctl_dout[9], ioctl_dout[10],ioctl_dout[11],ioctl_dout[12],ioctl_dout[13],ioctl_dout[14],ioctl_dout[15],
		  ioctl_dout[0], ioctl_dout[1], ioctl_dout[2], ioctl_dout[3], ioctl_dout[4], ioctl_dout[5], ioctl_dout[6], ioctl_dout[7] }
		: ioctl_dout;

reg [1:0] populous;
reg sgx;
always @(posedge clk_sys) begin
	reg old_download, old_reset;

	old_download <= cart_download;
	old_reset <= reset;

	if(~old_reset && reset) ioctl_wait <= 0;
	if(~old_download && cart_download) begin
		romwr_a <= 0;
		populous <= 2'b11;
		sgx <= ioctl_index[0];
	end
	else begin
		if(ioctl_wr & cart_download) begin
			ioctl_wait <= 1;
			rom_wr <= ~rom_wr;
			if((romwr_a[23:4] == 'h212) || (romwr_a[23:4] == 'h1f2)) begin
				case(romwr_a[3:0])
					 6: if(romwr_d != 'h4F50) populous[romwr_a[13]] <= 0;
					 8: if(romwr_d != 'h5550) populous[romwr_a[13]] <= 0;
					10: if(romwr_d != 'h4F4C) populous[romwr_a[13]] <= 0;
					12: if(romwr_d != 'h5355) populous[romwr_a[13]] <= 0;
				endcase
			end
		end else if(ioctl_wait && (rom_wr == dd_wrack_sys) && (rom_wr == sd_wrack)) begin
			ioctl_wait <= 0;
			romwr_a <= romwr_a + 2'd2;
		end
	end
end


////////////////////////////  CODES  ///////////////////////////////////

reg [128:0] gg_code;
wire gg_avail;

// Code layout:
// {clock bit, code flags,     32'b address, 32'b compare, 32'b replace}
//  128        127:96          95:64         63:32         31:0
// Integer values are in BIG endian byte order, so it up to the loader
// or generator of the code to re-arrange them correctly.

always_ff @(posedge clk_sys) begin
	gg_code[128] <= 1'b0;

	if (code_download & ioctl_wr) begin
		case (ioctl_addr[3:0])
			0:  gg_code[111:96]  <= ioctl_dout; // Flags Bottom Word
			2:  gg_code[127:112] <= ioctl_dout; // Flags Top Word
			4:  gg_code[79:64]   <= ioctl_dout; // Address Bottom Word
			6:  gg_code[95:80]   <= ioctl_dout; // Address Top Word
			8:  gg_code[47:32]   <= ioctl_dout; // Compare Bottom Word
			10: gg_code[63:48]   <= ioctl_dout; // Compare top Word
			12: gg_code[15:0]    <= ioctl_dout; // Replace Bottom Word
			14: begin
				gg_code[31:16]   <= ioctl_dout; // Replace Top Word
				gg_code[128]     <=  1'b1;      // Clock it in
			end
		endcase
	end
end


////////////////////////////  INPUT  ///////////////////////////////////

wire [15:0] joy_data;
always_comb begin
	case (joy_port)
		0: joy_data = (status[27:26] == 2'b01) ? {mouse_data, mouse_data} :
						  (status[27:26] == 2'b11) ? {xe1_data[2], xe1_data[1], xe1_data[3], xe1_data[0], xe1_runbtn, xe1_selbtn, xe1_trg2, xe1_trg1,
																xe1_data[2], xe1_data[1], xe1_data[3], xe1_data[0], xe1_runbtn, xe1_selbtn, xe1_trg2, xe1_trg1} :
						                            ~{4'hF, joy_0[11:8], joy_0[1], joy_0[2], joy_0[0], joy_0[3], joy_0[7:6], (status[30:29] == 2'b01) ? joyrept_0[1:0] : joy_0[5:4]};
															  
		1: joy_data = (status[27:26] == 2'b10) ? pachinko                 : ~{4'hF, joy_1[11:8], joy_1[1], joy_1[2], joy_1[0], joy_1[3], joy_1[7:6], (status[30:29] == 2'b01) ? joyrept_1[1:0] : joy_1[5:4]};
		2: joy_data = ~{4'hF, joy_2[11:8], joy_2[1], joy_2[2], joy_2[0], joy_2[3], joy_2[7:6], (status[30:29] == 2'b01) ? joyrept_2[1:0] : joy_2[5:4]};
		3: joy_data = ~{4'hF, joy_3[11:8], joy_3[1], joy_3[2], joy_3[0], joy_3[3], joy_3[7:6], (status[30:29] == 2'b01) ? joyrept_3[1:0] : joy_3[5:4]};
		4: joy_data = ~{4'hF, joy_4[11:8], joy_4[1], joy_4[2], joy_4[0], joy_4[3], joy_4[7:6], (status[30:29] == 2'b01) ? joyrept_4[1:0] : joy_4[5:4]};
		default: joy_data = 16'h0FFF;
	endcase
end

reg [6:0] pachinko;
always @(posedge clk_sys) begin
	reg use_paddle = 0;
	reg old_pd = 0;

	old_pd <= pd_0[5];
	if(old_pd ^ pd_0[5]) use_paddle <= 1;
	if(reset | cart_download) use_paddle <= 0;

	if(use_paddle) begin
		// use only second half of paddle range
		// Spring centering paddles then can simulate pachinko's spring

		pachinko <= pd_0[6:0];
		if(pd_0 < 8'h83) pachinko <= 7'h3;
		else if(pd_0 > 8'hF4) pachinko <= 7'h74;
	end
	else begin
		pachinko <= 7'd0 - joy_a[14:8];
		if(joy_a[15:8] > 8'hFC || !joy_a[15]) pachinko <= 7'h3;
		else if(joy_a[15:8] < 8'h8B) pachinko <= 7'h74;
	end
end

wire [7:0] mouse_data;
assign mouse_data[3:0] = ~{ joy_0[7:6] | {ps2_mouse_ext[8], ps2_mouse_ext[9]} , ps2_mouse[0], ps2_mouse[1]};

always_comb begin
	case (mouse_cnt)
		0: mouse_data[7:4] = ms_x[7:4];
		1: mouse_data[7:4] = ms_x[3:0];
		2: mouse_data[7:4] = ms_y[7:4];
		3: mouse_data[7:4] = ms_y[3:0];
	endcase
end

reg [3:0] joy_latch;
reg [2:0] joy_port;
reg [3:0] scan_counter = 0;
reg [1:0] joyrept_0;
reg [1:0] joyrept_1;
reg [1:0] joyrept_2;
reg [1:0] joyrept_3;
reg [1:0] joyrept_4;
reg [1:0] mouse_cnt;
reg [7:0] ms_x, ms_y;

 reg [3:0] ss_sh_joy_latch;
 reg [2:0] ss_sh_joy_port;
 reg [3:0] ss_sh_scan_counter;
 reg [1:0] ss_sh_joyrept_0;
 reg [1:0] ss_sh_joyrept_1;
 reg [1:0] ss_sh_joyrept_2;
 reg [1:0] ss_sh_joyrept_3;
 reg [1:0] ss_sh_joyrept_4;
 reg [1:0] ss_sh_mouse_cnt;
 reg [7:0] ss_sh_ms_x;
 reg [7:0] ss_sh_ms_y;
 reg [1:0] ss_sh_last_gp;
 reg  ss_sh_high_buttons;
 reg [14:0] ss_sh_mouse_to;
 reg  ss_sh_ms_stb;
 reg [7:0] ss_sh_msr_x;
 reg [7:0] ss_sh_msr_y;

always @(posedge clk_sys) begin : input_block
	reg  [1:0] last_gp;
	reg        high_buttons = 0;
	reg [14:0] mouse_to;
	reg        ms_stb;
	reg  [7:0] msr_x, msr_y;

 if(ss_save || bg_cut) begin
 ss_sh_joy_latch <= joy_latch;
 ss_sh_joy_port <= joy_port;
 ss_sh_scan_counter <= scan_counter;
 ss_sh_joyrept_0 <= joyrept_0;
 ss_sh_joyrept_1 <= joyrept_1;
 ss_sh_joyrept_2 <= joyrept_2;
 ss_sh_joyrept_3 <= joyrept_3;
 ss_sh_joyrept_4 <= joyrept_4;
 ss_sh_mouse_cnt <= mouse_cnt;
 ss_sh_ms_x <= ms_x;
 ss_sh_ms_y <= ms_y;
 ss_sh_last_gp <= last_gp;
 ss_sh_high_buttons <= high_buttons;
 ss_sh_mouse_to <= mouse_to;
 ss_sh_ms_stb <= ms_stb;
 ss_sh_msr_x <= msr_x;
 ss_sh_msr_y <= msr_y;
 end
 if(ss_we && ss_addr[17:15]==6) case(ss_addr[14:0])
 15'd561: ss_sh_joy_latch <= ss_din[3:0];
 15'd562: ss_sh_joy_port <= ss_din[2:0];
 15'd563: ss_sh_scan_counter <= ss_din[3:0];
 15'd564: ss_sh_joyrept_0 <= ss_din[1:0];
 15'd565: ss_sh_joyrept_1 <= ss_din[1:0];
 15'd566: ss_sh_joyrept_2 <= ss_din[1:0];
 15'd567: ss_sh_joyrept_3 <= ss_din[1:0];
 15'd568: ss_sh_joyrept_4 <= ss_din[1:0];
 15'd569: ss_sh_mouse_cnt <= ss_din[1:0];
 15'd570: ss_sh_ms_x <= ss_din[7:0];
 15'd571: ss_sh_ms_y <= ss_din[7:0];
 15'd572: ss_sh_last_gp <= ss_din[1:0];
 15'd573: ss_sh_high_buttons <= ss_din[0];
 15'd574: ss_sh_mouse_to <= ss_din[14:0];
 15'd575: ss_sh_ms_stb <= ss_din[0];
 15'd576: ss_sh_msr_x <= ss_din[7:0];
 15'd577: ss_sh_msr_y <= ss_din[7:0];
 default: ;
 endcase
 if(ss_load_commit) begin
 joy_latch <= ss_sh_joy_latch;
 joy_port <= ss_sh_joy_port;
 scan_counter <= ss_sh_scan_counter;
 joyrept_0 <= ss_sh_joyrept_0;
 joyrept_1 <= ss_sh_joyrept_1;
 joyrept_2 <= ss_sh_joyrept_2;
 joyrept_3 <= ss_sh_joyrept_3;
 joyrept_4 <= ss_sh_joyrept_4;
 mouse_cnt <= ss_sh_mouse_cnt;
 ms_x <= ss_sh_ms_x;
 ms_y <= ss_sh_ms_y;
 last_gp <= ss_sh_last_gp;
 high_buttons <= ss_sh_high_buttons;
 mouse_to <= ss_sh_mouse_to;
 ms_stb <= ss_sh_ms_stb;
 msr_x <= ss_sh_msr_x;
 msr_y <= ss_sh_msr_y;
 end else if(!ss_machine_freeze) begin

	joy_latch <= joy_data[{high_buttons, joy_out[0], 2'b00} +:4];

	last_gp <= joy_out;

	if(joy_out[1]) mouse_to <= 0;
	else if(~&mouse_to) mouse_to <= mouse_to + 1'd1;

	if(&mouse_to) mouse_cnt <= 3;
	if(~last_gp[1] & joy_out[1]) begin
	
  		scan_counter <= scan_counter + 1'd1;
		joyrept_0[0] <= (joy_0[8] & scan_counter[2]) | (joy_0[10] & scan_counter[1]) | joy_0[4];
		joyrept_0[1] <= (joy_0[9] & scan_counter[2]) | (joy_0[11] & scan_counter[1]) | joy_0[5];
		
		joyrept_1[0] <= (joy_1[8] & scan_counter[2]) | (joy_1[10] & scan_counter[1]) | joy_1[4];
		joyrept_1[1] <= (joy_1[9] & scan_counter[2]) | (joy_1[11] & scan_counter[1]) | joy_1[5];
		
		joyrept_2[0] <= (joy_2[8] & scan_counter[2]) | (joy_2[10] & scan_counter[1]) | joy_2[4];
		joyrept_2[1] <= (joy_2[9] & scan_counter[2]) | (joy_2[11] & scan_counter[1]) | joy_2[5];
		
		joyrept_3[0] <= (joy_3[8] & scan_counter[2]) | (joy_3[10] & scan_counter[1]) | joy_3[4];
		joyrept_3[1] <= (joy_3[9] & scan_counter[2]) | (joy_3[11] & scan_counter[1]) | joy_3[5];
		
		joyrept_4[0] <= (joy_4[8] & scan_counter[2]) | (joy_4[10] & scan_counter[1]) | joy_4[4];
		joyrept_4[1] <= (joy_4[9] & scan_counter[2]) | (joy_4[11] & scan_counter[1]) | joy_4[5];
		

		mouse_cnt <= mouse_cnt + 1'd1;
		if(&mouse_cnt) begin
			ms_x  <= msr_x;
			ms_y  <= msr_y;
			msr_x <= 0;
			msr_y <= 0;
		end
	end

	ms_stb <= ps2_mouse[24];
	if(ms_stb ^ ps2_mouse[24]) begin
		msr_x <= 8'd0 - ps2_mouse[15:8];
		msr_y <= ps2_mouse[23:16];
	end

	if (joy_out[1]) begin
		joy_port  <= 0;
		if (status[27:26] != 2'b11) begin
			joy_latch <= 0;
			if (~last_gp[1] && (status[30:29] == 2'b10)) high_buttons <= ~high_buttons;
		end
		else
			high_buttons <= 0;
	end
	else if (joy_out[0] && ~last_gp[0] && (status[2] | status[27]) && (status[27:26] != 2'b11)) begin	// suppress if XE-1AP
		joy_port <= joy_port + 3'd1;
	end
    if (reset || ss_fault_pending) high_buttons <= 0;

end
end

wire snac = status[13];

// Index Name    HDMI System
// 0   = D+    = 2  = d1/right/2
// 1   = D-    = 1  = d0/up/1
// 2   = TX-   = 5  = SEL
// 3   = GND_d = 4  = d3/left/run
// 4   = RX+   = 6  = CLR
// 5   = RX-   = 3  = d2/down/sel

reg [3:0] snac_dat;
reg       snac_sel, snac_clr;
always @(posedge clk_sys) begin
	reg [2:0] d0sr, d1sr, d2sr, d3sr;
	reg [20:0] sesr, clsr;

	d0sr <= {d0sr[1:0],  USER_IN[1]};
	d1sr <= {d1sr[1:0],  USER_IN[0]};
	d2sr <= {d2sr[1:0],  USER_IN[5]};
	d3sr <= {d3sr[1:0],  USER_IN[3]};
	sesr <= {sesr[8:0],  joy_out[0]};
	clsr <= {clsr[19:0], joy_out[1]};

	snac_dat <= {|d3sr, |d2sr, |d1sr, |d0sr};
	snac_sel <= |sesr;
	snac_clr <= |clsr;
end

wire [1:0] joy_out;
wire [3:0] joy_in = snac ? snac_dat : (mb128_ena & mb128_Active) ? mb128_Data : joy_latch;

assign USER_OUT = snac ? {2'b11, snac_clr, 1'b1, snac_sel, 2'b11} : '1;

wire xe1_trg1;
wire xe1_trg2;
wire xe1_runbtn;
wire xe1_selbtn;
wire [3:0] xe1_data;

XE1AP #(43) XE1AP		// 43 clock cycles per microsecond
(
	.reset(reset|cart_download),
	.clk_sys(clk_sys),

   .joystick_0(joy_0),
   .joystick_l_analog_0(joy_a),
   .joystick_r_analog_0(joy_b),

   .orientation(1),                     // throttle on the right side, stick on the left side
   .req(joy_out[1]),			// signal requesting response from XE-1AP (on return to high)
									// pin 8 on original 9-pin connector 
   .lo_hi(xe1_trg1),			// pin 6 on original 9-pin connector
   .ack(xe1_trg2),			// pin 7 on original 9-pin connector
   .data(xe1_data),			// Data[3] = pin 4 on original 9-pin connector
									// Data[2] = pin 3 on original 9-pin connector
									// Data[1] = pin 2 on original 9-pin connector
									// Data[0] = pin 1 on original 9-pin connector
   .run_btn(xe1_runbtn),	// need to send back for the XHE-3 PC Engine attachment
   .select_btn(xe1_selbtn)	// need to send back for the XHE-3 PC Engine attachment

);

/////////////////////////  BACKUP RAM SAVE/LOAD  /////////////////////////////

wire [15:0] mb128_dout;
wire        mb128_dirty;
wire        mb128_ena = status[21];
wire        mb128_Active;
wire  [3:0] mb128_Data;

MB128 MB128
(
	.reset(reset|cart_download),
	.clk_sys(clk_sys),

	.i_Clk(mb128_ena & joy_out[1]),	// send only if MB128 enabled
	.i_Data(joy_out[0]),

   .o_Active(mb128_Active),	// high if MB128 asserts itself instead of joypad inputs
	.o_Data(mb128_Data),

	.bk_clk(clk_sys),
	.bk_address({sd_lba[7:0] - 3'd4,sd_buff_addr}),
	.bk_din(sd_buff_dout),
	.bk_dout(mb128_dout),
	.bk_we(~bk_int & sd_buff_wr & sd_ack),
	.bk_written(mb128_dirty)
);

reg bk_pending;

always @(posedge clk_sys) begin
	if (bk_ena && (ss_load_commit || (~OSD_STATUS && (bram_wr || mb128_dirty))))
		bk_pending <= 1'b1;
	else if (bk_state)
		bk_pending <= 1'b0;
end

wire [10:0] bram_addr;
wire  [7:0] bram_data;
wire  [7:0] bram_q;
wire  [7:0] bram_q_raw;
wire [7:0] ss_bram_qa0, ss_bram_qa1;
wire [15:0] ss_bram_qb0, ss_bram_qb1;
wire [15:0] ss_bram_word;
// Not reset on console reset or cartridge download: active storage must remain
// selected across those events, just as the original single RAM persists.
reg ss_bram_bank = 0;
always @(posedge clk_sys) if (ss_load_commit) ss_bram_bank <= ~ss_bram_bank;
assign bram_q_raw = ss_bram_bank ? ss_bram_qa1 : ss_bram_qa0;
assign ss_bram_word = ss_bram_bank ? ss_bram_qb1 : ss_bram_qb0;
reg [7:0] ss_bram_q;
reg ss_bram_replay = 0;
// Shadow the synchronous CPU-side output so the first restored bus read
// sees the saved latch, even when the restored address differs.
always @(posedge clk_sys) begin
    ss_bram_replay <= ss_machine_freeze;
    if (ss_save || bg_cut) ss_bram_q <= bram_q_raw;
    if (ss_we && ss_addr[17:15] == 7 && ss_addr[14:0] == 1024)
        ss_bram_q <= ss_din[7:0];
end
assign bram_q = ss_bram_replay ? ss_bram_q : bram_q_raw;
wire        bram_wr;

wire        format = status[12];
reg   [3:0] defbram = 4'hF;
reg  [15:0] defval[4] = '{ 16'h5548, 16'h4D42, 16'h8800, 16'h8010 }; //{ HUBM,0x00881080 };

wire        bk_int = !sd_lba[31:2];
wire [15:0] bk_int_dout = ss_bram_word;

assign      sd_buff_din = bk_int ? bk_int_dout : mb128_dout;

// Double-buffer the 2 KiB battery RAM. A validated state is written only
// to the inactive copy; ss_load_commit swaps the visible bank atomically. Normal
// CPU and SD/format writes address the active copy only.
wire [9:0] ss_bram_baddr = ss_machine_freeze ? ss_addr[9:0] :
                            (defbram[3] ? {sd_lba[1:0],sd_buff_addr} : defbram[2:1]);
wire [15:0] ss_bram_bdata = ss_machine_freeze ? ss_din :
                            (defbram[3] ? sd_buff_dout : defval[defbram[2:1]]);
wire ss_bram_scan_write = ss_machine_freeze && ss_we && ss_addr[17:15] == 7 && ss_addr[14:0] < 1024;
wire ss_bram_host_write = !ss_machine_freeze && (defbram[3] ? bk_int & sd_buff_wr & sd_ack : 1'b1);
dpram_difclk #(11,8,10,16) backram0
(
 .clock0(clk_sys), .address_a(bram_addr), .data_a(bram_data),
 .wren_a(bram_wr && !ss_machine_freeze && !ss_bram_bank), .enable_a(!ss_machine_freeze && !ss_bram_bank), .q_a(ss_bram_qa0),
 .clock1(clk_sys), .address_b(ss_bram_baddr), .data_b(ss_bram_bdata),
 .wren_b((ss_bram_host_write && !ss_bram_bank) || (ss_bram_scan_write && ss_bram_bank)), .q_b(ss_bram_qb0)
);
dpram_difclk #(11,8,10,16) backram1
(
 .clock0(clk_sys), .address_a(bram_addr), .data_a(bram_data),
 .wren_a(bram_wr && !ss_machine_freeze && ss_bram_bank), .enable_a(!ss_machine_freeze && ss_bram_bank), .q_a(ss_bram_qa1),
 .clock1(clk_sys), .address_b(ss_bram_baddr), .data_b(ss_bram_bdata),
 .wren_b((ss_bram_host_write && ss_bram_bank) || (ss_bram_scan_write && !ss_bram_bank)), .q_b(ss_bram_qb1)
);

wire downloading = cart_download;
reg old_downloading = 0;

reg bk_ena = 0;
always @(posedge clk_sys) begin

	old_downloading <= downloading;
	if(~old_downloading & downloading) bk_ena <= 0;

	//Save file always mounted in the end of downloading state.
	if(downloading && img_mounted && !img_readonly) bk_ena <= 1;
end

wire bk_load    = status[16];
// Rewind changes in-memory battery RAM; automatic SD writes wait until release.
// On release the existing OSD-triggered autosave/manual-save policy applies.
wire bk_manual_save = status[7];
wire bk_autosave = bk_pending & OSD_STATUS && status[23] && !rw_held_active;
wire bk_save = bk_manual_save | bk_autosave;
reg  bk_loading = 0;
reg  bk_state   = 0;
// Snapshot freezes must not consume backup request edges. A one-deep request
// queue also retains short manual pulses until SD is idle; load wins a tie.
// Keep autosave separate so a queued OSD request cannot interrupt resumed rewind.
reg bk_req_load=0, bk_req_save=0, bk_req_auto=0;
// Cartridge completion may occur before a cancelled snapshot has drained.
// Retain its battery import independently, with priority over manual requests.
reg bk_req_boot=0;
// Format operates on local battery RAM even without an SD backing file.
// Serialize it with backup transfers and retain a short pulse across freezes.
reg bk_req_format=0;

always @(posedge clk_sys) begin
	reg old_format = 0;
	reg old_load = 0, old_save = 0, old_auto = 0, old_ack;
	reg mb128sz;

	old_load <= bk_load;
	old_save <= bk_manual_save;
	old_auto <= bk_autosave;
	old_ack  <= sd_ack;

	if(~old_ack & sd_ack) {sd_rd, sd_wr} <= 0;

	if(bk_ena && !downloading) begin
		if(old_downloading) bk_req_boot <= 1;
		if(~old_load & bk_load) bk_req_load <= 1;
		if(~old_save & bk_manual_save) bk_req_save <= 1;
		if(~old_auto & bk_autosave) bk_req_auto <= 1;
	end

	if(!downloading && !old_format && format) bk_req_format <= 1;

	// WAIT_SAFE is already an accepted snapshot even before freeze rises.
	// Do not let an SD/format dispatch race that same freeze-acceptance edge.
	if(!bk_state && !ss_machine_freeze && !ss_backend_busy && !ss_video_busy && defbram[3]) begin
		if(bk_ena && !downloading && (bk_req_boot || old_downloading)) begin
			bk_state <= 1;
			bk_loading <= 1;
			mb128sz <= 1;
			sd_lba <= 0;
			sd_rd <= 1;
			sd_wr <= 0;
			bk_req_load <= 0; bk_req_save <= 0; bk_req_auto <= 0; bk_req_boot <= 0;
		end else if(!downloading && (bk_req_format || (!old_format && format))) begin
			defbram <= 0;
			bk_req_format <= 0;
		end else if(bk_ena && !downloading &&
		            (bk_req_load || bk_req_save || (~old_load & bk_load) || (~old_save & bk_manual_save) ||
		             (!rw_held_active && (bk_req_auto || (~old_auto & bk_autosave))))) begin
			bk_state <= 1;
			bk_loading <= bk_req_load || (~old_load & bk_load);
			mb128sz <= bk_req_load || (~old_load & bk_load) || (mb128_ena && mb128_dirty);
			sd_lba <= 0;
			sd_rd <= bk_req_load || (~old_load & bk_load);
			sd_wr <= !(bk_req_load || (~old_load & bk_load));
			bk_req_load <= 0; bk_req_save <= 0; bk_req_auto <= 0;
		end
	end else if (bk_state) begin
		if(old_ack & ~sd_ack) begin
			if(sd_lba[8] == mb128sz && &sd_lba[1:0]) begin
				bk_loading <= 0;
				bk_state <= 0;
				sd_lba <= 0;
			end else begin
				sd_lba <= sd_lba + 1'd1;
				sd_rd  <=  bk_loading;
				sd_wr  <= ~bk_loading;
			end
		end
	end

	// Never carry a request across cartridge identity or backup availability.
	if(downloading || !bk_ena) begin bk_req_load <= 0; bk_req_save <= 0; bk_req_auto <= 0; bk_req_boot <= 0; end

	if(downloading) bk_req_format <= 0;
	old_format <= format;
	// The BRAM host port is blocked while frozen. Advance only on cycles
	// that can actually write a format byte-pair, never skip frozen writes.
	if(~defbram[3] && !ss_machine_freeze && !bk_state) begin
		defbram <= defbram + 4'd1;
	end
end


/////////////////////////////////////////////////////////////////////////

//reg dbg_menu = 0;
//always @(posedge clk_sys) begin
//	reg old_stb;
//	reg enter = 0;
//	reg esc = 0;
//
//	old_stb <= ps2_key[10];
//	if(old_stb ^ ps2_key[10]) begin
//		if(ps2_key[7:0] == 'h5A) enter <= ps2_key[9];
//		if(ps2_key[7:0] == 'h76) esc   <= ps2_key[9];
//	end
//
//	if(enter & esc) begin
//		dbg_menu <= ~dbg_menu;
//		enter <= 0;
//		esc <= 0;
//	end
//end

`ifdef DEBUG_BUILD

reg VDC_BG_EN  = 1;
reg VDC_SPR_EN = 1;
reg [1:0] VDC_GRID_EN = 2'd0;
reg CPU_PAUSE_EN = 0;
reg PSG_EN  = 1;
reg CDDA_EN = 1;
reg ADPCM_EN = 1;

wire       pressed = ps2_key[9];
wire [8:0] code    = ps2_key[8:0];
always @(posedge clk_sys) begin
	reg old_state = 0;

	old_state <= ps2_key[10];

	if((ps2_key[10] != old_state) && pressed) begin
		casex(code)
			'h005: begin VDC_BG_EN <= ~VDC_BG_EN; end 			// F1
			'h006: begin VDC_SPR_EN <= ~VDC_SPR_EN; end 			// F2
			'h004: begin VDC_GRID_EN <= VDC_GRID_EN + 2'd1; end// F3
			'h00C: begin PSG_EN <= ~PSG_EN; end 					// F4
			'h003: begin CDDA_EN <= ~CDDA_EN; end 					// F5
			'h00B: begin ADPCM_EN <= ~ADPCM_EN; end 				// F6
			'h083: begin CPU_PAUSE_EN <= ~CPU_PAUSE_EN; end 	// F7
		endcase
	end
end

`else

wire VDC_BG_EN  = 1;
wire VDC_SPR_EN = 1;
wire [1:0] VDC_GRID_EN = 2'd0;
wire CPU_PAUSE_EN = 0;
wire PSG_EN  = 1;
wire CDDA_EN = 1;
wire ADPCM_EN = 1;

`endif


// Four SD-backed HuCard slots. MiSTer Main imports and persists their DDR images.
assign ss_input_dout = ss_addr[14:0]==15'd561 ? { 12'd0,ss_sh_joy_latch } :
ss_addr[14:0]==15'd562 ? { 13'd0,ss_sh_joy_port } :
ss_addr[14:0]==15'd563 ? { 12'd0,ss_sh_scan_counter } :
ss_addr[14:0]==15'd564 ? { 14'd0,ss_sh_joyrept_0 } :
ss_addr[14:0]==15'd565 ? { 14'd0,ss_sh_joyrept_1 } :
ss_addr[14:0]==15'd566 ? { 14'd0,ss_sh_joyrept_2 } :
ss_addr[14:0]==15'd567 ? { 14'd0,ss_sh_joyrept_3 } :
ss_addr[14:0]==15'd568 ? { 14'd0,ss_sh_joyrept_4 } :
ss_addr[14:0]==15'd569 ? { 14'd0,ss_sh_mouse_cnt } :
ss_addr[14:0]==15'd570 ? { 8'd0,ss_sh_ms_x } :
ss_addr[14:0]==15'd571 ? { 8'd0,ss_sh_ms_y } :
ss_addr[14:0]==15'd572 ? { 14'd0,ss_sh_last_gp } :
ss_addr[14:0]==15'd573 ? { 15'd0,ss_sh_high_buttons } :
ss_addr[14:0]==15'd574 ? { 1'd0,ss_sh_mouse_to } :
ss_addr[14:0]==15'd575 ? { 15'd0,ss_sh_ms_stb } :
ss_addr[14:0]==15'd576 ? { 8'd0,ss_sh_msr_x } :
ss_addr[14:0]==15'd577 ? { 8'd0,ss_sh_msr_y } :
16'd0;
wire ss_freeze, ss_machine_freeze, ss_save, ss_load, ss_load_commit, ss_safe, ss_valid, ss_fault_reset, ss_cd_unsafe;
wire ss_cdram_hold;
// Prime a registered physical hold while the controller or a CD-RAM drain is
// frozen; keep it asserted for eight full clk_sys edges after those requests
// drop. It is already high before any restore can commit, including a watchdog
// on the commit edge. A reset or guard loss cannot clear it. Using one FF for
// the hold output avoids binary countdown reduction glitches on CDC consumers.
reg [3:0] ss_restore_warm_count = 0;
(* altera_attribute = "-name PRESERVE_REGISTER ON" *) reg ss_restore_warm_hold = 0;
always @(posedge clk_sys) begin
 if (ss_freeze || ss_cdram_hold || ss_load_commit) begin
  ss_restore_warm_count <= 4'd8;
  ss_restore_warm_hold <= 1'b1;
 end else if (ss_restore_warm_hold) begin
  if (ss_restore_warm_count == 1) begin
   ss_restore_warm_count <= 0;
   ss_restore_warm_hold <= 1'b0;
  end else ss_restore_warm_count <= ss_restore_warm_count - 1'b1;
 end
end
wire ss_base_freeze = ss_freeze | ss_cdram_hold | ss_restore_warm_hold;
assign ss_machine_freeze = ss_base_freeze | ss_video_hold;
video_phase_align video_phase_align(
 .clk(clk_sys), .freeze_request(ss_base_freeze),
 .cancel(reset | cart_download | ss_config_changed | ss_fault_pending | !ss_available),
 .core_phase(ss_video_phase), .machine_hold(ss_video_hold),
 .video_freeze(ss_video_freeze), .busy(ss_video_busy), .fault(ss_video_fault),
 .reference_ce(), .reference_hs(), .reference_vs(),
 .reference_hbl(), .reference_vbl(), .presentation_phase(ss_reference_phase)
);
// Retain the fault reset until every outstanding SDRAM scan response drains
// and the machine is unfrozen long enough to observe the reset.
reg ss_fault_pending=0,ss_cold_pending=0;
reg [3:0] ss_fault_count=0;
reg [15:0] ss_cold_count=0;
always @(posedge clk_sys) begin
 if(cart_download && ss_machine_freeze) begin ss_cold_pending<=1;ss_cold_count<=0;end
 else if(ss_cold_pending && !ss_machine_freeze) begin
  if(ss_cold_count==32771) begin ss_cold_pending<=0;ss_cold_count<=0;end
  else ss_cold_count<=ss_cold_count+1'd1;
 end
 // pce_top samples RESET only while unfrozen. Retain an external reset
 // seen during snapshot ownership until the machine can observe it.
 if(ss_fault_reset || ss_video_fault || ((reset || cart_download) && ss_machine_freeze)) begin ss_fault_pending<=1;ss_fault_count<=0;end
 else if(ss_fault_pending && !ss_machine_freeze && !ss_cold_pending) begin
   if(ss_fault_count==7)ss_fault_pending<=0;else ss_fault_count<=ss_fault_count+1'd1;
 end
end
wire [17:0] ss_addr, ss_legacy_addr;
assign ss_addr=bg_busy ? {3'd6,bg_reg_addr} : ss_legacy_addr;
wire [16:0] ss_adpcm_addr;
wire [3:0] ss_adpcm_din, ss_adpcm_dout;
wire ss_adpcm_we;
wire [17:0] ss_cdram_addr;
wire [7:0] ss_cdram_din, ss_cdram_dout;
wire ss_cdram_req,ss_cdram_ack,ss_cdram_write;
// Persistent physical bank select: commit switches only after full validation.
reg ss_cdram_bank=0;
always @(posedge clk_sys) if(ss_load_commit && !ss_operation_private) ss_cdram_bank<=~ss_cdram_bank;
wire [24:0] ss_cdram_scan_addr={3'b001,3'b100,(ss_cdram_bank ^ ss_cdram_write),ss_cdram_addr};
wire [24:0] ss_cdram_normal_addr=(cd_ram_a[21:18]==4'b1000) ?
  {3'b001,3'b100,ss_cdram_bank,cd_ram_a[17:0]} : {3'b001,cd_ram_a};
wire [15:0] ss_din, ss_dout, ss_ram_dout, ss_reg_dout;
wire [15:0] ss_input_dout, ss_sdram_dout;
wire [3:0] ss_error;
assign ss_dout = ss_addr[17:15]==6 ? (ss_reg_dout | ss_input_dout | ss_sdram_dout | ss_audio_dout) :
                 ss_addr[17:15]==7 ? (ss_addr[14:0]==1024 ? {8'd0,ss_bram_q} : ss_bram_word) : ss_ram_dout;
`include "rtl/snapshot_layout.vh"
wire ss_we, ss_take_ddr, ss_reg_rotate, ss_legacy_reg_rotate;
assign ss_reg_rotate=bg_busy ? bg_reg_rotate : ss_legacy_reg_rotate;
// Do not snapshot unsupported external devices or active cheat mappings.
// GG_EN is active-low: status[5] is 0 when cheats are enabled. LITE builds
// report gg_avail=0. MB128 memory and protocol state are not serialized.
// Snapshot-only qualification of the related clk_ram backend selector. Native
// ROM/CD traffic continues to use use_sdr directly. Admission/cancellation
// observes a backend change within one clk_sys cycle; the final restore commit
// additionally vetoes raw backend loss below. Do not register scan_we: it is a
// native write strobe, not an admission signal.
reg ss_use_sdr = 0;
always @(posedge clk_sys) ss_use_sdr <= use_sdr;
wire ss_available = ss_cart_swap_ok && !ss_rom_oversize && ss_use_sdr && !cd_en && !sgx && !populous[romwr_a[9]] &&
                    !ioctl_download && !ss_cd_unsafe && !status[13] && !status[21] && !status[27] && !status[26] && !bk_state && defbram[3] &&
                    (!gg_avail || status[5]);
wire [7:0] normal_burst, normal_be;
wire [28:0] normal_addr, ss_ddr_addr;
wire [63:0] normal_din, ss_ddr_din;
wire normal_rd, normal_we, ss_ddr_rd, ss_ddr_we, normal_ddr_idle;
wire primary_ddr_busy, primary_ddr_ready;
wire [63:0] primary_ddr_dout;
video_ddr_arbiter video_ddr_arbiter(
 .clk(DDRAM_CLK), .idle(bg_foreground_idle), .primary_addr(ss_take_ddr ? ss_ddr_addr : normal_addr),
 .primary_din(ss_take_ddr ? ss_ddr_din : normal_din),
 .primary_byteenable(ss_take_ddr ? 8'hff : normal_be),
 .primary_burst(ss_take_ddr ? 8'd1 : normal_burst),
 .primary_rd(ss_take_ddr ? ss_ddr_rd : normal_rd),
 .primary_we(ss_take_ddr ? ss_ddr_we : normal_we),
 .primary_idle(ss_take_ddr || normal_ddr_idle), .primary_pulse_read(!ss_take_ddr),
 .primary_busy(primary_ddr_busy), .primary_ready(primary_ddr_ready), .primary_dout(primary_ddr_dout),
 .video_addr(video_ddr_addr), .video_din(video_ddr_din), .video_burst(video_ddr_burst),
 .video_rd(video_ddr_rd), .video_we(video_ddr_we),
 .video_busy(video_ddr_busy), .video_ready(video_ddr_ready), .video_dout(video_ddr_dout),
 .ddr_addr(bg_foreground_addr), .ddr_din(bg_foreground_din), .ddr_byteenable(bg_foreground_be), .ddr_burst(bg_foreground_burst),
 .ddr_rd(bg_foreground_rd), .ddr_we(bg_foreground_we), .ddr_busy(bg_foreground_busy),
 .ddr_ready(bg_foreground_ready), .ddr_dout(bg_foreground_dout)
);
reg [31:0] ss_rom_id=0;
function automatic [31:0] ss_rom_crc(input [31:0] c0,input [15:0] d);
 reg [31:0] c;integer i;begin c=c0;for(i=0;i<16;i=i+1)c=(c>>1)^((c[0]^d[i])?32'hedb88320:0);ss_rom_crc=c;end
endfunction
always @(posedge clk_sys) if(cart_download && ioctl_wr)
 ss_rom_id <= ss_rom_crc(ioctl_addr==0 ? 32'hffffffff : ss_rom_id,ioctl_dout);
reg ss_key_save=0, ss_key_load=0, ss_key_strobe=0, rw_key_held=0;
// Include all identity settings and abort an in-flight operation if any changes.
wire [12:0] ss_config = {status[22],status[20],status[19:18],status[2],status[30:29],status[3],status[28],status[17],status[41],status[40:39]};
reg [12:0] ss_old_config=0;
wire ss_config_changed = ss_old_config != ss_config;
// A restore request is a registered pulse. An abort on its consuming edge
// must suppress it consistently for CPU, SDRAM, backup bank and dirty flag.
assign ss_load_commit = ss_load && !(reset || cart_download || ss_config_changed || ss_fault_reset || ss_fault_pending) && ss_available && use_sdr;
// clk_ram is twice clk_sys. Delay the SDRAM action until the actual clk_sys
// commit edge has passed; otherwise it can consume the pulse half a cycle
// before a reset/configuration abort is seen by the machine and bank logic.
reg ss_sdram_load = 0;
always @(posedge clk_sys) ss_sdram_load <= ss_load_commit;
always @(posedge clk_sys) begin
 ss_key_save<=0; ss_key_load<=0; ss_key_strobe<=ps2_key[10];
 ss_old_config<=ss_config;
 if(reset || cart_download || !status[46] || OSD_STATUS) rw_key_held<=0;
 else if(ps2_key[10]!=ss_key_strobe && ps2_key[8:0]==9'h066) rw_key_held<=ps2_key[9]; // Backspace make/break
 if(ps2_key[10]!=ss_key_strobe && ps2_key[9] && !OSD_STATUS) begin
   if(ps2_key[8:0]==9'h003) ss_key_save<=1; // F5
   if(ps2_key[8:0]==9'h00a) ss_key_load<=1; // F8
 end
end
// Rewind owns a private 16 MiB DDR region, byte 0x3e000000..0x3effffff.
// Four manual 512 KiB slots and the existing host protocol remain untouched.
wire ss_backend_busy, ss_backend_accept, ss_backend_done, ss_backend_failed;
wire ss_operation_private, ss_legacy_operation_private;
wire ss_legacy_busy, ss_legacy_accept, ss_legacy_done, ss_legacy_failed;
assign ss_operation_private=ss_legacy_operation_private | bg_busy;
assign ss_backend_busy=ss_legacy_busy | bg_busy;
assign ss_backend_accept=ss_legacy_accept | bg_start_accept;
assign ss_backend_done=ss_legacy_done | bg_done;
assign ss_backend_failed=ss_legacy_failed | bg_failed;
wire rw_save, rw_load, rw_private, rw_held_active;
wire [6:0] rw_slot;
wire [7:0] rw_count;
wire rw_enabled=status[46] && ss_available && !ss_fault_pending;
// Presentation-only eligibility boundary. The raw guard includes same-cycle
// CPU/CD address decoding; register it on its native clock before driving the
// related 2x video domain. All snapshot/machine safety guards remain immediate.
reg ss_replay_enabled=0;
always @(posedge clk_sys) ss_replay_enabled <= rw_enabled;
reg ss_rewind_tint_active=0;
always @(posedge clk_sys) ss_rewind_tint_active <= rw_held_active;
wire rw_held=(rw_key_held || joy_0[12]) && !OSD_STATUS;
// Independent real-time tick continues while the emulated VCE is frozen.
// 42.954545 MHz / 715909 is approximately 60 Hz.
reg [19:0] rw_tick_count=0;
reg rw_tick=0;
always @(posedge clk_sys) begin
 rw_tick<=0;
 if(reset || cart_download || !rw_enabled) rw_tick_count<=0;
 else if(rw_tick_count==20'd715908) begin rw_tick_count<=0;rw_tick<=1;end
 else rw_tick_count<=rw_tick_count+1'b1;
end
// Queue a manual edge while an automatic transaction drains. Keep its slot
// stable too; selecting a different OSD slot cannot redirect a queued request.
wire manual_save_raw=status[42] | ss_key_save;
wire manual_load_raw=status[43] | ss_key_load;
reg manual_save_old=0, manual_load_old=0;
reg manual_pending=0, manual_loading=0;
reg [1:0] manual_slot=0;
wire manual_save_edge=manual_save_raw && !manual_save_old;
wire manual_load_edge=manual_load_raw && !manual_load_old;
wire manual_request=manual_pending || manual_save_edge || manual_load_edge;
always @(posedge clk_sys) begin
 manual_save_old<=manual_save_raw;manual_load_old<=manual_load_raw;
 if(reset || cart_download || ss_config_changed || !ss_available || ss_fault_pending)
  manual_pending<=0;
 else begin
  if(ss_backend_accept && !rw_private) manual_pending<=0;
  if(!manual_pending && (manual_save_edge || manual_load_edge)) begin
   manual_pending<=1;manual_loading<=!manual_save_edge;manual_slot<=status[45:44];
  end
 end
end
// Nominal 60 Hz ticks, not raster fields; completion/window waits add spacing.
rewind_history #(.CAPTURE_FRAMES(60)) rewind_history(
 .clk(clk_sys), .reset(reset|cart_download|ss_config_changed),
 .enabled(rw_enabled), .frame_tick(rw_tick), .rewind_held(rw_held),
 .osd_open(OSD_STATUS), .manual_request(manual_request),
 .history_depth(status[48:47]), .capture_rate(status[50:49]),
 .backend_busy(ss_backend_busy|ss_restore_warm_hold|ss_video_busy),
 .backend_accept(ss_backend_accept), .backend_done(ss_backend_done), .backend_failed(ss_backend_failed),
 .save_request(rw_save), .load_request(rw_load), .private_mode(rw_private),
 .private_slot(rw_slot), .count(rw_count), .held_active(rw_held_active)
);
// Present fresh request edges only when the backend can accept them. Otherwise
// edge detection could consume a held request during DDR drain or warm-up.
// Private saves may freeze only during the early native blank window.
// Case equality fails closed on simulation metavalues, not physical metastability.
wire ss_private_save_window =
 ((^ss_video_phase) !== 1'bx) &&
 ((ss_video_phase[11:0] < 12'd2730) === 1'b1) &&
 (((ss_video_phase[31:22] == 10'd262) || (ss_video_phase[31:22] == 10'd263)) === 1'b1) &&
 ((ss_video_phase[21:12] < ss_video_phase[31:22]) === 1'b1) &&
 ((ss_video_phase[21:12] <= 10'd1) === 1'b1) &&
 (ss_video_phase[48] === 1'b1);
wire ss_request_ready=!ss_backend_busy && !ss_restore_warm_hold && !ss_video_busy;
// Offer automatic capture in line zero, leaving line one as margin for
// the backend's existing safe-boundary check before it freezes the machine.
wire ss_private_save_offer = ss_private_save_window &&
                             ((ss_video_phase[21:12] == 10'd0) === 1'b1);
wire ss_request_save=ss_request_ready && (rw_private ? (rw_save && ss_private_save_offer) :
                                                        (manual_pending&&!manual_loading));
wire ss_request_load=ss_request_ready && (rw_private ? rw_load : (manual_pending&&manual_loading));
wire ss_info_req;
wire [7:0] ss_info;
state_feedback state_feedback(
 .clk(clk_sys), .reset(reset|cart_download|ss_config_changed),
 .available(ss_available && !ss_fault_pending), .selected_slot(status[45:44]),
 .manual_edge(manual_save_edge|manual_load_edge),
 .request_accept(ss_backend_accept), .operation_private(ss_operation_private),
 .accepted_loading(manual_loading), .accepted_slot(manual_slot),
 .backend_done(ss_backend_done), .backend_failed(ss_backend_failed),
 .backend_error(ss_error), .info_req(ss_info_req), .info(ss_info)
);
// Manual loads borrow rewind slots 0..3 only after metadata invalidation.
// The backend latches this grant and retains physical ownership through abort drain.
wire ss_manual_stage_allowed=manual_pending && !rw_private && (rw_count==0);
ninja_savestate #(.REGISTER_WORDS(SS_REGISTER_WORDS), .SCHEMA(SS_SCHEMA), .MANUAL_LOAD_STAGING(1), .PRIVATE_SAVE_WINDOW_ENABLE(1)) ninja_states(
 .private_save_window(ss_private_save_window),
 .clk(clk_sys), .ram_clk(clk_ram),
 .reset(reset|cart_download|ss_config_changed),
 .enabled(ss_available && !ss_fault_pending), .slot(manual_slot), .rom_id(ss_rom_id),
 .private_mode(rw_private), .private_slot(rw_slot), .operation_private(ss_legacy_operation_private),
 .manual_stage_allowed(ss_manual_stage_allowed),
 .busy(ss_legacy_busy), .request_accept(ss_legacy_accept), .done(ss_legacy_done), .failed(ss_legacy_failed),
 .config_id({3'd0,ss_config}), .error(ss_error),
 .safe(ss_safe && !ss_restore_warm_hold && !ss_video_busy), .start_block(ss_restore_warm_hold | ss_video_busy),
 .save_button(ss_request_save && !rw_private), .load_button(ss_request_load),
 .freeze(ss_freeze), .save_pulse(ss_save), .load_pulse(ss_load),
 .valid(ss_valid), .fault_reset(ss_fault_reset),
 .adpcm_addr(ss_adpcm_addr), .adpcm_din(ss_adpcm_din), .adpcm_we(ss_adpcm_we), .adpcm_dout(ss_adpcm_dout),
 .cd_ram_addr(ss_cdram_addr), .cd_ram_din(ss_cdram_din), .cd_ram_write(ss_cdram_write), .cd_ram_req(ss_cdram_req), .cd_ram_hold(ss_cdram_hold),
 .cd_ram_ack(ss_cdram_ack), .cd_ram_dout(ss_cdram_dout),
 .reg_rotate(ss_legacy_reg_rotate), .scan_addr(ss_legacy_addr), .scan_dout(ss_dout), .scan_din(ss_din), .scan_we(ss_we),
 .normal_idle(normal_ddr_idle), .ram_busy(primary_ddr_busy), .ram_ready(primary_ddr_ready), .ram_dout(primary_ddr_dout),
 .take_ddr(ss_take_ddr), .ram_addr(ss_ddr_addr), .ram_din(ss_ddr_din),
 .ram_rd(ss_ddr_rd), .ram_we(ss_ddr_we)
);

`include "rtl/background/background_top.vh"
endmodule
