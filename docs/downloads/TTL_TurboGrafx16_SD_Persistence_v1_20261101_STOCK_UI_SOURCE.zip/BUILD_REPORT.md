# TG16 stock-Main UI-only rebuild — 2026-11-01

Only production source change: TurboGrafx16.sv OSD string `Wait for Saved to SD in Main` becomes `Main writes snapshots to SD`. Existing retry text is unchanged. No payload, protocol, controller logic, initialization, timing constraints or no-duplication settings changed. Keep your stock Main; no Main replacement is included. Earlier tested release is preserved separately.

Fresh database, Quartus Prime Lite 23.1std Build 991. Map: 0 errors/100 warnings. Standard seed-7 fit with register retiming OFF: 0 errors/10 warnings. Multicorner STA: all 172 rows nonnegative and zero TNS; minimum +0.013 ns. Assembly: 0 errors/0 warnings. All 156 pinned input files remained unchanged through the build. Exact comparison against the delivered source confirms only the single string substitution; the source manifest was regenerated as metadata.

RBF: 4,371,936 bytes; SHA-256 e1e89008f53f7e16714dc0b02c55f73a1c560da9064ca7d84911cb50c33d131e.

No hardware verification occurred. Stock-Main interoperability harness evidence applies to the unchanged controller, not a newly executed whole RBF. Incomplete I/O constraints and synchronizer MTBF coverage remain; this is not complete CDC signoff. Stock Main supplies no confirmed SD-completion acknowledgement or same-generation automatic retry. Follow STOCK_MAIN_GUIDE.txt and protect existing saves.
