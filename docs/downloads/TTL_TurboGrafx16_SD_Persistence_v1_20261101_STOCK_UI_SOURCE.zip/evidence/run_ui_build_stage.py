#!/usr/bin/env python3
"""One isolated no-duplication build stage; no hardware/release verdict."""
from pathlib import Path
import os,sys,json,hashlib,fcntl,shutil,ctypes,signal,time,datetime
root=Path(__file__).resolve().parent;helper=Path('/workspace/scratch/3a9e05704b35/tg16_recovered_20261031/owned_group.py')
if hashlib.sha256(helper.read_bytes()).hexdigest()!='83dcdb95b50100a709cde8f9ad64d85349613847c15f9dd7a8ead00acde4272f':raise RuntimeError('helper pin mismatch')
sys.path.insert(0,str(helper.parent));from owned_group import run_owned
if len(sys.argv)!=2 or sys.argv[1] not in ('map','fit','sta','asm'):raise SystemExit('choose one stage')
stage=sys.argv[1];lock=(root/'build.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def verify():
 if sha(root/'source_pin_manifest.json')!='342a6e6c7ecc13d2fdc11a0c5ed99433b5e877d92cc34fa3c223c1de8bcd6170':raise RuntimeError('manifest pin mismatch')
 pins=json.loads((root/'source_pin_manifest.json').read_text())
 if len(pins)!=156 or any(sha(root/n)!=h for n,h in pins.items()):raise RuntimeError('source input changed')
def mem():return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def guard():
 if shutil.disk_usage(root).free<1181116006 or mem()<2147483648 or (root/'STOP_BUILD').exists():raise RuntimeError('resource floor or STOP')
verify();guard()
if stage!='map':
 prev={'fit':'map','sta':'fit','asm':'sta'}[stage];p=root/('stage_'+prev+'_success.json')
 if not p.is_file():raise RuntimeError('prior stage absent')
 x=json.loads(p.read_text())
 if x.get('stage')!=prev or x.get('exit')!=0 or x.get('source_manifest_sha256')!=sha(root/'source_pin_manifest.json') or x.get('log_sha256')!=sha(root/(prev+'.log')):raise RuntimeError('prior stage provenance mismatch')
logfile=root/(stage+'.log');receipt=root/('stage_'+stage+'_success.json')
if logfile.exists() or receipt.exists():raise RuntimeError('prior/uncertain stage; inspect before retry')
cmd={'map':['quartus_map','--parallel=2','--read_settings_files=on','--write_settings_files=off','TurboGrafx16'],
 'fit':['quartus_fit','--parallel=2','--effort=standard','--seed=7','--set=PHYSICAL_SYNTHESIS_REGISTER_RETIMING=OFF','--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16'],
 'sta':['quartus_sta','TurboGrafx16','-c','TurboGrafx16','--multicorner=on','--do_report_timing'],
 'asm':['quartus_asm','--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16']}[stage]
owner=os.getpid();lib=ctypes.CDLL(None,use_errno=True);env=dict(os.environ);env['PATH']='/workspace/scratch/3a9e05704b35/quartus_toolchain/quartus23/quartus/bin:'+env.get('PATH','')
def setup():
 if lib.prctl(1,signal.SIGTERM,0,0,0)!=0 or os.getppid()!=owner:os._exit(125)
def started(q):
 with (root/(stage+'_process.json')).open('x') as f:json.dump({'pid':q.pid,'pgid':q.pid,'wrapper_pid':owner,'namespace':os.readlink('/proc/self/ns/pid'),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'command':cmd,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f);f.flush();os.fsync(f.fileno())
 print('START',stage,flush=True)
last=[time.monotonic()]
def probe(q):
 guard();now=time.monotonic()
 if now-last[0]>30:print('HEARTBEAT',stage,'disk',shutil.disk_usage(root).free,'mem',mem(),flush=True);last[0]=now
with logfile.open('x') as f:result=run_owned(cmd,cwd=root,env=env,stdout=f,setup=setup,on_started=started,probe=probe,interval=2)
if result['returncode']!=0 or not result['group_quiescent']:raise RuntimeError('tool failure or group not quiescent '+str(result))
text=logfile.read_text(errors='replace')
if 'successful' not in text.lower() or any(x.startswith('Error') for x in text.splitlines()):raise RuntimeError('missing tool success or Quartus errors')
verify();guard()
with receipt.open('x') as f:json.dump({'stage':stage,'exit':0,'log_sha256':sha(logfile),'source_manifest_sha256':sha(root/'source_pin_manifest.json'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_release_verdict':True},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print('TERMINAL',stage,'passed; no release verdict',flush=True)
