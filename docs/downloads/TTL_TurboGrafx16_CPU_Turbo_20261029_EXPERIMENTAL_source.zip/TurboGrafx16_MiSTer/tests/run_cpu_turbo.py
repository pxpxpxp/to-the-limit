#!/usr/bin/env python3
"""Run actual HuC6280 RTL against upstream and synthetic workloads (no game ROM)."""
import argparse
import hashlib
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
# tests/upstream/HUC6280.vhd is from upstream commit 827d45f45799b8ab3a536510847f2108a92e81bd.


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ghdl', default='ghdl')
    parser.add_argument('--compile-only', action='store_true')
    args = parser.parse_args()
    ghdl = args.ghdl
    with tempfile.TemporaryDirectory(prefix='tgfx16-turbo-') as directory:
        tmp = Path(directory)
        def run(*cmd):
            result = subprocess.run(cmd, cwd=tmp, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError(result.stdout)
            return result.stdout
        # Match the upstream PSG volume ROM with a portable synchronous read model.
        dpram = (ROOT / 'rtl/dpram.vhd').read_text().split('ARCHITECTURE SYN OF dpram IS')[0]
        dpram = dpram.replace('LIBRARY altera_mf;\nUSE altera_mf.altera_mf_components.all;',
                              'use ieee.numeric_std.all;')
        values = re.findall(r'^([0-9A-F]{4}) : ([0-9A-F]{6});',
                            (ROOT / 'rtl/HUC6280/voltab.mif').read_text(), re.M)
        assert len(values) == 4096
        dpram += '''architecture sim of dpram is
        type rom_t is array(0 to 4095) of std_logic_vector(23 downto 0);
        constant rom : rom_t := (\n'''
        dpram += ',\n'.join(f'{int(a,16)} => x"{v}"' for a, v in values)
        dpram += ''');
        begin
          process(clock) begin
            if rising_edge(clock) then
              if enable_a = '1' then
                q_a <= rom(to_integer(unsigned(address_a)));
              end if;
              if enable_b = '1' then
                q_b <= rom(to_integer(unsigned(address_b)));
              end if;
            end if;
          end process;
        end architecture;\n'''
        (tmp / 'dpram.vhd').write_text(dpram)
        original_bytes = (ROOT / 'tests/upstream/HUC6280.vhd').read_bytes()
        assert hashlib.sha256(original_bytes).hexdigest() == \
            'c3d32c79fb01f4613ea3439c50db4042237e568bf1a2ee3911ed3bc1ed328b6c', \
            'upstream regression fixture changed'
        original = original_bytes.decode().replace('\r\n', '\n')
        def instrument(source, name):
            source = re.sub(r'\bHUC6280\b', name, source)
            source = source.replace('AUD_RDATA: out std_logic_vector(23 downto 0)', '''AUD_RDATA: out std_logic_vector(23 downto 0);
                DBG_IO_CE : out std_logic;
                DBG_COUNT : out unsigned(4 downto 0);
                DBG_TIMER : out std_logic_vector(6 downto 0)''')
            source = source.replace('begin\n', '''begin
                DBG_IO_CE <= IO_CE;
                DBG_COUNT <= CPU_CLK_CNT;
                DBG_TIMER <= TMR_VALUE;
''', 1)
            return source
        (tmp / 'upstream.vhd').write_text(instrument(original, 'HUC6280_UPSTREAM'))
        (tmp / 'modified.vhd').write_text(instrument(
            (ROOT / 'rtl/HUC6280/HUC6280.vhd').read_text(), 'HUC6280_TEST'))
        units = ['HUC6280_PKG.vhd', 'AddSubBCD.vhd', 'HUC6280_ALU.vhd',
                 'HUC6280_AG.vhd', 'HUC6280_MC.vhd', 'HUC6280_CPU.vhd', 'psg.vhd']
        files = [tmp / 'dpram.vhd'] + [ROOT / 'rtl/HUC6280' / p for p in units]
        files += [tmp / 'upstream.vhd', tmp / 'modified.vhd', ROOT / 'tests/tb_cpu_turbo.vhd']
        print(run(ghdl, '-a', '--std=08', '-fsynopsys', *map(str, files)), end='')
        run(ghdl, '-e', '--std=08', '-fsynopsys', 'tb_cpu_turbo')
        if args.compile_only:
            print('PASS: CPU RTL analyzes as VHDL-2008; testbench elaborates.')
            return
        traces = {}
        for mode in range(5):
            # 4 changes the menu selection during execution and during wait states.
            for stalled in (False, True):
                out = run(ghdl, '-r', '--std=08', '-fsynopsys', 'tb_cpu_turbo',
                          f'-gMODE={mode}', f'-gSTALLED={str(stalled).lower()}',
                          '--assert-level=error', '--ieee-asserts=disable')
                lines = (tmp / 'trace.txt').read_text().splitlines()
                traces[mode, stalled] = lines
                print(out, end='')
                assert lines == traces[0, False], f'write trace differs: mode={mode}, stalled={stalled}'
        print('PASS: all ten CPU write traces match; Off/reserved lockstep with upstream; '
              'clock ratios, live changes, I/O timing, timer cadence, and wait-state checks passed.')

if __name__ == '__main__':
    main()
