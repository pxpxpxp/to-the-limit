#!/usr/bin/env python3
"""Verify the logical CD/BRAM bank merge from source and official map output."""
import hashlib,json,re,sys
from pathlib import Path
b=Path(sys.argv[1]);rev=sys.argv[2];out=Path(sys.argv[3])
top=b/'TurboGrafx16.sv';mp=b/'output_files'/f'{rev}.map.rpt'
s=top.read_text();text=mp.read_text(errors='replace')
for n in ('ss_bram_bank','ss_cdram_bank'):
 assert re.search(r'\breg\s+'+n+r'\s*=\s*0\s*;',s),'Bank does not initialize identically'
 assert re.search(r'always\s*@\s*\(posedge\s+clk_sys\)\s*if\s*\(ss_load_commit\)\s*'+n+r'\s*<=\s*~'+n+r'\s*;',s),'Bank does not use identical commit update'
 assert len(re.findall(r'\b'+n+r'\s*<=',s))==1,'Bank has another assignment'
match=re.search(r'^;\s*emu:emu\|ss_cdram_bank\s*;\s*Merged with emu:emu\|ss_bram_bank\s*;',text,re.M)
assert match,'Official map report does not establish the required merge'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
data={'logical_register':'emu:emu|ss_cdram_bank','physical_register':'emu:emu|ss_bram_bank','official_map_row':match.group(0),'top_sha256':sha(top),'map_report_sha256':sha(mp),'equivalence':'Both initialize to zero and have exactly one identical toggle assignment on posedge clk_sys when ss_load_commit. The synthesis map explicitly merges CD bank into BRAM bank.','coverage':'Do not drop the CD commit target. Query its setup/hold and cut paths through the verified shared physical register at every condition.'}
(out/'bank_alias_proof.json').write_text(json.dumps(data,indent=2)+'\n');(out/'bank_alias_verified.txt').write_text('ss_cdram_bank=emu:emu|ss_bram_bank\n')
print('Verified CD bank -> BRAM bank physical alias; mandatory commit target retained')
