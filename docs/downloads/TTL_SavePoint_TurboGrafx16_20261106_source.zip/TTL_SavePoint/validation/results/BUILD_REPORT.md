# TTL SavePoint build report

Build 261106SP1 used Quartus Prime Lite 23.1std Build 991 on Cyclone V 5CSEBA6U23I7, with fitter seed 41.
The RBF is 4,365,828 bytes. Its SHA-256 is `77fd4978e2a10f6a7aaf2a02a44cee5dd508d9806c7d93a4d68025e281745f09`.

The source derives from the hardware-tested 261106RF3R2 build. Changes remove the rewind frontend and private dispatch from the compiled design and brand the manual save menu. The save-state backend, video phase alignment, clock constraints and CPU Turbo logic carry forward from that source.

The fitted netlist passed 1,120 numeric timing checks across 8 conditions, including 49 manual-save, video, backup and host timing pairs. Minimum global setup/hold slack was +0.080/+0.070 ns. Minimum reported pulse or period slack was +0.529 ns. Inherited board-I/O constraint coverage is partial.

The four protocol 3 snapshots matched the parent build byte for byte in simulation. The patched Main handler wrote and reimported all four slots through real files, and a fresh RTL process restored the modeled state. The new RBF still needs physical MiSTer validation.

## Rebuild

Use the commands below from the core directory. The direct Quartus stages use the supplied build ID. The corresponding core source and upstream notices are included. SavePoint uses the standard MiSTer save-state interface.

```sh
quartus_map --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
quartus_fit --parallel=4 --seed=41 --set=PHYSICAL_SYNTHESIS_REGISTER_RETIMING=OFF --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
quartus_sta --parallel=4 TurboGrafx16 -c TurboGrafx16
quartus_asm --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
```
