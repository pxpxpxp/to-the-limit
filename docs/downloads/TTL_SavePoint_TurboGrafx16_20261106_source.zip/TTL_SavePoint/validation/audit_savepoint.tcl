# Read-only fitted-netlist audit for Quartus Prime Lite 23.1std.0 Build 991.
# Usage: quartus_sta -t signoff.tcl PROJECT REVISION OUTPUT_DIR
# Run only after the build's fitter/STA process has finished. No SDC exceptions
# are created, removed or modified. This script is not hardware validation.
package require ::quartus::project
package require ::quartus::sta
if {[llength $quartus(args)] != 3} { error "Expected PROJECT REVISION OUTPUT_DIR" }
lassign $quartus(args) project revision out
set out [file normalize $out]
file mkdir $out
set fh [open [file join $out summary.tsv] w]
puts $fh "corner\tscope\tcheck\tlabel\tstatus\tslack_ns\tfrom\tto\tfrom_clock\tto_clock"
set cov [open [file join $out coverage.tsv] w]
puts $cov "kind\tlabel\tcount\tpatterns"
set negative_count 0
set missing_count 0
set cut_count 0
set row_count 0
proc clean {s} { return [string map [list "\t" " " "\n" " " "\r" " "] $s] }
proc safe_name {s} { regsub -all {[^A-Za-z0-9_.-]} $s _ s; return $s }
proc path_row {corner scope typ label options {required 0}} {
 global fh negative_count missing_count row_count
 set paths [get_timing_paths -$typ -npaths 1 -detail summary {*}$options]
 set n [get_collection_size $paths]
 incr row_count
 if {!$n} {
  puts $fh "[clean $corner]\t$scope\t$typ\t[clean $label]\tNO_PATH\t\t\t\t\t"
  if {$required} {incr missing_count}
  return 0
 }
 foreach_in_collection p $paths {
  set slack [get_path_info -slack $p]
  if {![string is double -strict $slack]} {error "Non-numeric slack: $slack"}
  set status PASS
  if {$slack < 0.0} {set status FAIL;incr negative_count}
  set a [get_path_info -from $p];set b [get_path_info -to $p]
  set ac [get_path_info -from_clock $p];set bc [get_path_info -to_clock $p]
  set an "";set bn "";set acn "";set bcn ""
  if {$a ne ""} {set an [get_node_info -name $a]}
  if {$b ne ""} {set bn [get_node_info -name $b]}
  if {$ac ne ""} {set acn [get_clock_info -name $ac]}
  if {$bc ne ""} {set bcn [get_clock_info -name $bc]}
  puts $fh "[clean $corner]\t$scope\t$typ\t[clean $label]\t$status\t$slack\t[clean $an]\t[clean $bn]\t[clean $acn]\t[clean $bcn]"
 }
 flush $fh
 return $n
}
project_open $project -revision $revision
create_timing_netlist
read_sdc
update_timing_netlist
set mf [open [file join $out metadata.txt] w]
puts $mf "tool=$quartus(version)\nproject=[file normalize $project]\nrevision=$revision\nnetlist=fitted\nconstraints=project read_sdc, unchanged"
puts $mf "device=[get_global_assignment -name DEVICE]"
close $mf
# Explicit coverage of the source FFs whose obsolete fixed locations were
# removed. This reads physical locations only; no assignments are changed.
if {1} {
 set pf [open [file join $out placement_nodes.tsv] w]
 puts $pf "label\tnode\ttype\tlocation"
 foreach {label pattern} {vs_source vs de_source de vs_output hdmi_out_vs de_output hdmi_out_de} {
  set placement($label) [get_keepers [list $pattern]]
  set placement_count [get_collection_size $placement($label)]
  # Quartus includes register-packing duplicates in an exact-name keeper
  # query. Retain every output duplicate in timing and location coverage.
  if {!$placement_count || ($label in {vs_source de_source} && $placement_count!=1)} {error "Missing/ambiguous placement endpoint $label"}
  foreach_in_collection node $placement($label) {
   puts $pf "$label\t[clean [get_node_info -name $node]]\t[get_node_info -type $node]\t[clean [get_node_info -location $node]]"
  }
 }
 close $pf
 set placement_defs [list vs_fanin [list -to $placement(vs_source)] de_fanin [list -to $placement(de_source)] vs_to_output [list -from $placement(vs_source) -to $placement(vs_output)] de_to_output [list -from $placement(de_source) -to $placement(de_output)]]
}
report_clocks -file [file join $out clocks.rpt]
set clocks_file [open [file join $out clock_names.tsv] w]
puts $clocks_file "clock"
foreach_in_collection c [get_clocks *] {puts $clocks_file [get_clock_info -name $c]}
close $clocks_file
report_sdc -file [file join $out constraints.rpt]
report_sdc -ignored -file [file join $out ignored_constraints.rpt]
# Quartus 23.1 Standard uses Legacy reporting: -report_clock_groups is
# unsupported. report_sdc records group constraints and clock-transfer reports
# record their effects; inspect ordinary exceptions separately for each check.
foreach typ {setup hold recovery removal} {
 report_exceptions -$typ -detail summary -file [file join $out exceptions_${typ}.rpt]
}
report_ucp -file [file join $out unconstrained.rpt]
check_timing -include {no_clock multiple_clock generated_clock loops latches pos_neg_clock_domain pll_cross_check uncertainty partial_multicycle multicycle_consistency no_input_delay no_output_delay partial_input_delay partial_output_delay io_min_max_delay_consistency partial_min_max_delay} -file [file join $out check_timing.rpt]
# Critical mapped endpoints. A missing group is a coverage blocker, not a pass.
set definitions {
 backend {*ninja_states*}
 manual {*manual_pending* *manual_loading* *manual_slot*}
 payload {*ninja_states*|payload*}
 mailbox {*ninja_states*mailbox_addr*}
 daddr {*ninja_states*|daddr*}
 ddata {*ninja_states*|ddata*}
 req {*ninja_states*|req}
 req_meta {*ninja_states*|req_meta}
 ack {*ninja_states*|ack}
 ack_meta {*ninja_states*|ack_meta}
 response {*ninja_states*|response*}
 crc {*ninja_states*|crc*}
 owned {*ninja_states*|owned}
 owned_meta {*ninja_states*|owned_meta}
 load_pulse {*ninja_states*load_pulse*}
 freeze {*ninja_states*|freeze}
 warm {*ss_restore_warm_hold*}
 bram_bank {*ss_bram_bank*}
 cdram_bank {*ss_cdram_bank*}
 adpcm_bank {*ADPCM_DRAM*active_bank*}
 host_session {*cd_guest_session*}
 host_replies {*emu|cd_stat* *emu|cd_dataout_req* *emu|cd_region*}
 video_reference {*video_phase_align*reference_phase*}
 video_machine_hold {*video_phase_align*machine_hold*}
 video_hold {*video_phase_align*video_hold*}
 video_wait {*video_phase_align*wait_count*}
 video_flush {*video_phase_align*flush_count*}
 video_fault {*video_phase_align*|fault}
 video_cancel {*video_phase_align*cancel_pending*}
 vce_phase {*VCE*|H_CNT* *VCE*|V_CNT* *VCE*|END_LINE* *VCE*|DOTCLOCK* *VCE*|MULTIRES* *VCE*|CLKEN* *VCE*|HBL* *VCE*|VBL* *VCE*|HS_N* *VCE*|VS_N*}
 pixel_enable {*emu|ce_pix* *emu|old_ce*}
 color_sync {*color_mix*|HS *color_mix*|VS *color_mix*|HBl *color_mix*|VBl}
 color_rgb {*color_mix*|R* *color_mix*|G* *color_mix*|B*}
 fault_pending {*ss_fault_pending*}
 backup_requests {*bk_req_*}
 boot_queue {*bk_req_boot*}
 format_queue {*bk_req_format*}
 backup_state {*bk_state* *bk_loading*}
 backup_sd {*emu|sd_rd* *emu|sd_wr* *emu|sd_lba*}
 format_counter {*defbram*}
 backup_ram {*backram0* *backram1*}
}
array set groups {}
set nf [open [file join $out matched_nodes.tsv] w]
puts $nf "group\tnode"
foreach {name patterns} $definitions {
 set groups($name) [get_keepers -nowarn -nocase $patterns]
 set n [get_collection_size $groups($name)]
 if {$name eq "cdram_bank" && $n==0} {
  set ap [open [file join $out bank_alias_verified.txt] r]
  set proof [string trim [read $ap]];close $ap
  if {$proof ne "ss_cdram_bank=emu:emu|ss_bram_bank"} {error "No verified CD bank merge proof"}
  set groups($name) $groups(bram_bank)
  set n [get_collection_size $groups($name)]
  if {$n!=1} {error "Missing/ambiguous canonical merged BRAM/CD bank register"}
  puts $cov "mapped_alias\tcdram_bank\tss_bram_bank\tVerified original source equivalence and official map-report merge; commit timing queried explicitly"
 }
 puts $cov "group\t$name\t$n\t[join $patterns { }]"
 if {$n==0} {incr missing_count}
 foreach_in_collection node $groups($name) { puts $nf "$name\t[clean [get_node_info -name $node]]" }
}
close $nf
# Each pair is expected to contain a real synchronous path in the fitted core.
set pairdefs {
 manual_to_backend manual backend
 mailbox_to_ddr_address mailbox daddr
 payload_to_ddr_data payload ddata
 request_crossing req req_meta
 acknowledge_crossing ack ack_meta
 ownership_crossing owned owned_meta
 response_to_crc response crc
 restore_to_bram_bank load_pulse bram_bank
 restore_to_cd_bank load_pulse cdram_bank
 restore_to_adpcm_bank load_pulse adpcm_bank
 freeze_to_warm_hold freeze warm
 warm_hold_to_backend warm backend
 host_fence_to_replies host_session host_replies
 core_phase_to_reference vce_phase video_reference
 core_phase_to_alignment vce_phase video_machine_hold
 reference_recurrence video_reference video_reference
 reference_to_alignment video_reference video_machine_hold
 alignment_freezes_vce video_machine_hold vce_phase
 alignment_to_backend video_machine_hold backend
 display_flush_to_backend video_hold backend
 reference_to_pixel_enable video_reference pixel_enable
 reference_to_color_sync video_reference color_sync
 display_hold_blacks_color video_hold color_rgb
 alignment_timeout video_wait video_fault
 video_fault_to_reset_pending video_fault fault_pending
 fault_to_alignment_cancel fault_pending video_cancel
 snapshot_freeze_to_alignment freeze video_machine_hold
 warm_hold_to_alignment warm video_machine_hold
 flush_counter_to_video_hold video_flush video_hold
 backup_queue_to_dispatch backup_requests backup_state
 backup_queue_to_sd backup_requests backup_sd
 alignment_to_backup_dispatch video_machine_hold backup_state
 warm_hold_to_backup_dispatch warm backup_state
 backup_busy_to_backend backup_state backend
 format_queue_to_counter format_queue format_counter
 boot_queue_to_dispatch boot_queue backup_state
 boot_queue_to_sd boot_queue backup_sd
 boot_priority_over_format boot_queue format_counter
 format_priority_over_sd format_queue backup_state
 format_counter_to_dispatch format_counter backup_state
 format_counter_to_backend format_counter backend
 format_counter_to_ram format_counter backup_ram
 snapshot_freeze_to_format freeze format_counter
 warm_hold_to_format warm format_counter
 alignment_to_format video_machine_hold format_counter
 backend_busy_to_backup_dispatch backend backup_state
 backend_busy_to_format backend format_counter
 display_flush_to_backup_dispatch video_hold backup_state
 display_flush_to_format video_hold format_counter
}
set targets_file [open [file join $out target_definitions.tsv] w]
puts $targets_file "label\tsource_group\tdestination_group"
foreach {label src dst} $pairdefs {puts $targets_file "$label\t$src\t$dst"}
close $targets_file
set corners [get_available_operating_conditions -all]
set ccount [get_collection_size $corners]
if {$ccount != 8} {error "Expected eight operating conditions, found $ccount"}
set cf [open [file join $out corners.tsv] w]
puts $cf "index\tname\tmodel\ttemperature_C\tvoltage_mV\tspeed\tgrade"
set ci 0
foreach_in_collection op $corners {
 incr ci
 set cn [get_operating_conditions_info -display_name $op]
 puts $cf "$ci\t[clean $cn]\t[get_operating_conditions_info -model $op]\t[get_operating_conditions_info -temperature $op]\t[get_operating_conditions_info -voltage $op]\t[get_operating_conditions_info -speed $op]\t[get_operating_conditions_info -grade $op]"
 set_operating_conditions $op
 update_timing_netlist
 set dir [file join $out [format "corner_%02d" $ci]]
 file mkdir $dir
 puts "AUDIT_CORNER $ci/$ccount $cn"
 foreach typ {setup hold recovery removal} {
  path_row $cn global $typ all {} 1
  foreach_in_collection c [get_clocks *] {
   set c_name [get_clock_info -name $c]
   path_row $cn clock $typ $c_name [list -to_clock $c]
  }
 }
 report_min_pulse_width -nworst 100 -detail summary -file [file join $dir min_pulse_summary.rpt]
 # Supplemental standard STA reports are retained as well. MTBF estimates
 # are diagnostic only; missing activity assumptions are explicitly reviewed.
 if {1} {
  foreach {label opts} $placement_defs {
   foreach typ {setup hold} {
    path_row $cn placement $typ $label $opts 1
   }
  }
  foreach {label src dst} $pairdefs {
   if {![get_collection_size $groups($src)] || ![get_collection_size $groups($dst)]} {
    puts $cov "pair\t${ci}:$label\tMISSING_GROUP\t$src -> $dst"
    continue
   }
   set opts [list -from $groups($src) -to $groups($dst)]
   foreach typ {setup hold} {
    path_row $cn target $typ $label $opts 1
   }
   if {$ci==1} {
    foreach typ {setup hold} {
     set cut [get_timing_paths -$typ -false_path {*}$opts -npaths 1]
     set ncut [get_collection_size $cut]
     puts $cov "cut_path\t${label}:$typ\t$ncut\t$src -> $dst"
     if {$ncut} {
      incr cut_count
     }
    }
   }
  }
 }
}
close $cf;close $cov;close $fh
set sf [open [file join $out audit_status.txt] w]
puts $sf "REPORT_GENERATION_COMPLETE=1\nCORNERS=$ccount\nPATH_ROWS=$row_count\nNEGATIVE_PATH_ROWS=$negative_count\nMISSING_REQUIRED_COVERAGE=$missing_count\nTARGET_CUT_PATH_GROUPS=$cut_count"
puts $sf "MIN_PULSE_REQUIRES_PARSING=1\nCONSTRAINT_REPORTS_REQUIRE_REVIEW=1\nHARDWARE_VALIDATION=NOT_PERFORMED"
close $sf
delete_timing_netlist
project_close
puts "AUDIT_REPORTS_COMPLETE corners=$ccount rows=$row_count negative=$negative_count missing=$missing_count cuts=$cut_count"
if {$negative_count || $missing_count || $cut_count} {qexit -error}
