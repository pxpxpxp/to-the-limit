# Save-state and rewind video phase fix

## Status

Implemented and passed focused RTL/VCE/native-video simulation. FPGA fit/timing and real MiSTer/PVM validation are separate requirements. This report does not claim hardware verification, smooth analog rewind, or release qualification by itself.

## What caused the jump

The old save-state path halted the emulated VCE at a CPU-safe point. The existing video freezer kept synthesized sync running, but switched directly back to core sync when the machine resumed. The external scan had advanced while the core was stopped; loading additionally restored an arbitrary saved beam position. The handover could therefore shorten or lengthen a line, sync pulse, or field.

An isolated test of the unchanged baseline video_freezer reproduced the mechanism. A representative save pause produced a 21.36 ms field rather than 16.65 ms. A restore to a different phase produced a 14.42 ms field and a horizontal sync pulse shortened from 4.47 us to 1.69 us. The no-freeze control had no anomalies. This mechanism is consistent with a PVM visibly moving while reacquiring sync, although a monitor/adapter has not been tested here.

## Implemented repair

- New `rtl/video_phase_align.sv` continuously mirrors the VCE's presentation timing: beam position, field geometry, pixel dividers, sync registers, and blanking pipelines.
- When the machine is paused, the presentation reference continues scanning. It changes between the legal 262/263-line geometries only at a complete field boundary.
- Core resume is delayed until the next reference state equals the held/restored VCE presentation state. The first resumed core edge and reference edge then advance from the same phase.
- The mirror drives sync, blanking, and pixel enable in normal operation as well as during a pause. There is no switch from the old free-running sync generator to an unrelated core phase.
- The old internal mixer freezer is disabled for this path. Analog RGB is blacked explicitly; HDMI's frame hold remains active. RGB/HDMI hold lasts two more lines after core resume so the live pipeline can refill.
- Snapshot arbitration blocks new work through both alignment and the short display-only flush. A bounded timeout retains machine freeze until the existing fault reset is armed. Brief reset/configuration/eligibility cancellation pulses are retained while the backend drains.
- The 52-bit VCE observation bus is read-only. It does not add snapshot words or change the manual snapshot layout.
- The inherited video_mixer's shared RGB generate outputs were declared in their enclosing scope, preserving intended Quartus behavior while avoiding Icarus implicit one-bit nets.

A reset, invalid restore, or configuration/eligibility cancellation can still reset or discontinuously resume the display. The phase-continuity assertions cover normal supported save/load operation, not a promise of uninterrupted sync through a requested reset or invalid-state recovery.

## Verification completed

`source/tests/run_video_phase_tests.sh`:

- 80 hold, cancellation, repeated-request, timeout, and fault-reset control checks passed.
- The actual production VCE VHDL was synthesized with GHDL and instantiated with the actual color_mix, gamma, and video_mixer RTL. Its palette RAM uses the repository behavioral model. The unselected scandoubler output is stubbed in this explicitly native-output bench.
- Three scenarios cover both 262/263-line geometry directions, pixel-clock changes, an active-line control write that produces mixed resolution, real VCE snapshot save/load, and display-pipeline refill.
- 9,350,595 live-cycle comparisons, six aligned resumes, and approximately 5,500 raw line periods passed. Raw horizontal/vertical periods and sync pulse widths remained exact.
- At the native mixer output, the largest period change during a mode transition was 32 video clocks, approximately 0.3725 us. Horizontal and vertical sync pulse-width error was zero in the measured scenarios. The acceptance envelope allowed pixel-sampling quantization, not a shortened/lengthened field.
- A deliberate negative control that removes phase qualification fails the actual-VCE resume assertion.
- RTL/test source fingerprints were unchanged between the start and end of the successful suite.

Evidence: `validation/video_phase_final_suite.log` and `validation/video_phase_final/`.

`source/tests/run_video_phase_restore.sh`:

- A separate native GHDL test saved three real VCE fixtures, including active mixed resolution, then restored them nine times.
- All 52 presentation bits exactly matched the captured state after every restore. This checks the observation mapping and VCE serialization rather than assuming the saved phase was restored correctly.

Evidence: `validation/video_phase_restore/run.log`.

The exact top/backend integration tests were also updated separately to exercise alignment/postflush request blocking and retained fault handling. Their results belong to the main rewind validation report.

## Additional mode and boundary coverage

Four further actual-VCE/native-video scenarios passed for RVBL=1, DOTCLOCK=3, line/field/sync boundaries, and short through multi-field request holds. They added 12,924,023 live comparisons and eight aligned resumes with exact raw sync. Native vertical-pulse sampling changed by up to 32 video clocks (about 0.3725 us) when a dot-clock change occurred during vertical sync; the original zero-width-error result above applies only to the original scenarios. A further coincident system/video clock-edge run also passed, adding 3,589,942 live comparisons and two aligned resumes. See `VIDEO_PHASE_EXTENDED.md` for exact conditions, measurements, and evidence.

## Latency tradeoff

The backend transfer benchmarks alone do not describe total guest pause anymore. For representative 4.71 ms save and 7.30 ms load transfers, the phase tests measured:

| Operation | Guest-machine pause | Analog black / HDMI frame hold |
|---|---:|---:|
| Save, 262-line state | About 16.65 ms | About 16.78 ms |
| Save, 263-line state | About 16.72 ms | About 16.84 ms |
| Tested geometry-changing loads | About 27.60 ms | About 27.73 ms |

These are simulation measurements, not hardware latency guarantees. Pause depends on transfer duration, saved/current beam positions, and geometry. Alignment can add approximately a field, and changing geometry can require another boundary. The post-resume display hold is two lines, about 0.127 ms.

The scheduler counts the 15 capture ticks and four rewind-step ticks only while idle and the backend/video path is ready. Those idle ticks are therefore additional to transaction and alignment time; this is not a fixed four-captures-per-second wall-clock schedule. As an illustrative calculation only, exactly four 16.65 ms pauses per wall-clock second would consume about 6.7% of that second. Actual cadence is slower, and this is not a measured slowdown result. Analog output still shows black during capture/restore. This repair targets scan stability; it does not provide a held analog image or smooth frame-by-frame reverse playback. Rewind remains off by default.

## Still required

- New full-project FPGA synthesis, fit, and timing qualification for each candidate.
- Broader phase/duration sweeps, startup/early-save cases, and actual scandoubler/HQ2x output-path simulation.
- Full-core/game validation of snapshots and repeated rewind with the longer pause.
- Scope measurement at the actual analog connector, including composite-sync generation and the user's adapter path.
- Repeated saves, loads from different game moments, and rewind on the actual PVM. Verify vertical position, horizontal stability, pulse widths, frame lock, black flashes, and reset/abort recovery. Check HDMI separately.
