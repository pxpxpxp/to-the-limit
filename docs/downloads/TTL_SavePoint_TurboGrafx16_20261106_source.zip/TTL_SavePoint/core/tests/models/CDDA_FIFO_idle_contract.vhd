library ieee;use ieee.std_logic_1164.all;
-- Test-only empty-FIFO contract, not vendor timing/CDC behavior.
entity CDDA_FIFO is port(clock:in std_logic;data:in std_logic_vector(31 downto 0);rdreq,sclr,wrreq:in std_logic;empty,full:out std_logic;q:out std_logic_vector(31 downto 0));end;
architecture idle_contract of CDDA_FIFO is begin
 empty<='1';full<='0';q<=(others=>'0');
 process(clock)variable cycles:natural:=0;begin if rising_edge(clock)then
 cycles:=cycles+1;if cycles>100 then
 assert wrreq='0' and rdreq='0' report "CDDA_FIFO idle contract violated" severity failure;
 end if;end if;end process;
end;
