library ieee; use ieee.std_logic_1164.all;
-- Test-only idle FIFO contract. This is not a vendor FIFO implementation.
-- Fail if the DUT attempts FIFO traffic; only status-only behavior is in scope.
entity SCSI_FIFO is port(
 aclr:in std_logic:='0';data:in std_logic_vector(7 downto 0);
 rdclk:in std_logic;rdreq:in std_logic;wrclk:in std_logic;wrreq:in std_logic;
 q:out std_logic_vector(7 downto 0);rdempty:out std_logic;wrfull:out std_logic);
end;
architecture test_idle of SCSI_FIFO is begin
 q<=(others=>'0');rdempty<='1';wrfull<='0';
 process(wrclk)begin if rising_edge(wrclk) and aclr='0' then
  assert wrreq='0' report "idle FIFO contract violated: write" severity failure;
 end if;end process;
 process(rdclk)begin if rising_edge(rdclk) and aclr='0' then
  assert rdreq='0' report "idle FIFO contract violated: read" severity failure;
 end if;end process;
end;
