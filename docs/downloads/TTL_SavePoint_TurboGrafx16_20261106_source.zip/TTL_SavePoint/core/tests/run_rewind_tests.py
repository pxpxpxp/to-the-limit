#!/usr/bin/env python3
"""Compile independent scheduler and exact-source top arbitration/bank tests.

Python only extracts and fingerprints the production blocks. HDL expectations
remain in tb_rewind_top.sv.in; production sources are never rewritten.
"""
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile


def exact_section(text, start, end):
    if text.count(start) != 1 or text.count(end) != 1:
        raise RuntimeError(f"Production section boundaries changed: {start!r}, {end!r}")
    return text[text.index(start):text.index(end)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--iverilog', default=shutil.which('iverilog'))
    parser.add_argument('--vvp', default=shutil.which('vvp'))
    parser.add_argument('--iverilog-base', help='Optional -B directory for unpacked Icarus installation')
    parser.add_argument('--output-dir', type=pathlib.Path)
    parser.add_argument('--extract-only', action='store_true')
    parser.add_argument('--negative-control-rtl', type=pathlib.Path,
                        help='Pre-fix scheduler, expected to fail the registered-backend release test')
    args = parser.parse_args()
    source = pathlib.Path(__file__).resolve().parents[1]
    output = args.output_dir or pathlib.Path(tempfile.mkdtemp(prefix='tg_rewind_tests_'))
    output.mkdir(parents=True, exist_ok=True)
    top = (source / 'TurboGrafx16.sv').read_text()
    blocks = {
        'ARBITRATION': exact_section(top, '// Rewind owns', 'ninja_savestate #'),
        'BRAM_BANK': exact_section(top, 'reg ss_bram_bank = 0;', 'assign bram_q_raw'),
        'CD_BANK': exact_section(top, 'reg ss_cdram_bank=0;', 'wire [15:0] ss_din, ss_dout'),
    }
    commit = [line for line in top.splitlines(keepends=True) if line.startswith('assign ss_load_commit =')]
    if len(commit) != 1:
        raise RuntimeError('Expected exactly one production load-commit assignment')
    blocks['COMMIT'] = commit[0]
    bench = (source / 'tests/tb_rewind_top.sv.in').read_text()
    hashes = {'TurboGrafx16.sv': hashlib.sha256(top.encode()).hexdigest()}
    for key, block in blocks.items():
        marker = '// INSERT_PRODUCTION_' + key
        if bench.count(marker) != 1:
            raise RuntimeError('Missing or duplicate extraction marker ' + marker)
        bench = bench.replace(marker, block)
        hashes[key] = hashlib.sha256(block.encode()).hexdigest()
    (output / 'tb_rewind_top.sv').write_text(bench)
    integration = (source / 'tests/tb_rewind_integrated.sv.in').read_text()
    integration_blocks = dict(blocks)
    integration_blocks['WARM'] = exact_section(top, 'reg [3:0] ss_restore_warm_count = 0;', 'video_phase_align video_phase_align(')
    integration_blocks['FAULT'] = exact_section(top, '// Retain the fault reset', 'wire [17:0] ss_addr;')
    integration_blocks['BACKEND'] = exact_section(top, 'ninja_savestate #', '\nendmodule')
    for key in ('WARM', 'FAULT', 'COMMIT', 'ARBITRATION', 'BACKEND'):
        marker = '// INSERT_PRODUCTION_' + key
        if integration.count(marker) != 1:
            raise RuntimeError('Missing integration extraction marker ' + marker)
        integration = integration.replace(marker, integration_blocks[key])
        hashes['INTEGRATED_' + key] = hashlib.sha256(integration_blocks[key].encode()).hexdigest()
    (output / 'tb_rewind_integrated.sv').write_text(integration)
    (output / 'extracted_source_hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
    print(f'Exact production blocks and SHA-256 fingerprints: {output}', flush=True)
    if args.extract_only:
        return
    if not args.iverilog or not args.vvp:
        parser.error('Icarus not available; provide --iverilog and --vvp, or use --extract-only')
    for name, test in [('tb_rewind_history', source / 'tests/tb_rewind_history.sv'),
                       ('tb_rewind_top', output / 'tb_rewind_top.sv'),
                       ('tb_rewind_registered_backend', source / 'tests/tb_rewind_registered_backend.sv'),
                       ('tb_rewind_integrated', output / 'tb_rewind_integrated.sv')]:
        compile_cmd = [args.iverilog]
        if args.iverilog_base:
            compile_cmd += ['-B', args.iverilog_base]
        compile_cmd += ['-g2012', '-Wall', '-s', name, '-o', str(output / name),
                        str(source / 'rtl/rewind_history.sv'), str(test)]
        if name == 'tb_rewind_integrated':
            compile_cmd += [str(source / 'rtl' / module) for module in
                            ('ninja_savestate.sv', 'word_scan_pack_engine.sv',
                             'adpcm_pack_engine.sv', 'cd_ram_pack_engine.sv')]
        subprocess.run(compile_cmd, check=True, timeout=30)
        result = subprocess.run([args.vvp, str(output / name)], text=True, capture_output=True, timeout=30)
        log = result.stdout + result.stderr
        (output / (name + '.log')).write_text(log)
        print(log, end='', flush=True)
        result.check_returncode()
        if 'PASS ' + name not in log:
            raise RuntimeError(f'{name} did not report completion')
        if name == 'tb_rewind_integrated':
            for offset in (5, 11):
                result = subprocess.run([args.vvp, str(output / name), f'+STALL_OFFSET={offset}'],
                                        text=True, capture_output=True, timeout=30)
                log = result.stdout + result.stderr
                (output / f'{name}_phase{offset}.log').write_text(log)
                print(log, end='', flush=True)
                result.check_returncode()
                if 'PASS ' + name not in log:
                    raise RuntimeError(f'{name} stall phase {offset} did not report completion')



    if args.negative_control_rtl:
        name = 'tb_rewind_registered_backend'
        command = [args.iverilog]
        if args.iverilog_base:
            command += ['-B', args.iverilog_base]
        command += ['-g2012', '-s', name, '-o', str(output / 'negative_control'),
                    str(args.negative_control_rtl), str(source / 'tests' / (name + '.sv'))]
        subprocess.run(command, check=True, timeout=30)
        result = subprocess.run([args.vvp, str(output / 'negative_control')],
                                text=True, capture_output=True, timeout=30)
        log = result.stdout + result.stderr
        (output / 'negative_control.log').write_text(log)
        print(log, end='', flush=True)
        if result.returncode == 0 or 'RELEASE_CANCEL:' not in log:
            raise RuntimeError('Pre-fix scheduler did not fail the intended release/acceptance assertion')
        (output / 'negative_control_sha256.txt').write_text(
            hashlib.sha256(args.negative_control_rtl.read_bytes()).hexdigest()
            + '  ' + str(args.negative_control_rtl) + '\n')
        print('PASS negative control: pre-fix RTL fails the release/acceptance assertion', flush=True)


if __name__ == '__main__':
    main()
