#!/usr/bin/env bash
set -euo pipefail
SOURCE=$(cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:?Usage: run_video_phase_restore.sh NEW_OUTPUT_DIRECTORY}
mkdir -p "$OUT";OUT=$(cd "$OUT" && pwd);cd "$OUT"
sha256sum "$SOURCE/rtl/huc6260.vhd" "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/tests/tb_video_phase_restore.vhd" > source_sha256.txt
ghdl -a --std=08 -fsynopsys "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/rtl/huc6260.vhd" "$SOURCE/tests/tb_video_phase_restore.vhd" > compile.log 2>&1
ghdl -e --std=08 -fsynopsys tb_video_phase_restore > elaborate.log 2>&1
ghdl -r --std=08 -fsynopsys tb_video_phase_restore --assert-level=error --ieee-asserts=disable > run.log 2>&1
cat run.log
