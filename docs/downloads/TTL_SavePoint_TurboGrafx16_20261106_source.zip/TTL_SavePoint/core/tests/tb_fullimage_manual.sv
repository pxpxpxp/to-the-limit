`timescale 1ns/1ps
module tb_fullimage_manual;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;
 reg [31:0] rom_id=32'h1234abcd;
 reg [15:0] config_id=16'h02;
 wire reg_rotate;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,take_ddr,ram_rd,ram_we;
 wire [3:0] error;
 wire [16:0] adpcm_addr;wire [3:0] adpcm_din;wire adpcm_we;reg [3:0] adpcm_dout=0;
 reg [3:0] adpcm0[0:131071],adpcm1[0:131071];reg adpcm_bank=0;integer adpcm_writes=0;
 wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;
 reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;reg [7:0] cd0[0:262143],cd1[0:262143];
 reg cd_pending=0,cd_pending_write=0,cd_block=0;reg [17:0] cd_pending_addr=0;reg [7:0] cd_pending_data=0;integer cd_delay=0,cd_writes=0;
 wire [17:0] scan_addr;reg [15:0] scan_dout;wire [15:0] scan_din;
 reg normal_idle=1;reg ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;
 wire [28:0] ram_addr;wire [63:0] ram_din;
 wire start_block=0;
 // Optional rewind ports: retain the legacy snapshot profile.
 wire private_mode=1'b0;wire [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 ninja_savestate #(.PRIVATE_FULL_IMAGE(1)) dut(.*);
 localparam CG=(43777+681+3)/4,N=CG+8192+32768,IMAGE=N+5;
 reg [15:0] memory[0:262143];reg [63:0] ddr[0:262143];
 integer i,j,b,limit,ticks=0,delay_left=0,pending=0;
 integer writes=0,ram_writes=0,loads=0,fd,c,k,offset,r;
 integer reg_head=0;
 reg expect_fault=0;
 reg [63:0] backup;
 function [15:0] pattern(input integer a,input integer variant);
   pattern=a^(a>>8)^16'h9d35^(variant*16'h571b);
 endfunction
 function integer banklimit(input integer bank);
 case(bank)0:banklimit=8192;1:banklimit=32768;2:banklimit=256;6:banklimit=681;7:banklimit=1025;default:banklimit=512;endcase
 endfunction
 always @(posedge clk) begin
   scan_dout<=scan_addr[17:15]==6 ? memory[6*32768+reg_head] : memory[scan_addr];
   adpcm_dout<=adpcm_bank ? adpcm1[adpcm_addr] : adpcm0[adpcm_addr];
   if(adpcm_we)begin
     if(!freeze)$fatal(1,"ADPCM write outside freeze");
     if(adpcm_bank)adpcm0[adpcm_addr]<=adpcm_din;else adpcm1[adpcm_addr]<=adpcm_din;
     adpcm_writes<=adpcm_writes+1;
   end
   if(load_pulse)adpcm_bank<=!adpcm_bank;
   if(scan_we) begin
     if(!freeze) $fatal(1,"write outside freeze");
     if(scan_addr[17:15]==6) begin
       memory[6*32768+reg_head]<=scan_din;
       reg_head <= (reg_head==680) ? 0 : reg_head+1;
     end else memory[scan_addr]<=scan_din;
     ram_writes<=ram_writes+1;
   end
   if(reg_rotate) begin
     if(!freeze || scan_we || scan_addr[17:15]!=6) $fatal(1,"bad scan-chain rotation");
     reg_head <= (reg_head==680) ? 0 : reg_head+1;
   end
   if(load_pulse) loads<=loads+1;
   if(fault_reset && !expect_fault) $fatal(1,"unexpected fault");
 end
 always @(negedge ram_clk) begin ticks=ticks+1;ram_busy=((ticks%13)<4);end
 always @(posedge ram_clk)begin
  if(cd_ram_req!=cd_ram_ack && cd_delay==0)begin cd_pending<=cd_ram_req;cd_pending_write<=cd_ram_write;cd_pending_addr<=cd_ram_addr;cd_pending_data<=cd_ram_din;cd_delay<=3+(ticks%7);end
  else if(cd_delay!=0 && !cd_block)begin
   if(cd_ram_addr!==cd_pending_addr||cd_ram_din!==cd_pending_data||cd_ram_write!==cd_pending_write)$fatal(1,"CD mailbox changed before ack");
   cd_delay<=cd_delay-1;
   if(cd_delay==1)begin
    if(cd_pending_write)begin if(adpcm_bank)cd0[cd_pending_addr]<=cd_pending_data;else cd1[cd_pending_addr]<=cd_pending_data;cd_writes<=cd_writes+1;end
    else cd_ram_dout<=adpcm_bank?cd1[cd_pending_addr]:cd0[cd_pending_addr];
    cd_ram_ack<=cd_pending;
   end
  end
 end
 always @(posedge ram_clk) begin
   ram_ready<=0;
   if(delay_left!=0) begin delay_left<=delay_left-1;
     if(delay_left==1) begin ram_dout<=ddr[pending];ram_ready<=1;end
   end
   if((ram_we||ram_rd)&&!ram_busy) begin
     if(!take_ddr||ram_addr<29'h7e00000||ram_addr>=29'h7e40000) $fatal(1,"DDR ownership/address");
     if(ram_we) begin ddr[ram_addr-29'h7e00000]<=ram_din;writes<=writes+1;end
     if(ram_rd) begin pending<=ram_addr-29'h7e00000;delay_left<=2+(ticks%9);end
   end
 end
 task save;
 begin wait(!busy);@(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);
 if(error) $fatal(1,"save error %0d",error);end
 endtask
 task load;
 begin wait(!busy);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(freeze);wait(!freeze);wait(!busy);@(negedge clk);end
 endtask
 task fill(input integer variant);
 begin reg_head=0;for(i=0;i<262144;i=i+1)memory[i]=pattern(i,variant);
 for(i=0;i<131072;i=i+1)if(adpcm_bank)adpcm1[i]=pattern(i,variant);else adpcm0[i]=pattern(i,variant);
 for(i=0;i<262144;i=i+1)if(adpcm_bank)cd1[i]=pattern(i,variant);else cd0[i]=pattern(i,variant);end
 endtask
 task check(input integer variant);
 begin for(b=0;b<8;b=b+1)for(j=0;j<banklimit(b);j=j+1)
 if(memory[b*32768+((b==6) ? ((reg_head+j)%681) : j)]!==pattern(b*32768+j,variant))$fatal(1,"restore mismatch bank=%0d addr=%0d",b,j);
 for(j=0;j<131072;j=j+1)if((adpcm_bank?adpcm1[j]:adpcm0[j])!==4'(pattern(j,variant)))$fatal(1,"ADPCM restore mismatch addr=%0d",j);
 for(j=0;j<262144;j=j+1)if((adpcm_bank?cd1[j]:cd0[j])!==8'(pattern(j,variant)))$fatal(1,"CD RAM restore mismatch addr=%0d",j);end
 endtask
 task rejected(input integer code);
 integer before_writes,before_adpcm,before_cd;
 begin before_writes=ram_writes;before_adpcm=adpcm_writes;before_cd=cd_writes;load();
 if(error!=code||before_writes!=ram_writes||before_adpcm!=adpcm_writes||before_cd!=cd_writes)$fatal(1,"invalid image modified machine, expected=%0d got=%0d",code,error);
 end
 endtask
 integer part;string path;
 task read_slot(input integer sn); begin
   path=$sformatf("slot%0d.ss",sn);fd=$fopen(path,"rb");if(!fd)$fatal(1,"missing %s",path);
   for(i=0;i<IMAGE;i=i+1)for(j=0;j<8;j=j+1)begin c=$fgetc(fd);if(c<0)$fatal(1,"short file");ddr[sn*65536+i][j*8+:8]=c;end
   if($fgetc(fd)!=-1)$fatal(1,"long file");$fclose(fd);
 end endtask
 task write_slot(input integer sn); begin
   path=$sformatf("slot%0d.ss",sn);fd=$fopen(path,"wb");if(!fd)$fatal(1,"open %s",path);
   for(i=0;i<IMAGE;i=i+1)for(j=0;j<8;j=j+1)$fwrite(fd,"%c",ddr[sn*65536+i][j*8+:8]);$fclose(fd);
 end endtask
 initial begin
 if(!$value$plusargs("PART=%d",part))$fatal(1,"missing part");
 for(i=0;i<262144;i=i+1)ddr[i]=0;
 fill(0);repeat(4)@(negedge clk);reset=0;
 if(part>=0 && part<4) begin
   slot=part;fill(part);save();if(ddr[part*65536][63:32]!=(IMAGE-1)*2)$fatal(1,"bad size header");write_slot(part);
   $display("PASS: segmented full-size save slot %0d and binary file",part+1);
 end else if(part>=4 && part<8) begin
   slot=part-4;fill(9);read_slot(slot);@(negedge clk);reset=1;repeat(3)@(negedge clk);reset=0;
   load();if(error)$fatal(1,"reload error %0d",error);check(slot);
   $display("PASS: segmented full-size file reload slot %0d after reset",slot+1);
 end else if(part==8) begin
   slot=3;read_slot(slot);fill(3);backup=ddr[3*65536];save();if(ddr[3*65536][31:0]==backup[31:0])$fatal(1,"unchanged generation");
   rom_id=rom_id^1;rejected(4);rom_id=rom_id^1;
   config_id=config_id^1;rejected(4);config_id=config_id^1;
   config_id=config_id^16'h0040;rejected(4);config_id=config_id^16'h0040;
   config_id=config_id^16'h0080;rejected(4);config_id=config_id^16'h0080;
   config_id=config_id^16'h0100;rejected(4);config_id=config_id^16'h0100;
   offset=3*65536;backup=ddr[offset+2];ddr[offset+2]=backup^1;rejected(3);ddr[offset+2]=backup;
   backup=ddr[offset+1];ddr[offset+1]=backup^1;rejected(2);ddr[offset+1]=backup;
   backup=ddr[offset+5+N-1];ddr[offset+5+N-1]=backup^1;rejected(6);ddr[offset+5+N-1]=backup;
   backup=ddr[offset+5+CG+3];ddr[offset+5+CG+3]=backup^64'h8000000000000000;rejected(6);ddr[offset+5+CG+3]=backup;
   backup=ddr[offset+5+CG+8192+3];ddr[offset+5+CG+8192+3]=backup^64'h8000000000000000;rejected(6);ddr[offset+5+CG+8192+3]=backup;
   $display("PASS: segmented full-size generation/identity/schema/version and CRC rejections");
 end else if(part==9) begin
   slot=3;read_slot(slot);fill(9);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(scan_we);
   @(negedge clk);expect_fault=1;reset=1;@(negedge clk);if(!fault_reset)$fatal(1,"partial restore did not reset");reset=0;
   repeat(12)@(negedge clk);expect_fault=0;load();if(error)$fatal;check(3);
   $display("PASS: segmented full-size interrupted core apply and retry");
 end else if(part==10) begin
   slot=3;read_slot(slot);fill(9);@(negedge clk);load_button=1;@(negedge clk);load_button=0;wait(adpcm_we);
   repeat(10)@(negedge clk);expect_fault=1;enabled=0;@(negedge clk);if(!fault_reset)$fatal(1,"ADPCM abort lacked reset");
   enabled=1;repeat(12)@(negedge clk);expect_fault=0;
   for(j=0;j<131072;j=j+1)if((adpcm_bank?adpcm1[j]:adpcm0[j])!==4'(pattern(j,9)))$fatal(1,"ADPCM bank changed");
   load();if(error)$fatal;check(3);$display("PASS: segmented full-size interrupted ADPCM apply and retry");
 end else if(part==11) begin
   slot=3;read_slot(slot);fill(9);@(negedge clk);load_button=1;@(negedge clk);load_button=0;
   wait(cd_ram_write && cd_ram_req!=cd_ram_ack);cd_block=1;@(negedge clk);expect_fault=1;enabled=0;@(negedge clk);
   if(!fault_reset||!cd_ram_hold)$fatal(1,"CD abort did not hold outstanding request");
   repeat(12)@(negedge clk);if(!cd_ram_hold)$fatal(1,"CD hold released early");cd_block=0;wait(!cd_ram_hold);
   @(negedge clk);enabled=1;repeat(12)@(negedge clk);expect_fault=0;
   for(j=0;j<262144;j=j+1)if((adpcm_bank?cd1[j]:cd0[j])!==8'(pattern(j,9)))$fatal(1,"CD active bank modified");
   load();if(error)$fatal;check(3);$display("PASS: segmented full-size interrupted CD RAM apply and retry");
 end else $fatal(1,"unknown part");
 $finish;
 end
 initial begin #1000000000;$fatal(1,"timeout");end
endmodule
