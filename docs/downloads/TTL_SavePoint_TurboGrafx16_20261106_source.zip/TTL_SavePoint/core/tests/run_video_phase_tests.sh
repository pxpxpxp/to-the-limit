#!/usr/bin/env bash
set -euo pipefail
SOURCE=$(cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:?Usage: run_video_phase_tests.sh NEW_OUTPUT_DIRECTORY}
mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
cd "$OUT"
sources=("$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/huc6260.vhd" "$SOURCE/rtl/pce_top.vhd" "$SOURCE/TurboGrafx16.sv"
 "$SOURCE/sys/video_mixer.sv" "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/tests/tb_video_phase_actual.sv"
 "$SOURCE/tests/tb_video_phase_control.sv" "$SOURCE/tests/run_video_phase_tests.sh")
sha256sum "${sources[@]}" > source_sha256.txt
# The VCE is synthesized directly from the production VHDL. Only its palette
# RAM uses the repository behavioral RAM model. No handwritten beam model.
ghdl -a --std=08 -fsynopsys "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/rtl/huc6260.vhd" > vce_analyze.log 2>&1
ghdl --synth --std=08 -fsynopsys --out=verilog huc6260 > huc6260_actual.v 2> vce_synth.log
iverilog -g2012 -s tb_video_phase_control -o control.vvp "$SOURCE/tests/tb_video_phase_control.sv" "$SOURCE/rtl/video_phase_align.sv" > control_compile.log 2>&1
vvp control.vvp > control.log
cat control.log
iverilog -g2012 -s tb_video_phase_actual -o actual.vvp "$SOURCE/tests/tb_video_phase_actual.sv" huc6260_actual.v \
 "$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv" "$SOURCE/sys/video_mixer.sv" > actual_compile.log 2>&1
# The deliberate negative control removes only phase qualification. It must
# fail the actual-VCE resume assertion; success would invalidate this test.
python3 - "$SOURCE/rtl/video_phase_align.sv" <<'PYNEG'
import pathlib,sys
s=pathlib.Path(sys.argv[1]).read_text()
a='if (valid_phase && next_phase == core_phase) begin'
assert s.count(a)==1
pathlib.Path('video_phase_no_alignment.sv').write_text(s.replace(a,'if (valid_phase) begin'))
PYNEG
iverilog -g2012 -s tb_video_phase_actual -o negative.vvp "$SOURCE/tests/tb_video_phase_actual.sv" huc6260_actual.v \
 video_phase_no_alignment.sv "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv" "$SOURCE/sys/video_mixer.sv" > negative_compile.log 2>&1
pids=()
for scenario in 0 1 2; do
  echo "Running actual VCE/native pipeline scenario $scenario"
  timeout 1800 vvp actual.vvp +SCENARIO="$scenario" > "actual.$scenario.log" &
  pids+=("$!")
done
(set +e; timeout 1800 vvp negative.vvp +SCENARIO=0 > negative.log; echo "$?" > negative.status) &
negative_pid=$!
status=0
for scenario in 0 1 2; do
  wait "${pids[$scenario]}" || status=1
  cat "actual.$scenario.log"
done
wait "$negative_pid" || true
if [[ ! -f negative.status ]]; then echo "Negative control did not complete"; exit 1; fi
if [[ $(cat negative.status) == 0 ]] || ! grep -q 'resume phase mismatch' negative.log; then
  echo "Negative control did not fail the intended phase assertion";cat negative.log;exit 1
fi
echo "PASS negative control: disabling alignment fails the actual VCE resume assertion"
sha256sum "${sources[@]}" > source_sha256_after.txt
cmp source_sha256.txt source_sha256_after.txt
[[ "$status" == 0 ]]
