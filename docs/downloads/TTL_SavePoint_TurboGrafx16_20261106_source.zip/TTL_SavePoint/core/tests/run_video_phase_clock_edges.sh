#!/usr/bin/env bash
set -euo pipefail
SOURCE=$(cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:?Usage: run_video_phase_clock_edges.sh NEW_OUTPUT_DIRECTORY}
mkdir -p "$OUT";OUT=$(cd "$OUT" && pwd);cd "$OUT"
sources=("$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/huc6260.vhd" "$SOURCE/sys/video_mixer.sv"
 "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv"
 "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/tests/tb_video_phase_extended.sv" "$SOURCE/tests/run_video_phase_clock_edges.sh")
sha256sum "${sources[@]}" > source_sha256.txt
# Shift only the testbench clk_sys origin. The production clock ratio stays
# 2:1, but now every system rising edge coincides with a video rising edge.
python3 - "$SOURCE/tests/tb_video_phase_extended.sv" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a='always #2 clk=~clk; always #1 video_clk=~video_clk;'
b='initial begin #1; forever #2 clk=~clk; end always #1 video_clk=~video_clk;'
assert s.count(a)==1
Path('tb_video_phase_coincident.sv').write_text(s.replace(a,b))
PY
ghdl -a --std=08 -fsynopsys "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/rtl/huc6260.vhd" > vce_analyze.log 2>&1
ghdl --synth --std=08 -fsynopsys --out=verilog huc6260 > huc6260_actual.v 2> vce_synth.log
iverilog -g2012 -s tb_video_phase_extended -o coincident.vvp tb_video_phase_coincident.sv huc6260_actual.v \
 "$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv" "$SOURCE/sys/video_mixer.sv" > compile.log 2>&1
timeout 1800 vvp coincident.vvp +SCENARIO=10 > run.log
cat run.log
sha256sum "${sources[@]}" > source_sha256_after.txt
cmp source_sha256.txt source_sha256_after.txt
sha256sum tb_video_phase_coincident.sv > generated_test_sha256.txt
