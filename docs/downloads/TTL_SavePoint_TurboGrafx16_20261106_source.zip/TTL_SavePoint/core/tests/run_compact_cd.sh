#!/bin/sh
set -eu
SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:-/tmp/tg_compact_cd}
GHDL=${GHDL:-ghdl}
mkdir -p "$OUT"
cd "$OUT"
"$GHDL" -a --std=08 -fsynopsys "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/tests/models/SCSI_FIFO_idle_contract.vhd" "$SOURCE/tests/models/CDDA_FIFO_idle_contract.vhd" "$SOURCE/tests/models/CDSUBC_FIFO_idle_contract.vhd" "$SOURCE/rtl/cd/CEGen_CD.vhd" "$SOURCE/rtl/cd/MSM5205.vhd" "$SOURCE/rtl/cd/SCSI.vhd" "$SOURCE/rtl/cd/adpcm_snapshot_ram.vhd" "$SOURCE/rtl/cd/cd.vhd" "$SOURCE/tests/tb_compact_cd.vhd" > compile.log 2>&1
"$GHDL" -e --std=08 -fsynopsys tb_compact_cd > elaborate.log 2>&1
"$GHDL" -r --std=08 -fsynopsys tb_compact_cd --assert-level=error > run.log 2>&1
cat run.log
