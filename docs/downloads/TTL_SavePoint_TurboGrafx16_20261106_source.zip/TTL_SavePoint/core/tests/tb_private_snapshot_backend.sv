`timescale 1ns/1ps
module tb_private_snapshot_backend;
 reg clk=0,ram_clk=0;always #10 clk=~clk;always #5 ram_clk=~ram_clk;
 reg reset=1,enabled=1,safe=1,save_button=0,load_button=0;
 reg [1:0] slot=0;reg [31:0] rom_id=32'h1234abcd;reg [15:0] config_id=16'h42;
 wire freeze,save_pulse,load_pulse,valid,fault_reset,scan_we,reg_rotate,take_ddr,ram_rd,ram_we;
 wire [3:0] error;wire [17:0] scan_addr;reg [15:0] scan_dout=0;wire [15:0] scan_din;
 wire [16:0] adpcm_addr;wire [3:0] adpcm_din;wire adpcm_we;reg [3:0] adpcm_dout=0;
 wire [17:0] cd_ram_addr;wire [7:0] cd_ram_din;wire cd_ram_write,cd_ram_req,cd_ram_hold;
 reg cd_ram_ack=0;reg [7:0] cd_ram_dout=0;
 reg [7:0] cd0[0:31],cd1[0:31];integer cd_delay=0;reg cd_pending=0,cd_pending_write=0,cd_block=0;
 reg [17:0] cd_pending_addr=0;reg [7:0] cd_pending_data=0;
 reg normal_idle=1;reg ram_busy=0,ram_ready=0;reg [63:0] ram_dout=0;wire [28:0] ram_addr;wire [63:0] ram_din;
 localparam RM=5,AM=8,CM=4,RG=4,CG=(RM+RG+3)/4,N=CG+AM+CM;
 reg private_mode=0;reg [6:0] private_slot=0;
 wire busy,done,failed,request_accept,operation_private;
 integer successes=0,failures=0,accepts=0,cdwrites=0;
 reg old_done=0,old_failed=0,stall_ddr=0;
 always @(posedge clk) begin
  old_done<=done;old_failed<=failed;
  if(done)begin
   successes<=successes+1;
   if(freeze||take_ddr||old_done)$fatal(1,"premature or repeated success");
  end
  if(failed)begin failures<=failures+1;if(old_failed)$fatal(1,"repeated failure");end
  if(request_accept)accepts<=accepts+1;
  if(operation_private && (adpcm_we||cd_ram_hold))$fatal(1,"private operation touched CD/ADPCM payload");
 end
 wire start_block=0;
 ninja_savestate #(.RAM_WORDS(RM),.ADPCM_WORDS(AM),.CDRAM_WORDS(CM),.REGISTER_WORDS(RG)) dut(.*);
 reg [15:0] live[0:7],regs[0:3];reg [3:0] a0[0:127],a1[0:127];reg bank=0;
 reg [63:0] ddr[0:2359295];integer i,j,k,r,fd,ticks=0,pending=0,delay_left=0,writes=0,adwrites=0;reg expect_fault=0;reg [63:0] backup,checkword;reg [31:0] checksum;integer cbit,cbyte;
 function [3:0] pat(input integer idx,input integer variant);pat=(idx^(idx>>3)^(variant*7))&15;endfunction
 always @(posedge clk) begin
  scan_dout <= scan_addr[17:15]==6 ? regs[0] : live[scan_addr[2:0]];
  adpcm_dout <= bank ? a1[adpcm_addr] : a0[adpcm_addr];
  if(scan_we) begin
   if(!freeze)$fatal(1,"scan write outside freeze");
   if(scan_addr[17:15]==6)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=scan_din;end
   else live[scan_addr[2:0]]<=scan_din;
   writes<=writes+1;
  end
  if(reg_rotate)begin regs[0]<=regs[1];regs[1]<=regs[2];regs[2]<=regs[3];regs[3]<=regs[0];end
  if(adpcm_we)begin
   if(!freeze)$fatal(1,"ADPCM write outside freeze");
   if(bank)a0[adpcm_addr]<=adpcm_din;else a1[adpcm_addr]<=adpcm_din;
   adwrites<=adwrites+1;
  end
  if(load_pulse && !operation_private)bank<=!bank;
  if(fault_reset && !expect_fault)$fatal(1,"unexpected fault reset");
 end
 always @(negedge ram_clk)begin ticks=ticks+1;ram_busy=((ticks%11)<3);end
 always @(posedge ram_clk)begin
  if(cd_ram_req!=cd_ram_ack && cd_delay==0)begin cd_pending<=cd_ram_req;cd_pending_write<=cd_ram_write;cd_pending_addr<=cd_ram_addr;cd_pending_data<=cd_ram_din;cd_delay<=3+(ticks%7);end
  else if(cd_delay!=0 && !cd_block)begin
   if(cd_ram_addr!==cd_pending_addr||cd_ram_din!==cd_pending_data||cd_ram_write!==cd_pending_write)$fatal(1,"CD mailbox changed before ack");
   cd_delay<=cd_delay-1;
   if(cd_delay==1)begin
    if(cd_pending_write)begin if(bank)cd0[cd_pending_addr]<=cd_pending_data;else cd1[cd_pending_addr]<=cd_pending_data;end
    else cd_ram_dout<=bank?cd1[cd_pending_addr]:cd0[cd_pending_addr];
    cd_ram_ack<=cd_pending;
   end
  end
 end
 always @(posedge ram_clk)begin
  ram_ready<=0;
  if(delay_left!=0 && !stall_ddr)begin delay_left<=delay_left-1;if(delay_left==1)begin ram_dout<=ddr[pending];ram_ready<=1;end end
  if((ram_we||ram_rd)&&!ram_busy)begin
   if(!take_ddr)$fatal(1,"DDR ownership");
   if(operation_private)begin
    if(ram_addr<29'h7c00000 || ram_addr>=29'h7e00000 ||
       ram_addr<(29'h7c00000+dut.active_private_slot*16384) ||
       ram_addr>=(29'h7c00000+dut.active_private_slot*16384+CG+5))$fatal(1,"private bounds");
   end else if(ram_addr<(29'h7e00000+dut.active_slot*65536) ||
               ram_addr>=(29'h7e00000+dut.active_slot*65536+N+5))$fatal(1,"manual bounds");
   if(ram_we)ddr[ram_addr-29'h7c00000]<=ram_din;
   if(ram_rd)begin pending<=ram_addr-29'h7c00000;delay_left<=2+(ticks%5);end
  end
 end
 task fill(input integer v);begin
  for(i=0;i<RM;i=i+1)live[i]=16'h1100+i+v;
  for(i=0;i<RG;i=i+1)regs[i]=16'h2200+i+v;
  for(i=0;i<128;i=i+1)if(bank)a1[i]=pat(i,v);else a0[i]=pat(i,v);
  for(i=0;i<32;i=i+1)if(bank)cd1[i]=8'(i^(v*37));else cd0[i]=8'(i^(v*37));
 end endtask
 task check(input integer v);begin
  for(i=0;i<RM;i=i+1)if(live[i]!==16'h1100+i+v)$fatal(1,"RAM %0d",i);
  for(i=0;i<RG;i=i+1)if(regs[i]!==16'h2200+i+v)$fatal(1,"REG %0d",i);
  for(i=0;i<128;i=i+1)if((bank?a1[i]:a0[i])!==pat(i,v))$fatal(1,"ADPCM %0d",i);
  for(i=0;i<32;i=i+1)if((bank?cd1[i]:cd0[i])!==8'(i^(v*37)))$fatal(1,"CD RAM %0d",i);
 end endtask
 task check_crc(input integer b,input integer n);reg [31:0] c;integer w,l;begin
  c=32'hffffffff;
  for(w=0;w<n;w=w+1)for(l=0;l<64;l=l+1)
   c=(c>>1)^((c[0]^ddr[b+5+w][l])?32'hedb88320:0);
  if(ddr[b+4][31:0]!==~c)$fatal(1,"independent CRC mismatch");
 end endtask
 task op(input bit isload,input integer expected_error);integer before_done,before_failed;begin
  wait(!busy);repeat(2)@(negedge clk);
  before_done=successes;before_failed=failures;
  if(isload)load_button=1;else save_button=1;
  @(negedge clk);load_button=0;save_button=0;
  wait(busy);wait(!busy);repeat(3)@(negedge clk);
  if(error!=expected_error)$fatal(1,"operation error %0d expected %0d",error,expected_error);
  if(expected_error==0)begin
   if(successes!=before_done+1||failures!=before_failed)$fatal(1,"missing success");
  end else if(successes!=before_done||failures!=before_failed+1)$fatal(1,"bad failure completion");
 end endtask
 task check_core(input integer v);begin
  for(j=0;j<RM;j=j+1)if(live[j]!==16'h1100+j+v)$fatal(1,"core RAM %0d",j);
  for(j=0;j<RG;j=j+1)if(regs[j]!==16'h2200+j+v)$fatal(1,"core register %0d",j);
 end endtask
 integer base_addr,prior_done,prior_failed,prior_writes,prior_adwrites;
 initial begin
  for(i=0;i<2359296;i=i+1)ddr[i]=0;
  repeat(4)@(negedge clk);reset=0;
  // The full legacy layout and schema remain byte-for-byte unchanged.
  for(k=0;k<4;k=k+1)begin
   slot=k;fill(k+1);op(0,0);base_addr=2097152+k*65536;check_crc(base_addr,N);
   if(ddr[base_addr][63:32]!=(N+4)*2 || ddr[base_addr+4][63:32]!=N ||
      ddr[base_addr+1]!==64'h54474c5353000003 ||
      ddr[base_addr+2]!==64'h7b4a4831e0d369a8)$fatal(1,"manual format changed");
  end
  for(k=0;k<4;k=k+1)begin slot=k;fill(7);op(1,0);check(k+1);end
  // X and Z on optional mode must select manual, just as omitted ports do.
  private_mode=1'bx;slot=0;fill(11);op(0,0);
  if(operation_private)$fatal(1,"X selected private profile");
  private_mode=1'bz;fill(7);op(1,0);check(11);
  // Every compact slot, including both reservation boundaries, is independent.
  private_mode=1;
  for(k=0;k<128;k=k+1)begin
   private_slot=k;fill(k);op(0,0);base_addr=k*16384;check_crc(base_addr,CG);
   if(ddr[base_addr][63:32]!=(CG+4)*2 || ddr[base_addr+4][63:32]!=CG ||
      ddr[base_addr+1]!==64'h5447525744000001 ||
      ddr[base_addr+2]!== (64'h7b4a4831e0d369a8 ^ 64'h524557494e440001))$fatal(1,"private format");
  end
  prior_adwrites=adwrites;
  for(k=127;k>=0;k=k-1)begin private_slot=k;fill(200);op(1,0);check_core(k);end
  if(adwrites!=prior_adwrites)$fatal(1,"compact load modified ADPCM");
  // Manual images remain untouched by all private transactions.
  private_mode=0;slot=0;fill(7);op(1,0);check(11);
  for(k=1;k<4;k=k+1)begin slot=k;fill(7);op(1,0);check(k+1);end
  private_mode=1;private_slot=127;base_addr=127*16384;
  // Header, schema, identity, count, CRC and padding reject before any apply.
  for(k=0;k<6;k=k+1)begin
   backup=ddr[base_addr+k];ddr[base_addr+k]=backup^(k==0||k==4?64'h100000000:64'h1);
   prior_writes=writes;
   case(k)
    0:op(1,1);1:op(1,2);2:op(1,3);3:op(1,4);4:op(1,5);5:op(1,6);
   endcase
   if(writes!=prior_writes)$fatal(1,"invalid image applied");
   ddr[base_addr+k]=backup;
  end
  backup=ddr[base_addr+5+CG-1];ddr[base_addr+5+CG-1]=backup^64'h1000000000000000;
  prior_writes=writes;op(1,8);if(writes!=prior_writes)$fatal(1,"padding applied");
  ddr[base_addr+5+CG-1]=backup;
  // Latched profile and address cannot change when caller changes its inputs.
  private_slot=0;fill(25);wait(!busy);@(negedge clk);save_button=1;
  @(negedge clk);save_button=0;wait(request_accept);
  private_mode=0;private_slot=126;slot=3;
  wait(!busy);repeat(3)@(negedge clk);
  if(!operation_private)$fatal(1,"profile was not latched");
  private_mode=1;private_slot=0;fill(7);op(1,0);check_core(25);
  // Abort before freeze, during capture, and during applying. No false success.
  for(k=0;k<3;k=k+1)begin
   wait(!busy);prior_done=successes;prior_failed=failures;
   if(k==0)safe=0;
   @(negedge clk);if(k==2)load_button=1;else save_button=1;
   @(negedge clk);save_button=0;load_button=0;
   if(k==0)wait(request_accept);
   else if(k==1)wait(dut.state==7);
   else wait(scan_we);
   @(negedge clk);expect_fault=(k==2);enabled=0;
   repeat(4)@(negedge clk);enabled=1;safe=1;
   wait(!busy);repeat(4)@(negedge clk);expect_fault=0;
   if(successes!=prior_done||failures!=prior_failed+1)$fatal(1,"abort completion");
   fill(25);op(0,0);
  end
  // Abort an accepted DDR read: keep ownership and the latched profile until
  // the late response drains, without presenting success or reusing its data.
  wait(!busy);prior_done=successes;prior_failed=failures;
  @(negedge clk);load_button=1;@(negedge clk);load_button=0;
  wait(ram_rd);stall_ddr=1;wait(dut.dstate==2);
  @(negedge clk);enabled=0;private_mode=0;
  repeat(12)@(negedge clk);
  if(!busy||!take_ddr||!operation_private||successes!=prior_done)$fatal(1,"late read owner lost");
  stall_ddr=0;wait(!busy);@(negedge clk);enabled=1;private_mode=1;
  repeat(4)@(negedge clk);
  if(failures!=prior_failed+1||successes!=prior_done)$fatal(1,"late read abort completion");
  fill(25);op(0,0);fill(7);op(1,0);check_core(25);
  // Forced watchdog exercises the same abort completion path.
  prior_done=successes;prior_failed=failures;safe=0;
  @(negedge clk);save_button=1;@(negedge clk);save_button=0;wait(request_accept);
  @(negedge clk);force dut.watchdog=28'hfffffff;
  @(negedge clk);release dut.watchdog;dut.watchdog=0;safe=1;
  wait(!busy);repeat(4)@(negedge clk);
  if(successes!=prior_done||failures!=prior_failed+1||error!=7)$fatal(1,"watchdog completion");
  fill(25);op(0,0);fill(7);op(1,0);check_core(25);
  $display("PASS: private 128-slot bounds, full legacy format, latched profile, CRC/header rejection, completion and aborts");$finish;
 end
 initial begin #20000000;$fatal(1,"timeout");end
endmodule
