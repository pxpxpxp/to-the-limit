#!/usr/bin/env python3
"""Independent exact-production battery request freeze/busy regression.
No model of the request controller: the complete production battery FSM and
its dirty flag and BRAM host-port equations are inserted verbatim. The real
one-cycle download sampler is retained. SD acknowledgements and RAM storage
are test fixtures; vendor RAM timing is not simulated.
"""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir', type=pathlib.Path)
parser.add_argument('--baseline-source', type=pathlib.Path,
                    help='Pre-fix top file or source directory; expected to fail the freeze-autosave check')
parser.add_argument('--boundary-negative-controls', action='store_true',
                    help='Require boot-queue, format-queue and frozen-pointer mutants to fail intended checks')
parser.add_argument('--iverilog', default=shutil.which('iverilog'))
parser.add_argument('--vvp', default=shutil.which('vvp'))
args = parser.parse_args()
source = pathlib.Path(__file__).resolve().parents[1] / 'TurboGrafx16.sv'
out = args.output_dir or pathlib.Path(tempfile.mkdtemp(prefix='tg_backup_freeze_'))
if not args.iverilog or not args.vvp:
    parser.error('Icarus and vvp are required; put them on PATH or pass their paths')

def production_blocks(path):
    text = path.read_text()
    markers = ('reg bk_pending;', 'wire [10:0] bram_addr;', 'wire bk_load    = status[16];')
    for marker in markers:
        if text.count(marker) != 1:
            raise RuntimeError('Missing or ambiguous production marker: ' + marker)
    a = text.index(markers[0])
    b = text.index(markers[1], a)
    dirty = text[a:b]
    a = text.index(markers[2])
    b = text.index('\n\n/////////////////////////////////////////////////////////////////////////', a)
    block = text[a:b]
    a = text.index('wire [9:0] ss_bram_baddr =')
    b = text.index('dpram_difclk', a)
    host = text[a:b]
    sampler = '\n'.join(line for line in text.splitlines() if line.strip() == 'old_downloading <= downloading;')
    if not sampler or sampler.count('old_downloading') != 1:
        raise RuntimeError('Missing or ambiguous real download sampler')
    return text, dirty, block, host, sampler

pre='''`timescale 1ns/1ps
module tb_backup_freeze_edges;
reg clk_sys=0; always #5 clk_sys=~clk_sys;
reg [63:0] status=0;
reg OSD_STATUS=0,bk_ena=0,ss_load_commit=0,bram_wr=0;
reg sd_ack=0,ss_machine_freeze=0,old_downloading=0,downloading=0,mb128_ena=0,mb128_dirty=0,format=0;
reg [31:0] sd_lba=0;
reg sd_rd=0,sd_wr=0;
reg ss_backend_busy=0,ss_video_busy=0;
reg [3:0] defbram=15;
wire bk_int = !sd_lba[31:2];
reg [17:0] ss_addr=0;reg [15:0] ss_din=0;reg ss_we=0;
reg [7:0] sd_buff_addr=0;reg [15:0] sd_buff_dout=0;reg sd_buff_wr=0;
reg [15:0] defval[0:3];
initial begin defval[0]=16'h5548;defval[1]=16'h4D42;defval[2]=16'h8800;defval[3]=16'h8010;end
'''
post=r'''
integer starts=0,checks=0,format_writes=0,format_runs=0;
integer format_addr_writes[0:3];reg [15:0] format_mem[0:3];
reg [3:0] prev_defbram=15;
integer init_i;
initial for(init_i=0;init_i<4;init_i=init_i+1)begin format_addr_writes[init_i]=0;format_mem[init_i]=0;end
always @(posedge clk_sys)begin
 prev_defbram<=defbram;
 if(!defbram[3] && prev_defbram[3])format_runs<=format_runs+1;
 if(!defbram[3] && ss_bram_host_write)begin
  if(bk_state || sd_rd || sd_wr)$fatal(1,"Format writes overlap active SD transfer");
  if(ss_bram_baddr!=defbram[2:1] || ss_bram_bdata!=defval[defbram[2:1]])$fatal(1,"Format host-port mapping is incorrect");
  format_writes<=format_writes+1;
  format_addr_writes[ss_bram_baddr]<=format_addr_writes[ss_bram_baddr]+1;
  format_mem[ss_bram_baddr]<=ss_bram_bdata;
 end
end
reg old_state=0;
always @(posedge clk_sys)begin
 old_state<=bk_state;
 if(bk_state && !old_state) starts<=starts+1;
 if(ss_machine_freeze && bk_state && !old_state) $fatal(1,"Backup starts during snapshot freeze");
end
task cycle; begin @(posedge clk_sys);#1;end endtask
task check(input bit ok,input string what);begin
 checks=checks+1;
 if(!ok)$fatal(1,"CHECK %0d: %s starts=%0d loading=%b pending=%b",checks,what,starts,bk_loading,bk_pending);
end endtask
task fresh;begin
 @(negedge clk_sys);bk_ena=0;status=0;OSD_STATUS=0;sd_ack=0;
 ss_machine_freeze=0;ss_backend_busy=0;ss_video_busy=0;downloading=0;mb128_dirty=0;bram_wr=0;ss_load_commit=0;format=0;
 repeat(4)cycle();check(!bk_state,"fresh case begins idle");
 @(negedge clk_sys);bk_pending=0;bk_ena=1;repeat(3)cycle();
end endtask
task mark_dirty;begin
 @(negedge clk_sys);bram_wr=1;cycle();@(negedge clk_sys);bram_wr=0;cycle();
 check(bk_pending,"CPU battery write marks dirty");
end endtask
task pulse(input bit loading);begin
 @(negedge clk_sys);if(loading)status[16]=1;else status[7]=1;
 cycle();@(negedge clk_sys);status[16]=0;status[7]=0;cycle();
end endtask
task await_start(input bit loading,input string what);
 integer n;begin
 n=0;while(!bk_state && n<40)begin cycle();n=n+1;end
 check(bk_state && bk_loading==loading && (loading ? sd_rd : sd_wr),what);
 cycle();
end endtask
task finish_transfer;
 integer blocks;begin
 blocks=0;
 while(bk_state && blocks<300)begin
  check(sd_rd || sd_wr,"active transfer has a sector request");
  @(negedge clk_sys);sd_ack=1;cycle();
  check(!sd_rd && !sd_wr,"acknowledgement drops read/write strobes");
  @(negedge clk_sys);sd_ack=0;cycle();blocks=blocks+1;
 end
 check(!bk_state,"transfer completes in bounded sectors");
end endtask
task quiet(input integer count,input string what);
 integer i;begin for(i=0;i<count;i=i+1)begin cycle();check(!bk_state && !sd_wr && !sd_rd,what);end end
endtask
task complete_download;begin
 @(negedge clk_sys);downloading=1;cycle();
 @(negedge clk_sys);downloading=0;cycle();
end endtask
task format_pulse;begin
 @(negedge clk_sys);format=1;cycle();
 @(negedge clk_sys);format=0;cycle();
end endtask
task await_format(input string what);integer n;begin
 n=0;while(defbram[3] && n<40)begin cycle();n=n+1;end
 check(!defbram[3] && !bk_state,what);
end endtask
task finish_format;integer n;begin
 n=0;while(!defbram[3] && n<40)begin cycle();n=n+1;end
 check(defbram[3],"format completes in eight writable cycles");
end endtask
integer before_starts,before_writes,before_formats,save_pointer,j,k;
integer before_addr[0:3];
initial begin
 bk_pending=0;repeat(4)cycle();
 $display("CASE autosave edge while snapshot frozen");
 fresh();mark_dirty();before_starts=starts;
 @(negedge clk_sys);ss_machine_freeze=1;repeat(3)cycle();
 @(negedge clk_sys);OSD_STATUS=1;status[23]=1;repeat(4)cycle();
 check(!bk_state && !sd_wr,"autosave waits through freeze");
 @(negedge clk_sys);ss_machine_freeze=0;
 await_start(0,"queued autosave begins after thaw");finish_transfer();quiet(12,"autosave does not retrigger while OSD stays open");
 check(starts==before_starts+1 && !bk_pending,"exactly one autosave clears dirty");

 $display("CASE autosave high cannot mask brief manual save edge");
 fresh();mark_dirty();before_starts=starts;
 @(negedge clk_sys);ss_machine_freeze=1;OSD_STATUS=1;status[23]=1;repeat(4)cycle();
 pulse(0);repeat(3)cycle();
 @(negedge clk_sys);OSD_STATUS=0;ss_machine_freeze=0;
 await_start(0,"manual save edge survives overlapping high autosave");
 finish_transfer();quiet(8,"overlapping manual save only once");
 quiet(8,"overlapping autosave is consumed");
 check(starts==before_starts+1,"high autosave does not hide explicit manual save");

 $display("CASE brief manual save while snapshot frozen");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;
 pulse(0);repeat(5)cycle();check(!bk_state,"brief manual save waits through freeze");
 @(negedge clk_sys);ss_machine_freeze=0;
 await_start(0,"brief manual save survives until thaw");finish_transfer();quiet(8,"manual save only once");
 check(starts==before_starts+1,"one brief manual save request");

 $display("CASE brief manual load while snapshot frozen");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;
 pulse(1);repeat(5)cycle();check(!bk_state,"brief manual load waits through freeze");
 @(negedge clk_sys);ss_machine_freeze=0;
 await_start(1,"brief manual load survives until thaw");finish_transfer();quiet(8,"manual load only once");
 check(starts==before_starts+1,"one brief manual load request");

 $display("CASE simultaneous load/save priority");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;
 @(negedge clk_sys);status[16]=1;status[7]=1;cycle();
 @(negedge clk_sys);status[16]=0;status[7]=0;repeat(3)cycle();ss_machine_freeze=0;
 await_start(1,"simultaneous load wins over save");finish_transfer();quiet(8,"simultaneous lower-priority save is consumed");
 check(starts==before_starts+1,"simultaneous request dispatches only once");

 $display("CASE request arrives while previous transfer busy");
 fresh();before_starts=starts;pulse(0);await_start(0,"first save begins");pulse(1);
 check(bk_state && !bk_loading,"new load does not redirect active save");
 finish_transfer();await_start(1,"queued load begins after active save");finish_transfer();quiet(8,"busy-arrival load dispatches once");
 check(starts==before_starts+2,"busy-arrival creates exactly two operations");

 $display("CASE request on final sector completion edge");
 fresh();before_starts=starts;pulse(0);await_start(0,"save before final-edge arrival");
 while(sd_lba!=3)begin
  @(negedge clk_sys);sd_ack=1;cycle();@(negedge clk_sys);sd_ack=0;cycle();
 end
 @(negedge clk_sys);sd_ack=1;cycle();
 @(negedge clk_sys);sd_ack=0;status[16]=1;cycle();
 check(!bk_state,"current save finishes on request edge");
 @(negedge clk_sys);status[16]=0;
 await_start(1,"request on final acknowledge edge remains pending");finish_transfer();quiet(8,"final-edge request only once");
 check(starts==before_starts+2,"final-edge arrival dispatches exactly twice");

 $display("CASE cartridge start defeats same-edge stale request");
 fresh();before_starts=starts;
 @(negedge clk_sys);downloading=1;status[7]=1;cycle();
 check(!bk_state,"download blocks same-edge manual save");
 @(negedge clk_sys);status[7]=0;cycle();
 @(negedge clk_sys);bk_ena=0;downloading=0;cycle();
 @(negedge clk_sys);bk_ena=1;quiet(8,"download-coincident request cannot revive");
 check(starts==before_starts,"same-edge download request discarded");

 $display("CASE boot-load takes precedence over queued save");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;downloading=1;cycle();
 @(negedge clk_sys);downloading=0;status[7]=1;ss_machine_freeze=0;cycle();
 @(negedge clk_sys);status[7]=0;
 await_start(1,"boot-load wins queued save");
 finish_transfer();quiet(8,"boot-load consumes stale save request");
 check(starts==before_starts+1,"boot-load only once");

 $display("CASE new cartridge invalidates queued request");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;pulse(0);
 @(negedge clk_sys);downloading=1;cycle();
 @(negedge clk_sys);cycle();
 @(negedge clk_sys);bk_ena=0;downloading=0;cycle();
 @(negedge clk_sys);ss_machine_freeze=0;repeat(3)cycle();
 @(negedge clk_sys);bk_ena=1;quiet(10,"old cartridge request cannot persist");
 check(starts==before_starts,"new cartridge drops stale pending save");

 $display("CASE backup disable invalidates queued request");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;pulse(1);
 @(negedge clk_sys);bk_ena=0;repeat(3)cycle();
 @(negedge clk_sys);ss_machine_freeze=0;cycle();
 @(negedge clk_sys);bk_ena=1;quiet(10,"disabled backup queue stays cleared");
 check(starts==before_starts,"disabled backup drops stale pending load");
 $display("CASE download completion while frozen is retained once");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;
 complete_download();repeat(4)cycle();check(!bk_state,"frozen boot import cannot start early");
 @(negedge clk_sys);ss_machine_freeze=0;
 await_start(1,"frozen download completion imports after thaw");finish_transfer();quiet(8,"boot completion dispatches only once");
 check(starts==before_starts+1,"one real completion creates exactly one boot import");

 $display("CASE boot completion while transfer busy");
 fresh();before_starts=starts;pulse(0);await_start(0,"save before busy boot completion");
 complete_download();check(bk_state&&!bk_loading,"boot completion cannot redirect active save");
 finish_transfer();await_start(1,"busy boot import dispatches next");finish_transfer();quiet(8,"busy boot import exactly once");
 check(starts==before_starts+2,"busy boot import follows original operation");

 $display("CASE boot completion on final acknowledge edge");
 fresh();before_starts=starts;pulse(0);await_start(0,"save before final-edge boot import");
 while(sd_lba!=3)begin @(negedge clk_sys);sd_ack=1;cycle();@(negedge clk_sys);sd_ack=0;cycle();end
 @(negedge clk_sys);sd_ack=1;downloading=1;cycle();
 @(negedge clk_sys);sd_ack=0;downloading=0;cycle();check(!bk_state,"old save finishes on completion edge");
 await_start(1,"boot import survives final acknowledge edge");finish_transfer();quiet(8,"final-edge boot import once");
 check(starts==before_starts+2,"final-edge boot import creates two operations");

 $display("CASE repeated cartridge identities replace pending boot import");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;
 complete_download();complete_download();complete_download();
 repeat(3)cycle();@(negedge clk_sys);ss_machine_freeze=0;
 await_start(1,"only latest completed identity imports");finish_transfer();quiet(8,"old identities cannot replay boot import");
 check(starts==before_starts+1,"repeated downloads coalesce into latest boot import");

 $display("CASE unavailable cartridge invalidates pending boot import");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;complete_download();
 @(negedge clk_sys);downloading=1;bk_ena=0;cycle();
 @(negedge clk_sys);downloading=0;cycle();repeat(3)cycle();
 @(negedge clk_sys);ss_machine_freeze=0;bk_ena=1;quiet(10,"old boot import cannot survive unavailable new cartridge");
 check(starts==before_starts,"unavailable new cartridge clears pending boot");

 $display("CASE backing file removal clears pending boot import");
 fresh();before_starts=starts;@(negedge clk_sys);ss_machine_freeze=1;complete_download();
 @(negedge clk_sys);bk_ena=0;repeat(3)cycle();
 @(negedge clk_sys);bk_ena=1;ss_machine_freeze=0;quiet(10,"removed backing file cancels queued boot import");
 check(starts==before_starts,"availability loss clears pending boot");

 $display("CASE brief format pulse survives freeze without backing file");
 fresh();before_starts=starts;before_writes=format_writes;before_formats=format_runs;
 for(j=0;j<4;j=j+1)before_addr[j]=format_addr_writes[j];
 @(negedge clk_sys);bk_ena=0;ss_machine_freeze=1;format_pulse();repeat(4)cycle();
 check(defbram[3] && format_writes==before_writes,"format waits while frozen without SD backing");
 @(negedge clk_sys);ss_machine_freeze=0;
 await_format("queued no-file format begins after thaw");finish_format();quiet(8,"format without file does not issue SD work");
 check(format_writes==before_writes+8,"format writes exactly eight header word cycles");
 check(format_runs==before_formats+1,"short frozen format pulse dispatches once");
 check(starts==before_starts && !bk_pending,"format preserves inherited no-autosave dirty policy");
 for(j=0;j<4;j=j+1)check(format_addr_writes[j]==before_addr[j]+2 && format_mem[j]==defval[j],"all four header words written twice correctly");

 $display("CASE format pointer stalls at every position during freeze");
 for(k=0;k<8;k=k+1)begin
  fresh();before_writes=format_writes;
  @(negedge clk_sys);format=1;cycle();check(defbram==0,"format starts at zero");
  repeat(k)cycle();
  @(negedge clk_sys);format=0;ss_machine_freeze=1;save_pointer=defbram;
  repeat(5)cycle();
  check(defbram==save_pointer,"format pointer remains stable while host writes blocked");
  check(format_writes==before_writes+k,"freeze cannot skip or duplicate format writes");
  @(negedge clk_sys);ss_machine_freeze=0;finish_format();quiet(3,"finished format remains idle");
  check(format_writes==before_writes+8,"all eight writes resume across every pointer freeze");
 end

 $display("CASE held format request dispatches only once then rearms");
 fresh();before_writes=format_writes;before_formats=format_runs;
 @(negedge clk_sys);format=1;cycle();await_format("held format begins");finish_format();quiet(12,"held format does not restart");
 check(format_writes==before_writes+8 && format_runs==before_formats+1,"held request formats once");
 @(negedge clk_sys);format=0;cycle();format_pulse();await_format("new format edge rearms");finish_format();quiet(3,"second format completes");
 check(format_writes==before_writes+16 && format_runs==before_formats+2,"released then pressed format starts again");

 $display("CASE format waits for active SD and precedes queued manual save");
 fresh();before_starts=starts;before_writes=format_writes;
 pulse(1);await_start(1,"load before queued format");format_pulse();pulse(0);
 check(defbram[3] && format_writes==before_writes,"format cannot write during SD load");
 finish_transfer();await_format("queued format follows active load before manual save");
 check(!bk_state,"queued manual save waits for format");finish_format();
 await_start(0,"manual save starts after complete format");finish_transfer();quiet(8,"format/save priority dispatches once");
 check(format_writes==before_writes+8 && starts==before_starts+2,"SD format SD ordering is exact");

 $display("CASE queued boot outranks format and consumes stale manual request");
 fresh();before_starts=starts;before_writes=format_writes;
 @(negedge clk_sys);ss_machine_freeze=1;complete_download();format_pulse();pulse(0);
 @(negedge clk_sys);ss_machine_freeze=0;await_start(1,"boot import wins format and queued save");
 check(defbram[3] && format_writes==before_writes,"format cannot precede boot import");
 finish_transfer();await_format("format follows boot import");finish_format();quiet(10,"boot consumes stale manual save but preserves format");
 check(starts==before_starts+1 && format_writes==before_writes+8,"boot format priority exact");

 $display("CASE format holds pending boot until all header writes complete");
 fresh();before_starts=starts;before_writes=format_writes;
 @(negedge clk_sys);format=1;cycle();@(negedge clk_sys);format=0;
 complete_download();check(!bk_state && !defbram[3],"boot cannot overlap already active format");
 finish_format();await_start(1,"boot follows active format completion");finish_transfer();quiet(8,"post-format boot once");
 check(starts==before_starts+1 && format_writes==before_writes+8,"active format finishes before boot");

 $display("CASE new cartridge clears old pending format request");
 fresh();before_writes=format_writes;before_formats=format_runs;
 @(negedge clk_sys);ss_machine_freeze=1;format_pulse();bk_ena=0;complete_download();
 @(negedge clk_sys);ss_machine_freeze=0;quiet(12,"old format request cannot carry across identity");
 check(defbram[3] && format_writes==before_writes && format_runs==before_formats,"new cartridge cancels pending format");

 $display("CASE format request coincident with new cartridge is discarded");
 fresh();before_writes=format_writes;
 @(negedge clk_sys);format=1;downloading=1;bk_ena=0;cycle();
 @(negedge clk_sys);format=0;downloading=0;cycle();quiet(10,"download wins same-edge format");
 check(defbram[3] && format_writes==before_writes,"format pulse during download is not replayed");
 $display("CASE snapshot backend and display-only busy serialize all new work");
 for(k=0;k<2;k=k+1)begin
  for(j=0;j<5;j=j+1)begin
   fresh();before_starts=starts;before_writes=format_writes;
   @(negedge clk_sys);ss_backend_busy=(k==0);ss_video_busy=(k==1);
   case(j)
    0:pulse(0);
    1:pulse(1);
    2:begin mark_dirty();@(negedge clk_sys);OSD_STATUS=1;status[23]=1;cycle();end
    3:format_pulse();
    4:complete_download();
   endcase
   repeat(8)cycle();
   check(!bk_state && !sd_rd && !sd_wr && defbram[3] && format_writes==before_writes,"new backup/format work waits for complete snapshot or video busy");
   @(negedge clk_sys);ss_backend_busy=0;ss_video_busy=0;
   if(j==3)begin
    await_format("format survives backend/display-only busy");finish_format();
    check(format_writes==before_writes+8 && starts==before_starts,"busy format performs exactly eight writes without SD");
   end else begin
    await_start(j==1||j==4,"queued SD work dispatches when backend and display are idle");finish_transfer();
    check(starts==before_starts+1,"busy queued backup dispatches exactly once");
   end
   quiet(8,"busy queued work cannot duplicate");
  end
 end

 $display("CASE backend-to-video busy handoff does not expose dispatch gap");
 fresh();before_starts=starts;@(negedge clk_sys);ss_backend_busy=1;pulse(0);
 @(negedge clk_sys);ss_backend_busy=0;ss_video_busy=1;
 quiet(8,"postflush keeps queued backup blocked after backend drain");
 @(negedge clk_sys);ss_video_busy=0;await_start(0,"backup dispatches after postflush");finish_transfer();quiet(8,"postflush handoff dispatches once");
 check(starts==before_starts+1,"busy handoff retains one request");

 $display("PASS tb_backup_freeze_edges: %0d checks",checks);$finish;
end
initial begin #5000000;$fatal(1,"WATCHDOG battery backup edges");end
endmodule
'''
def run_case(src, dest):
    dest.mkdir(parents=True, exist_ok=True)
    text, dirty, block, host, sampler = production_blocks(src)
    bench = dest / 'tb_backup_freeze_edges.sv'
    bench.write_text(pre + '\nalways @(posedge clk_sys) begin\n' + sampler + '\nend\n' + dirty + block + host + post)
    (dest / 'source_hashes.json').write_text(json.dumps({
        'source': str(src), 'sha256': hashlib.sha256(text.encode()).hexdigest(),
        'dirty_block': hashlib.sha256(dirty.encode()).hexdigest(),
        'request_block': hashlib.sha256(block.encode()).hexdigest(),
        'host_port': hashlib.sha256(host.encode()).hexdigest(),
        'download_sampler': sampler.strip()
    }, indent=2) + '\n')
    result = subprocess.run([args.iverilog, '-g2012', '-s', 'tb_backup_freeze_edges',
                             '-o', str(dest / 'test.vvp'), str(bench)],
                            capture_output=True, text=True, timeout=30)
    (dest / 'compile.log').write_text(result.stdout + result.stderr)
    result.check_returncode()
    result = subprocess.run([args.vvp, str(dest / 'test.vvp')],
                            capture_output=True, text=True, timeout=30)
    log = result.stdout + result.stderr
    (dest / 'run.log').write_text(log)
    print(log, end='')
    return result, log

def run_backend_collisions(src, dest, expect_failure=False):
    dest.mkdir(parents=True, exist_ok=True)
    text, dirty, block, host, sampler = production_blocks(src)
    a = text.index('reg [3:0] ss_restore_warm_count = 0;')
    b = text.index('video_phase_align video_phase_align(', a)
    warm = text[a:b]
    collision = (source.parent / 'tests/tb_backup_backend_collision.sv.in').read_text()
    collision = collision.replace('// INSERT_PRODUCTION_WARM', warm)
    fixture = pre.replace('ss_machine_freeze=0,', '').replace(
        'reg ss_backend_busy=0,ss_video_busy=0;', 'wire ss_backend_busy;reg ss_video_busy=0;')
    bench = dest / 'tb_backup_backend_collision.sv'
    bench.write_text(fixture + '\nalways @(posedge clk_sys) begin\n' + sampler + '\nend\n' + dirty + block + host + collision)
    rtl = [source.parent / 'rtl' / (name + '.sv') for name in
           ('ninja_savestate', 'word_scan_pack_engine', 'adpcm_pack_engine', 'cd_ram_pack_engine')]
    pinned = {str(f): hashlib.sha256(f.read_bytes()).hexdigest() for f in [src, *rtl]}
    (dest / 'source_hashes.json').write_text(json.dumps(pinned, indent=2) + '\n')
    compiled = subprocess.run([args.iverilog, '-g2012', '-s', 'tb_backup_freeze_edges',
                               '-o', str(dest / 'test.vvp'), str(bench), *map(str, rtl)],
                              capture_output=True, text=True, timeout=30)
    (dest / 'compile.log').write_text(compiled.stdout + compiled.stderr)
    compiled.check_returncode()
    for mode in range(3 if expect_failure else 5):
        result = subprocess.run([args.vvp, str(dest / 'test.vvp'), '+MODE=' + str(mode)],
                                capture_output=True, text=True, timeout=30)
        log = result.stdout + result.stderr
        (dest / ('case' + str(mode) + '.log')).write_text(log)
        print(log, end='')
        if expect_failure:
            if result.returncode == 0 or 'snapshot freeze and backup/format dispatch overlap' not in log:
                raise RuntimeError('Real backend collision negative control did not fail as intended')
        else:
            result.check_returncode()
            if 'PASS real backend' not in log:
                raise RuntimeError('Real backend collision fixture did not report PASS')
    if pinned != {str(f): hashlib.sha256(f.read_bytes()).hexdigest() for f in [src, *rtl]}:
        raise RuntimeError('RTL changed during real-backend collision tests')
    print('PASS real backend collision ' + ('negative controls' if expect_failure else 'suite: 5 cases'))

result, log = run_case(source, out)
result.check_returncode()
if 'PASS tb_backup_freeze_edges:' not in log:
    raise RuntimeError('Backup regression did not report successful completion')
run_backend_collisions(source, out / 'real_backend_collisions')
if args.baseline_source:
    baseline = args.baseline_source
    if baseline.is_dir():
        baseline = baseline / 'TurboGrafx16.sv'
    result, log = run_case(baseline, out / 'negative_control')
    if result.returncode == 0 or 'CHECK 4: queued autosave begins after thaw' not in log:
        raise RuntimeError('Pre-fix baseline did not fail the intended autosave assertion')
    print('PASS negative control: pre-fix source fails queued autosave after thaw')

if args.boundary_negative_controls:
    original = source.read_text()
    mutations = (
        ('dispatch_during_backend_busy', '!bk_state && !ss_machine_freeze && !ss_backend_busy && !ss_video_busy && defbram[3]', '!bk_state && !ss_machine_freeze && defbram[3]',
         'new backup/format work waits for complete snapshot or video busy'),
        ('lost_boot_edge', '\t\tif(old_downloading) bk_req_boot <= 1;', '',
         'frozen download completion imports after thaw'),
        ('lost_format_edge', '\tif(!downloading && !old_format && format) bk_req_format <= 1;', '',
         'queued no-file format begins after thaw'),
        ('format_skips_frozen_writes', 'if(~defbram[3] && !ss_machine_freeze && !bk_state)', 'if(~defbram[3])',
         'format pointer remains stable while host writes blocked'),
    )
    for name, before, after, expected in mutations:
        if original.count(before) != 1:
            raise RuntimeError('Mutation target missing or ambiguous: ' + name)
        dest = out / 'boundary_negative_controls' / name
        dest.mkdir(parents=True, exist_ok=True)
        mutant = dest / 'mutant_top.sv'
        mutant.write_text(original.replace(before, after))
        result, log = run_case(mutant, dest)
        if result.returncode == 0 or expected not in log or 'FATAL:' not in log:
            raise RuntimeError('Boundary mutant did not fail the intended assertion: ' + name)
        print('PASS negative control:', name, 'fails', expected)
        if name == 'dispatch_during_backend_busy':
            run_backend_collisions(mutant, dest / 'real_backend_collisions', expect_failure=True)
    if source.read_text() != original:
        raise RuntimeError('Production source changed during boundary controls')
