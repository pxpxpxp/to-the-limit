#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:?Usage: run_fullimage_tests.sh OUTPUT_DIRECTORY [BASELINE_SLOT0_IMAGE]}
mkdir -p "$OUT"; OUT=$(cd "$OUT" && pwd)
python3 "$ROOT/tests/run_rewind_tests.py" --output-dir "$OUT/rewind" > "$OUT/rewind.log" 2>&1
python3 - "$OUT/rewind" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=(p/'tb_rewind_top.sv').read_text()
s=s.replace('defparam rewind_history.CAPTURE_FRAMES=3;', '// No cadence override.')
s=s.replace('defparam rewind_history.REWIND_FRAMES=2;', '// No cadence override.')
s=s.replace('guard<12', 'guard<40')
(p/'tb_rewind_top_production_cadence.sv').write_text(s)
PY
iverilog -g2012 -s tb_rewind_top -o "$OUT/rewind/production_cadence" "$ROOT/rtl/rewind_history.sv" "$OUT/rewind/tb_rewind_top_production_cadence.sv"
vvp "$OUT/rewind/production_cadence" > "$OUT/rewind/production_cadence.log"
python3 "$ROOT/tests/run_backup_freeze.py" --output-dir "$OUT/backup_freeze" --boundary-negative-controls > "$OUT/backup_freeze.log" 2>&1
bash "$ROOT/tests/run_compact_cd.sh" "$OUT/cd_profiles" > "$OUT/cd_profiles.log" 2>&1
RTL=("$ROOT/rtl/ninja_savestate.sv" "$ROOT/rtl/word_scan_pack_engine.sv" "$ROOT/rtl/adpcm_pack_engine.sv" "$ROOT/rtl/cd_ram_pack_engine.sv")
cd "$OUT"
for test in tb_fullimage_snapshot_backend tb_fullimage_snapshot_full; do
  iverilog -g2012 -s "$test" -o "$test" "$ROOT/tests/$test.sv" "${RTL[@]}" > "$test.compile.log" 2>&1
  timeout 300 vvp "$test" > "$test.log" 2>&1
  grep PASS "$test.log"
done
mkdir -p manual_verified; cd manual_verified
iverilog -g2012 -s tb_fullimage_manual -o full_manual "$ROOT/tests/tb_fullimage_manual.sv" "${RTL[@]}" > compile.log 2>&1
for part in {0..11}; do
 timeout 300 vvp full_manual +PART=$part > "part.$part.log" 2>&1
 grep PASS "part.$part.log"
done
if [[ $# -gt 1 ]]; then
 cmp slot0.ss "$2"
 printf '%s\n' 'PASS: full-image mode manual image is byte-identical to supplied baseline' > compare.log
fi
