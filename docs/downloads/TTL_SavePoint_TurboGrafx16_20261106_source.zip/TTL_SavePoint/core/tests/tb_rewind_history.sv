`timescale 1ns/1ps
// Standalone scheduler contract regression. No external state/backend model.
// Run: iverilog -g2012 -s tb_rewind_history -o /tmp/rewind_history_test \
//        rtl/rewind_history.sv tests/tb_rewind_history.sv && vvp /tmp/rewind_history_test
module tb_rewind_history;
    localparam SLOT_BITS = 2;
    localparam CAPTURE_FRAMES = 3;
    localparam REWIND_FRAMES = 2;
    reg clk = 0;
    always #5 clk = ~clk;
    reg reset = 1, enabled = 0, frame_tick = 0;
    reg rewind_held = 0, osd_open = 0, manual_request = 0;
    reg backend_busy = 0, backend_accept = 0, backend_done = 0, backend_failed = 0;
    wire save_request, load_request, private_mode, held_active;
    wire [SLOT_BITS-1:0] private_slot;
    wire [SLOT_BITS:0] count;
    integer checks = 0;
    integer i;

    rewind_history #(.SLOT_BITS(SLOT_BITS), .CAPTURE_FRAMES(CAPTURE_FRAMES),
        .REWIND_FRAMES(REWIND_FRAMES)) dut (
        .clk(clk), .reset(reset), .enabled(enabled), .frame_tick(frame_tick),
        .rewind_held(rewind_held), .osd_open(osd_open), .manual_request(manual_request),
        .backend_busy(backend_busy), .backend_accept(backend_accept),
        .backend_done(backend_done), .backend_failed(backend_failed),
        .save_request(save_request), .load_request(load_request),
        .private_mode(private_mode), .private_slot(private_slot),
        .count(count), .held_active(held_active)
    );

    initial begin
        #200000;
        $fatal(1, "WATCHDOG: scheduler regression stalled");
    end

    task cycle;
        begin @(posedge clk); #1; end
    endtask
    task check(input bit ok, input string description);
        begin
            checks = checks + 1;
            if (!ok) $fatal(1, "CHECK %0d FAILED at %0t: %s (count=%0d slot=%0d save=%b load=%b private=%b)",
                checks, $time, description, count, private_slot, save_request, load_request, private_mode);
        end
    endtask
    task frame;
        begin frame_tick = 1; cycle(); frame_tick = 0; cycle(); end
    endtask
    task frames(input integer n);
        integer j;
        begin for (j=0; j<n; j=j+1) frame(); end
    endtask
    task no_requests(input integer n);
        integer j;
        begin
            for (j=0; j<n; j=j+1) begin
                frame();
                check(!save_request && !load_request, "unexpected backend request");
            end
        end
    endtask
    task fresh;
        begin
            reset=1; enabled=0; frame_tick=0; rewind_held=0; osd_open=0;
            manual_request=0; backend_busy=0; backend_accept=0; backend_done=0; backend_failed=0;
            repeat (4) cycle();
            reset=0; enabled=1;
            repeat (3) cycle();
            check(count == 0 && !save_request && !load_request, "reset clears history and requests");
        end
    endtask
    task wait_request(input bit want_load, input integer expected_slot);
        integer ticks;
        begin
            ticks=0;
            while (!(save_request || load_request) && ticks<20) begin
                frame(); ticks=ticks+1;
            end
            check(save_request || load_request, "request arrives within bounded frame count");
            check(load_request == want_load && save_request == !want_load, "correct operation requested");
            check(private_mode, "private request owns private backend address");
            check(private_slot == expected_slot, "request uses expected ring slot");
        end
    endtask
    task accept_request;
        reg [SLOT_BITS-1:0] slot;
        reg saving, loading;
        integer j;
        begin
            slot=private_slot; saving=save_request; loading=load_request;
            for (j=0; j<3; j=j+1) begin
                cycle();
                check(private_slot == slot && private_mode && save_request == saving && load_request == loading,
                    "pending request and address remain stable until accept");
            end
            backend_busy=1; backend_accept=1; cycle(); backend_accept=0; cycle();
            check(!save_request && !load_request, "accept deasserts request strobes");
            check(private_mode && private_slot == slot, "accepted operation retains private owner and slot");
        end
    endtask
    task finish_request(input bit fail);
        begin
            repeat (3) cycle();
            backend_failed=fail; backend_done=!fail; cycle();
            backend_failed=0; backend_done=0;
            // Busy may outlive the completion pulse. Never launch another op in this tail.
            repeat (2) begin
                cycle();
                check(!save_request && !load_request, "no request in backend completion tail");
            end
            backend_busy=0;
            repeat (4) cycle();
        end
    endtask
    task capture(input integer slot, input integer expected_count);
        begin
            wait_request(0,slot); accept_request(); finish_request(0);
            check(count == expected_count, "successful capture commits history count");
        end
    endtask
    task load_snapshot(input integer slot, input integer expected_count);
        begin
            wait_request(1,slot); accept_request(); finish_request(0);
            check(count == expected_count, "successful rewind pops newest or retains oldest snapshot");
        end
    endtask

    // Structural invariants checked for the entire simulation.
    always @(negedge clk) begin
        if (!reset) begin
            if (save_request && load_request) $fatal(1,"simultaneous save/load requests");
            if ((save_request || load_request) && !private_mode) $fatal(1,"request without private mode");
            if (count > (1 << SLOT_BITS)) $fatal(1,"history count overflow");
        end
    end

    initial begin
        $display("CASE capture cadence and idle clocks");
        fresh();
        repeat (20) cycle();
        check(!save_request, "clock cycles without frame tick do not capture");
        no_requests(CAPTURE_FRAMES-1);
        frame();
        check(save_request && !load_request, "capture occurs exactly at configured frame interval");
        check(count == 0, "pending save is not committed history");
        accept_request(); finish_request(0);
        check(count == 1, "first successful save commits one snapshot");

        $display("CASE partial history, reverse order, exhaustion, branch capture");
        capture(1,2); capture(2,3);
        rewind_held=1;
        load_snapshot(2,2); load_snapshot(1,1); load_snapshot(0,1);
        load_snapshot(0,1); load_snapshot(0,1);
        check(count == 1, "repeated oldest restore does not underflow");
        check(held_active, "oldest snapshot remains available while held");
        rewind_held=0; cycle(); cycle();
        check(!held_active, "release resumes guest");
        capture(1,2);

        $display("CASE wraparound and full capacity newest-first");
        fresh();
        for (i=0; i<7; i=i+1) capture(i%4, i<4 ? i+1 : 4);
        rewind_held=1;
        load_snapshot(2,3); load_snapshot(1,2); load_snapshot(0,1); load_snapshot(3,1);
        load_snapshot(3,1); load_snapshot(3,1);

        $display("CASE stepped restore cadence");
        fresh(); capture(0,1); capture(1,2); rewind_held=1;
        load_snapshot(1,1);
        no_requests(REWIND_FRAMES-1);
        frame();
        check(load_request && !save_request, "next restore occurs at configured realtime frame interval");
        check(private_slot == 0, "cadenced restore targets oldest slot");
        accept_request(); finish_request(0);
        check(count == 1, "cadenced oldest restore preserves oldest");

        $display("CASE failed overwrite invalidates all history");
        fresh();
        for (i=0; i<4; i=i+1) capture(i, i+1);
        wait_request(0,0); accept_request(); finish_request(1);
        check(count == 0, "failed overwrite cannot expose corrupted old history");
        rewind_held=1; no_requests(8);

        $display("CASE failed load invalidates history");
        fresh(); capture(0,1); capture(1,2);
        rewind_held=1; wait_request(1,1); accept_request(); finish_request(1);
        check(count == 0, "failed load invalidates history");
        no_requests(8);

        $display("CASE held rewind on empty history");
        fresh(); rewind_held=1;
        no_requests(12);
        check(count == 0, "empty rewind never invents history");
        check(!held_active, "empty history does not activate rewind");
        rewind_held=0; cycle(); capture(0,1);

        $display("CASE OSD suspends capture and rewind");
        fresh(); osd_open=1; no_requests(12);
        osd_open=0; capture(0,1); capture(1,2);
        osd_open=1; rewind_held=1; no_requests(12);
        check(count == 2, "OSD preserves captured history");
        osd_open=0; load_snapshot(1,1);

        $display("CASE OSD cancels pending but retains accepted operation identity");
        fresh(); wait_request(0,0); osd_open=1; cycle(); cycle();
        check(!save_request && !load_request && !private_mode, "OSD cancels unaccepted request");
        no_requests(5); osd_open=0; wait_request(0,0); accept_request();
        osd_open=1; cycle();
        check(private_mode && private_slot == 0, "OSD preserves accepted private operation identity");
        finish_request(0); check(count == 1, "OSD permits accepted save to finish");
        no_requests(5);

        $display("CASE unrelated backend busy suppresses capture");
        fresh(); backend_busy=1; no_requests(12);
        backend_busy=0; capture(0,1);

        $display("CASE manual request wins at capture boundary");
        fresh(); capture(0,1);
        manual_request=1; no_requests(6);
        check(count == 0, "manual state operation invalidates private history");
        manual_request=0; capture(0,1);

        $display("CASE manual request cancels unaccepted private request");
        fresh(); wait_request(0,0);
        manual_request=1; cycle(); cycle();
        check(!save_request && !load_request, "manual request cancels unaccepted private work");
        check(!private_mode && count == 0, "manual operation does not inherit stale private address");
        manual_request=0; capture(0,1);

        $display("CASE manual request during accepted operation drains privately");
        fresh(); capture(0,1); wait_request(0,1); accept_request();
        manual_request=1; cycle();
        check(private_mode && private_slot == 1, "manual interrupt cannot redirect accepted private write");
        check(count == 0, "manual interrupt invalidates history immediately");
        finish_request(0);
        check(count == 0, "interrupted completion cannot revive invalid history");
        no_requests(4); manual_request=0; capture(0,1);

        $display("CASE disable cancels pending operation");
        fresh(); wait_request(0,0); enabled=0; cycle(); cycle();
        check(!save_request && !load_request && count == 0, "disable discards pending private request");
        no_requests(5); enabled=1; capture(0,1);

        $display("CASE disable during accepted operation drains and cannot recommit");
        fresh(); wait_request(0,0); accept_request(); enabled=0; cycle();
        check(private_mode, "disable retains private address while backend is busy");
        enabled=1; no_requests(5);
        finish_request(0);
        check(count == 0, "disabled in-flight operation is never committed");
        capture(0,1);

        $display("CASE acceptance wins cancellation reporting race");
        fresh(); wait_request(0,0);
        // Accept is registered by the backend at its previous consuming edge.
        // A newly arriving manual request must not redirect that transfer.
        backend_busy=1; backend_accept=1; manual_request=1; cycle();
        backend_accept=0; cycle();
        check(private_mode && private_slot==0, "accepted cancellation race retains private owner");
        check(!save_request && !load_request && count==0, "accepted cancellation race invalidates history");
        manual_request=0; finish_request(0);
        check(count==0, "cancelled accepted completion is not committed");
        capture(0,1);

        $display("CASE releasing rewind cancels pending load but drains accepted load");
        fresh(); capture(0,1); capture(1,2);
        rewind_held=1; wait_request(1,1); rewind_held=0; cycle(); cycle();
        check(!load_request && !private_mode && count==2, "release cancels an unaccepted rewind without popping");
        rewind_held=1; wait_request(1,1); accept_request(); rewind_held=0; cycle();
        check(private_mode && !held_active, "release retains accepted operation ownership but stops held mode");
        finish_request(0); check(count==1, "accepted restore completes and pops even after release");
        capture(1,2);

        $display("CASE reset during pending operation");
        fresh(); wait_request(0,0); reset=1; cycle(); cycle(); reset=0;
        check(count == 0 && !save_request && !load_request, "reset cancels pending work");
        capture(0,1);

        $display("CASE reset during accepted operation");
        fresh(); wait_request(0,0); accept_request(); reset=1; cycle();
        check(!save_request && !load_request && count == 0, "reset clears control state during accepted work");
        reset=0; no_requests(5); finish_request(0);
        check(count == 0, "reset in-flight completion cannot revive old history");
        capture(0,1);

        $display("PASS tb_rewind_history: %0d checks", checks);
        $finish;
    end
endmodule
