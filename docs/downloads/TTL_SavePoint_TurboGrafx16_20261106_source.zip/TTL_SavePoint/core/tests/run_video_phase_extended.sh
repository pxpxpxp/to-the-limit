#!/usr/bin/env bash
set -euo pipefail
SOURCE=$(cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:?Usage: run_video_phase_extended.sh NEW_OUTPUT_DIRECTORY}
mkdir -p "$OUT";OUT=$(cd "$OUT" && pwd);cd "$OUT"
sources=("$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/huc6260.vhd" "$SOURCE/rtl/pce_top.vhd" "$SOURCE/TurboGrafx16.sv"
 "$SOURCE/sys/video_mixer.sv" "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv"
 "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/tests/tb_video_phase_extended.sv" "$SOURCE/tests/run_video_phase_extended.sh")
sha256sum "${sources[@]}" > source_sha256.txt
ghdl -a --std=08 -fsynopsys "$SOURCE/tests/models/dpram_model.vhd" "$SOURCE/rtl/huc6260.vhd" > vce_analyze.log 2>&1
ghdl --synth --std=08 -fsynopsys --out=verilog huc6260 > huc6260_actual.v 2> vce_synth.log
iverilog -g2012 -s tb_video_phase_extended -o extended.vvp "$SOURCE/tests/tb_video_phase_extended.sv" huc6260_actual.v \
 "$SOURCE/rtl/video_phase_align.sv" "$SOURCE/rtl/color_mix.sv" "$SOURCE/sys/gamma_corr.sv" "$SOURCE/sys/video_freezer.sv" "$SOURCE/sys/video_mixer.sv" > extended_compile.log 2>&1
pids=()
for scenario in 10 11 12 13; do
  echo "Running extended actual VCE/native pipeline scenario $scenario"
  timeout 1800 vvp extended.vvp +SCENARIO="$scenario" > "extended.$scenario.log" &
  pids+=("$!")
done
status=0
for index in 0 1 2 3; do
  wait "${pids[$index]}" || status=1
  cat "extended.$((10+index)).log"
done
sha256sum "${sources[@]}" > source_sha256_after.txt
cmp source_sha256.txt source_sha256_after.txt
[[ "$status" == 0 ]]
