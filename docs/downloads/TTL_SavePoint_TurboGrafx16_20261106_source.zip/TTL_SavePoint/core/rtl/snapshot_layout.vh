localparam integer SS_REGISTER_WORDS = 681;
localparam [63:0] SS_SCHEMA = 64'h7b4a4831e0d369a8;
