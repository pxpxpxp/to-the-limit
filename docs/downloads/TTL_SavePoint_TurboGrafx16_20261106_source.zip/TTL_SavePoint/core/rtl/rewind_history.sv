// Volatile HuCard rewind history. Owns no external memory and never touches SD.
// The common snapshot backend serializes all private/manual transfers. Pointer
// changes require its explicit, fully drained completion, never sticky valid.
module rewind_history #(
 parameter integer SLOT_BITS=7,
 parameter integer CAPTURE_FRAMES=15,
 parameter integer REWIND_FRAMES=4
)(
 input wire clk,reset,enabled,frame_tick,rewind_held,osd_open,manual_request,
 input wire backend_busy,backend_accept,backend_done,backend_failed,
 output wire save_request,load_request,private_mode,
 output reg [SLOT_BITS-1:0] private_slot=0,
 output reg [SLOT_BITS:0] count=0,
 output wire held_active
);
 localparam integer CAP_BITS=(CAPTURE_FRAMES>1)?$clog2(CAPTURE_FRAMES+1):1;
 localparam integer REW_BITS=(REWIND_FRAMES>1)?$clog2(REWIND_FRAMES+1):1;
 localparam [1:0] IDLE=0,REQUEST=1,INFLIGHT=2;
 reg [1:0] state=IDLE;
 reg loading=0,invalidated=0,old_held=0;
 reg [SLOT_BITS-1:0] head=0;
 reg [CAP_BITS-1:0] capture_count=0;
 reg [REW_BITS-1:0] rewind_wait=0;
 assign private_mode=(state!=IDLE);
 assign save_request=(state==REQUEST)&&!loading&&enabled&&!osd_open&&!manual_request;
 assign load_request=(state==REQUEST)&&loading&&rewind_held&&enabled&&!osd_open&&!manual_request;
 // This is not a machine-freeze signal: run between restores so the restored
 // video frame can reach HDMI/analog. At the oldest point reload that snapshot
 // periodically, rather than underflowing or running forward indefinitely.
 assign held_active=enabled&&rewind_held&&((count!=0)||private_mode);
 always @(posedge clk) begin
  old_held<=rewind_held;
  if(reset) begin
   state<=IDLE;head<=0;count<=0;private_slot<=0;loading<=0;
   capture_count<=0;rewind_wait<=0;invalidated<=0;old_held<=0;
  end else begin
   if(!enabled||manual_request) begin
    count<=0;head<=0;capture_count<=0;rewind_wait<=0;
   end
   case(state)
    IDLE: begin
     invalidated<=0;
     if(!rewind_held) rewind_wait<=0;
     if(enabled&&!manual_request&&!osd_open&&!backend_busy) begin
      if(rewind_held) begin
       capture_count<=0;
       if(count!=0 && (rewind_wait==0 || !old_held)) begin
        private_slot<=head-1'b1;loading<=1;state<=REQUEST;
       end else if(frame_tick && rewind_wait!=0) rewind_wait<=rewind_wait-1'b1;
      end else if(frame_tick) begin
       if(capture_count==CAPTURE_FRAMES-1) begin
        private_slot<=head;loading<=0;state<=REQUEST;capture_count<=0;
       end else capture_count<=capture_count+1'b1;
      end
     end
    end
    REQUEST: begin
     // Acceptance precedes cancellation: it reports the previous consuming
     // edge, so an already accepted transaction must retain its ownership.
     if(backend_accept) begin
      state<=INFLIGHT;invalidated<=!enabled||manual_request;
     end else if(!enabled||manual_request||osd_open||(loading&&!rewind_held)) begin
      state<=IDLE;capture_count<=0;rewind_wait<=0;
     end
    end
    INFLIGHT: begin
     if(!enabled||manual_request) invalidated<=1;
     if(backend_failed) begin
      count<=0;head<=0;state<=IDLE;capture_count<=0;rewind_wait<=0;
     end else if(backend_done) begin
      state<=IDLE;capture_count<=0;rewind_wait<=REWIND_FRAMES;
      if(!invalidated&&enabled&&!manual_request) begin
       if(loading) begin
        if(count>1) begin head<=private_slot;count<=count-1'b1;end
       end else begin
        head<=head+1'b1;
        if(count<(1<<SLOT_BITS)) count<=count+1'b1;
       end
      end
     end
    end
    default: begin state<=IDLE;count<=0;head<=0;end
   endcase
  end
 end
endmodule
