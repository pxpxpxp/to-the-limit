# Extended video-phase validation

## Status and scope

The four additional actual-VCE/native-video scenarios passed without changing production RTL. The extended runner verified identical input fingerprints before and after the run. These tests supplement `VIDEO_PHASE_FIX.md`; they do not certify a PVM, adapter, full game, or FPGA timing closure.

The actual `huc6260.vhd` is synthesized with GHDL and run with production `video_phase_align`, `color_mix`, `gamma_corr`, and `video_mixer` RTL. Palette memory uses the existing behavioral RAM model. The native video path is selected; the unused scandoubler output is a test stub.

RVBL=1 is the actual reduced-vertical-blank input used by the user-facing 240-line setting. The VCE itself uses a 19-line top blank and 242 active lines in that configuration. This bench does not instantiate any later 240-line crop.

## Added conditions

Coordinates below are `(vertical counter, horizontal counter)` in system-clock units. A line is 2,730 system clocks. The additional hold counts occur after the VCE snapshot scan; they are not the entire freeze interval or measured backend transfer latency.

| Case | RVBL | Saved mode → live mode before load | Capture position | Load-request position | Additional save / load hold clocks |
|---|---:|---|---|---|---:|
| 10 | 1 | DOTCLOCK 3 / 263 lines → DOTCLOCK 0 / 262 lines | (262, 2728) | (0, 0) | 0 / 1 |
| 11 | 1 | DOTCLOCK 3 / 262 lines → DOTCLOCK 1 / 263 lines | (0, 0) | (262, 2728) | 718009 / 1436017 |
| 12 | 1 | DOTCLOCK 0 / 262 lines → DOTCLOCK 3 / 262 lines | (19, 46) | (3, 238) | 2723 / 2743 |
| 13 | 0 | DOTCLOCK 3 / 263 lines → DOTCLOCK 2 / 262 lines | (3, 0) | (261, 2729) | 20 / 1048 |

This exercises field start/end, the last clocks of a line, horizontal sync assertion/deassertion, vertical sync boundaries, the RVBL=1 active-area boundary, both field geometries, and very short through multi-field holds. Mode changes are programmed through the actual VCE control interface. Each restored 52-bit presentation state must exactly match its captured image.

## Results

- 12,924,023 additional live VCE comparisons passed.
- Eight additional phase-aligned resumes passed.
- 7,640 raw line periods and 29 raw fields were observed without any raw horizontal/vertical period or sync-width error.
- Native horizontal sync pulse-width error was zero in all four cases.
- Native line/field period sampling changes were at most 32 video clocks, about 0.3725 us.
- Changing pixel-clock mode during vertical sync produced a native vertical-pulse sampling shift of 32 video clocks in case 10 and 16 in case 11. Raw vertical pulse width remained exact. The original three scenarios had zero native vertical-pulse-width error; that result should not be generalized beyond those scenarios.
- No unexpected timeout, lost restored phase, or RGB-unblanking failure occurred.

The long-hold case intentionally kept the request asserted for more than one/two fields. Its measured guest pauses were approximately 33.30 ms for save and 50.02 ms for load, with the existing additional two-line display hold. These are synthetic stress conditions, not compact or full-image backend benchmarks.

Case 10 used a very short request after scanning but changed field geometry at a difficult boundary. Its load still waited about 33.37 ms to resume at a legal matching phase. This reinforces that alignment delay depends on both geometry and saved/current beam position, not only transfer length.

## Reproduce and evidence

Run `source/tests/run_video_phase_extended.sh NEW_OUTPUT_DIRECTORY` with the documented GHDL/Icarus toolchain available on PATH.

- Test: `source/tests/tb_video_phase_extended.sv`
- Summary: `validation/video_phase_extended_suite.log`
- Per-case logs, synthesized VCE, compile logs, and before/after fingerprints: `validation/video_phase_extended/`

## Coincident clock-edge result

`source/tests/run_video_phase_clock_edges.sh` also passed. It shifts only the testbench system-clock origin so system rising edges coincide with video rising edges while retaining the 2:1 clock ratio, then repeats case 10 against the same production RTL.

This added 3,589,942 live comparisons, two aligned resumes, 2,103 raw line periods, and eight raw fields. Raw sync again remained exact. Native horizontal pulse-width error was zero; line/field period and vertical pulse-width sampling shifts remained at most 32 video clocks. Source fingerprints were unchanged during the run.

Evidence: `validation/video_phase_clock_edges_suite.log` and `validation/video_phase_clock_edges/`. The generated bench and its hash are preserved there. This digital clock-phase check does not replace FPGA setup/hold analysis or physical clock-domain timing validation.
