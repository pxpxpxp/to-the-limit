# Building

## Toolchain

Use Intel Quartus Prime Lite **23.1std.0 Build 991**, with Cyclone V device support. Project/revision: `TurboGrafx16`; device: `5CSEBA6U23I7`; fitter seed: **37**. The frozen date is `261112`. The toolchain and proprietary simulation models are not bundled.

Python 3 is required for the included integrity and build helpers. On Linux or another suitable Quartus host:

1. Extract the archive into a writable folder.
2. Run `python3 scripts/verify.py` to verify the package.
3. Put the intended Quartus `bin` directory on PATH.
4. Run `python3 scripts/build.py /path/to/new-build-directory`.

The helper refuses an existing destination, copies only the frozen source files, and verifies them before and after every stage. It runs, in order:

```
quartus_map --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
quartus_fit --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
quartus_asm --read_settings_files=on --write_settings_files=off TurboGrafx16 -c TurboGrafx16
```

The RBF is `output_files/TurboGrafx16.rbf` in the new build directory. Logs are retained beside it. Compilation does **not** constitute timing approval.

Do not use the GUI full-compile command or `quartus_sh --flow compile` to reproduce these frozen inputs: the project's pre-flow hook can rewrite `build_id.v` to today's date and generate JTAG metadata. The direct module commands preserve the source metadata. Byte-identical RBF output across machines is not guaranteed.

## Timing and hardware validation

Run fresh TimeQuest analysis on your fitted design. At minimum inspect setup, hold, recovery, removal and minimum pulse width at the Slow and Fast 1100 mV models at -40, 0, 85 and 100 °C. Examine unconstrained/ignored paths, clocks, clock-domain crossings and intentional cuts; do not treat a successful process exit or a positive worst slack alone as complete qualification. Preserve the source, tool version, settings and exact RBF hash with the result.

The published build's numerical timing outcome, when available, is recorded in `BUILD_INFO.json`. The private evidence collector and full review workflow are not shipped here; these instructions do not claim to reproduce that exact automated audit. Changes or a rebuilt binary require their own review and hardware tests.

## Tests

The `source/tests/` files are selected fixtures, not a complete runnable regression suite. Some fixtures require separate harnesses or models which are not bundled. The included Python helpers test integrity and assist compilation; they are not gameplay simulations. Do not infer regression success merely from the presence of test files.

Test save/restore and rewind in different games and busy scenes, SD persistence, video/audio continuity, controller controls, reset, game switching and the known reload behavior. Use separate save copies.
