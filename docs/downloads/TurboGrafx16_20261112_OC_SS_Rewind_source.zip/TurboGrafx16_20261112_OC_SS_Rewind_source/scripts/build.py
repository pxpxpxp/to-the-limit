#!/usr/bin/env python3
"""Compile a new copy with direct Quartus modules; this is not timing approval."""
import json, shutil, subprocess, sys
from pathlib import Path
from verify import ROOT, verify_source, digest
if len(sys.argv)!=2: raise SystemExit('Usage: build.py NEW_BUILD_DIRECTORY')
dst=Path(sys.argv[1]).resolve()
if dst.exists(): raise SystemExit('Refusing existing destination: '+str(dst))
verify_source(ROOT/'source')
for tool in ('quartus_map','quartus_fit','quartus_asm'):
    if not shutil.which(tool): raise SystemExit('Missing tool on PATH: '+tool)
dst.mkdir(parents=True)
manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
for name in manifest:
    target=dst/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/'source'/name,target)
for stage in ('map','fit','asm'):
    verify_source(dst)
    cmd=['quartus_'+stage,'--read_settings_files=on','--write_settings_files=off','TurboGrafx16','-c','TurboGrafx16']
    print('Running:', ' '.join(cmd),flush=True)
    with (dst/('build_'+stage+'.log')).open('w') as log:
        result=subprocess.run(cmd,cwd=dst,stdout=log,stderr=subprocess.STDOUT)
    verify_source(dst)
    if result.returncode: raise SystemExit(f'{stage} failed: inspect build_{stage}.log')
rbf=dst/'output_files/TurboGrafx16.rbf'
print('RBF:',rbf,'\nSHA256:',digest(rbf))
print('Compile complete. Fresh timing review and hardware testing are still required.')
