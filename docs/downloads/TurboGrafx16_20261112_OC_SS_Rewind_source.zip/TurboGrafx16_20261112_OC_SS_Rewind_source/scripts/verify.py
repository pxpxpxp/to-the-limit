#!/usr/bin/env python3
"""Verify the extracted source package, or a build copy's frozen source files."""
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def verify_source(root):
    m=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
    for name, expected in m.items():
        p=root/name
        if not p.is_file() or p.is_symlink() or digest(p)!=expected:
            raise SystemExit('Source missing or changed: '+name)
    print(f'PASS: {len(m)} frozen source files')
if __name__=='__main__':
    if len(sys.argv)>2: raise SystemExit('Usage: verify.py [build-source-directory]')
    if len(sys.argv)==2: verify_source(Path(sys.argv[1])); sys.exit(0)
    m=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text())
    for name, expected in m.items():
        p=ROOT/name
        if not p.is_file() or p.is_symlink() or digest(p)!=expected:
            raise SystemExit('Package missing or changed: '+name)
    verify_source(ROOT/'source')
    print(f'PASS: {len(m)} package members')
