# Limitations and save safety

Supported HuCard save states and rewind are the scope of this build. **CD save states and CD rewind are not supported.** SuperGrafx, Populous and other unsupported snapshot profiles are not qualified by this package. Do not alter MiSTer Main for this build.

The predecessor MainMenu binary received positive owner hardware feedback. This separately compiled version-label successor must be tested on hardware independently. Passing a bounded global timing screen is not full-system, CDC, external-I/O, mode-switch or all-game qualification.

After a core reload, select the ROM again through **Load TurboGrafx** before using save states. Retained game memory is not proof that the new core has valid ROM-load metadata. This known issue is under investigation by THE OWNER.

Back up battery saves and state files. Restoring an earlier snapshot can restore older BRAM contents; a later backup-RAM save or autosave may write that older progress to SD. Keep important progress separate while testing. Rewind history is temporary and does not survive reloading/powering off.

Analog video may flash during restoration. Audio crossings, mute/unmute coherence, metastability, reset behavior, shared-memory contention and absolute capture invisibility are not comprehensively proven. Test the HDMI/analog paths and settings you use.

The archive excludes RBFs, ROMs/BIOS, captured game data, screenshots, fitted databases, caches, raw private reports and proprietary tools. License notices and upstream credits remain authoritative; credited contributors do not endorse this derivative.
