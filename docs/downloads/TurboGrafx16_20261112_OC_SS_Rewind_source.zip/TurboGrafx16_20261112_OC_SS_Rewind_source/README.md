# TurboGrafx16 OC, SS and Rewind

Matching source for `TurboGrafx16_20261112_OC_SS_Rewind.rbf`, an independent To the Limit derivative of the MiSTer TurboGrafx16 core.

- **OC:** CPU overclock controls.
- **SS:** four save-state slots and SD persistence for supported HuCards.
- **Rewind:** a temporary RAM history with capture-pace controls.
- About-screen version: **TGFX16 v261112 OC SS Rewind**.

This revision changes only the About version label and build-date metadata from the preceding MainMenu build. Game logic, save-state behavior, menu layout, timing constraints and fitter seed are unchanged. The prior MainMenu binary was reported working by THE OWNER on MiSTer. That report is not a hardware test of this separately compiled binary and does not establish universal game compatibility.

## Contents

`source/` contains all 203 frozen project/source files, including selected test fixtures, in their original relative paths. `SOURCE_MANIFEST.json` records their SHA-256 hashes. `BUILD_INFO.json` identifies the separately distributed RBF. `PACKAGE_MANIFEST.json` hashes every other archive member.

Start with [BUILD.md](BUILD.md) for the toolchain and repeatable compile commands, [LIMITATIONS.md](LIMITATIONS.md) for test scope and save safety, and [CREDITS.md](CREDITS.md) for attribution. Original licenses and file-level notices are preserved.

## Known reload issue

A core reload may reopen the game from retained memory while save states and rewind are unavailable. Select the HuCard again through **Load TurboGrafx**. THE OWNER is investigating this issue. This version-label update does not fix it.

## Upstream relationship

Base: [MiSTer-devel/TurboGrafx16_MiSTer, 827d45f45799b8ab3a536510847f2108a92e81bd](https://github.com/MiSTer-devel/TurboGrafx16_MiSTer/tree/827d45f45799b8ab3a536510847f2108a92e81bd).

Local extensions include HuCard save/restore serialization, state eligibility and identity checks, rewind-history control and background capture integration, CPU Turbo controls and associated video handling. Shared MiSTer framework files also contain integration changes. This source package is not an official upstream release or a minimal rewind-only patch. Stock MiSTer Main remains unchanged.
